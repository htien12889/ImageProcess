<?php
echo chr(0xEF).chr(0xBB).chr(0xBF);
header('Content-Type: text/html; charset=utf-8');
include_once("simplehtmldom_1_5/simple_html_dom.php");

$k = 0;
$list = array(
		"content$&!question1$&!question2$&!question3$&!question4$&!answer"
);
$csv_content = "";
$n = 1;
while ( $n <= 10) {
	if($n < 10){
		$html = file_get_html('http://www.mlcjapanese.co.jp/JLPTPage/KajiQuizN1-0'.$n.'.html');
	}
	else{
		$html = file_get_html('http://www.mlcjapanese.co.jp/JLPTPage/KajiQuizN1-'.$n.'.html');
	}
	foreach($html->find("form table") as $elements){
		$values = $elements->find("tr td")[1];
		$values = explode("<br>", $values);
		$values_str_content = str_replace('<td bgcolor="#dddddd" width="700" style="border:solid 1px #000000">', '', $values[0]);
		$values_str_content = str_replace('<font color="#ff0000">', '<highlight>', $values_str_content);
		$values_str_content = str_replace('</font>', '</highlight>', $values_str_content);
		$values[1] = str_replace('</td>', '', $values[1]);
		$values_content[] = $values_str_content;
		$values_question_choice = $values[1];
		for($i=0;$i<4;$i++){
			$j = $i + 1;
			//var_dump('<input type="radio" value="'.$j.'" name="'.'q'.$i.'">');die();
			$values_question_choice = str_replace('<input type="radio" value="'.$j.'" name="'.'q'.$k.'">', '$%^&', $values_question_choice);
		}
		$values_question_choice = explode('$%^&', $values_question_choice);
		unset($values_question_choice[0]);
		$values_question_choice_array[] = $values_question_choice;
		$k++;
	}
	//var_dump($values_question_choice_array);
	foreach ($html->find("head script") as $javascript) {
		$answer = "";
		$javascript = str_replace('<script language="JavaScript">', '', $javascript);
		$javascript = str_replace('</script>', '', $javascript);
		$javascript = str_replace('</script>', '', $javascript);
		for($i=0;$i<10;$i++){
			for($j=0;$j<4;$j++){
				if (strpos($javascript,"document.quiz.q".$i."[".$j."].checked") !== false){
					if($i == 9){
						$answer .= $j;
					}else{
						$answer .= $j.",";
					}
				}
			}
		}
	}
	$answer_array = explode(",", $answer);
	for($i=0;$i<10;$i++){
		$csv_content = $values_content[$i]."$&!".$values_question_choice_array[$i][1]."$&!".$values_question_choice_array[$i][2]."$&!".$values_question_choice_array[$i][3]."$&!".$values_question_choice_array[$i][4]."$&!".$answer_array[$i];
		array_push($list, $csv_content);
	}
	$n++;
}
$file = fopen("n1".".csv","w");
fprintf($file, chr(0xEF).chr(0xBB).chr(0xBF));
foreach ($list as $line)
{
	fputcsv($file,explode('$&!',$line));
}

fclose($file);	
echo "<h1>successfully</h1>";
// echo "<pre>";
// print_r($list);
// echo "</pre>";