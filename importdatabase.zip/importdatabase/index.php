<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "jptest";

// Create connection
//$conn = new mysqli($servername, $username, $password, $dbname);
$conn->set_charset("utf8");
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo chr(0xEF).chr(0xBB).chr(0xBF);
header('Content-Type: text/html; charset=utf-8');
$file = fopen("n1.csv","r");
$i = 0;
while(! feof($file))
{
	$file_arr = fgetcsv($file);
	if($i == 0){
		$i++;
		continue;
	}
	$content = $file_arr[0];
	$question1 = $file_arr[1];
	$question2 = $file_arr[2];
	$question3 = $file_arr[3];
	$question4 = $file_arr[4];
	$answer = $file_arr[5];
	$query = "insert into test_table (test_topic_id, content, question1, question2, question3, question4, answer) values ('5', '$content', '$question1','$question2','$question3','$question4','$answer')";
	if ($conn->query($query) === TRUE) {
		echo "New record created successfully";
	} else {
		echo "Error: " . $query . "<br>" . $conn->error;
	}
}
$conn->close();
fclose($file);
?>