package com.example.macpro.jlpt.common;

import android.content.Context;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import java.util.List;

/**
 * Created by h_tien on 2017/10/26.
 */

public class ItemButtonAdapter extends ArrayAdapter<ListItem> {
    public List<ListItem> listItem;
    private Context context;
    private HandleClickItemButton handleClick;
    public ItemButtonAdapter(@NonNull Context context, @LayoutRes int resource, @NonNull List<ListItem> objects) {
        super(context, resource, objects);
        this.context = context;
        this.listItem = objects;
    }
    @Override
    public View getView(final int position, View convertView, ViewGroup parent){
        ItemButton view = new ItemButton(this.context);
        view.updateView(this.listItem.get(position));
        view.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                handleClick.setOnclick(position);
            }
        });
        return view;
    }
    public void setHandleClick(HandleClickItemButton handleClick){
        this.handleClick = handleClick;
    }
}
