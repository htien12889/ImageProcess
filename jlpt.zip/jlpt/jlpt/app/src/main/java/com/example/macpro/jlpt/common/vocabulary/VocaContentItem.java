package com.example.macpro.jlpt.common.vocabulary;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.macpro.jlpt.R;

/**
 * Created by h_tien on 2017/10/31.
 */

public class VocaContentItem extends LinearLayout {
    private TextView janapeseText;
    private TextView meanText;
    public VocaContentItem(Context context){
        super(context);
        LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (inflater != null){
            inflater.inflate(R.layout.voca_content_item, this);
            janapeseText = (TextView) findViewById(R.id.japanese);
            meanText = (TextView) findViewById(R.id.mean);
        }
    }
    public VocaContentItem(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }
    public void setTextViews(Vocabulary vocabulary){
        janapeseText.setText(vocabulary.japanese);
        meanText.setText(vocabulary.mean);
    }
}
