package com.example.macpro.jlpt.common.kanji;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.macpro.jlpt.common.DataBaseHelper;
import com.example.macpro.jlpt.common.ListItem;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Created by h_tien on 2017/10/30.
 */

public class KanjiModel {
    protected static final String TAG = "DataAdapter";

    private final Context mContext;
    private SQLiteDatabase mDb;
    private DataBaseHelper mDbHelper;

    public KanjiModel(Context context)
    {
        this.mContext = context;
        mDbHelper = new DataBaseHelper(mContext);
    }

    public KanjiModel createDatabase() throws SQLException
    {
        try
        {
            mDbHelper.createDataBase();
        }
        catch (IOException mIOException)
        {
            Log.e(TAG, mIOException.toString() + "  UnableToCreateDatabase");
            throw new Error("UnableToCreateDatabase");
        }
        return this;
    }

    public KanjiModel open() throws SQLException
    {
        mDbHelper.openDataBase();
        mDbHelper.close();
        mDb = mDbHelper.getReadableDatabase();
        return this;
    }

    public void close()
    {
        mDbHelper.close();
    }

    public Cursor getKanjiData()
    {
        String sql ="SELECT * FROM lesson where cat_id=2";

        Cursor mCur = mDb.rawQuery(sql, null);
        if (mCur!=null)
        {
            mCur.moveToNext();
        }
        return mCur;
    }
    public ArrayList<ListItem> getDatas(int jlpt){
        ArrayList<ListItem> listItem = new ArrayList<ListItem>();
        String sql ="SELECT * FROM category where id=" + jlpt;
        Cursor mCur = mDb.rawQuery(sql, null);
        if (mCur!=null)
        {
            int sum = 1;
            if (mCur.moveToFirst()){
                while(!mCur.isAfterLast()){
                    sum = mCur.getInt(mCur.getColumnIndex("number_page_kanji"));
                    mCur.moveToNext();
                }
            }
            for(int i = 0; i < sum; i++) {
                listItem.add(new ListItem("" + (i + 1), "Bài " + (i + 1), "" + i));
            }
            mCur.close();
        }
        return listItem;
    }
    public String getContent(String id){
        String content = "";
        String sql = "SELECT content FROM lesson where id=" + id;
        Cursor mCur = mDb.rawQuery(sql, null);
        if (mCur!=null)
        {
            if (mCur.moveToFirst()){
                while(!mCur.isAfterLast()){
                    content = mCur.getString(mCur.getColumnIndex("content"));
                    mCur.moveToNext();
                }
            }
            mCur.close();
        }
        return content;
    }
}
