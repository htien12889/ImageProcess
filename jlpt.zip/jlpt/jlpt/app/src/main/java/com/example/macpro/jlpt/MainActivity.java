package com.example.macpro.jlpt;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void panMenu(View view){
        Intent intent = new Intent(MainActivity.this, ContentActivity.class);
        Button bt = (Button) view;
        Bundle bd = new Bundle();
        if (bt.getId() == (R.id.n1)){
            bd.putInt("id", 39);
        } else if (bt.getId() == (R.id.n2)) {
            bd.putInt("id", 38);
        } else if (bt.getId() == (R.id.n3)) {
            bd.putInt("id", 40);
        } else if (bt.getId() == (R.id.n4)) {
            bd.putInt("id", 41);
        } else if (bt.getId() == (R.id.n5)) {
            bd.putInt("id", 42);
        }
        intent.putExtras(bd);
        startActivity(intent);
        finish();
    }
}
