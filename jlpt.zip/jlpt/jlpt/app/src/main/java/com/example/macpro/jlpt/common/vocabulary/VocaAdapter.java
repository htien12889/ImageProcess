package com.example.macpro.jlpt.common.vocabulary;

import android.content.Context;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import com.example.macpro.jlpt.common.HandleClickItemButton;

import java.util.List;

/**
 * Created by h_tien on 2017/10/31.
 */

public class VocaAdapter extends ArrayAdapter<Vocabulary> {
    public List<Vocabulary> vocabulary;
    private Context context;
    private HandleClickItemButton handleClick;
    public VocaAdapter(@NonNull Context context, @LayoutRes int resource, @NonNull List<Vocabulary> objects) {
        super(context, resource, objects);
        this.context = context;
        this.vocabulary = objects;
    }
    @Override
    public View getView(final int position, View convertView, ViewGroup parent){
        VocaContentItem view = new VocaContentItem(this.context);
        view.setTextViews(this.vocabulary.get(position));
        view.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                handleClick.setOnclick(position);
            }
        });
        return view;
    }
    public void setupHandleClick(HandleClickItemButton handleClick){
        this.handleClick = handleClick;
    }
}
