package com.example.macpro.jlpt.common;

/**
 * Created by h_tien on 2017/10/26.
 */

public class ListItem {
    public String number;
    public String title;
    public String id;
    public ListItem(String number, String title, String id){
        this.number = number;
        this.title = title;
        this.id = id;
    }
}
