package com.example.macpro.jlpt.common.vocabulary;

/**
 * Created by h_tien on 2017/10/31.
 */

public class Vocabulary {
    public String japanese;
    public String mean;
    public Vocabulary(String japanese, String mean){
        this.japanese = japanese;
        this.mean = mean;
    }
}
