package com.example.macpro.jlpt.common;

/**
 * Created by h_tien on 2017/10/26.
 */

public interface HandleClickItemButton {
    void setOnclick(int position);
}
