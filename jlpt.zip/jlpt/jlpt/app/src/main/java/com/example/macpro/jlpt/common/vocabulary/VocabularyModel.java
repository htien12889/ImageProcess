package com.example.macpro.jlpt.common.vocabulary;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.widget.ArrayAdapter;

import com.example.macpro.jlpt.common.DataBaseHelper;
import com.example.macpro.jlpt.common.ListItem;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Created by h_tien on 2017/10/30.
 */

public class VocabularyModel {
    protected static final String TAG = "DataAdapter";

    private final Context mContext;
    private SQLiteDatabase mDb;
    private DataBaseHelper mDbHelper;

    public VocabularyModel(Context context)
    {
        this.mContext = context;
        mDbHelper = new DataBaseHelper(mContext);
    }

    public VocabularyModel createDatabase() throws SQLException
    {
        try
        {
            mDbHelper.createDataBase();
        }
        catch (IOException mIOException)
        {
            Log.e(TAG, mIOException.toString() + "  UnableToCreateDatabase");
            throw new Error("UnableToCreateDatabase");
        }
        return this;
    }

    public VocabularyModel open() throws SQLException
    {
        mDbHelper.openDataBase();
        mDbHelper.close();
        mDb = mDbHelper.getReadableDatabase();
        return this;
    }

    public void close()
    {
        mDbHelper.close();
    }

    public Cursor getVocabularyData()
    {
        String sql ="SELECT * FROM lesson where cat_id=2";

        Cursor mCur = mDb.rawQuery(sql, null);
        if (mCur!=null)
        {
            mCur.moveToNext();
        }
        return mCur;
    }
    public ArrayList<ListItem> getDatas(int jlpt){
        ArrayList<ListItem> listItem = new ArrayList<ListItem>();
        String sql ="SELECT * FROM category where id=" + jlpt;
        Cursor mCur = mDb.rawQuery(sql, null);
        if (mCur!=null)
        {
            int sum = 1;
            if (mCur.moveToFirst()){
                while(!mCur.isAfterLast()){
                    sum = mCur.getInt(mCur.getColumnIndex("number_page_voca"));
                    mCur.moveToNext();
                }
            }
            for(int i = 0; i < sum; i++) {
                listItem.add(new ListItem("" + (i + 1), "Bài " + (i + 1), "" + i));
            }
            mCur.close();
        }
        return listItem;
    }
    public ArrayList<Vocabulary> getVocabularyContent(int jlpt, String page){
        ArrayList<Vocabulary> vocaburayContents = new ArrayList<Vocabulary>();
        String sql ="SELECT * FROM vocabulary where parent_id=" + jlpt + " and page=" + page;
        Cursor mCur = mDb.rawQuery(sql, null);
        if (mCur!=null)
        {
            if (mCur.moveToFirst()){
                while(!mCur.isAfterLast()){
                    String word = mCur.getString(mCur.getColumnIndex("word")) + "(" + mCur.getString(mCur.getColumnIndex("phonetic")) + ")";
                    String mean = mCur.getString(mCur.getColumnIndex("mean"));
                    mCur.moveToNext();
                    vocaburayContents.add(new Vocabulary(word, mean));
                }
            }
            mCur.close();
        }
        return vocaburayContents;
    }
    public String getContent(String id){
        String content = "";
        String sql = "SELECT content FROM lesson where id=" + id;
        Cursor mCur = mDb.rawQuery(sql, null);
        if (mCur!=null)
        {
            if (mCur.moveToFirst()){
                while(!mCur.isAfterLast()){
                    content = mCur.getString(mCur.getColumnIndex("content"));
                    mCur.moveToNext();
                }
            }
            mCur.close();
        }
        return content;
    }
}
