package com.example.macpro.jlpt;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import com.example.macpro.jlpt.common.HandleClickItemButton;
import com.example.macpro.jlpt.common.ItemButtonAdapter;
import com.example.macpro.jlpt.common.ListItem;
import com.example.macpro.jlpt.common.grammar.GrammarModel;
import com.example.macpro.jlpt.common.kanji.KanjiModel;
import com.example.macpro.jlpt.common.vocabulary.VocaAdapter;
import com.example.macpro.jlpt.common.vocabulary.VocaContentItem;
import com.example.macpro.jlpt.common.vocabulary.Vocabulary;
import com.example.macpro.jlpt.common.vocabulary.VocabularyModel;

import java.sql.SQLException;
import java.util.ArrayList;

public class ContentActivity extends AppCompatActivity {
    private static int VOCA_CONTENT = 1;
    private static int GRAMMAR_CONTENT = 2;
    private static int KANJI_CONTENT = 3;
    ArrayList<ListItem> listItem = new ArrayList<ListItem>();
    LinearLayout contentViews = null;
    Button grammarBtn = null;
    Button vocaBtn = null;
    Button kanjiBtn = null;
    Button header = null;
    ListView layout = null;
    ArrayList<Vocabulary> vocaContentList = new ArrayList<Vocabulary>();
    int value = -1; // or other values
    int jlpt = -1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_activity_content);
        contentViews = (LinearLayout) findViewById(R.id.layout_content);
        layout = (ListView)findViewById(R.id.list_view_content);
        grammarBtn = (Button) findViewById(R.id.nguphap_button);
        vocaBtn = (Button) findViewById(R.id.tuvung_button);
        kanjiBtn = (Button) findViewById(R.id.kanji_button);
        header = (Button) findViewById(R.id.header);
        Bundle b = getIntent().getExtras();
        if(b != null){
            if (b.getInt("id") == 39){
                jlpt = 2;
                value = 5;
            } else if (b.getInt("id") == 38) {
                jlpt = 1;
                value = 6;
            } else if (b.getInt("id") == 40) {
                jlpt = 3;
                value = 4;
            } else if (b.getInt("id") == 41) {
                jlpt = 4;
                value = 2;
            } else if (b.getInt("id") == 42) {
                jlpt = 5;
                value = 3;
            } else {
                jlpt = 4;
                value = 2;
            }
        }
        createGrammar();
        grammarBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                header.setText("Ngữ Pháp");
                resetAll();
                grammarBtn.setBackgroundResource(R.color.clickColor);
                layout.setAdapter(null);
                //layout.removeAllViews();
                createGrammar();
                contentViews.addView(layout);
            }
        });
        vocaBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                header.setText("Từ Vựng");
                resetAll();
                vocaBtn.setBackgroundResource(R.color.clickColor);
                layout.setAdapter(null);
                createVoca();
                contentViews.addView(layout);
            }
        });
        kanjiBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                header.setText("Kanji");
                resetAll();
                kanjiBtn.setBackgroundResource(R.color.clickColor);
                layout.setAdapter(null);
                createKanji();
                contentViews.addView(layout);
            }
        });

    }
    public void resetAll(){
        vocaBtn.setBackgroundResource(R.color.blue);
        kanjiBtn.setBackgroundResource(R.color.blue);
        grammarBtn.setBackgroundResource(R.color.blue);
        contentViews.removeAllViews();
        listItem.clear();
    }
    void createKanji(){
        KanjiModel kanji = createKanjiModel();
        listItem = kanji.getDatas(jlpt);
        kanji.close();
        setupListView(KANJI_CONTENT);
    }
    void createVoca(){
        VocabularyModel vocabulary = createVocabularyModel();
        listItem = vocabulary.getDatas(jlpt);
        vocabulary.close();
        setupListView(VOCA_CONTENT);
    }
    void createGrammar() {
        GrammarModel grammar = createGrammarModel();
        listItem = grammar.getDatas(value);
        grammar.close();
        setupListView(GRAMMAR_CONTENT);
    }
    void setupListView(final int type){
        ItemButtonAdapter itemButtonAdapter = new ItemButtonAdapter(this, layout.getId(), listItem);
        layout.setAdapter(itemButtonAdapter);
        itemButtonAdapter.setHandleClick(new HandleClickItemButton() {
            @Override
            public void setOnclick(int position) {
                Context context = getApplicationContext();
                CharSequence text = "Click the " + listItem.get(position).id;
                int duration = Toast.LENGTH_SHORT;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                contentViews.removeAllViews();
                if (type == GRAMMAR_CONTENT) {
                    createGrammarContent(listItem.get(position).id);
                } else if (type == VOCA_CONTENT) {
                    createVocaContent(jlpt, listItem.get(position).id);
                } else if (type == KANJI_CONTENT) {

                }
            }
        });
    }
    void createVocaContent(int jlptType, String id) {
        View item = LayoutInflater.from(this).inflate(R.layout.voca_content_layout, null);
        Button tuvungBtn = (Button) item.findViewById(R.id.first);
        Button flashCardBtn = (Button) item.findViewById(R.id.second);
        Button kiemTraBtn = (Button) item.findViewById(R.id.third);
        ListView content = (ListView) item.findViewById(R.id.vocabulary_content);
        content.setAdapter(null);
        VocabularyModel vocabularyModel = createVocabularyModel();
        vocaContentList.clear();
        vocaContentList = vocabularyModel.getVocabularyContent(jlptType, id);
        vocabularyModel.close();
        VocaAdapter vocaAdapter = new VocaAdapter(this, content.getId(), vocaContentList);
        content.setAdapter(vocaAdapter);
        contentViews.addView(item);
    }
    void createGrammarContent(String id) {
        View item = LayoutInflater.from(this).inflate(R.layout.grammar_content, null);
        WebView webView = (WebView) item.findViewById(R.id.grammar_content);
        GrammarModel grammar = createGrammarModel();
        String content = grammar.getContent(id);
        grammar.close();
        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadDataWithBaseURL("", content, "text/html", "UTF-8", "");
        contentViews.addView(item);
    }
    GrammarModel createGrammarModel(){
        GrammarModel grammar = new GrammarModel(this);
        try {
            grammar.createDatabase();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            grammar.open();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return  grammar;
    }
    VocabularyModel createVocabularyModel(){
        VocabularyModel vocabulary = new VocabularyModel(this);
        try {
            vocabulary.createDatabase();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            vocabulary.open();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return  vocabulary;
    }
    KanjiModel createKanjiModel(){
        KanjiModel kanji = new KanjiModel(this);
        try {
            kanji.createDatabase();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            kanji.open();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return  kanji;
    }
}
