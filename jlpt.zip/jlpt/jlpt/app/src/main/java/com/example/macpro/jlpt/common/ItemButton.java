package com.example.macpro.jlpt.common;

import android.content.ClipData;
import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.macpro.jlpt.R;

/**
 * Created by h_tien on 2017/10/25.
 */

public class ItemButton extends LinearLayout {
    private TextView number = null;
    private TextView title = null;
    public ItemButton(Context context){
        super(context);
        LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if(inflater != null){
            inflater.inflate(R.layout.item_button, this);
            this.number = (TextView) findViewById(R.id.number);
            this.title = (TextView) findViewById(R.id.title);
        }
    }
    public ItemButton(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if(inflater != null){
            inflater.inflate(R.layout.item_button, this);
            this.number = (TextView) findViewById(R.id.number);
            this.title = (TextView) findViewById(R.id.title);
        }
    }
    public ItemButton(Context context, AttributeSet attrs, String number, String title){
        super(context, attrs);
        LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if(inflater != null){
            inflater.inflate(R.layout.item_button, this);
            this.number = (TextView) findViewById(R.id.number);
            this.title = (TextView) findViewById(R.id.title);
        }
    }
    public void updateView(ListItem listItem){
        this.number.setText(listItem.number);
        this.title.setText(listItem.title);
    }
}
