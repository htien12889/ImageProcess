/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  View, TouchableOpacity, Image, Text, ScrollView
} from 'react-native';
import Header from './commons/main/commons/Header.js';
import {
  WIDTH_ITEM_TOPIC, WIDTH_ITEM_GAME, HEIGHT_ITEM_TOPIC,
  HEIGHT_ITEM_GAME, WIDTH_ITEM_SILE_TOPIC, WIDTH_ITEM_SILE_GAME,
  RADIUS_TOPIC, RADIUS_GAME, db1, GAME_LIST
} from './commons/Constant.js';
import styles from './commons/styles.js';
import Game from './commons/home/Game.js';
export default class Result extends Component<Props> {
	constructor(props) {
		super(props);
		this.gameType = this.props.gameType + 1;
		console.log(this.gameType);
		this.state = {
			datas: this.props.datas,
		}
	}
	render() {
		return(
			<View style={{flex: 1, backgroundColor: '#4fc1e9'}}>
				<Header title={this.props.mainTitle} background={'#4fc1e9'}/>
				<View style={styless.subHeader}>
					<Text style={styless.subHeaderTest}>{this.props.title}</Text>
				</View>
				<ScrollView style={styless.scrollView}>
					{this.state.datas.map((prop, key) => {
			          //console.log(prop);
						var favorit_image = require("./assets/favorit_true.png");
						if(prop.is_love) {
						  favorit_image = require("./assets/favorit_true.png");
						} else {
						  favorit_image = require("./assets/favorit_false.png");
						}
						return (
							<View key={key} style={styless.scrollViewContent}>
								<View style={styless.scrollViewContentText}>
									<Image style={{resizeMode: 'contain', width: 50, height: 50, borderRadius: 5, backgroundColor: '#ffffff' }} source={{ uri: "http://data.minder.vn/Japanese/104000002/images/words/104000632.jpg" }} />
									<View>
										<Text style={styless.scrollViewContentTextContent}>{prop.en_us.charAt(0).toUpperCase() + prop.en_us.slice(1)}</Text>
										<Text style={styless.scrollViewContentTextContentRe}>[{prop.en_us_pr}]</Text>
									</View>
								</View>
								<View style={{justifyContent: 'center'}}>
									<TouchableOpacity onPress={() => {this.updateLove(prop, key)}} style={styless.scrollViewContentImage}>
										<Image style={styless.favoriteContent} source={favorit_image} />
									</TouchableOpacity>
								</View>
								
							</View>
						);
			        })}

				</ScrollView>
				<Game
					style={{flex: 1}}
		            widthItem={WIDTH_ITEM_GAME}
		            heightItem={HEIGHT_ITEM_GAME}
		            widthItemSlide={WIDTH_ITEM_SILE_GAME}
		            radius={RADIUS_GAME}
		            slideDatas={GAME_LIST}
		            firstItem={this.gameType}
		            updateData={(value) => {this.updateGameType(value)}}/>
		        <View style={styles.bottomViewHome}>
					<TouchableOpacity style={styles.bottomButtonViewHome} onPress={() => {this.playGame()}}>
						<Image style={styles.bottomImageViewHome} source={require("./assets/play.png")} />
					</TouchableOpacity>
				</View>
			</View>
		);
	}
	resetResult(value) {
		this.setState({
			datas: value,
		});
	}
	updateGameType(value){
		this.gameType = value;
	}
	updateLove(value, index){
		//console.log("hello abcdef");
	    var dataTemp = this.state.datas;
	    var isFavorite = value.is_love;
	    var idItem = value.id;
	    if(isFavorite) {
	      dataTemp[index].is_love = !dataTemp[index].is_love;
	      let sql = "DELETE FROM `folder` WHERE vocabulary_id="+idItem;
	      console.log(sql);
	      db1.transaction((tx) => {
	        tx.executeSql(sql, [], (tx, results) => {
	          this.setState({
	            datas: dataTemp,
	          });
	        });
	      });
	    } else {
	      dataTemp[index].is_love = !dataTemp[index].is_love;
	      let sql = "INSERT INTO folder (`vocabulary_id`) VALUES ('"+idItem+"')";
	      console.log(sql);
	      db1.transaction((tx) => {
	        tx.executeSql(sql, [], (tx, results) => {
	          this.setState({
	            datas: dataTemp,
	          });
	        });
	      });
	    }
	}
	playGame(){
		this.props.reloadMain(this.gameType);
	}
}

const styless = StyleSheet.create({
  subHeader: {
    height: 30,
    justifyContent: 'center',
    backgroundColor: '#3bafda',
  },
  subHeaderTest: {
    fontSize: 20,
    color: 'white',
    textAlign: 'center'
  },
  scrollView: {
  	flex: 3
  },
  scrollViewContent: {
  	flexDirection: 'row',
    padding: 10,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderBottomColor: '#2ea5dd',
    borderTopColor: '#75d2f0',
    backgroundColor: '#4fc1e9',
  },
  scrollViewContentText: {
  	flex: 1,
  	flexDirection: 'row',
  },
  scrollViewContentTextContent: {
  	fontSize: 20,
  	color: 'white',
  	marginLeft: 10,
  	fontWeight: 'bold',
  },
  scrollViewContentTextContentRe: {
  	fontSize: 15,
  	color: 'white',
  	marginLeft: 10,
  },
  scrollViewContentImage: {
  	width: 25,
  	height: 25,
  	justifyContent: 'center',
  },
  favoriteContent: {
  	width: 25,
  	height: 25,
  },
});