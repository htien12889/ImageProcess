/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  View, TouchableOpacity, Image
} from 'react-native';

export default class Main extends Component<Props> {
	constructor(props) {
		super(props);
	}
	render() {
		return(
			<View></View>
		);
	}
}
