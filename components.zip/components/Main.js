/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  View, TouchableOpacity, Image
} from 'react-native';
import Vocabulary from './commons/main/Vocabulary/Vocabulary.js';
import ChooseImage from './commons/main/ChooseImage/ChooseImage.js';
import {db} from './commons/Constant.js';
export default class Main extends Component<Props> {
	constructor(props) {
		super(props);
    this.gameType = this.props.navigation.state.params.gameType;
    this.topicID = this.props.navigation.state.params.topicID;
    this.state = {
      datas: [],
      datasForCheck: [],
      numberData: 0,
    }
    this.getDatas();
	}
	render() {
    if(this.state.datas.length == 0) {
      return(
        <View></View>
      );
    } else {
      if(this.gameType == 1) {
        return(
          <View style={{flex: 1}}>
            <Vocabulary
              datas={this.state.datas}
              gameType={this.gameType}
              topicID={this.topicID}/>
          </View>
        );
      } else if(this.gameType == 2) {
        return(
          <View style={{flex: 1}}>
            <ChooseImage
              datas={this.state.datasForCheck}
              numberDatas={this.state.numberData}
              gameType={this.gameType}
              topicID={this.topicID}/>
          </View>
        );
      } 
    }

	}

  getDatas(){
    db.transaction((tx) => {
      tx.executeSql("SELECT * FROM voc_cat WHERE cat_id=" + this.topicID, [], (tx, results) => {
        var array = [];
        var len = results.rows.length;
        let j = 0;
        var ids = "";
        for (let i = 0; i < len; i++) {
          if(i < len - 1) {
            ids = ids + results.rows.item(i).voc_id + ",";
          } else {
            ids = ids + results.rows.item(i).voc_id;
          }
        }
        db.transaction((tx) => {
          tx.executeSql("SELECT * FROM vocabularies WHERE id in ("+ ids +")", [], (tx, results) => {
            var len1 = results.rows.length;
            var tempIds = [];
            var arrayIndex = 0;
            var vocabularyDatas = [];
            for (let i = 0; i < len1; i++) {
              array[i] = {
                id: results.rows.item(i).id,
                thumbnail: "http://vnsupa.com/hoangtien/images/" + results.rows.item(i).image,
                en_us: results.rows.item(i).en_us,
                en_us_type: results.rows.item(i).en_us_type,
                en_us_pr: results.rows.item(i).en_us_pr,
                en_us_audio: "http://data.minder.vn/Japanese/104000002/audios/104000632.mp3",
                //en_us_audio: results.rows.item(i).en_us_audio,
                en_us_mean: results.rows.item(i).en_us_mean,
                en_us_ex: results.rows.item(i).en_us_ex,
              }
              vocabularyDatas[i] = {
                id: results.rows.item(i).id,
                thumbnail: "http://vnsupa.com/hoangtien/images/" + results.rows.item(i).image,
                en_us: results.rows.item(i).en_us,
                en_us_type: results.rows.item(i).en_us_type,
                en_us_pr: results.rows.item(i).en_us_pr,
                en_us_audio: "http://data.minder.vn/Japanese/104000002/audios/104000632.mp3",
                //en_us_audio: results.rows.item(i).en_us_audio,
                en_us_mean: results.rows.item(i).en_us_mean,
                en_us_ex: results.rows.item(i).en_us_ex,
              }
              tempIds[i] = results.rows.item(i).id;
              arrayIndex += 1;
            }
            if(array.length < 10) {
              db.transaction((tx) => {
                tx.executeSql("SELECT * FROM vocabularies", [], (tx, results) => {
                  for (let i = 0; i < results.rows.length; i++) {
                    let idItem = results.rows.item(i).id;
                    let checkExits = false;
                    for(let k = 0; k < tempIds.length; k++) {
                      if(idItem == tempIds[k]) {
                        checkExits = true;
                        break;
                      }
                    }
                    if(!checkExits){
                      array[arrayIndex] = {
                        id: results.rows.item(k).id,
                        thumbnail: "http://vnsupa.com/hoangtien/images/" + results.rows.item(k).image,
                        en_us: results.rows.item(k).en_us,
                        en_us_type: results.rows.item(k).en_us_type,
                        en_us_pr: results.rows.item(k).en_us_pr,
                        en_us_audio: "http://data.minder.vn/Japanese/104000002/audios/104000632.mp3",
                        //en_us_audio: results.rows.item(i).en_us_audio,
                        en_us_mean: results.rows.item(k).en_us_mean,
                        en_us_ex: results.rows.item(k).en_us_ex,
                      };
                      tempIds[arrayIndex] = results.rows.item(k).id;
                      if(array.length >= 10) {
                        break;
                      }
                      arrayIndex += 1;
                    } else {
                      continue;
                    }
                  }
                  this.setState({
                    datas: vocabularyDatas,
                    datasForCheck: array,
                    numberData: vocabularyDatas.length,
                  });
                });
              });
            } else {
              this.setState({
                datas: vocabularyDatas,
                datasForCheck: array,
                numberData: vocabularyDatas.length,
              });
            }
            
          });
        });
      });
    });
  }
}
