/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  View, TouchableOpacity, Image
} from 'react-native';
import Vocabulary from './commons/main/Vocabulary/Vocabulary.js';
import ChooseImage from './commons/main/ChooseImage/ChooseImage.js';
import {db} from './commons/Constant.js';
export default class Main extends Component<Props> {
	constructor(props) {
		super(props);
    this.gameType = this.props.navigation.state.params.gameType;
    this.topicID = this.props.navigation.state.params.topicID;
    this.state = {
      datas: [],
    }
    this.getDatas();
	}
	render() {
    if(this.state.datas.length == 0) {
      return(
        <View></View>
      );
    } else {
      return(
        <View style={{flex: 1}}>
          <ChooseImage
            datas={this.state.datas}
            gameType={this.gameType}
            topicID={this.topicID}/>
        </View>

      );
    }

	}

  getDatas(){
    db.transaction((tx) => {
      tx.executeSql("SELECT * FROM voc_cat WHERE cat_id=" + this.topicID, [], (tx, results) => {
        var array = [];
        var len = results.rows.length;
        let j = 0;
        var ids = "";
        for (let i = 0; i < len; i++) {
          if(i < len - 1) {
            ids = ids + results.rows.item(i).voc_id + ",";
          } else {
            ids = ids + results.rows.item(i).voc_id;
          }
        }
        db.transaction((tx) => {
          tx.executeSql("SELECT * FROM vocabularies WHERE id in ("+ ids +")", [], (tx, results) => {
            var len1 = results.rows.length;
            for (let i = 0; i < len1; i++) {
              array[i] = {
                id: results.rows.item(i).id,
                thumbnail: "http://vnsupa.com/hoangtien/images/" + results.rows.item(i).image,
                en_us: results.rows.item(i).en_us,
                en_us_type: results.rows.item(i).en_us_type,
                en_us_pr: results.rows.item(i).en_us_pr,
                en_us_audio: "http://data.minder.vn/Japanese/104000002/audios/104000632.mp3",
                //en_us_audio: results.rows.item(i).en_us_audio,
                en_us_mean: results.rows.item(i).en_us_mean,
                en_us_ex: results.rows.item(i).en_us_ex,
              }
            }
            this.setState({
              datas: array,
            });
          });
        });
      });
    });
  }
}
