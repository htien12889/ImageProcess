/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  View, TouchableOpacity, Image
} from 'react-native';
import Vocabulary from './commons/main/Vocabulary/Vocabulary.js';
import ChooseImage from './commons/main/ChooseImage/ChooseImage.js';
import FlashCardQuiz from './commons/main/FlashCard/FlashCardQuiz.js';
import Header from './commons/main/commons/Header.js';
import {db, db1} from './commons/Constant.js';
export default class Main extends Component<Props> {
	constructor(props) {
		super(props);
    this.gameType = this.props.navigation.state.params.gameType;
    this.topicID = this.props.navigation.state.params.topicID;
    this.state = {
      datas: [],
      datasForCheck: [],
      numberData: 0,
      isUpdate: false,
    }
    this.getDatas();
	}
	render() {
    if(this.state.datas.length == 0) {
      return(
        <View></View>
      );
    } else {
      if(this.gameType == 1) {
        return(
          <View style={{flex: 1}}>
            <Vocabulary
              back={() => {this.back()}}
              datas={this.state.datas}
              gameType={this.gameType}
              topicID={this.topicID}
              reloadMain={(value) => {this.reloadMain(value)}}/>
          </View>
        );
      } else if(this.gameType == 3) {
        return(
          <View style={{flex: 1}}>
            <ChooseImage
              datas={this.state.datasForCheck}
              numberDatas={this.state.numberData}
              gameType={this.gameType}
              topicID={this.topicID}/>
          </View>
        );
      } else if(this.gameType == 2) {
        return(
          <View style={{flex: 1}}>
            <FlashCardQuiz
              vocabularyDatas={this.state.datas} 
              reloadMain={(value) => {this.reloadMain(value)}}/>
          </View>
        );
      }
    }

	}
  back() {
    this.props.navigation.navigate('HomeScreens');
  }
  reloadMain(value) {
    this.gameType = value;
    this.setState({
      isUpdate: !this.isUpdate,
      datas: [],
    });
    this.getDatas();
  }
  getDatas(){
    var sql = "";
    var database = db;
    if(this.topicID == 0) {
      sql = "SELECT * FROM folder";
      database = db1;
    } else {
      sql = "SELECT * FROM voc_cat where cat_id=" + this.topicID;
      database = db;
    }
    database.transaction((tx) => {
      tx.executeSql(sql, [], (tx, results) => {
        var len = results.rows.length;
        var ids = "";
        var favoriteIDs = [];
        for (let i = 0; i < len; i++) {
          if(i < len - 1) {
            ids = ids + results.rows.item(i).voc_id + ",";
          } else {
            ids = ids + results.rows.item(i).voc_id;
          }
        }
        if(this.topicID == 0) {
          this.getDatasForSlide(ids, favoriteIDs, true);
        } else {
          db1.transaction((tx) => {
            tx.executeSql("SELECT * FROM folder", [], (tx, results) => {
              for (let i = 0; i < results.rows.length; i++) {
                favoriteIDs[i] = results.rows.item(i).vocabulary_id;
              }
              this.getDatasForSlide(ids, favoriteIDs, false);
            });
          });
        }
      });
    });
  }
  getDatasForSlide(ids, favoriteIDs, isFavorite) {
    db.transaction((tx) => {
      tx.executeSql("SELECT * FROM vocabularies WHERE id in ("+ ids +")", [], (tx, results) => {
        var len1 = results.rows.length;
        var tempIds = [];
        var arrayIndex = 0;
        var vocabularyDatas = [];
        var array = [];
        for (let i = 0; i < 3; i++) {
          var is_love = false;

          if(!isFavorite) {
            for(let l = 0; l < favoriteIDs.length; l++) {
              if(favoriteIDs[l] == results.rows.item(i).id) {
                is_love = true;
                break;
              }
            }
          } else {
            is_love = true;
          }
          array[i] = {
            id: results.rows.item(i).id,
            thumbnail: "http://vnsupa.com/hoangtien/images/" + results.rows.item(i).image,
            en_us: results.rows.item(i).en_us.charAt(0).toUpperCase() + results.rows.item(i).en_us.slice(1),
            en_us_type: results.rows.item(i).en_us_type,
            en_us_pr: results.rows.item(i).en_us_pr, 
            en_us_audio: "http://data.minder.vn/Japanese/104000002/audios/104000632.mp3",
            //en_us_audio: results.rows.item(i).en_us_audio,
            en_us_mean: results.rows.item(i).en_us_mean,
            en_us_ex: results.rows.item(i).en_us_ex,
            is_love: is_love,
          }
          vocabularyDatas[i] = {
            id: results.rows.item(i).id,
            thumbnail: "http://vnsupa.com/hoangtien/images/" + results.rows.item(i).image,
            en_us: results.rows.item(i).en_us.charAt(0).toUpperCase() + results.rows.item(i).en_us.slice(1),
            en_us_type: results.rows.item(i).en_us_type,
            en_us_pr: results.rows.item(i).en_us_pr,
            en_us_audio: "http://data.minder.vn/Japanese/104000002/audios/104000632.mp3",
            //en_us_audio: results.rows.item(i).en_us_audio,
            en_us_mean: results.rows.item(i).en_us_mean,
            en_us_ex: results.rows.item(i).en_us_ex,
            is_love: is_love,
          }
          tempIds[i] = results.rows.item(i).id;
          arrayIndex += 1;
        }
        if(array.length < 10) {
          db.transaction((tx) => {
            tx.executeSql("SELECT * FROM vocabularies", [], (tx, results) => {
              for (let i = 0; i < results.rows.length; i++) {
                let idItem = results.rows.item(i).id;
                let checkExits = false;
                for(let k = 0; k < tempIds.length; k++) {
                  if(idItem == tempIds[k]) {
                    checkExits = true;
                    break;
                  }
                }

                if(!checkExits){
                  array[arrayIndex] = {
                    id: results.rows.item(i).id,
                    thumbnail: "http://vnsupa.com/hoangtien/images/" + results.rows.item(i).image,
                    en_us: results.rows.item(i).en_us.charAt(0).toUpperCase() + results.rows.item(i).en_us.slice(1),
                    en_us_type: results.rows.item(i).en_us_type,
                    en_us_pr: results.rows.item(i).en_us_pr,
                    en_us_audio: "http://data.minder.vn/Japanese/104000002/audios/104000632.mp3",
                    //en_us_audio: results.rows.item(i).en_us_audio,
                    en_us_mean: results.rows.item(i).en_us_mean,
                    en_us_ex: results.rows.item(i).en_us_ex,
                    is_love: false,
                  };
                  tempIds[arrayIndex] = results.rows.item(i).id;
                  if(array.length >= 10) {
                    break;
                  }
                  arrayIndex += 1;
                } else {
                  continue;
                }

              }

              this.setState({
                datas: vocabularyDatas,
                datasForCheck: array,
                numberData: vocabularyDatas.length,
              });
            });
          });
        } else {
          this.setState({
            datas: vocabularyDatas,
            datasForCheck: array,
            numberData: vocabularyDatas.length,
          });
        }
        
      });
    });
  }
}
