import React, { Component } from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  Image,
  Dimensions
} from 'react-native';
const deviceWidth = Dimensions.get('window').width;
import {
  SLIDE_WIDTH, LAYOUT_TYPE,
  FIRST_ITEM, AUTO_PLAY_DELAY, AUTO_PLAY, ITEM_SUB_VALUE,
  ITEM_PADDING, BACKGROUND_DEFAULT, BACKGROUND_ACTIVE
} from './Constant.js';
import styles from './styles.js';
import Carousel from 'react-native-snap-carousel'; // Version can be specified in package.json

export default class SlideComponent extends Component<Props> {
  constructor(props){
    super();
    this.background = [];
    this.props = props;
    this._carousel = {};
    this.init();
    this.createBackground();
  }

  init(){
    this.state = {
      errors: [],
      firstItem: this.props.firstItem,
      datas: this.props.slideDatas,

    };

    /*this.state = {
      datas: this.props.datas,
    }*/
    console.log("ThumbnailCarousel Props: ", this.props)
  }
  createBackground(){
    for(let i = 0; i < this.state.datas.length; i++) {
      this.background[i] = BACKGROUND_DEFAULT;
    }
    this.background[this.state.firstItem] = BACKGROUND_ACTIVE;
  }
  handleSnapToItem(index){
    this.props.updateData(this.state.datas[index].id, this.state.datas[index].gamePercent);
    this.setState({
      firstItem: index,
    });
  }
  contentRender(array) {
    console.log("hello");
    this.setState({
      datas: array,
      firstItem: 0,
    });
  }
  _renderItem = ( {item, index} ) => {
    return (
        <View style={styles.ThumbnailBackgroundView}>
          <TouchableOpacity
                onPress={ () => {
                  this._carousel.snapToItem(index);
                }}>
            <View>
              <View style={{backgroundColor: this.background[index], width: this.props.widthItem, height: this.props.heightItem, borderRadius: this.props.radius, padding: ITEM_PADDING, borderColor: BACKGROUND_ACTIVE, borderWidth: 1}}>
                <Image style={{resizeMode: 'contain', width: this.props.widthItem - ITEM_SUB_VALUE, height: this.props.heightItem - ITEM_SUB_VALUE, borderRadius: (this.props.widthItem - ITEM_SUB_VALUE) / 2}} source={{ uri: item.thumbnail }} />
              </View>
            </View>
            <Text style={styles.slideText}>{item.title}</Text>
          </TouchableOpacity>
        </View>
    );
  }

  render() {
    this.createBackground();
    return (
      <View style={styles.CarouselBackgroundView} >
        <Carousel
          ref={ (c) => { this._carousel = c; } }
          inactiveSlideOpacity={0.3}
          data={this.state.datas}
          renderItem={this._renderItem.bind(this)}
          onSnapToItem={this.handleSnapToItem.bind(this)}
          sliderWidth={deviceWidth}
          itemWidth={this.props.widthItemSlide}
          layout={LAYOUT_TYPE}
          firstItem={this.state.firstItem}
          autoplayDelay={AUTO_PLAY_DELAY}
          autoplay={AUTO_PLAY}
          enableMomentum={true}
          //useScrollView={true}
        />
      </View>
    );
  }
}
