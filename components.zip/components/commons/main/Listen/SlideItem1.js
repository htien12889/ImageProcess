import React, { Component } from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  Image,
  Dimensions,
  StyleSheet
} from 'react-native';
var Sound = require('react-native-sound');
const deviceWidth = Dimensions.get('window').width;
const deviceHeight = Dimensions.get('window').height;
import {
  SLIDE_WIDTH, LAYOUT_TYPE,
  FIRST_ITEM, AUTO_PLAY_DELAY, AUTO_PLAY, ITEM_SUB_VALUE,
  ITEM_PADDING, BACKGROUND_DEFAULT, BACKGROUND_ACTIVE
} from '../../Constant.js';
import Carousel from 'react-native-snap-carousel'; // Version can be specified in package.json
var Sound = require('react-native-sound');
export default class SlideItemComponent1 extends Component<Props> {
  constructor(props){
    super(props);
    this.opacity = [0 , 0, 0, 0];
    this.init();
    this.isWrong = false;
  }
  getRandomInt(min, max) {
    var number = Math.floor(Math.random() * (max - min + 1)) + min;
    return parseInt(number);
  }
  init(){
    this.state = {
      opacity: [0 , 0, 0, 0],
      heightView: 0,
      widthView: 0,
      dataForKiemTra: this.props.dataForKiemTra,
    };
  }

  render() {
    return (
      <View style={styleVoca.continer}>
        <View style={styleVoca.content}>
          <View style={styleVoca.images}>
            <TouchableOpacity style={styleVoca.chooseImage} onPress={() => {this.answer(0)}} onLayout={this.getViewHeight}>
              <Image style={{flex: 1, resizeMode: 'contain'}} source={{ uri: this.state.dataForKiemTra.answers[0] }}/>
              <View style={[styleVoca.overlayRed, {width: this.state.widthView, height: this.state.heightView, opacity: this.opacity[0]}]}>
                <Image style={{marginLeft: 5, width: this.state.widthView - 10, height: this.state.widthView - 10}} source={require("../../../assets/wrong.png")} />
              </View>
            </TouchableOpacity>

            <TouchableOpacity style={styleVoca.chooseImage} onPress={() => {this.answer(1)}}>
              <Image style={{flex: 1, resizeMode: 'contain'}} source={{ uri: this.state.dataForKiemTra.answers[1] }}/>
              <View style={[styleVoca.overlayRed, {width: this.state.widthView, height: this.state.heightView, opacity: this.opacity[1]}]}>
                <Image style={{marginLeft: 5, width: this.state.widthView - 10, height: this.state.widthView - 10}} source={require("../../../assets/wrong.png")} />
              </View>
            </TouchableOpacity>

          </View>
          <View style={styleVoca.images}>
            <TouchableOpacity style={styleVoca.chooseImage} onPress={() => {this.answer(2)}}>
              <Image style={{flex: 1, resizeMode: 'contain'}} source={{ uri: this.state.dataForKiemTra.answers[2] }}/>
              <View style={[styleVoca.overlayRed, {width: this.state.widthView, height: this.state.heightView, opacity: this.opacity[2]}]}>
                <Image style={{marginLeft: 5, width: this.state.widthView - 10, height: this.state.widthView - 10}} source={require("../../../assets/wrong.png")} />
              </View>
            </TouchableOpacity>

            <TouchableOpacity style={styleVoca.chooseImage} onPress={() => {this.answer(3)}}>
              <Image style={{flex: 1, resizeMode: 'contain'}} source={{ uri: this.state.dataForKiemTra.answers[3] }}/>
              <View style={[styleVoca.overlayRed, {width: this.state.widthView, height: this.state.heightView, opacity: this.opacity[3]}]}>
                <Image style={{marginLeft: 5, width: this.state.widthView - 10, height: this.state.widthView - 10}} source={require("../../../assets/wrong.png")} />
              </View>
            </TouchableOpacity>
          </View>

          <View style={{height: 50, width: deviceWidth, justifyContent: 'center', flexDirection: 'row'}}>
            <TouchableOpacity style={{width: 50, height: 50}} onPress={() => {this.readWord()}}>
              <Image style={{width: 50, height: 50, borderWidth: 3, borderColor: 'white', borderRadius: 25}} source={require("../../../assets/reader.png")} />
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );
  }
  readWord() {
    this.state.dataForKiemTra.questionAudio.play();
  }
  reRender(value){
    this.opacity = [0 , 0, 0, 0];
    this.setState({
      opacity: [0, 0, 0, 0],
      dataForKiemTra: value,
    });
  }
  getViewHeight = (event) => {
    var heightItem = event.nativeEvent.layout.height;
    var widthItem = event.nativeEvent.layout.width;
    this.setState({
      heightView: heightItem,
      widthView: widthItem,
    });

  }
  resetView(value) {
    this.opacity = [0 , 0, 0, 0];
    this.setState({
      opacity: [0, 0, 0, 0],
      dataForKiemTra: value,
    });
  }
  answer(value){
    if(value == this.state.dataForKiemTra.correctNumber) {
      this.props.nextItem1(this.isWrong);
      this.isWrong = false;
    } else {
      this.opacity[value] = 0.5;
      this.isWrong = true;
      this.setState({
        opacity: this.opacity,
      });
    }
  }
}

const styleVoca = StyleSheet.create({
  CarouselBackgroundView: {
    flex: 1,
    backgroundColor: '#4fc1e9',
  },
  overlayRed: {
    //backgroundColor: 'white',
    justifyContent: 'center',
    position: 'absolute',
    top: 0,
    left: 0,
  },
  continer: {
    flex: 1,
  },
  content: {
    flex: 1,
    margin: 5,
  },
  images: {
    flex: 1,
    flexDirection: 'row',
  },
  chooseImage: {
    flex: 1,
    margin: 5,
    backgroundColor: 'white',
    borderRadius: 5,
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 3
    },
    shadowRadius: 5,
    shadowOpacity: 1.0
  },
});
