import React, { Component } from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  Image,
  Dimensions,
  StyleSheet
} from 'react-native';
const deviceWidth = Dimensions.get('window').width;
const deviceHeight = Dimensions.get('window').height;
import {
  SLIDE_WIDTH, LAYOUT_TYPE,
  FIRST_ITEM, AUTO_PLAY_DELAY, AUTO_PLAY, ITEM_SUB_VALUE,
  ITEM_PADDING, BACKGROUND_DEFAULT, BACKGROUND_ACTIVE
} from '../../Constant.js';
import Carousel from 'react-native-snap-carousel'; // Version can be specified in package.json
var Sound = require('react-native-sound');
export default class SlideComponent extends Component<Props> {
  constructor(props){
    super();
    this.background = [];
    this.dataForKiemTra = [];
    this.props = props;
    this.opacity = [0 , 0, 0, 0];
    this._carousel = {};
    this.init();
  }
  getRandomInt(min, max) {
    var number = Math.floor(Math.random() * (max - min + 1)) + min;
    return parseInt(number);
  }
  init(){
    this.state = {
      opacity: [0 , 0, 0, 0],
      isRemoveSlide: false,
      play: false,
      errors: [],
      firstItem: 0,
      heightView: 0,
      widthView: 0,
    };
    this.createDataForKiemTra();
  }
  
  createDataForKiemTra() {
    var len = this.props.numberDatas;
    var allDatasLen = this.props.datas.length;
    for(let i = 0; i < len; i++){
      //rowData.word + "(" + rowData.phonetic + ")"
      this.tongSo += 1;
      var answers = [];
      var oldIndex = [];
      var questionText = new Sound(this.props.datas[i].en_us_audio, Sound.MAIN_BUNDLE, (error) => {
        if (error) {
          console.log('failed to load the sound', error);
          return;
        }
        // loaded successfully
      });
      var correctNumber = this.getRandomInt(0, 3);
      for(let j = 0; j < 4; j++) {
        if(j != correctNumber) {
          var aswIndex = this.getRandomInt(0, allDatasLen - 1);
          oldIndex[j] = aswIndex;
        } else {
          //answers[j] = this.props.vocabularyDatas[i].mean;
          oldIndex[j] = i;
        }
      }
      var lenAnswerIndex = oldIndex.length;
      for(let j = 0; j < lenAnswerIndex; j++) {
        if(j == correctNumber) {
          answers[j] = this.props.datas[oldIndex[j]].thumbnail;
          continue;
        }
        let answ1 = oldIndex[0];
        let answ2 = oldIndex[1];
        let answ3 = oldIndex[2];
        let answ4 = oldIndex[3];
        while (oldIndex[j] == answ1 || oldIndex[j] == answ2 || oldIndex[j] == answ3 || oldIndex[j] == answ4) {
          oldIndex[j] = this.getRandomInt(0, allDatasLen - 1);
        }
        answers[j] = this.props.datas[oldIndex[j]].thumbnail;
      }
      var row = {"answers": answers, "correctNumber": correctNumber, "question": questionText};
      this.dataForKiemTra[i] = row;
    }

    for(let i = 0; i < len; i++) {
      var ranNum = this.getRandomInt(0, len - 1);
      var temp = this.dataForKiemTra[ranNum];
      this.dataForKiemTra[ranNum] = this.dataForKiemTra[i];
      this.dataForKiemTra[i] = temp;
    }
  }

  handleSnapToItem(index){
    this.opacity = [0 , 0, 0, 0];
    this.setState({
      opacity: [0, 0, 0, 0],
      firstItem: index,
    });
  }
  render() {
    if(this.state.isRemoveSlide) {
      this.setState({
        isRemoveSlide: !this.state.isRemoveSlide,
      });
      return(
        <View style={styleVoca.CarouselBackgroundView} ></View>
      );
    } else {
      return (
        <View style={styleVoca.CarouselBackgroundView} >
          <Carousel
            ref={ (c) => { this._carousel = c; } }
            inactiveSlideOpacity={0.3}
            data={this.dataForKiemTra}
            renderItem={this._renderItem.bind(this)}
            onSnapToItem={this.handleSnapToItem.bind(this)}
            sliderWidth={deviceWidth}
            itemWidth={this.props.widthItemSlide}
            layout={LAYOUT_TYPE}
            firstItem={this.state.firstItem}
            autoplayDelay={3000}
            autoplayInterval={3000}
            autoplay={this.state.play}
          />
        </View>
      );
    }

  }
  reRender(autoplay) {
    this.setState({
      isRemoveSlide: true,
      play: autoplay
    })
  }
  readWord() {
    this.state.readerDatas[this.state.firstItem].stop(() => {
      // Note: If you want to play a sound after stopping and rewinding it,
      // it is important to call play() in a callback.
      this.state.readerDatas[this.state.firstItem].play();
    });
  }
  _renderItem = ( {item, index} ) => {
    return (
        <View style={styleVoca.continer}>
          <View style={styleVoca.content}>
            <View style={styleVoca.images}>
              <TouchableOpacity style={styleVoca.chooseImage} onPress={() => {this.answer(0)}} onLayout={this.getViewHeight}>
                <Image style={{flex: 1, resizeMode: 'contain'}} source={{ uri: "http://data.minder.vn/Japanese/104000002/images/words/104000632.jpg" }}/>
                <View style={[styleVoca.overlayRed, {width: this.state.widthView, height: this.state.heightView, opacity: this.opacity[0]}]}></View>
              </TouchableOpacity>

              <TouchableOpacity style={styleVoca.chooseImage} onPress={() => {this.answer(1)}}>
                <Image style={{flex: 1, resizeMode: 'contain'}} source={{ uri: "http://data.minder.vn/Japanese/104000002/images/words/104000632.jpg" }}/>
                <View style={[styleVoca.overlayRed, {width: this.state.widthView, height: this.state.heightView, opacity: this.opacity[1]}]}></View>
              </TouchableOpacity>

            </View>
            <View style={styleVoca.images}>
              <TouchableOpacity style={styleVoca.chooseImage} onPress={() => {this.answer(2)}}>
                <Image style={{flex: 1, resizeMode: 'contain'}} source={{ uri: "http://data.minder.vn/Japanese/104000002/images/words/104000632.jpg" }}/>
                <View style={[styleVoca.overlayRed, {width: this.state.widthView, height: this.state.heightView, opacity: this.opacity[2]}]}></View>
              </TouchableOpacity>

              <TouchableOpacity style={styleVoca.chooseImage} onPress={() => {this.answer(3)}}>
                <Image style={{flex: 1, resizeMode: 'contain'}} source={{ uri: "http://data.minder.vn/Japanese/104000002/images/words/104000632.jpg" }}/>
                <View style={[styleVoca.overlayRed, {width: this.state.widthView, height: this.state.heightView, opacity: this.opacity[3]}]}></View>
              </TouchableOpacity>
            </View>
          </View>
        </View>
    );
  }
  getViewHeight = (event) => {
    var heightItem = event.nativeEvent.layout.height;
    var widthItem = event.nativeEvent.layout.width;
    this.setState({
      heightView: heightItem,
      widthView: widthItem,
    });

  }
  answer(value){
    if(value == this.dataForKiemTra[this.state.firstItem].correctNumber) {
      this._carousel.snapToItem(this.state.firstItem + 1, true);
    } else {
      this.opacity[value] = 0.5;
      this.setState({
        opacity: this.opacity,
      });
    }
  }
}

const styleVoca = StyleSheet.create({
  CarouselBackgroundView: {
    flex: 1,
    backgroundColor: '#4fc1e9',
  },
  overlayRed: {
    backgroundColor: 'red',
    position: 'absolute',
    top: 0,
    left: 0,
  },
  continer: {
    flex: 1,
  },
  content: {
    flex: 1,
    marginLeft: 10,
    marginRight: 10,
    marginTop: 10,
    marginBottom: 10,
  },
  images: {
    flex: 1,
    flexDirection: 'row',
  },
  chooseImage: {
    flex: 1,
    margin: 10,
    backgroundColor: 'white',
  },
});
