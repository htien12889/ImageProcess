/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  View, TouchableOpacity, Image, Dimensions, Animated, StatusBar
} from 'react-native';
import Header from '../commons/Header.js';
import SlideComponent from './Slide.js';
import Result from '../../../Result.js';
const deviceWidth = Dimensions.get('window').width;
const deviceHeight = Dimensions.get('window').height;
export default class ChooseImage extends Component<Props> {
	constructor(props) {
		super(props);
    this.gameType = this.props.gameType;
    this.topicID = this.props.topicID;
    this.state = {
      marginSlide: new Animated.Value(0),
      datas: this.props.datas,
      datasWrong: [],
      play: false,
    }
	}
	render() {
		return(
			<Animated.View style={{flexDirection: 'row', width: deviceWidth * 2, height: deviceHeight - StatusBar.currentHeight, backgroundColor: '#4fc1e9', marginLeft: this.state.marginSlide}}>
        <View style={{width: deviceWidth, height: deviceHeight - StatusBar.currentHeight}}>
          <Header title={"Listen & choose image"} background={'#3bafda'}/>
          <SlideComponent
            ref="slide"
            numberDatas={this.props.numberDatas}
            widthItem={deviceWidth}
            heightItem={deviceHeight}
            widthItemSlide={deviceWidth}
            radius={0}
            updateDataResult={(value) => {this.updateDataResult(value)}}
            goToResult={() => {this.goToResult()}}
            datas={this.state.datas}/>
        </View>
        <View style={{width: deviceWidth, height: deviceHeight - StatusBar.currentHeight}}>
          <Result 
              ref="result"
              datas={this.state.datasWrong}
              gameType={2}
              reloadMain={(value) => {this.props.reloadMain(value)}}
              title={'Words Was Wrong'}
              mainTitle={'Listen & choose image'}/>
        </View>
      </Animated.View>
		);
	}
  updateDataResult(value) {
    this.setState({
      datasWrong: value,
    });
    this.refs.result.resetResult(this.state.datasWrong);
  }
  goToResult(){
    Animated.timing(
      this.state.marginSlide,
      {
        toValue: -deviceWidth,
        duration: 250,
      }
    ).start();
  }
}

const styles = StyleSheet.create({
  bottomView: {
    flexDirection: 'row',
    height: 50,
    justifyContent: 'center',
    marginTop: 5,
  },
  imageButton: {
    width: 50,
    height: 50
  },
  buttonControol: {
    width: 50,
    height: 50
  },
});
