/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  View, TouchableOpacity, Image, Dimensions
} from 'react-native';
import Header from '../commons/Header.js';
import SlideComponent from './Slide.js';
const deviceWidth = Dimensions.get('window').width;
const deviceHeight = Dimensions.get('window').height;
export default class ChooseImage extends Component<Props> {
	constructor(props) {
		super(props);
    this.gameType = this.props.gameType;
    this.topicID = this.props.topicID;
    this.state = {
      datas: this.props.datas,
      play: false,
    }
	}
	render() {
		return(
			<View style={{flex: 1, backgroundColor: '#4fc1e9'}}>
        <Header title={"Listen & choose image"} background={'#3bafda'}/>
        <SlideComponent
          ref="slide"
          numberDatas={this.props.numberDatas}
          widthItem={deviceWidth}
          heightItem={deviceHeight}
          widthItemSlide={deviceWidth}
          radius={0}
          datas={this.state.datas}/>
      </View>
		);
	}
  
}

const styles = StyleSheet.create({
  bottomView: {
    flexDirection: 'row',
    height: 50,
    justifyContent: 'center',
    marginTop: 5,
  },
  imageButton: {
    width: 50,
    height: 50
  },
  buttonControol: {
    width: 50,
    height: 50
  },
});
