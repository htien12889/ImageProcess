import React, { Component } from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  Image,
  Dimensions,
  StyleSheet,
  Animated,
  StatusBar
} from 'react-native';
import SlideItemComponent1 from './SlideItem1.js';
import SlideItemComponent2 from './SlideItem2.js';
const deviceWidth = Dimensions.get('window').width;
const deviceHeight = Dimensions.get('window').height;
var Sound = require('react-native-sound');
export default class SlideComponent extends Component<Props> {
  constructor(props){
    super(props);
    this.currentItem = 0;
    this.dataForKiemTra = [];
    this.dataWrong = [];
    this.dataRight = [];
    this.dataWrongIndex = 0;
    this.dataRightIndex = 0;
    this.init();
  }
  getRandomInt(min, max) {
    var number = Math.floor(Math.random() * (max - min + 1)) + min;
    return parseInt(number);
  }
  init(){
    this.state = {
      marginSlide: new Animated.Value(0),
      marginSlide1: new Animated.Value(0),
      marginSlide2: new Animated.Value(deviceWidth),
    };
    this.createDataForKiemTra();
  }
  render() {

    return(
      <Animated.View style={{marginLeft: this.state.marginSlide, width: parseInt(this.dataForKiemTra.length + 1) * deviceWidth, height: deviceHeight - 50 - StatusBar.currentHeight, flexDirection: 'row'}}>
        <Animated.View style={{width: deviceWidth, height: deviceHeight - 50 - StatusBar.currentHeight, position: 'absolute', top: 0, left: this.state.marginSlide1}}>
          <SlideItemComponent1
            ref="slideItem1"
            dataForKiemTra={this.dataForKiemTra[this.currentItem]}
            nextItem1={(value) => {this.nextItem1(value)}}/>
        </Animated.View>

        <Animated.View style={{width: deviceWidth, height: deviceHeight - 50 - StatusBar.currentHeight, position: 'absolute', top: 0, left: this.state.marginSlide2}}>
          <SlideItemComponent2
            ref="slideItem2"
            dataForKiemTra={this.dataForKiemTra[this.currentItem + 1]}
            nextItem2={(value) => {this.nextItem2(value)}}/>
        </Animated.View>
      </Animated.View>
    );
  }
  nextItem1(value){
    if(value) {
      this.dataWrong[this.dataWrongIndex] = this.dataForKiemTra[this.currentItem];
      this.dataWrongIndex += 1;
      this.props.updateDataResult(this.dataWrong, value);
    } else {
      this.dataRight[this.dataRightIndex] = this.dataForKiemTra[this.currentItem];
      this.dataRightIndex += 1;
      this.props.updateDataResult(this.dataRight, value);
    }
    if(this.currentItem == this.dataForKiemTra.length - 1) {
      this.props.goToResult();
    } else {
      this.currentItem += 1;
      Animated.timing(
        this.state.marginSlide,
        {
          toValue: -this.currentItem * deviceWidth,
          duration: 250,
        }
      ).start(() => {
        Animated.timing(
          this.state.marginSlide1,
          {
            toValue: (this.currentItem + 1) * deviceWidth,
            duration: 0,
          }
        ).start(() => {
          if(this.currentItem + 1 < this.dataForKiemTra.length) {
            this.refs.slideItem1.reRender(this.dataForKiemTra[this.currentItem + 1]);
          }
        });
      });
    }
  }

  nextItem2(value){
    if(value) {
      this.dataWrong[this.dataWrongIndex] = this.dataForKiemTra[this.currentItem];
      this.dataWrongIndex += 1;
      this.props.updateDataResult(this.dataWrong, value);
    } else {
      this.dataRight[this.dataRightIndex] = this.dataForKiemTra[this.currentItem];
      this.dataRightIndex += 1;
      this.props.updateDataResult(this.dataRight, value);
    }
    if(this.currentItem == this.dataForKiemTra.length - 1) {
      this.props.goToResult();
    } else {
      this.currentItem += 1;
      Animated.timing(
        this.state.marginSlide,
        {
          toValue: -this.currentItem * deviceWidth,
          duration: 250,
        }
      ).start(() => {
        Animated.timing(
          this.state.marginSlide2,
          {
            toValue: (this.currentItem + 1) * deviceWidth,
            duration: 0,
          }
        ).start(() => {
          if(this.currentItem + 1 < this.dataForKiemTra.length) {
            this.refs.slideItem2.reRender(this.dataForKiemTra[this.currentItem + 1]);
          }
        });
      });
    }
  }
  createDataForKiemTra() {
    var len = this.props.numberDatas;
    var allDatasLen = this.props.datas.length;
    for(let i = 0; i < len; i++){
      //rowData.word + "(" + rowData.phonetic + ")"
      this.tongSo += 1;
      var answers = [];
      var oldIndex = [];
      var questionAudio = new Sound(this.props.datas[i].en_us_audio, Sound.MAIN_BUNDLE, (error) => {
        if (error) {
          console.log('failed to load the sound', error);
          return;
        }
        // loaded successfully
      });
      var questionWord = this.props.datas[i].thumbnail;
      var en_us = this.props.datas[i].en_us;
      var thumbnail = this.props.datas[i].thumbnail;
      var en_us_pr = this.props.datas[i].en_us_pr;
      var is_love = this.props.datas[i].is_love;
      var idItem = this.props.datas[i].id;
      var correctNumber = this.getRandomInt(0, 3);
      for(let j = 0; j < 4; j++) {
        if(j != correctNumber) {
          var aswIndex = this.getRandomInt(0, allDatasLen - 1);
          oldIndex[j] = aswIndex;
        } else {
          //answers[j] = this.props.vocabularyDatas[i].mean;
          oldIndex[j] = i;
        }
      }
      var lenAnswerIndex = oldIndex.length;
      for(let j = 0; j < lenAnswerIndex; j++) {
        if(j == correctNumber) {
          answers[j] = this.props.datas[oldIndex[j]].en_us + "\n" + "[" + this.props.datas[oldIndex[j]].en_us_pr + "]";
          continue;
        }
        let answ1 = oldIndex[0];
        let answ2 = oldIndex[1];
        let answ3 = oldIndex[2];
        let answ4 = oldIndex[3];
        while (oldIndex[j] == answ1 || oldIndex[j] == answ2 || oldIndex[j] == answ3 || oldIndex[j] == answ4) {
          oldIndex[j] = this.getRandomInt(0, allDatasLen - 1);
        }
        answers[j] = this.props.datas[oldIndex[j]].en_us + "\n" + "[" + this.props.datas[oldIndex[j]].en_us_pr + "]";
      }
      var row = {"answers": answers, "correctNumber": correctNumber, "questionAudio": questionAudio, "questionWord": questionWord, en_us: en_us, thumbnail: thumbnail, en_us_pr: en_us_pr, is_love: is_love, id: idItem};
      this.dataForKiemTra[i] = row;
    }

    for(let i = 0; i < len; i++) {
      var ranNum = this.getRandomInt(0, len - 1);
      var temp = this.dataForKiemTra[ranNum];
      this.dataForKiemTra[ranNum] = this.dataForKiemTra[i];
      this.dataForKiemTra[i] = temp;
    }
  }


}
