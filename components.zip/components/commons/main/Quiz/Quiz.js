/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  View, TouchableOpacity, Image, Dimensions, Animated, StatusBar
} from 'react-native';
import Header from './Header.js';
import SlideComponent from './Slide.js';
import Result from '../../../Result.js';
const deviceWidth = Dimensions.get('window').width;
const deviceHeight = Dimensions.get('window').height;
export default class Quiz extends Component<Props> {
	constructor(props) {
		super(props);
    this.gameType = this.props.gameType;
    this.topicID = this.props.topicID;
    this.datasWrong = [];
    this.datasRight = [];
    this.state = {
      marginSlide: new Animated.Value(0),
      datas: this.props.datas,
      play: false,
    }
	}
	render() {
		return(
			<Animated.View style={{flexDirection: 'row', width: deviceWidth * 2, height: deviceHeight - StatusBar.currentHeight, backgroundColor: '#4fc1e9', marginLeft: this.state.marginSlide}}>
        <View style={{width: deviceWidth, height: deviceHeight - StatusBar.currentHeight}}>
          <Header title={"Listen & choose image"} background={'#3bafda'} back={() => {this.props.back()}}/>
          <SlideComponent
            ref="slide"
            numberDatas={this.props.numberDatas}
            widthItem={deviceWidth}
            heightItem={deviceHeight}
            widthItemSlide={deviceWidth}
            radius={0}
            updateDataResult={(dataRW, value) => {this.updateDataResult(dataRW, value)}}
            goToResult={() => {this.goToResult()}}
            datas={this.state.datas}/>
        </View>
        <View style={{width: deviceWidth, height: deviceHeight - StatusBar.currentHeight}}>
          <Result
              ref="result"
              back={() => {this.props.back()}}
              datas={this.props.realDatas}
              likeDatas={this.datasRight}
              unlikeDatas={this.datasWrong}
              gameType={3}
              reloadMain={(value) => {this.props.reloadMain(value)}}
              title={'Words Was Wrong'}
              mainTitle={'Listen & choose image'}
              resultTextLike={'Not good!!! There is no right answers'}
              resultTextUnlike={'Very good!!!'}/>
        </View>
      </Animated.View>
		);
	}
  updateDataResult(dataRW, value) {
    if(value) {
      this.datasWrong = dataRW;
    } else {
      this.datasRight = dataRW;
    }
    this.refs.result.resetResult(this.datasRight, this.datasWrong);
  }
  goToResult(){
    Animated.timing(
      this.state.marginSlide,
      {
        toValue: -deviceWidth,
        duration: 250,
      }
    ).start();
  }
}

const styles = StyleSheet.create({
  bottomView: {
    flexDirection: 'row',
    height: 50,
    justifyContent: 'center',
    marginTop: 5,
  },
  imageButton: {
    width: 50,
    height: 50
  },
  buttonControol: {
    width: 50,
    height: 50
  },
});
