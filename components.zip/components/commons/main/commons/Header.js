/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View, Image, TouchableOpacity
} from 'react-native';

export default class Header extends Component<Props> {
  constructor(props) {
    super(props);
    this.state = {
      activeMenu: 0,
      likeDatasLen: this.props.likeDatasLen,
      unlikeDatasLen: this.props.unlikeDatas,
    };
  }
  render() {
    return (
      <View>
        <View style={[styles.container, {backgroundColor: this.props.background}]} >
          <TouchableOpacity style={styles.backMenuStyle} onPress={() => {this.props.back()}}>
            <Image style={{width: 30, height: 30}} source={require("../../../assets/back.png")} />
          </TouchableOpacity>

          <View style={styles.contentStyle} >
            <Text style={styles.headerText}>{this.props.title}</Text>
          </View>

          <View style={styles.backMenuStyle} >
            
          </View>
        </View>
        {this.renderMenu()}
      </View>
      
    );
    
  }
  updateHeader(likeDatas, unlikeDatas){
    this.setState({
      activeMenu: 0,
      likeDatasLen: likeDatas,
      unlikeDatasLen: unlikeDatas,
    })
  }
  renderMenu(){
    if(this.state.activeMenu == 0) {
      return(
        <View style={{flexDirection: 'row'}}>
          <TouchableOpacity style={[styles.menuTop, {borderColor: '#FFFF8D'}]} onPress={() => {this.props.likeChoose(); this.setState({activeMenu: 0})}}>
            <View>
              <Image style={{width: 25, height: 25}} source={require("../../../assets/like.png")} />
              <Text style={{textAlign: 'center', color: 'white', fontSize: 10}}>{this.state.likeDatasLen}</Text>
            </View>
            
          </TouchableOpacity>
          <TouchableOpacity style={styles.menuTop} onPress={() => {this.props.unlikeChoose(); this.setState({activeMenu: 1})}}>
            <View>
              <Image style={{width: 25, height: 25}} source={require("../../../assets/dislike_ua.png")} />
              <Text style={{textAlign: 'center', color: '#A7E8F0', fontSize: 10}}>{this.state.unlikeDatasLen}</Text>
            </View>
          </TouchableOpacity>
        </View>
      );
    } else {
      return(
        <View style={{flexDirection: 'row'}}>
          <TouchableOpacity style={styles.menuTop} onPress={() => {this.props.likeChoose(); this.setState({activeMenu: 0})}}>
            <View>
              <Image style={{width: 25, height: 25}} source={require("../../../assets/like_ua.png")} />
              <Text style={{textAlign: 'center', color: '#A7E8F0', fontSize: 10}}>{this.state.likeDatasLen}</Text>
            </View>
            
          </TouchableOpacity>
          <TouchableOpacity style={[styles.menuTop, {borderColor: '#FFFF8D'}]} onPress={() => {this.props.unlikeChoose(); this.setState({activeMenu: 1})}}>
            <View>
              <Image style={{width: 25, height: 25}} source={require("../../../assets/dislike.png")} />
              <Text style={{textAlign: 'center', color: 'white', fontSize: 10}}>{this.state.unlikeDatasLen}</Text>
            </View>
            
          </TouchableOpacity>
        </View>
      );
    }
  }

}

const styles = StyleSheet.create({
  menuTop: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    paddingTop: 5, 
    paddingBottom: 5,
    borderBottomWidth: 2,
    borderColor: '#3bafda',
    backgroundColor: '#3bafda',
  },
  menuTopText: {
    fontSize: 15,
    color: '#A7E8F0',
    textAlign: 'center',
    fontWeight: 'bold',
  }, 
  container: {
    flexDirection: 'row',
    height: 50,
    justifyContent: 'space-between',
  },
  backMenuStyle: {
    width: 50,
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerText: {
    fontSize: 20,
    color: 'white',
    textAlign: 'center'
  },
  contentStyle: {
      justifyContent: 'center',
  }
});
