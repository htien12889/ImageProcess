import React, {Component} from 'react';
import {View, Text, StyleSheet, Switch, TouchableOpacity, Dimensions} from 'react-native';
import SegmentedControlTab from 'react-native-segmented-control-tab';
import {
  DISPLAY_FRONT_CARD_STRING, AUTO_PLAY_STRING, AUTO_FLIP_STRING,
  RANDOM_STRING, OK_STRING, CLOSE_STRING
} from '../../Constant.js'
const deviceWidth = Dimensions.get('window').width;

export default class FlashCardSetting extends Component<{}>{
  constructor(props) {
		super(props);
		this.state = {
      selectedIndexLang: this.props.engORJP,
      selectedIndexAuPlay: this.props.renderSlider,
      selectedIndexAuFlip: this.props.autoflipCard,
      selectedIndexRandom: this.props.randomCard,
      timerValue: 10,
		}
	}
  render(){
    return(
      <View style={{flex: 1, padding: 5, paddingLeft: 0, paddingRight: 0, paddingTop: 0, backgroundColor: '#4fc1e9'}}>
        <View style={style.itemSetting}>
          <View style={style.segmentView}>
            <Text style={style.textStyle}>{DISPLAY_FRONT_CARD_STRING}</Text>
          </View>
          <View style={style.segmentView}>
              <SegmentedControlTab
                values={['Mean', 'Image']}
                selectedIndex={this.state.selectedIndexLang}
                onTabPress={this.handleIndexChange}
              />
          </View>
        </View>
        <View style={{borderTopWidth: 2,borderColor: '#75d2f0', marginLeft: -5, paddingLeft: 5}}>
          <View style={style.itemSettingSlider}>
            <View style={style.segmentView2}>
              <Text style={style.textStyle}>{AUTO_PLAY_STRING}</Text>
            </View>
            <View style={style.segmentView}>
              <Switch
                onValueChange = {() => {this.toggleAutoPlay()}}
                value = {this.state.selectedIndexAuPlay}/>
            </View>

          </View>
        </View>
        {this.renderAutoFlipCard()}

        <View style={style.itemSetting}>
          <View style={style.segmentView2}>
            <Text style={style.textStyle}>{RANDOM_STRING}</Text>
          </View>
          <View style={style.segmentView}>
            <Switch
              onValueChange = {() => {this.toggleRandom()}}
              value = {this.state.selectedIndexRandom}/>
          </View>
        </View>
        <View style={{flexDirection: 'row', justifyContent: 'center', backgroundColor: '#4fc1e9', paddingBottom: 10, paddingTop: 20, paddingRight: 10}}>
          <TouchableOpacity onPress={() => {this.props.okPress()}} style={{marginLeft: 0, marginRight: 0, padding: 10, borderWidth: 1, borderColor: 'white', backgroundColor: '#ed5565', borderRadius: 3,}}>
            <Text style={{textAlign: 'center', fontSize: 17, color: 'white'}}>{CLOSE_STRING}</Text>
          </TouchableOpacity>
        </View>

      </View>
    );
  }
  renderAutoFlipCard() {
    if(this.state.selectedIndexAuPlay) {
      return(
        <View style={{borderTopWidth: 2,borderColor: '#75d2f0'}}>
          <View style={style.itemSettingSlider}>
            <View style={style.segmentView2}>
              <Text style={style.textStyle}>{AUTO_FLIP_STRING}</Text>
            </View>
            <View style={style.segmentView}>
              <Switch
                onValueChange = {() => {this.toggleAutoFlipCard()}}
                value = {this.state.selectedIndexAuFlip}/>
            </View>
          </View>
        </View>
      );
    }
  }
  handleIndexChange = (index) => {
    this.props.changeLanguage(index);
    this.setState({
      selectedIndexLang: index,
    });
  }
  toggleAutoPlay(){
    this.props.changeAutoPlay(!this.state.selectedIndexAuPlay);
    this.setState({
      selectedIndexAuPlay: !this.state.selectedIndexAuPlay,
    });
  }
  toggleRandom(){
    this.props.changeRandom(!this.state.selectedIndexRandom);
    this.setState({
      selectedIndexRandom: !this.state.selectedIndexRandom,
    });
  }
  toggleAutoFlipCard(){
    this.props.changeFlip(!this.state.selectedIndexAuFlip);
    this.setState({
      selectedIndexAuFlip: !this.state.selectedIndexAuFlip,
    });
  }
}

const style = StyleSheet.create({
  itemSetting: {
    flexDirection: 'row',
    borderTopWidth: 2,
    borderColor: '#75d2f0',
    paddingTop: 10,
    paddingBottom: 10,
    backgroundColor: '#4fc1e9',
    paddingLeft: 5,
    paddingRight: 5,
    marginLeft: -5,
    width: deviceWidth,
  },
  itemSettingSlider: {
    flexDirection: 'row',
    paddingTop: 10,
    paddingBottom: 10,
    backgroundColor: '#4fc1e9',
    paddingLeft: 5,
    paddingRight: 5,
    marginLeft: -5,
  },
  itemSettingSlider1: {
    flexDirection: 'row',
    paddingTop: 0,
    paddingBottom: 10,
    backgroundColor: '#4fc1e9',
    paddingLeft: 5,
    paddingRight: 5,
    marginLeft: -5,
  },
  segmentView: {
    flex: 1,
  },
  segmentView2: {
    flex: 2,
  },
  textStyle: {
    color: 'white',
    fontSize: 15,
    fontWeight: 'bold',
  }
});
