import React, {Component} from 'react';
import {View, Text, StyleSheet, TouchableOpacity, Animated, Image} from 'react-native';
import {db1} from '../../Constant.js';
export default class CardQuizz extends Component<{}>{
  constructor(props) {
    super(props);
    this.setParameter();
    this.autoFlip = false;
    this.state = {
      reRender: false,
    }
    this.isClickLove = false;
    this.is_love = this.props.is_love;
  }
  setParameter() {
    this.animatedValue = new Animated.Value(0);
    this.value = 0;
    this.animatedValue.addListener(({ value }) => {
      this.value = value;
    })
    this.frontOpacity = this.animatedValue.interpolate({
      inputRange: [89, 90],
      outputRange: [1, 0]
    })
    this.frontInterpolate = this.animatedValue.interpolate({
      inputRange: [0, 180],
      outputRange: ['0deg', '180deg'],
    })
    this.backInterpolate = this.animatedValue.interpolate({
      inputRange: [0, 180],
      outputRange: ['180deg', '360deg']
    })
    this.backOpacity = this.animatedValue.interpolate({
      inputRange: [89, 90],
      outputRange: [0, 1]
    })
  }
  reRenderCard(){
    this.setState({
      reRender: !this.reRender,
    });
  }
  flipCard() {
    if (this.value >= 90) {
      Animated.spring(this.animatedValue,{
        toValue: 0,
        friction: 8,
        tension: 30
      }).start();
    } else {
      Animated.spring(this.animatedValue,{
        toValue: 180,
        friction: 8,
        tension: 30
      }).start();
    }
  }
  autoflipCard() {
    this.autoFlip = true;
    if (this.value >= 90) {
      Animated.spring(this.animatedValue,{
        toValue: 0,
        friction: 8,
        tension: 30
      }).start(() => {
        this.autoFlip = false;
      });
    } else {
      Animated.spring(this.animatedValue,{
        toValue: 180,
        friction: 8,
        tension: 30
      }).start(() => {
        this.autoFlip = false;
      });
    }
  }
  render() {
    if(!this.autoFlip) {
      this.animatedValue.setValue(0);
    }
    if(!this.isClickLove) {
      this.is_love = this.props.is_love;
    } 
    const frontAnimatedStyle = {
      width: this.props.width,
      height: this.props.height,
      opacity: this.frontOpacity,
      transform: [
        { rotateY: this.frontInterpolate}
      ]
    }

    const backAnimatedStyle = {
      width: this.props.width,
      height: this.props.height,
      opacity: this.backOpacity,
      transform: [
        { rotateY: this.backInterpolate }
      ]
    }
    const flipCard = {
      width: this.props.width,
      height: this.props.height,
      justifyContent: 'center',
      backgroundColor: 'white',
      backfaceVisibility: 'hidden',
    }
    if(this.props.imageOrText == 0) {
      return (
        <View style={{width: this.props.width, height: this.props.height}}>
          <TouchableOpacity style={{width: this.props.width, height: this.props.height}} onPress={() => this.flipCard()}>
            <Animated.View style={[flipCard, frontAnimatedStyle]}>
              <Text style={{textAlign: 'center', fontSize: 20, fontWeight: 'bold', color: 'black'}}>
                {this.props.frontString}
              </Text>
            </Animated.View>

            <Animated.View style={[flipCard, styles.flipCardBack, backAnimatedStyle]}>
              <Image style={{flex: 1, resizeMode: 'contain'}} source={{ uri: "http://data.minder.vn/Japanese/104000002/images/words/104000632.jpg" }} />
            </Animated.View>
          </TouchableOpacity>
        </View>
      );
    } else {
      return (
        <View style={{width: this.props.width, height: this.props.height}}>
          <TouchableOpacity style={{width: this.props.width, height: this.props.height}} onPress={() => this.flipCard()}>
            <Animated.View style={[flipCard, frontAnimatedStyle]}>
              <Image style={{flex: 1, resizeMode: 'contain'}} source={{ uri: "http://data.minder.vn/Japanese/104000002/images/words/104000632.jpg" }} />
            </Animated.View>

            <Animated.View style={[flipCard, styles.flipCardBack, backAnimatedStyle]}>
              <Text style={{textAlign: 'center', fontSize: 20, fontWeight: 'bold', color: 'black'}}>
                {this.props.backString}
              </Text>
            </Animated.View>
          </TouchableOpacity>
        </View>
      );
    }

  }
  addFavorite(value) {
    this.isClickLove = true;
    var isFavorite = this.is_love;
    var idItem = value;
    this.is_love = !this.is_love;
    //console.log("addFavorite Status: " + this.is_love);
    if(isFavorite) {
      let sql = "DELETE FROM `folder` WHERE voc_id="+idItem;
      console.log(sql);
      db1.transaction((tx) => {
        tx.executeSql(sql, [], (tx, results) => {
          this.setState({
            reRender: !this.reRender,
          });
          this.props.updateWordDatas(value);
        });
      });
    } else {
      let sql = "INSERT INTO folder (`voc_id`) VALUES ('"+idItem+"')";
      console.log(sql);
      db1.transaction((tx) => {
        tx.executeSql(sql, [], (tx, results) => {
          this.setState({
            reRender: !this.reRender,
          });
          this.props.updateWordDatas(value);
        });
      });
    }
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  flipCardBack: {
    backgroundColor: 'white',
    position: 'absolute',
    top: 0,
    left: 0,
  },
  flipText: {
    fontSize: 15,
    color: 'black',
    fontWeight: '300',
  }
});
