import React, {Component} from 'react';
import {View, Text, StyleSheet, TouchableOpacity, Animated, Image} from 'react-native';
export default class CardQuizz extends Component<{}>{
  constructor(props) {
    super(props);
    this.setParameter();
    this.autoFlip = false;
    this.state = {
      reRender: false,
    }
  }
  setParameter() {
    this.animatedValue = new Animated.Value(0);
    this.value = 0;
    this.animatedValue.addListener(({ value }) => {
      this.value = value;
    })
    this.frontOpacity = this.animatedValue.interpolate({
      inputRange: [89, 90],
      outputRange: [1, 0]
    })
    this.frontInterpolate = this.animatedValue.interpolate({
      inputRange: [0, 180],
      outputRange: ['0deg', '180deg'],
    })
    this.backInterpolate = this.animatedValue.interpolate({
      inputRange: [0, 180],
      outputRange: ['180deg', '360deg']
    })
    this.backOpacity = this.animatedValue.interpolate({
      inputRange: [89, 90],
      outputRange: [0, 1]
    })
  }
  reRenderCard(){
    this.setState({
      reRender: !this.reRender,
    });
  }
  flipCard() {
    if (this.value >= 90) {
      Animated.spring(this.animatedValue,{
        toValue: 0,
        friction: 8,
        tension: 30
      }).start();
    } else {
      Animated.spring(this.animatedValue,{
        toValue: 180,
        friction: 8,
        tension: 30
      }).start();
    }
  }
  autoflipCard() {
    this.autoFlip = true;
    if (this.value >= 90) {
      Animated.spring(this.animatedValue,{
        toValue: 0,
        friction: 8,
        tension: 30
      }).start(() => {
        this.autoFlip = false;
      });
    } else {
      Animated.spring(this.animatedValue,{
        toValue: 180,
        friction: 8,
        tension: 30
      }).start(() => {
        this.autoFlip = false;
      });
    }
  }
  render() {
    if(!this.autoFlip) {
      this.animatedValue.setValue(0);
    }
    const frontAnimatedStyle = {
      width: this.props.width,
      height: this.props.height,
      opacity: this.frontOpacity,
      transform: [
        { rotateY: this.frontInterpolate}
      ]
    }

    const backAnimatedStyle = {
      width: this.props.width,
      height: this.props.height,
      opacity: this.backOpacity,
      transform: [
        { rotateY: this.backInterpolate }
      ]
    }
    const flipCard = {
      width: this.props.width,
      height: this.props.height,
      justifyContent: 'center',
      backgroundColor: 'white',
      backfaceVisibility: 'hidden',
    }
    var favorit_image = require("../../../assets/favorit_true.png");
    if(this.props.imageOrText == 0) {
      return (
        <View style={{width: this.props.width, height: this.props.height}}>
          <TouchableOpacity style={{flex: 1, backgroundColor: 'white'}}>
            <Image style={{width: 300, height: 300}} source={favorit_image} />
          </TouchableOpacity>
          <TouchableOpacity style={{width: this.props.width, height: this.props.height}} onPress={() => this.flipCard()}>
            <Animated.View style={[flipCard, frontAnimatedStyle]}>
              <Text style={{textAlign: 'center', fontSize: 20, fontWeight: 'bold', color: 'black'}}>
                {this.props.frontString}
              </Text>
            </Animated.View>

            <Animated.View style={[flipCard, styles.flipCardBack, backAnimatedStyle]}>
              <Image style={{flex: 1, resizeMode: 'contain'}} source={{ uri: "http://data.minder.vn/Japanese/104000002/images/words/104000632.jpg" }} />
            </Animated.View>
          </TouchableOpacity>
        </View>
      );
    } else {
      return (
        <View style={{width: this.props.width, height: this.props.height}}>
          <TouchableOpacity style={{width: this.props.width, height: this.props.height}} onPress={() => this.flipCard()}>
            <Animated.View style={[flipCard, frontAnimatedStyle]}>
              <TouchableOpacity style={{width: 25, height: 25, position: 'absolute', top: 10, right: 10, zIndex: 99999999}}>
                <Image style={{width: 25, height: 25}} source={favorit_image} />
              </TouchableOpacity>
              <Image style={{flex: 1, resizeMode: 'contain'}} source={{ uri: "http://data.minder.vn/Japanese/104000002/images/words/104000632.jpg" }} />
            </Animated.View>

            <Animated.View style={[flipCard, styles.flipCardBack, backAnimatedStyle]}>
              <TouchableOpacity style={{width: 25, height: 25, position: 'absolute', top: 10, right: 10, zIndex: 99999999}}>
                <Image style={{width: 25, height: 25}} source={favorit_image} />
              </TouchableOpacity>
              <Text style={{textAlign: 'center', fontSize: 20, fontWeight: 'bold', color: 'black'}}>
                {this.props.backString}
              </Text>
            </Animated.View>
          </TouchableOpacity>
        </View>
      );
    }
    
  }

}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  flipCardBack: {
    backgroundColor: 'white',
    position: 'absolute',
    top: 0,
    left: 0,
  },
  flipText: {
    fontSize: 15,
    color: 'black',
    fontWeight: '300',
  }
});
