import React, {Component} from 'react';
import {View, TouchableOpacity, Text, StyleSheet, Linking} from 'react-native';
import PercentageCircle from 'react-native-percentage-circle';
export default class FlashCardQuizResult extends Component<{}>{
  render() {
    return(
      <View style={style.resultContainer}>
        <View style={style.resultText}>
          <Text style={{textAlign: 'center', fontSize: 20, fontWeight: 'bold', padding: 5, color: 'white'}}>Hoàn Thành ({this.props.percent}%)!!!</Text>
          <Text style={{textAlign: 'center', fontSize: 17, fontWeight: 'bold', padding: 5, color: 'white'}}>Kết Quả Là: {this.props.knowResult} Từ Đã Biết Và {this.props.unknowResult} Từ Chưa Biết</Text>
          {this.renderUnknownBox()}

          <TouchableOpacity style={style.resultButton}
            onPress={() => {this.props.restart()}}>
            <Text style={{textAlign: 'center', padding: 5, fontSize: 18, color: 'white', fontWeight: 'bold', paddingTop: 5, paddingBottom: 10}}>Học Lại Từ Đầu</Text>
          </TouchableOpacity>
          <TouchableOpacity style={style.resultButton}
            onPress={() => {this.reviewApp()}}>
            <Text style={{textAlign: 'center', padding: 5, fontSize: 18, color: 'white', fontWeight: 'bold', paddingTop: 5, paddingBottom: 10}}>Đánh Giá Ứng Dụng</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }
  renderUnknownBox(){
    if(this.props.unknowResult != 0) {
      return(
        <TouchableOpacity style={style.resultButton}
          onPress={() => {this.props.retryUnknown()}}>
          <Text style={{textAlign: 'center', padding: 5, fontSize: 18, color: 'white', fontWeight: 'bold', paddingTop: 5, paddingBottom: 10}}>Học Lại Từ Chưa Biết</Text>
        </TouchableOpacity>
      );
    }
  }
  reviewApp(){
    Linking.openURL('https://play.google.com/store/apps/details?id=tienjoneey.com.jlpt');
  }
  tryAgain(){
    this.props.lessonUpdateClick(1);
    this.props.tryAgain();
  }
  renderKetQua() {
    if(this.props.percent < 50) {
      return(
        <Text style={{textAlign: 'center', fontSize: 20, fontWeight: 'bold', padding: 5, color: 'white'}}>Not Well!!!</Text>
      );
    } else if (this.props.percent >= 50 && this.props.percent < 70) {
      return(
        <Text style={{textAlign: 'center', fontSize: 20, fontWeight: 'bold', padding: 5, color: 'white'}}>Average!!!</Text>
      );
    } else if (this.props.percent >= 70 && this.props.percent < 100) {
      return(
        <Text style={{textAlign: 'center', fontSize: 20, fontWeight: 'bold', padding: 5, color: 'white'}}>Good!!!</Text>
      );
    } else if (this.props.percent == 100) {
      return(
        <Text style={{textAlign: 'center', fontSize: 20, fontWeight: 'bold', padding: 5, color: 'white'}}>Perfect!!!</Text>
      );
    }
  }
}

const style = StyleSheet.create({
  resultButton: {
    marginTop: 10,
    marginLeft: 20,
    marginRight: 20,
    backgroundColor: '#a0d468',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'white',
    borderRadius: 5
  },
  resultPercent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  resultContainer: {
		flex: 1,
    justifyContent: 'center',
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: 'white',
    backgroundColor: '#4fc1e9',
	},
  resultText: {
    flex: 1,
    justifyContent: 'center',
  }
});
