import React, {Component} from 'react';
import {View, TouchableOpacity, Text, StyleSheet, Animated, Dimensions, StatusBar, Slider, Image} from 'react-native';
import CardQuizz from './CardQuizz.js';
import FlashCardSetting from './FlashCardSetting.js';
import Result from '../../../Result.js';
import Header from '../commons/Header.js';
import {KHONG_DU_TU, TOUCH_TO_FLIP, CARD_KNOWN, CARD_REMAIN, UN_KNOWN, TIMER_SETTING} from '../../Constant.js';
var heightItemMainCard = 0;
var WidthItemMainCard = 0;
var positionLeftMainCard = 0;
var positionTopMainCard = 0;
var cardWidth = 0;
var cardHeight = 0;
var cardTop1 = 0;
var cardTop2 = 0;
var cardTop3 = 0;
var cardRight = 0;
var cardButtonHeight = 0;
var {height, width} = Dimensions.get('window');
var Sound = require('react-native-sound');
export default class FlashCardQuiz extends Component<{}>{
  constructor(props) {
		super(props);
		this.lanThu = 0;
    this.dataRemain = [];
    this.dataKnow = [];
    this.dataUnknow = [];
    this.remainText = "";
    this.knowText = "";
    this.unknowText = "";
    this.remainNumber = 0;
    this.knowNumber = 0;
    this.unKnowNumber = 0;
    this.tongSo = 0;
    this.firstTimerAniSett = true;
    this.sliderRenderFirst = false;
    this.sliderIsFirstChange = true;
    this.haveSetting = false;
    this.knowResult = 0;
    this.unknowResult = 0;
    this.percent = 0;
		this.state = {
			level: this.props.level,
			titleName: 'Grammar N' + this.props.level,
			type: 'grammar',
			isContent: 0,
      heightView: 0,
      widthView: 0,
      isClicked: 0,
      status: 0,
      move: new Animated.ValueXY(),
      scale: new Animated.Value(1),
      opacity: new Animated.Value(1),
      marginMain: new Animated.Value(0),
      marginSetting: new Animated.Value(width),
      timerWidth: new Animated.Value(0),
      mainMargin: new Animated.Value(0),
      opacityKnow: 0,
      opacityUnknow: 0,
      opacityRemain: 1,
      timerValue: 10,
      renderSlider: false,
      engORJP: 0,
      randomCard: false,
      autoflipCard: false,
      finish: false,
		}
    this.getDatas();
	}
  render(){
    if(this.props.vocabularyDatas.length > 1) {
      this.card1PressProcessing();
      return(
        <Animated.View style={[style.flashQuizContainer, {marginLeft: this.state.mainMargin}]}>
          <View style={{width: width, height: height}}>
            <Header title={"Vocabulary"} background={'#3bafda'}/>
            <View style={{flexDirection: 'row', width: width * 2, height: height - 50 - StatusBar.currentHeight}}>
              <Animated.View style={{marginLeft: this.state.marginMain, width: width, height: height - 50 - StatusBar.currentHeight}} onLayout={this.getViewHeight}>
                {this.renderSliderSetting()}
                {this.renderMainCard()}
                {this.renderChuaNhoCard1()}
                {this.renderChuaNhoCard2()}
                {this.renderChuaNhoCard3()}
                <TouchableOpacity onPress={() => {this.settingClick()}} style={{backgroundColor: '#3bafda',width: WidthItemMainCard, padding: 10, borderRadius: 5, position: 'absolute', left: 10, top: 10}}>
                  <Text style={{fontSize: 17, fontWeight: 'bold', color: 'white', textAlign: 'center', width: WidthItemMainCard}}>FlashCard Setting</Text>
                </TouchableOpacity>
                <Text style={{color: '#989fa9', fontWeight: 'bold', fontStyle: 'italic', zIndex: 99999, position: 'absolute', width: WidthItemMainCard, height: 20, left: 10, top: positionTopMainCard + heightItemMainCard - 20, textAlign: 'center'}}>
                  {TOUCH_TO_FLIP}
                </Text>
              </Animated.View>
              {this.renderSettingOrResult()}
            </View>
          </View>
          
          <View>
            <Result 
              datas={this.dataUnknow}
              gameType={2}
              reloadMain={(value) => {this.props.reloadMain(value)}}
              title={'Words Unknown'}
              mainTitle={'Flash Card'}/>
          </View>
        </Animated.View>
      );
    } else {
      return(
        <View style={{flex: 1, justifyContent: 'center', paddingLeft: 5, paddingRight: 5}}>
          <Text style={{textAlign: 'center', fontWeight: 'bold', fontSize: 25}}>{KHONG_DU_TU}</Text>
        </View>
      );

    }
  }
  renderSettingOrResult() {
    return(
      <Animated.View style={{width: width, height: height - 50 - StatusBar.currentHeight, marginLeft: this.state.marginSetting}}>
        <FlashCardSetting
          renderSlider={this.state.renderSlider}
          engORJP={this.state.engORJP}
          randomCard={this.state.randomCard}
          autoflipCard={this.state.autoflipCard}
          changeAutoPlay={(value) => {this.changeAutoPlay(value)}}
          changeLanguage={(value) => {this.changeLanguage(value)}}
          changeRandom={(value) => {this.changeRandom(value)}}
          changeFlip={(value) => {this.changeFlip(value)}}
          okPress={() => {this.okSettingPress()}}/>
      </Animated.View>
    );
    
  }

  retryUnknown(){
    //this.props.lessonUpdateClick(3);
    Animated.timing(
      this.state.timerWidth,
    ).stop();
    this.state.timerWidth.setValue(0);
    this.remainNumber = this.unKnowNumber - 1;
    let len = this.dataUnknow.length;
    for(let i = 0; i < len; i++){
      this.dataRemain[i] = this.dataUnknow[i];
    }
    this.unKnowNumber = 0;
    this.dataUnknow = [];
    this.state.move.setValue({x: 0, y: 0});
    this.state.scale.setValue(1);
    Animated.parallel([
      Animated.timing(
        this.state.marginMain,
        {
          toValue: 0,
          duration: 250,
        }
      ),
      Animated.timing(
        this.state.marginSetting,
        {
          toValue: width,
          duration: 250,
        }
      ),
    ]).start(() => {
      if(this.state.renderSlider) {
        this.haveSetting = false;
        this.sliderRenderFirst = true;
      }
      this.setState({
        opacityRemain: 1,
        opacityUnknow: 0,
        finish: false,
      });
    });

  }
  restart(){
    //this.props.lessonUpdateClick(3);
    this.getDatas();
    this.dataKnow = [];
    this.dataUnknow = [];
    this.state.move.setValue({x: 0, y: 0});
    this.state.scale.setValue(1);
    Animated.parallel([
      Animated.timing(
        this.state.marginMain,
        {
          toValue: 0,
          duration: 250,
        }
      ),
      Animated.timing(
        this.state.marginSetting,
        {
          toValue: width,
          duration: 250,
        }
      ),
    ]).start(() => {
      if(this.state.renderSlider) {
        this.haveSetting = false;
        this.sliderRenderFirst = true;
      }
      this.setState({
        opacityRemain: 1,
        opacityUnknow: 0,
        opacityKnow: 0,
        finish: false,
      });
    });

  }
  changeFlip(value){
    this.setState({
      autoflipCard: value,
    });
  }
  changeLanguage(value){
    let len = this.dataRemain.length;
    for(let i = 0; i < len; i++) {
      let temp = this.dataRemain[i].word;
      this.dataRemain[i].word = this.dataRemain[i].mean;
      this.dataRemain[i].mean = temp;
    }
    if(len > 1) {
      this.remainText = this.dataRemain[1].word;
    }
    len = this.dataKnow.length;
    for(let i = 0; i < len; i++) {
      let temp = this.dataKnow[i].word;
      this.dataKnow[i].word = this.dataKnow[i].mean;
      this.dataKnow[i].mean = temp;
    }
    if(len >= 1) {
      this.knowText = this.dataKnow[0].word;
    }
    len = this.dataUnknow.length;
    for(let i = 0; i < len; i++) {
      let temp = this.dataUnknow[i].word;
      this.dataUnknow[i].word = this.dataUnknow[i].mean;
      this.dataUnknow[i].mean = temp;
    }
    if(len >= 1) {
      this.unknowText = this.dataUnknow[0].word;
    }
    this.setState({
      engORJP: value,
    });
  }
  getDatas() {
    let array = [];
    let len = this.props.vocabularyDatas.length;
    if(len > 1) {
      for (let i = 0; i < len; i++) {
        var questionAudio = new Sound(this.props.vocabularyDatas[i].en_us_audio, Sound.MAIN_BUNDLE, (error) => {
          if (error) {
            console.log('failed to load the sound', error);
            return;
          }
          // loaded successfully
        });
        if(this.props.vocabularyDatas[i].phonetic != "") {
          array[i] = {id: this.props.vocabularyDatas[i].id,word: this.props.vocabularyDatas[i].en_us, mean: this.props.vocabularyDatas[i].thumbnail, audio: questionAudio, is_love: this.props.vocabularyDatas[i].is_love, thumbnail: this.props.vocabularyDatas[i].thumbnail, en_us: this.props.vocabularyDatas[i].en_us, en_us_pr: this.props.vocabularyDatas[i].en_us_pr};
        } else {
          array[i] = {id: this.props.vocabularyDatas[i].id,word: this.props.vocabularyDatas[i].thumbnail, mean: this.props.vocabularyDatas[i].en_us, audio: questionAudio, is_love: this.props.vocabularyDatas[i].is_love, thumbnail: this.props.vocabularyDatas[i].thumbnail, en_us: this.props.vocabularyDatas[i].en_us, en_us_pr: this.props.vocabularyDatas[i].en_us_pr};
        }
      }
      this.remainNumber = array.length - 1;
      this.tongSo = array.length;
      this.knowNumber = 0;
      this.unKnowNumber = 0;
      this.dataRemain = array;
      this.remainText = this.dataRemain[1].word;
    }
	}
  okSettingPress(){
    //this.props.lessonUpdateClick(1);
    Animated.parallel([
      Animated.timing(
        this.state.marginMain,
        {
          toValue: 0,
          duration: 250,
        }
      ),
      Animated.timing(
        this.state.marginSetting,
        {
          toValue: width,
          duration: 250,
        }
      ),
    ]).start(() => {
      if(this.state.renderSlider) {
        this.haveSetting = false;
        this.sliderRenderFirst = true;
      }
    });
  }
  changeRandom(value) {
    this.setState({
      randomCard: value,
    });
  }
  changeAutoPlay(value) {
    if(value == false) {
      Animated.timing(
        this.state.timerWidth,
      ).stop(() => {
        this.state.timerWidth.setValue(0);
      });
    }
    this.sliderRenderFirst = false;
    this.setState({
      renderSlider: value,
    });
  }
  renderSliderSetting(){
    console.log(this.state.engORJP);
    if(this.state.renderSlider && this.state.finish == false && this.haveSetting == false) {
      this.sliderRenderFirst = false;
      return(
        <View style={{width: WidthItemMainCard, height: 50, position: 'absolute', left: 10, top: positionTopMainCard + heightItemMainCard + 10}}>
          <View style={{flexDirection: 'row', width: WidthItemMainCard, height: 20}}>
            <View style={{flex: 1}}>
              <Text style={{fontSize: 10}}>{TIMER_SETTING}:{"\n"} ({this.state.timerValue} seconds)</Text>
            </View>
            <View style={{flex: 2,}}>
              <Slider
                minimumValue={3}
                maximumValue={20}
                step={1}
                value={this.state.timerValue}
                onValueChange={value => this.setState({ timerValue: value })}
              />
            </View>
          </View>
          <Animated.View style={{backgroundColor: '#3bafda',width: this.state.timerWidth, height: 5, marginTop: 20, borderRadius: 5}}>

          </Animated.View>
        </View>
      );
    }
  }

  renderMainCard() {
    //{this.dataRemain[0].word + "(" + this.dataRemain[0].phonetic + ")"}
    //console.log(this.dataRemain[0].word);
    this.calculateHeightOfViews();
    if(this.dataRemain.length > 0) {
      return(
        <Animated.View style={this.state.move.getLayout()}>
          <Animated.View style={[style.mainCardXoay, {opacity: this.state.opacity, transform: [{scale: this.state.scale}], width: WidthItemMainCard, height: heightItemMainCard, top: positionTopMainCard, left: positionLeftMainCard, zIndex: 9}]}>
            <CardQuizz
              ref="flip"
              imageOrText={this.state.engORJP}
              width={WidthItemMainCard}
              height={heightItemMainCard}
              is_love={this.dataRemain[0].is_love}
              frontString={this.dataRemain[0].word}
              backString={this.dataRemain[0].mean}
              id={this.dataRemain[0].id}
              updateWordDatas={(value) => {console.log("hello updateWordDatas"); this.dataRemain[0].is_love = value}}/>
          </Animated.View>
        </Animated.View>
      );
    }

  }
  getViewHeight = (event) => {
    var heightItem = event.nativeEvent.layout.height;
    var widthItem = event.nativeEvent.layout.width;
    this.setState({
      heightView: heightItem,
      widthView: widthItem,
    });
  }
  calculateHeightOfViews() {
    heightItemMainCard = parseInt(this.state.heightView / 1.5);
    positionLeftMainCard = 10;
    positionTopMainCard = parseInt(this.state.heightView / 2) - parseInt(heightItemMainCard / 2);
    WidthItemMainCard = parseInt((this.state.widthView / 1.5) - 20);
    cardWidth = this.state.widthView - WidthItemMainCard - 30;
    cardHeight = parseInt((this.state.heightView - 40) / 3);
    cardTop1 = 10;
    cardTop2 = 20 + cardHeight;
    cardTop3 = 30 + cardHeight * 2;
    cardRight = 10;
    cardButtonHeight = cardHeight - 20;
  }
  renderChuaNhoCard1(){
    return(
      <TouchableOpacity onPress={() => {this.card1Press()}}
        style={[style.mainCard1, {width: cardWidth, height: cardHeight, top: cardTop1, right: cardRight}]}>
        <View style={[style.mainCard, {width: cardWidth - 10, height: cardHeight, top: 0, left: 5, opacity: this.state.opacityKnow}]}>
          <Text style={{textAlign: 'center', fontSize: cardWidth * 0.1, fontWeight: 'bold', color: 'black'}}>{this.knowText}</Text>
        </View>
        <View style={[style.mainCard, {backgroundColor: '#a0d468',width: cardWidth, height: cardHeight * 0.3, top: cardHeight * 0.7, left: 0, zIndex: 99}]}>
          <Text style={{textAlign: 'center', fontSize: cardWidth * 0.1, fontWeight: 'bold', color: 'black'}}>{CARD_KNOWN} ({this.knowNumber}/{this.tongSo})</Text>
        </View>
      </TouchableOpacity>
    );
  }
  renderChuaNhoCard2(){
    return(
      <TouchableOpacity onPress={() => {this.card2Press()}}
        style={[style.mainCard1, {width: cardWidth, height: cardHeight, top: cardTop2, right: cardRight}]}>
        <View style={[style.mainCard, {width: cardWidth - 10, height: cardHeight, top: 0, left: 5, opacity: this.state.opacityRemain}]}>
          <Text style={{textAlign: 'center', fontSize: cardWidth * 0.1, fontWeight: 'bold', color: 'black'}}>{this.remainText}</Text>
        </View>
        <View style={[style.mainCard, {backgroundColor: '#3bafda',width: cardWidth, height: cardHeight * 0.3, top: cardHeight * 0.7, left: 0, zIndex: 99}]}>
          <Text style={{textAlign: 'center', fontSize: cardWidth * 0.1, fontWeight: 'bold', color: 'black'}}>{CARD_REMAIN} ({this.remainNumber}/{this.tongSo})</Text>
        </View>
      </TouchableOpacity>
    );
  }
  renderChuaNhoCard3(){
    return(
      <TouchableOpacity onPress={() => {this.card3Press()}}
        style={[style.mainCard1, {width: cardWidth, height: cardHeight, top: cardTop3, right: cardRight}]}>
        <View style={[style.mainCard, {width: cardWidth - 10, height: cardHeight, top: 0, left: 5, opacity: this.state.opacityUnknow}]}>
          <Text style={{textAlign: 'center', fontSize: cardWidth * 0.1, fontWeight: 'bold', color: 'black'}}>{this.unknowText}</Text>
        </View>
        <View style={[style.mainCard, {backgroundColor: '#ed5565',width: cardWidth, height: cardHeight * 0.3, top: cardHeight * 0.7, left: 0, zIndex: 99}]}>
          <Text style={{textAlign: 'center', fontSize: cardWidth * 0.1, fontWeight: 'bold', color: 'black'}}>{UN_KNOWN} ({this.unKnowNumber}/{this.tongSo})</Text>
        </View>
      </TouchableOpacity>
    );
  }
  settingClick(){
    this.sliderRenderFirst = false;
    this.haveSetting = true;
    Animated.timing(
      this.state.timerWidth,
    ).stop();

    /*if(this.state.renderSlider) {
      Animated.timing(
        this.state.timerWidth,
      ).stop();
      this.state.timerWidth.setValue(0);
    }*/
    Animated.parallel([
      Animated.timing(
        this.state.marginMain,
        {
          toValue: -width,
          duration: 250,
        }
      ),
      Animated.timing(
        this.state.marginSetting,
        {
          toValue: 0,
          duration: 250,
        }
      ),
    ]).start();
  }
  card1PressProcessing(){
    let left = (WidthItemMainCard + 15) - (WidthItemMainCard / 4);
    let top = (parseInt((this.state.heightView - heightItemMainCard) / 2) - 10) + (heightItemMainCard / 4);

    if(this.state.renderSlider && this.sliderRenderFirst && !this.state.finish) {
      this.sliderRenderFirst = false;
      this.sliderIsFirstChange = false;
      Animated.timing(
        this.state.timerWidth,
        {
          toValue: WidthItemMainCard / 2,
          duration: (this.state.timerValue / 2)*1000,
        }
      ).start(() => {
        this.setState({
          isClicked: 4,
          status: 1,
        });
      });
    }

    //console.log(this.state);
    if(this.state.isClicked == 1 && this.state.status == 1) {
      Animated.parallel([
        Animated.timing(
          this.state.move,
          {
            toValue: {x:left,y: -top},
            duration: 250,
          }
        ),
        Animated.timing(
          this.state.scale,
          {
            toValue: 0.4,
            duration: 250,
          }
        ),
      ]).start(() => {
        this.knowNumber = this.knowNumber + 1;
        this.dataKnow.unshift(this.dataRemain[0]);
        this.knowText = this.dataKnow[0].word;
        this.dataRemain.shift();
        let len = this.dataRemain.length;
        if(this.state.randomCard) {
          if(len > 2) {
            let randomNum = 1;
            while (randomNum == 1) {
              randomNum = this.getRandomInt(1, len - 1);
            }
            let temp = this.dataRemain[randomNum];
            this.dataRemain[randomNum] = this.dataRemain[1];
            this.dataRemain[1] = temp;
          }
        }
        if(this.remainNumber == 0) {
          this.haveSetting = true;
          this.knowResult = this.knowNumber;
          this.unknowResult = this.unKnowNumber;
          this.percent = (this.knowResult / this.tongSo) * 100;
          this.percent = parseFloat(this.percent).toFixed(2);
          this.sliderRenderFirst = false;
          this.haveSetting = true;
          this.setState({isClicked: 0,status: 0, finish: true});
          Animated.timing(
            this.state.mainMargin,
            {
              toValue: -width,
              duration: 250,
            }
          ).start();
        } else {
          this.remainNumber = this.remainNumber - 1;
          if(len < 2) {
            this.setState({isClicked: 1,status: 2, opacityKnow: 1, opacityRemain: 0});
          } else {
            this.remainText = this.dataRemain[1].word;
            this.setState({isClicked: 1,status: 2, opacityKnow: 1, opacityRemain: 1});
          }
        }
      });
    } else if(this.state.isClicked == 1 && this.state.status == 2) {
      Animated.sequence([
        Animated.timing(
          this.state.opacity,
          {
            toValue: 0,
            duration: 1,
          }
        ),
        Animated.timing(
          this.state.scale,
          {
            toValue: 0.4,
            duration: 1,
          }
        ),
        Animated.timing(
          this.state.move,
          {
            toValue: {x:left,y: cardHeight / 16},
            duration: 1,
          }
        ),
        Animated.timing(
          this.state.opacity,
          {
            toValue: 1,
            duration: 1,
          }
        ),
      ]).start(() => {
        //this.refs.flip.reRenderCard();
        this.setState({isClicked: 1,status: 3,});
      });
    } else if(this.state.isClicked == 1 && this.state.status == 3) {
      Animated.parallel([
        Animated.timing(
          this.state.move,
          {
            toValue: {x:0,y: 0},
            duration: 250,
          }
        ),
        Animated.timing(
          this.state.scale,
          {
            toValue: 1,
            duration: 250,
          }
        ),
      ]).start(() => {
        this.setState({isClicked: 0,status: 0});
      });
    }
    /***********************************************************************************************
    ************************************************************************************************/
    else if(this.state.isClicked == 2 && this.state.status == 1) {
      Animated.parallel([
        Animated.timing(
          this.state.move,
          {
            toValue: {x:left,y: cardHeight / 16},
            duration: 250,
          }
        ),
        Animated.timing(
          this.state.scale,
          {
            toValue: 0.4,
            duration: 250,
          }
        ),
      ]).start(() => {
        //this.refs.flip.reRenderCard();
        this.dataRemain.push(this.dataRemain[0]);
        this.dataRemain.shift();
        let len = this.dataRemain.length;
        if(this.state.randomCard) {
          if(len > 2) {
            let randomNum = 1;
            while (randomNum == 1) {
              randomNum = this.getRandomInt(1, len - 1);
            }
            let temp = this.dataRemain[randomNum];
            this.dataRemain[randomNum] = this.dataRemain[1];
            this.dataRemain[1] = temp;
          }
        }
        if(len < 2) {
          this.setState({isClicked: 2,status: 2, opacityRemain: 0});
        } else {
          this.remainText = this.dataRemain[1].word;
          this.setState({isClicked: 2,status: 2, opacityRemain: 1});
        }

      });
    } else if (this.state.isClicked == 2 && this.state.status == 2) {
      Animated.parallel([
        Animated.timing(
          this.state.move,
          {
            toValue: {x:0,y: 0},
            duration: 250,
          }
        ),
        Animated.timing(
          this.state.scale,
          {
            toValue: 1,
            duration: 250,
          }
        ),
      ]).start(() => {
        Animated.timing(
          this.state.timerWidth,
        ).stop(() => {
          this.state.timerWidth.setValue(0);
        });
        if(this.state.renderSlider) {
          Animated.timing(
            this.state.timerWidth,
          ).stop();
          if(this.haveSetting) {
            this.sliderRenderFirst = false;
          } else {
            this.sliderRenderFirst = true;
          }
          this.state.timerWidth.setValue(0);
          this.setState({isClicked: 0,status: 0});
        } else {
          this.setState({isClicked: 0,status: 0});
        }

      });
    }
    /***************************************************************************************
    ****************************************************************************************/
    if(this.state.isClicked == 3 && this.state.status == 1) {
      Animated.parallel([
        Animated.timing(
          this.state.move,
          {
            toValue: {x:left,y: cardHeight},
            duration: 250,
          }
        ),
        Animated.timing(
          this.state.scale,
          {
            toValue: 0.4,
            duration: 250,
          }
        ),
      ]).start(() => {
        this.unKnowNumber = this.unKnowNumber + 1;
        this.dataUnknow.unshift(this.dataRemain[0]);
        this.unknowText = this.dataUnknow[0].word;
        this.dataRemain.shift();
        let len = this.dataRemain.length;
        if(this.state.randomCard){
          if(len > 2) {
            let randomNum = 1;
            while (randomNum == 1) {
              randomNum = this.getRandomInt(1, len - 1);
            }
            let temp = this.dataRemain[randomNum];
            this.dataRemain[randomNum] = this.dataRemain[1];
            this.dataRemain[1] = temp;
          }
        }
        if(this.remainNumber == 0) {
          this.haveSetting = true;
          this.knowResult = this.knowNumber;
          this.unknowResult = this.unKnowNumber;
          this.percent = (this.knowResult / this.tongSo) * 100;
          this.percent = parseFloat(this.percent).toFixed(2);
          this.sliderRenderFirst = false;
          this.setState({isClicked: 0,status: 0, finish: true});

          Animated.timing(
            this.state.mainMargin,
            {
              toValue: -width,
              duration: 250,
            }
          ).start();

        } else {
          this.remainNumber = this.remainNumber - 1;
          if(len < 2) {
            this.setState({isClicked: 3,status: 2, opacityUnknow: 1, opacityRemain: 0});
          } else {
            this.remainText = this.dataRemain[1].word;
            this.setState({isClicked: 3,status: 2, opacityUnknow: 1, opacityRemain: 1});
          }
        }
      });


    } else if(this.state.isClicked == 3 && this.state.status == 2) {
      Animated.sequence([
        Animated.timing(
          this.state.opacity,
          {
            toValue: 0,
            duration: 1,
          }
        ),
        Animated.timing(
          this.state.scale,
          {
            toValue: 0.4,
            duration: 1,
          }
        ),
        Animated.timing(
          this.state.move,
          {
            toValue: {x:left,y: cardHeight / 16},
            duration: 1,
          }
        ),
        Animated.timing(
          this.state.opacity,
          {
            toValue: 1,
            duration: 1,
          }
        ),
      ]).start(() => {
        //this.refs.flip.reRenderCard();
        this.setState({isClicked: 3,status: 3,});
      });

    } else if(this.state.isClicked == 3 && this.state.status == 3) {
      Animated.parallel([
        Animated.timing(
          this.state.move,
          {
            toValue: {x:0,y: 0},
            duration: 250,
          }
        ),
        Animated.timing(
          this.state.scale,
          {
            toValue: 1,
            duration: 250,
          }
        ),
      ]).start(() => {
        this.setState({isClicked: 0,status: 0});
      });
    } else if(this.state.isClicked == 4 && this.state.status == 1) {
      if(this.state.autoflipCard && !this.haveSetting) {
        this.refs.flip.autoflipCard();
      }
      Animated.timing(
        this.state.timerWidth,
        {
          toValue: WidthItemMainCard,
          duration: (this.state.timerValue / 2)*1000,
        }
      ).start(() => {
        this.setState({
          isClicked: 2,
          status: 1,
        });
      });
    }
  }
  getRandomInt(min, max) {
    var number = Math.floor(Math.random() * (max - min + 1)) + min;
    return parseInt(number);
  }
  card1Press(){
    if(this.state.isClicked == 0 || this.state.isClicked == 4) {
      Animated.timing(
        this.state.timerWidth,
      ).stop();
      this.state.timerWidth.setValue(0);
      this.sliderRenderFirst = true;
      this.setState({
        isClicked: 1,
        status: 1,
      });
    }
  }
  card2Press(){
    if(this.state.isClicked == 0 || this.state.isClicked == 4) {
      Animated.timing(
        this.state.timerWidth,
      ).stop(() => {
        this.state.timerWidth.setValue(0);
        this.sliderRenderFirst = true;
      });
      this.setState({
        isClicked: 2,
        status: 1,
      });
    }
  }
  card3Press(){
    if(this.state.isClicked == 0 || this.state.isClicked == 4) {
      Animated.timing(
        this.state.timerWidth,
      ).stop();
      this.state.timerWidth.setValue(0);
      this.sliderRenderFirst = true;
      this.setState({
        isClicked: 3,
        status: 1,
      });
    }
  }
}

const style = StyleSheet.create({
  mainCard1: {
    justifyContent: 'center',
    position: 'absolute',
  },
  mainCardXoay: {
    justifyContent: 'center',
    position: 'absolute',
  },
  mainCard: {
    backgroundColor: 'white',
    justifyContent: 'center',
    position: 'absolute',
  },
  cardMainView: {
    flex: 1,
  },
  flashQuizContainer: {
		flex: 1,
    flexDirection: 'row',
    width: 2 * width,
    height: height,
		backgroundColor: '#4fc1e9',
	},
});
