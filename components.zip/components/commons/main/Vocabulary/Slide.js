import React, { Component } from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  Image,
  Dimensions,
  StyleSheet,
  ScrollView
} from 'react-native';
const deviceWidth = Dimensions.get('window').width;
const deviceHeight = Dimensions.get('window').height;
import {
  SLIDE_WIDTH, LAYOUT_TYPE,
  FIRST_ITEM, AUTO_PLAY_DELAY, AUTO_PLAY, ITEM_SUB_VALUE,
  ITEM_PADDING, BACKGROUND_DEFAULT, BACKGROUND_ACTIVE, db1
} from '../../Constant.js';
import Carousel from 'react-native-snap-carousel'; // Version can be specified in package.json
var Sound = require('react-native-sound');
export default class SlideComponent extends Component<Props> {
  constructor(props){
    super();
    this.background = [];
    this.props = props;
    this._carousel = {};
    this.autoPlay = false;
    this.init();
  }

  init(){
    var readers = [];
    for(let i = 0; i < this.props.slideDatas.length; i++) {
      readers[i] = new Sound(this.props.slideDatas[i].en_us_audio, Sound.MAIN_BUNDLE, (error) => {
        if (error) {
          console.log('failed to load the sound', error);
          return;
        }
        // loaded successfully
        console.log('duration in seconds: ' + readers[i].getDuration() + 'number of channels: ' + readers[i].getNumberOfChannels());
      });
    }
    this.state = {
      errors: [],
      firstItem: 0,
      readerDatas: readers,
      datas: this.props.slideDatas
    };
  }
  handleSnapToItem(index){
    this.state.readerDatas[index].stop(() => {
      this.state.readerDatas[index].play();
    });
    this.reRender(this.autoPlay);
    this.setState({
      firstItem: index,
    });
  }
  render() {
    return (
      <View style={styleVoca.CarouselBackgroundView} >
        <Carousel
          ref={ (c) => { this._carousel = c; } }
          inactiveSlideOpacity={0.3}
          data={this.state.datas}
          renderItem={this._renderItem.bind(this)}
          onSnapToItem={this.handleSnapToItem.bind(this)}
          sliderWidth={deviceWidth}
          itemWidth={this.props.widthItemSlide}
          layout={LAYOUT_TYPE}
          firstItem={this.state.firstItem}
        />
      </View>
    );
  }
  reRender(autoplay) {
    this.autoPlay = autoplay;
    if(autoplay == true) {
      clearInterval(this._autoplayInterval);
      clearTimeout(this._autoplayTimeout);
      this._autoplayTimeout = setTimeout(() => {
          this._autoplayInterval = setInterval(() => {
              this._carousel.snapToNext();
          }, 1000);
      }, 0);
    } else {
      clearInterval(this._autoplayInterval);
      clearTimeout(this._autoplayTimeout);
    }
  }
  readWord() {
    this.state.readerDatas[this.state.firstItem].stop(() => {
      // Note: If you want to play a sound after stopping and rewinding it,
      // it is important to call play() in a callback.
      this.state.readerDatas[this.state.firstItem].play();
    });
  }
  _renderItem = ( {item, index} ) => {
    var favorit_image = require("../../../assets/favorit_true.png");
    if(item.is_love) {
      favorit_image = require("../../../assets/favorit_true.png");
    } else {
      favorit_image = require("../../../assets/favorit_false.png");
    }
    return (
        <View style={styleVoca.continer}>
          <View style={styleVoca.image}>
            <TouchableOpacity style={styleVoca.favorit} onPress={() => {this.addFavorite()}}>
              <Image style={{width: 25, height: 25}} source={favorit_image} />
            </TouchableOpacity>
            <Image style={{flex: 1}} source={{ uri: "http://data.minder.vn/Japanese/104000002/images/words/104000632.jpg" }} />
          </View>
          <View style={styleVoca.content}>
            <TouchableOpacity style={styleVoca.reader} onPress={() => {this.readWord()}}>
              <Image style={{width: 25, height: 25}} source={require("../../../assets/reader.png")} />
            </TouchableOpacity>
            <ScrollView showsVerticalScrollIndicator={true} style={{flex: 1}}>
              {this.renderWord(item)}
              {this.renderPR(item)}
              {this.renderMean(item)}
              {this.renderExample(item)}
            </ScrollView>
          </View>
        </View>
    );
  }
  addFavorite() {
    //console.log("hello abcdef");
    var dataTemp = this.state.datas;
    var isFavorite = dataTemp[this.state.firstItem].is_love;
    var idItem = dataTemp[this.state.firstItem].id;
    if(isFavorite) {
      dataTemp[this.state.firstItem].is_love = !dataTemp[this.state.firstItem].is_love;
      let sql = "DELETE FROM `folder` WHERE vocabulary_id="+idItem;
      console.log(sql);
      db1.transaction((tx) => {
        tx.executeSql(sql, [], (tx, results) => {
          this.setState({
            datas: dataTemp,
          });
        });
      });
    } else {
      dataTemp[this.state.firstItem].is_love = !dataTemp[this.state.firstItem].is_love;
      let sql = "INSERT INTO folder (`vocabulary_id`) VALUES ('"+idItem+"')";
      console.log(sql);
      db1.transaction((tx) => {
        tx.executeSql(sql, [], (tx, results) => {
          this.setState({
            datas: dataTemp,
          });
        });
      });
    }
    
  }
  renderPR(item) {
    if(item.en_us_pr != '') {
      return(
        <Text style={styleVoca.word}>[{item.en_us_pr}]</Text>
      );
    }
  }
  renderWord(item){
    if(item.en_us_type != '') {
      return(
        <Text style={styleVoca.word}>{item.en_us} ({item.en_us_type})</Text>
      );
    } else {
      return(
        <Text style={styleVoca.word}>{item.en_us}</Text>
      );
    }
  }
  renderMean(item) {
    if(item.en_us_mean != '') {
      return(
        <View>
          <Text style={styleVoca.meanSpecial}>Mean: </Text>
          <Text style={styleVoca.mean}>{item.en_us_mean}</Text>
        </View>
      );
    }
  }
  renderExample(item) {
    if(item.en_us_ex != '') {
      var example = item.en_us_ex.replace("<br>", "\n");
      var example_len = example.split('<br>').length;
      for(let i = 0; i < example_len; i++) {
        example = example.replace("<br>", "\n");
      }
      return(
        <View>
          <Text style={styleVoca.meanSpecial}>Example: </Text>
          <Text style={styleVoca.example}>{example}</Text>
        </View>
      );
    }
  }
}

const styleVoca = StyleSheet.create({
  CarouselBackgroundView: {
    flex: 1,
    backgroundColor: '#4fc1e9',
  },
  meanSpecial: {
    color: '#333',
    fontSize: 17,
    fontWeight: 'bold',
    textDecorationLine: "underline",
    fontStyle: 'italic',
  },
  continer: {
    flex: 1,
  },
  image: {
    flex: 1.3,
    backgroundColor: 'white',
    borderRadius: 10,
    marginLeft: 5,
    marginRight: 5,
    marginTop: 5,
    marginBottom: 5,
  },
  content: {
    flex: 1,
    backgroundColor: 'white',
    borderRadius: 10,
    marginLeft: 5,
    marginRight: 5,
    padding: 10,
    justifyContent: 'center',
  },
  word: {
    color: 'black',
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  mean: {
    color: '#333',
    fontSize: 13,
  },
  example: {
    color: '#333',
    fontSize: 13,
  },
  reader: {
    width: 25,
    height: 25,
    position: 'absolute',
    top: 10,
    right: 10,
    zIndex: 99,
  },
  favorit: {
    width: 25,
    height: 25,
    position: 'absolute',
    top: 10,
    right: 10,
    zIndex: 999,
  }
});
