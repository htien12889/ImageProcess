/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View, Image, TouchableOpacity
} from 'react-native';

export default class Header extends Component<Props> {
  constructor(props) {
		super(props);
    this.state = {
      number: this.props.number,
    }
	}
  render() {
    return (
      <View style={[styles.container, {backgroundColor: this.props.background}]} >
      	<TouchableOpacity style={styles.backMenuStyle} onPress={() => {this.props.back()}}>
          <Image style={{width: 30, height: 30}} source={require("../../../assets/back.png")} />
        </TouchableOpacity>

      	<View style={styles.contentStyle} >
          <Text style={styles.headerText}>{this.props.title}</Text>
        </View>
        <View style={{justifyContent: 'center', flexDirection: 'row'}}>
          <View style={{justifyContent: 'center'}}>
            <Text style={styles.headerTextResult}>{this.state.number}/{this.props.total}</Text>
          </View>

          <TouchableOpacity style={styles.backMenuStyle} onPress={() => {this.props.setting()}}>
            <Image style={{width: 30, height: 30}} source={require("../../../assets/settings.png")} />
          </TouchableOpacity>
        </View>
      </View>
    );
  }
  updateCount(value) {
    this.setState({
      number: value,
    });
  }
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    height: 50,
    justifyContent: 'space-between',
  },
  backMenuStyle: {
    width: 50,
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTextResult: {
    fontSize: 17,
    color: 'white',
    textAlign: 'center'
  },
  headerText: {
    fontSize: 20,
    color: 'white',
    textAlign: 'center'
  },
  contentStyle: {
      justifyContent: 'center',
  }
});
