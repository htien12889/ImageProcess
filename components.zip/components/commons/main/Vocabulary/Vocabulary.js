/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  View, TouchableOpacity, Image, Dimensions,
  StatusBar, Animated, Slider, Switch, Text
} from 'react-native';
import {db} from '../../Constant.js';
import Header from './Header.js';
import SlideComponent from './Slide.js';
import Result from '../../../Result.js';
const deviceWidth = Dimensions.get('window').width;
const deviceHeight = Dimensions.get('window').height;
export default class Vocabulary extends Component<Props> {
	constructor(props) {
		super(props);
    this.gameType = this.props.gameType;
    this.topicID = this.props.topicID;
    this.state = {
      settingMg: new Animated.Value(deviceHeight),
      overlay: false,
      datas: this.props.datas,
      play: false,
      rePlay: true,
      timerValue: 3,
    }
	}
	render() {
    var button = require("../../../assets/play.png");
    if(this.state.play) {
      button = require("../../../assets/pause.png");
    } else {
      button = require("../../../assets/play.png");
    }
		return(
			<View style={{width: deviceWidth, height: deviceHeight - StatusBar.currentHeight, backgroundColor: '#4fc1e9'}}>
        {this.renderOverlay()}
        <View style={{width: deviceWidth, height: deviceHeight - StatusBar.currentHeight}}>
          <Header 
            title={"Vocabulary"} 
            background={'#3bafda'} 
            back={() => {this.props.back()}}
            setting={() => {this.setting()}}/>
          <SlideComponent
            ref="slide"
            timerPlay={this.state.timerValue}
            widthItem={deviceWidth}
            heightItem={deviceHeight}
            widthItemSlide={deviceWidth}
            radius={0}
            slideDatas={this.state.datas}
            gotoResultPage={(value) => {this.gotoResultPage(value)}}/>
          <View style={styles.bottomView}>
            <TouchableOpacity style={styles.buttonControol} onPress={() => {this.controlButtonClick()}}>
              <Image style={styles.imageButton} source={button} />
            </TouchableOpacity>
          </View>
        </View>
        <Animated.View style={{marginTop: this.state.settingMg,width: deviceWidth - 100, backgroundColor: 'white', position: 'absolute', top: 10, left: 50, zIndex: 9999999, paddingTop: 10, paddingBottom: 10, backgroundColor: '#4fc1e9', borderRadius: 5}}>
          <View style={{flex: 1, backgroundColor: '#4fc1e9'}}>
            <View style={{flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: 'white'}}>
              <View style={{padding: 10}}>
                <Text style={{fontSize: 15, color: 'white'}}>Auto Play Timer: </Text>
              </View>
              <View style={{justifyContent: 'center', flex: 1}}>
                <Slider
                  minimumValue={3}
                  maximumValue={20}
                  step={1}
                  value={this.state.timerValue}
                  onValueChange={value => this.changeTimer(value)} />
              </View>
            </View>

            <View style={{flexDirection: 'row', flexDirection: 'row'}}>
              <View style={{padding: 10, justifyContent: 'center'}}>
                <Text style={{fontSize: 15, color: 'white'}}>Replay:</Text>
              </View>
              <View style={{justifyContent: 'center', flex: 1, marginRight: 10}}>
                <Switch
                  onValueChange = {() => {this.changeReplay()}}
                  value = {this.state.rePlay}/>
              </View>
            </View>
          </View>
          <View style={styles.settingItem}></View>
        </Animated.View>
      </View>
		);
	}
  changeTimer(value) {
    this.refs.slide.changeTimer(value);
    this.setState({ timerValue: value });
  }
  changeReplay(){
    this.refs.slide.changeReplay(!this.state.rePlay);
    this.setState({rePlay: !this.state.rePlay});
  }

  renderOverlay(){
    if(this.state.overlay) {
      return (
        <TouchableOpacity style={{opacity: 0.5, width: deviceWidth, height: deviceHeight - StatusBar.currentHeight, zIndex: 999999, backgroundColor: '#000000', position: 'absolute', top: 0, left: 0 }} onPress={() => {this.removeOverlay()}}></TouchableOpacity>
      );
    }
  }
  removeOverlay(){
    Animated.timing(
      this.state.settingMg,
      {
        toValue: deviceHeight,
        duration: 250,
      }
    ).start();
    this.setState({
      overlay: false,
    });
  }
  setting(){
    Animated.timing(
      this.state.settingMg,
      {
        toValue: (deviceHeight - StatusBar.currentHeight) / 2.5,
        duration: 250,
      }
    ).start();
    this.setState({
      overlay: true,
    });
  }
  gotoResultPage(value) {
    Animated.timing(
      this.state.marginSlide,
      {
        toValue: -deviceWidth,
        duration: 250,
      }
    ).start();
  }
  controlButtonClick(){
    this.refs.slide.reRender(!this.state.play);
    this.setState({
      play: !this.state.play,
    });
  }
}

const styles = StyleSheet.create({
  bottomView: {
    flexDirection: 'row',
    height: 50,
    justifyContent: 'center',
    marginTop: 5,
  },
  imageButton: {
    width: 50,
    height: 50
  },
  buttonControol: {
    width: 50,
    height: 50
  },
});
