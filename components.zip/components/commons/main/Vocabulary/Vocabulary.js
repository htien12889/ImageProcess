/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  View, TouchableOpacity, Image, Dimensions
} from 'react-native';
import {db} from '../../Constant.js';
import Header from '../commons/Header.js';
import SlideComponent from './Slide.js';
const deviceWidth = Dimensions.get('window').width;
const deviceHeight = Dimensions.get('window').height;
export default class Vocabulary extends Component<Props> {
	constructor(props) {
		super(props);
    this.gameType = this.props.gameType;
    this.topicID = this.props.topicID;
    this.state = {
      datas: this.props.datas,
      play: false,
    }
	}
	render() {
    var button = require("../../../assets/play.png");
    if(this.state.play) {
      button = require("../../../assets/pause.png");
    } else {
      button = require("../../../assets/play.png");
    }
		return(
			<View style={{flex: 1, backgroundColor: '#4fc1e9'}}>
        <Header title={"Vocabulary"}/>
        <SlideComponent
          ref="slide"
          widthItem={deviceWidth}
          heightItem={deviceHeight}
          widthItemSlide={deviceWidth}
          radius={0}
          slideDatas={this.state.datas}/>
        <View style={styles.bottomView}>
          <TouchableOpacity style={styles.buttonControol} onPress={() => {this.controlButtonClick()}}>
            <Image style={styles.imageButton} source={button} />
          </TouchableOpacity>
        </View>
      </View>
		);
	}
  controlButtonClick(){
    this.refs.slide.reRender(!this.state.play);
    this.setState({
      play: !this.state.play,
    });
  }
}

const styles = StyleSheet.create({
  bottomView: {
    flexDirection: 'row',
    height: 50,
    justifyContent: 'center',
    marginTop: 5,
  },
  imageButton: {
    width: 50,
    height: 50
  },
  buttonControol: {
    width: 50,
    height: 50
  },
});
