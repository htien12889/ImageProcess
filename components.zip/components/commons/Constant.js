// database
var SQLite = require('react-native-sqlite-storage')
export const db = SQLite.openDatabase({name : "english_data", createFromLocation : "~eng.db"}, this.openCB,this.errorCB);
export const db1 = SQLite.openDatabase({name : "english_data_folder", createFromLocation : "~folder.db"}, this.openCB,this.errorCB);
// Slide config
export const SLIDE_IMAGE_WIDTH = 256;
export const SLIDE_IMAGE_HEIGHT = 256;
export const SLIDE_IMAGE_RADIUS = 128;
export const THUMBNAIL_PADDING_TOP = 0;
export const THUMBNAIL_PADDING_BOTTOM = 0;
export const SLIDE_TEXT_COLOR = 'white';
export const SLIDE_WIDTH = 360;
export const ITEM_WIDTH = 256;
export const AUTO_PLAY_DELAY = 300;
export const LAYOUT_TYPE = 'default';
export const FIRST_ITEM = 0;
export const AUTO_PLAY = false;
export const ITEM_PADDING = 10;
export const ITEM_SUB_VALUE = 20;
export const BACKGROUND_DEFAULT = 'transparent';
export const BACKGROUND_ACTIVE = '#3bafda';
// Home View
export const HOME_IMAGE_WIDTH_HEIGHT = 50;
export const HOME_WIDTH_BOTTOM = 50;
export const HOME_RADIUS_IMAGE_BOTTOM = 50;
export const HOME_BOTTOM_VIEW_COLOR = '#3bafda';
export const WIDTH_ITEM_TOPIC = 150;
export const WIDTH_ITEM_GAME = 100;
export const HEIGHT_ITEM_TOPIC = 150;
export const HEIGHT_ITEM_GAME = 100;
export const WIDTH_ITEM_SILE_TOPIC = 150;
export const WIDTH_ITEM_SILE_GAME = 100;
export const RADIUS_TOPIC = 75;
export const RADIUS_GAME = 50;
export const GAME_LIST = [{
	id: 1,
    thumbnail: "asset:/images/vocabulary.png",
    title: "Vocabulary",
}, {
	id: 2,
    thumbnail: "asset:/images/vocabulary_flashcard.png",
    title: "Flash Card",
}, {
	id: 3,
		thumbnail: "asset:/images/vocabulary_findImage.png",
    title: "Find Image",
}, {
	id: 4,
    thumbnail: "asset:/images/vocabulary_listen.png",
    title: "Listen",
}, {
	id: 5,
		thumbnail: "asset:/images/vocabulary_quiz.png",
    title: "Quizzes",
}];

//Flash Card
export const DISPLAY_FRONT_CARD_STRING = "Display Front Of Card:";
export const AUTO_PLAY_STRING = "Auto Play Card:";
export const AUTO_FLIP_STRING = "Auto Flip Card:";
export const RANDOM_STRING = "Random Card:";
export const OK_STRING = "Ok";
export const CLOSE_STRING = "Close";

export const KHONG_DU_TU = "The number of words must be more than one to use this function";
export const TOUCH_TO_FLIP = "Touch To Flip Card";
export const CARD_KNOWN = "Known";
export const CARD_REMAIN = "Remain";
export const UN_KNOWN = "Unknown";
export const TIMER_SETTING = "Timer";
//
export const FLASH_CARD_RESULT = "Very good!!! you have finished this part, please choose other game to play";
export const STORE_URL = "https://play.google.com/store/apps/details?id=tienjoneey.com.jlpt";
