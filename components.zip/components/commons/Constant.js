// Slide config
export const SLIDE_IMAGE_WIDTH = 256;
export const SLIDE_IMAGE_HEIGHT = 256;
export const SLIDE_IMAGE_RADIUS = 128;
export const THUMBNAIL_PADDING_TOP = 0;
export const THUMBNAIL_PADDING_BOTTOM = 0;
export const SLIDE_TEXT_COLOR = 'white';
export const SLIDE_WIDTH = 360;
export const ITEM_WIDTH = 256;
export const AUTO_PLAY_DELAY = 300;
export const LAYOUT_TYPE = 'default';
export const FIRST_ITEM = 0;
export const AUTO_PLAY = false;
export const ITEM_PADDING = 10;
export const ITEM_SUB_VALUE = 20;
export const BACKGROUND_DEFAULT = 'white';
export const BACKGROUND_ACTIVE = 'black';
//export const AUTO_PLAY = 256;
