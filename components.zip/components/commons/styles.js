import { StyleSheet, Dimensions } from 'react-native';

const deviceWidth = Dimensions.get('window').width;
import {
	SLIDE_TEXT_COLOR,
	SLIDE_IMAGE_WIDTH,
	SLIDE_IMAGE_HEIGHT,
	SLIDE_IMAGE_RADIUS,
	THUMBNAIL_PADDING_TOP,
	THUMBNAIL_PADDING_BOTTOM,
	CAROUSEL_BACKGROUND,
} from './Constant.js'
export default StyleSheet.create({
  slideText: {
    color: SLIDE_TEXT_COLOR,
    justifyContent: 'center',
  },

  ThumbnailBackgroundView: {
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: THUMBNAIL_PADDING_TOP,
    paddingBottom: THUMBNAIL_PADDING_BOTTOM,
  },
  CarouselBackgroundView: {
    width: deviceWidth,
  },
});

