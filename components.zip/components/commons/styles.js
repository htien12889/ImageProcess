import { StyleSheet, Dimensions } from 'react-native';

const deviceWidth = Dimensions.get('window').width;
import {
	SLIDE_TEXT_COLOR,
	SLIDE_IMAGE_WIDTH,
	SLIDE_IMAGE_HEIGHT,
	SLIDE_IMAGE_RADIUS,
	THUMBNAIL_PADDING_TOP,
	THUMBNAIL_PADDING_BOTTOM,
	CAROUSEL_BACKGROUND,HOME_WIDTH_BOTTOM, HOME_BOTTOM_VIEW_COLOR,
  HOME_IMAGE_WIDTH_HEIGHT, HOME_RADIUS_IMAGE_BOTTOM
} from './Constant.js'
export default StyleSheet.create({
  slideText: {
    color: SLIDE_TEXT_COLOR,
    fontSize: 17,
    justifyContent: 'center',
		fontWeight: 'bold',
    textAlign: 'center',
  },

  ThumbnailBackgroundView: {
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: THUMBNAIL_PADDING_TOP,
    paddingBottom: THUMBNAIL_PADDING_BOTTOM,
  },
  CarouselBackgroundView: {
    width: deviceWidth,
  },
  bottomViewHome: {
    height: HOME_WIDTH_BOTTOM, 
    backgroundColor: HOME_BOTTOM_VIEW_COLOR, 
    justifyContent: 'center', 
    alignItems: 'center'
  },
  bottomButtonViewHome: {
    width: HOME_IMAGE_WIDTH_HEIGHT, 
    height: HOME_IMAGE_WIDTH_HEIGHT, 
    borderRadius: HOME_RADIUS_IMAGE_BOTTOM
  },
  bottomImageViewHome: {
    width: HOME_IMAGE_WIDTH_HEIGHT, 
    height: HOME_IMAGE_WIDTH_HEIGHT
  }
});
