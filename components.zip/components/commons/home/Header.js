/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View
} from 'react-native';

export default class Header extends Component<Props> {
  render() {
    return (
      <View style={styles.container} >
      	<View style={styles.backMenuStyle}>
          <Text style={styles.headerText}>Back</Text>
        </View>

      	<View style={styles.contentStyle} >

        </View>

      	<View style={styles.backMenuStyle} >
          <Text style={styles.headerText}>Menu</Text>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    height: 50,
    justifyContent: 'space-between',
    backgroundColor: '#4fc1e9',
  },
  backMenuStyle: {
    width: 80,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerText: {
    fontSize: 20,
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center'
  },
});
