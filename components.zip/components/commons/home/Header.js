/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View, Image, TouchableOpacity, TextInput, Dimensions
} from 'react-native';
var {height, width} = Dimensions.get('window');
export default class Header extends Component<Props> {
  render() {
    return (
      <View style={styles.container} >
      	<View style={styles.backMenuStyle}>
        
        </View>

      	<TouchableOpacity style={styles.contentStyle} onPress={() => {this.props.search()}}>
          <TextInput
             style={styles.TextInputStyleClass}
             onFocus={() => {this.props.search()}}
             //onChangeText={(text) => this.props.SearchFilterFunction(text)}
             placeholderTextColor={'#FFF'}
             //value={this.state.text}
             underlineColorAndroid='transparent'
             placeholder="Search Words"
          />
        </TouchableOpacity>

      	<TouchableOpacity style={styles.backMenuStyle} >
          <Image style={{width: 30, height: 30}} source={require("../../assets/settings.png")} />
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    height: 50,
    justifyContent: 'space-between',
    backgroundColor: '#4fc1e9',
  },
  contentStyle: {
    width: width - 100,
    height: 50,
    justifyContent: 'center',
  },
  TextInputStyleClass: {
    textAlign: 'center',
    color: '#989fa9',
    height: 38,
    borderWidth: 1,
    borderColor: '#2d9ed0',
    borderRadius: 7 ,
    backgroundColor : "#3bafda",
    margin: 10
  },
  backMenuStyle: {
    width: 50,
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerText: {
    fontSize: 20,
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center'
  },
});
