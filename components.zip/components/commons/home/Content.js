/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  View,
  Text
} from 'react-native';
import SlideComponent from '../Slide.js';
export default class Content extends Component<Props> {
  constructor(props){
    super();
  }
  render() {
    return (
      <View style={styles.container} >
      	<View style={styles.header}>
          <Text style={styles.headerText}>Topics</Text> 
        </View>
        <View style={styles.slide}>
          <SlideComponent 
            widthItem={this.props.widthItem}
            heightItem={this.props.heightItem} 
            widthItemSlide={this.props.widthItemSlide} 
            radius={this.props.radius}/>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1.5,
    backgroundColor: 'red',
  },
  header: {
    height: 30,
    paddingLeft: 10,
    justifyContent: 'center',
    backgroundColor: 'green',
  },
  headerText: {
    fontSize: 20,
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'left'
  },
  slide: {
    flex: 1,
    justifyContent: 'center',
  }
});