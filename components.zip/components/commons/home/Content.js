/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  View,
  Text, TouchableOpacity, Image
} from 'react-native';
import SlideComponent from '../Slide.js';
export default class Content extends Component<Props> {
  constructor(props){
    super(props);
  }
  render() {
    return (
      <View style={styles.container} >
        <TouchableOpacity onPress={() => {this.props.reviewClick()}} style={{borderColor: 'white', borderWidth: 1, borderRadius: 25, width: 28, height: 28, position: 'absolute', top: 3, right: 10, backgroundColor: '#a0d468', zIndex: 9999, justifyContent: 'center'}}>
          <View style={{width: 28, flexDirection: 'row', justifyContent: 'center', marginLeft: -1}}>
            <Image style={styles.bottomImageViewHome} source={require("../../assets/star.png")} />
          </View>
        </TouchableOpacity>
      	<View style={styles.header}>
          <Text style={styles.headerText}>Topics</Text>
        </View>
        <View style={styles.slide}>
          <SlideComponent
            ref="content"
            widthItem={this.props.widthItem}
            heightItem={this.props.heightItem}
            widthItemSlide={this.props.widthItemSlide}
            radius={this.props.radius}
            firstItem={this.props.firstItem}
            slideDatas={this.props.slideDatas}
            updateData={(value) => {this.props.updateData(value)}}/>
        </View>
      </View>
    );
  }
  contentRender(value) {
    console.log("ACBD");
    this.refs.content.contentRender(value);
  }
}

const styles = StyleSheet.create({
  bottomImageViewHome: {
    width: 20,
    height: 20,
  },
  container: {
    flex: 1.5,
    backgroundColor: '#4fc1e9',
  },
  header: {
    height: 35,
    justifyContent: 'center',
    backgroundColor: '#3bafda',
  },
  headerText: {
    fontSize: 20,
    color: 'white',
    textAlign: 'center'
  },
  slide: {
    flex: 1,
    justifyContent: 'center',
  }
});
