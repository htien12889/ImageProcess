/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  View, TouchableOpacity, Image, Text, ScrollView
} from 'react-native';
import HeaderWordContent from './HeaderWordContent.js';
import {db1} from '../Constant.js';
export default class WordContent extends Component<Props> {
  constructor(props) {
    super(props);
    this.state = {
      datas: this.props.datas,
      isContent: false,
    }
  }

  render() {
    if(this.state.isContent) {
      var favorit_image = require("../../assets/favorit_true.png");
      if(this.state.datas.is_love) {
        favorit_image = require("../../assets/favorit_true.png");
      } else {
        favorit_image = require("../../assets/favorit_false.png");
      }
      return (
        <View style={{flex: 1}}>
          <HeaderWordContent title={this.state.datas.en_us} background={'#3bafda'} back={() => {this.props.back();}}/>
          <View style={styleVoca.image}>
            <TouchableOpacity style={styleVoca.favorit} onPress={() => {this.updateLove(this.state.datas)}}>
              <Image style={{width: 25, height: 25}} source={favorit_image} />
            </TouchableOpacity>
            <Image style={{flex: 1, resizeMode: 'contain'}} source={{ uri: "http://data.minder.vn/Japanese/104000002/images/words/104000632.jpg" }} />
          </View>
          <View style={styleVoca.content}>
            <TouchableOpacity style={styleVoca.reader} onPress={() => {this.readWord()}}>
              <Image style={{width: 25, height: 25}} source={require("../../assets/reader.png")} />
            </TouchableOpacity>
            <ScrollView showsVerticalScrollIndicator={true} style={{flex: 1}}>
              {this.renderWord(this.state.datas)}
              {this.renderPR(this.state.datas)}
              {this.renderMean(this.state.datas)}
              {this.renderExample(this.state.datas)}
            </ScrollView>
          </View>
        </View>
      );
    } else {
      return(
        <View></View>
      );
    }
    
  }
  renderPR(item) {
    if(item.en_us_pr != '') {
      return(
        <Text style={styleVoca.word}>[{item.en_us_pr}]</Text>
      );
    }
  }
  renderWord(item){
    if(item.en_us_type != '') {
      return(
        <Text style={styleVoca.word}>{item.en_us} ({item.en_us_type})</Text>
      );
    } else {
      return(
        <Text style={styleVoca.word}>{item.en_us}</Text>
      );
    }
  }
  renderMean(item) {
    if(item.en_us_mean != '') {
      return(
        <View>
          <Text style={styleVoca.meanSpecial}>Mean: </Text>
          <Text style={styleVoca.mean}>{item.en_us_mean}</Text>
        </View>
      );
    }
  }
  renderExample(item) {
    if(item.en_us_ex != '') {
      var example = item.en_us_ex.replace("<br>", "\n");
      var example_len = example.split('<br>').length;
      for(let i = 0; i < example_len; i++) {
        example = example.replace("<br>", "\n");
      }
      return(
        <View>
          <Text style={styleVoca.meanSpecial}>Example: </Text>
          <Text style={styleVoca.example}>{example}</Text>
        </View>
      );
    }
  }
  resetResult(value) {
    this.setState({
      datas: value,
      isContent: true,
    });
  }
  updateGameType(value){
    this.gameType = value;
  }
  updateLove(value){
    //console.log("hello abcdef");
      var dataTemp = value;
      var isFavorite = value.is_love;
      var idItem = value.id;
      if(isFavorite) {
        dataTemp.is_love = !dataTemp.is_love;
        let sql = "DELETE FROM `folder` WHERE vocabulary_id="+idItem;
        console.log(sql);
        db1.transaction((tx) => {
          tx.executeSql(sql, [], (tx, results) => {
            this.setState({
              datas: dataTemp,
            });
          });
        });
      } else {
        dataTemp.is_love = !dataTemp.is_love;
        let sql = "INSERT INTO folder (`vocabulary_id`) VALUES ('"+idItem+"')";
        console.log(sql);
        db1.transaction((tx) => {
          tx.executeSql(sql, [], (tx, results) => {
            this.setState({
              datas: dataTemp,
            });
          });
        });
      }
  }
  playGame(){
    this.props.reloadMain(this.gameType);
  }
}



const styleVoca = StyleSheet.create({
  CarouselBackgroundView: {
    flex: 1,
    backgroundColor: '#4fc1e9',
  },
  meanSpecial: {
    color: '#333',
    fontSize: 17,
    fontWeight: 'bold',
    textDecorationLine: "underline",
    fontStyle: 'italic',
  },
  continer: {
    flex: 1,
  },
  image: {
    flex: 1.3,
    backgroundColor: 'white',
    borderRadius: 10,
    marginLeft: 5,
    marginRight: 5,
    marginTop: 5,
    marginBottom: 5,
  },
  content: {
    flex: 1,
    backgroundColor: 'white',
    borderRadius: 10,
    marginLeft: 5,
    marginRight: 5,
    padding: 10,
    justifyContent: 'center',
    marginBottom: 10,
  },
  word: {
    color: 'black',
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  mean: {
    color: '#333',
    fontSize: 13,
  },
  example: {
    color: '#333',
    fontSize: 13,
  },
  reader: {
    width: 25,
    height: 25,
    position: 'absolute',
    top: 10,
    right: 10,
    zIndex: 99,
  },
  favorit: {
    width: 25,
    height: 25,
    position: 'absolute',
    top: 10,
    right: 10,
    zIndex: 999,
  }
});
