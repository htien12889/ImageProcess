/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  View,
  Text
} from 'react-native';
import GameSlide from '../GameSlide.js';
export default class Game extends Component<Props> {
  constructor(props){
    super();
  }
  render() {
    return (
      <View style={styles.container} >
      	<View style={styles.header}>
          <Text style={styles.headerText}>Games</Text>
        </View>
        <View style={styles.slide}>
          <GameSlide
            ref="gameSlide"
            widthItem={this.props.widthItem}
            heightItem={this.props.heightItem}
            widthItemSlide={this.props.widthItemSlide}
            gamePercent={this.props.gamePercent}
            radius={this.props.radius}
            firstItem={this.props.firstItem}
            slideDatas={this.props.slideDatas}
            updateDataGame={(value) => {this.props.updateDataGame(value)}}/>
        </View>
      </View>
    );
  }
  renderGames(gamePercent){
    this.refs.gameSlide.renderSlide(gamePercent);
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#4fc1e9',
  },
  header: {
    height: 30,
    justifyContent: 'center',
    backgroundColor: '#3bafda',
  },
  headerText: {
    fontSize: 20,
    color: 'white',
    textAlign: 'center',
  },
  slide: {
    flex: 1,
    justifyContent: 'center',
  }
});
