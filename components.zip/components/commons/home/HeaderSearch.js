/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View, Image, TouchableOpacity, TextInput, Dimensions, StatusBar, Animated
} from 'react-native';

import {
  db, db1
} from '../Constant.js';
import WordContent from './WordContent.js';
var {height, width} = Dimensions.get('window');
import SegmentedControlTab from 'react-native-segmented-control-tab';
import WordsList from './WordsList.js';
export default class HeaderSearch extends Component<Props> {
  constructor(props) {
    super(props);
    this.serchText = "";
    this.datas = [];
    this.dataContent = [];
    this.state = {
      overlayOpacity: 0,
      activeMenu: 0,
      marginSlide: new Animated.Value(0),
    };
  }
  render() {
    return (
      <Animated.View style={{marginLeft: this.state.marginSlide, flex: 1, flexDirection: 'row', width: 2 * width, height: height - StatusBar.currentHeight}}>
        <View style={{backgroundColor: '#3bafda', width: width, height: height - StatusBar.currentHeight}}>
          <View style={styles.container} >
            <View style={styles.contentStyle}>
              <TextInput
                style={styles.TextInputStyleClass}
                onChangeText={(text) => this.SearchFilterFunction(text)}
                placeholderTextColor={'#AFAFAF'}
                //value={this.state.text}
                underlineColorAndroid='transparent'
                placeholder="Search Words"/>
              <TouchableOpacity onPress={() => {this.queryDatas()}} style={{width: 38, height: 38, backgroundColor: '#AFAFAF', marginRight: 10, borderRadius: 3, borderWidth: 1, borderColor: '#AFAFAF'}}>
                <Image style={{width: 38, height: 38}} source={require("../../assets/search.png")} />
              </TouchableOpacity>
              <View style={{justifyContent: 'center'}}>
                <TouchableOpacity onPress={() => {this.props.back()}} style={{marginLeft: 5,marginRight: 10}}>
                  <Text style={{color: 'white', fontSize: 17, textAlign: 'center'}}>Cancle</Text>
                </TouchableOpacity>
              </View>
              
            </View>
          </View>
          {this.renderMenu()}
          {this.renderWordList()}
        </View>
        <View style={{backgroundColor: '#4fc1e9', width: width, height: height - StatusBar.currentHeight}}>
          <WordContent 
            back={() => {this.back()}}
            datas={this.dataContent}
            ref="wordContent"/>
        </View>
      </Animated.View>
    );
  }
  queryDatas(){
    var favoriteIDs = [];
    db1.transaction((tx) => {
      tx.executeSql("SELECT * FROM folder", [], (tx, results) => {
        for (let i = 0; i < results.rows.length; i++) {
          favoriteIDs[i] = results.rows.item(i).vocabulary_id;
        }
        this.getDatasSearch(favoriteIDs, false);
      });
    });
  }
  getDatasSearch(favoriteIDs, isFavorite){
    var text = this.serchText;
    if(text == "") {
      var array = [];
      this.refs.wordsList.resetResult(array);
    } else {
      db.transaction((tx) => {
        tx.executeSql("SELECT * FROM vocabularies WHERE status='1' and en_us like '%"+text+"%'", [], (tx, results) => {
          var array = [];
          var len = results.rows.length;
          for (let i = 0; i < len; i++) {
            var is_love = false;
            if(!isFavorite) {
              for(let l = 0; l < favoriteIDs.length; l++) {
                if(favoriteIDs[l] == results.rows.item(i).id) {
                  is_love = true;
                  break;
                }
              }
            } else {
              is_love = true;
            }
            array[i] = {
              id: results.rows.item(i).id,
              thumbnail: "http://vnsupa.com/hoangtien/images/" + results.rows.item(i).image,
              en_us: results.rows.item(i).en_us.charAt(0).toUpperCase() + results.rows.item(i).en_us.slice(1),
              en_us_type: results.rows.item(i).en_us_type,
              en_us_pr: results.rows.item(i).en_us_pr, 
              en_us_audio: "http://data.minder.vn/Japanese/104000002/audios/104000632.mp3",
              //en_us_audio: results.rows.item(i).en_us_audio,
              en_us_mean: results.rows.item(i).en_us_mean,
              en_us_ex: results.rows.item(i).en_us_ex,
              is_love: is_love,
            }
          }
          this.datas = array;
          this.refs.wordsList.resetResult(array);
        });
      });
    }
  }
  SearchFilterFunction(text){
    this.serchText = text;
  }
  renderWordList(){
    if(this.state.activeMenu == 0) {
      return(
        <WordsList 
          ref="wordsList"
          datas={this.datas}
          showContent={(value) => {this.showContent(value)}}
        />
      );
    } else {

    }
  }
  showContent(value) {
    this.dataContent = value;
    this.refs.wordContent.resetResult(value);
    Animated.timing(
      this.state.marginSlide,
      {
        toValue: -width,
        duration: 250,
      }
    ).start();
  }
  back(){
    this.queryDatas();
    Animated.timing(
      this.state.marginSlide,
      {
        toValue: 0,
        duration: 250,
      }
    ).start();
  }
  renderMenu(){
    if(this.state.activeMenu == 0) {
      return(
        <View style={{flexDirection: 'row'}}>
          <TouchableOpacity style={[styles.menuTop, {borderColor: '#FFFF8D'}]} onPress={() => {this.wordChoosen()}}>
            <Text style={[styles.menuTopText, {color: 'white'}]}>WORDS</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.menuTop} onPress={() => {this.topicChoosen()}}>
            <Text style={styles.menuTopText}>TOPICS</Text>
          </TouchableOpacity>
        </View>
      );
    } else {
      return(
        <View style={{flexDirection: 'row'}}>
          <TouchableOpacity style={styles.menuTop} onPress={() => {this.wordChoosen()}}>
            <Text style={styles.menuTopText}>WORDS</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.menuTop, {borderColor: '#FFFF8D'}]} onPress={() => {this.topicChoosen()}}>
            <Text style={[styles.menuTopText, {color: 'white'}]}>TOPICS</Text>
          </TouchableOpacity>
        </View>
      );
    }
  }
  wordChoosen(){
    this.setState({
      activeMenu: 0,
    });
  }
  topicChoosen(){
    this.setState({
      activeMenu: 1,
    });
  }
}

const styles = StyleSheet.create({
  menuTop: {
    flex: 1,
    paddingTop: 5, 
    paddingBottom: 10,
    borderBottomWidth: 2,
    borderColor: '#3bafda',
  },
  menuTopText: {
    fontSize: 15,
    color: '#A7E8F0',
    textAlign: 'center',
    fontWeight: 'bold',
  }, 
  container: {
    flexDirection: 'row',
    height: 50,
    justifyContent: 'space-between',
    backgroundColor: '#3bafda',
  },
  contentStyle: {
    flex: 1,
    flexDirection: 'row',
    height: 38,
    justifyContent: 'center',
    marginTop: 10,
  },
  TextInputStyleClass: {
    paddingLeft: 10,
    color: '#AFAFAF',
    //height: 38,
    flex: 1,
    borderWidth: 1,
    borderColor: '#AFAFAF',
    borderRadius: 3,
    backgroundColor : "white",
    margin: 10,
    marginTop: 0,
    marginBottom: 0,
    marginRight: 0,
  },
  buttonText: {
    color: 'white',
    fontSize: 15,
  },
  backMenuStyle: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingLeft: 5,
    paddingRight: 5,
    borderRadius: 5, 
    marginRight: 5,
    borderWidth: 1,
    borderColor: 'white'
  },
  headerText: {
    fontSize: 20,
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center'
  },
});
