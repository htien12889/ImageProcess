/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View, Image, TouchableOpacity, TextInput, Dimensions
} from 'react-native';
var {height, width} = Dimensions.get('window');
import SegmentedControlTab from 'react-native-segmented-control-tab';
export default class HeaderSearch extends Component<Props> {
  render() {
    return (
      <View style={{height: 100, backgroundColor: '#4fc1e9'}}>
        <View style={styles.container} >
          <TouchableOpacity style={styles.contentStyle}>
            <TextInput
              style={styles.TextInputStyleClass}
              onFocus={() => {this.props.search()}}
              //onChangeText={(text) => this.props.SearchFilterFunction(text)}
              placeholderTextColor={'#FFF'}
              //value={this.state.text}
              underlineColorAndroid='transparent'
              placeholder="Search Words"
            />
          </TouchableOpacity>
          <View style={{justifyContent: 'center'}}>
            <View style={{justifyContent: 'center', height: 35, width: 80}}>
              <TouchableOpacity style={[styles.backMenuStyle, {backgroundColor: '#3bafda'}]} >
                <Text style={styles.buttonText}>Go</Text>
              </TouchableOpacity>
            </View>
          </View>
          
          <View style={{justifyContent: 'center'}}>
            <View style={{justifyContent: 'center', height: 35, width: 80}}>
              <TouchableOpacity style={[styles.backMenuStyle, {backgroundColor: '#ed5565'}]} >
                <Text style={styles.buttonText}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
        <View style={{marginLeft: 10, marginRight: 10}}>
          <SegmentedControlTab
            values={['Word', 'Topic']}
            selectedIndex={0}
            onTabPress={this.handleIndexChange}
          />
        </View>
      </View>
      
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    height: 50,
    justifyContent: 'space-between',
    backgroundColor: '#4fc1e9',
  },
  contentStyle: {
    flex: 2,
    height: 50,
    justifyContent: 'center',
  },
  TextInputStyleClass: {
    textAlign: 'center',
    color: '#989fa9',
    height: 38,
    borderWidth: 1,
    borderColor: '#2d9ed0',
    borderRadius: 7 ,
    backgroundColor : "#3bafda",
    margin: 10
  },
  buttonText: {
    color: 'white',
    fontSize: 15,
  },
  backMenuStyle: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingLeft: 5,
    paddingRight: 5,
    borderRadius: 5, 
    marginRight: 5,
    borderWidth: 1,
    borderColor: 'white'
  },
  headerText: {
    fontSize: 20,
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center'
  },
});
