/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  View, TouchableOpacity, Image, Text, ScrollView
} from 'react-native';
import {db1} from '../Constant.js';
var Sound = require('react-native-sound');
export default class WordsList extends Component<Props> {
  constructor(props) {
    super(props);
    this.state = {
      datas: this.props.datas,
    }
  }

  render() {
    if(this.state.datas.length > 0) {
      return(
        <View style={{flex: 1, backgroundColor: '#4fc1e9'}}>
          <ScrollView style={styless.scrollView}>
            {this.state.datas.map((prop, key) => {
              var favorit_image = require("../../assets/favorit_true.png");
              if(prop.is_love) {
                favorit_image = require("../../assets/favorit_true.png");
              } else {
                favorit_image = require("../../assets/favorit_false.png");
              }
              return (
                <TouchableOpacity key={key} style={styless.scrollViewContent} onPress={() => {this.props.showContent(prop)}}>
                  <View style={styless.scrollViewContentText}>
                    <Image style={{resizeMode: 'contain', width: 50, height: 50, borderRadius: 5, backgroundColor: '#ffffff' }} source={{ uri: prop.thumbnail }} />
                    <View>
                      <Text style={styless.scrollViewContentTextContent}>{prop.en_us}</Text>
                      <Text style={styless.scrollViewContentTextContentRe}>[{prop.en_us_pr}]</Text>
                    </View>
                  </View>
                  <View style={{justifyContent: 'center', flexDirection: 'row'}}>
                    <View style={{justifyContent: 'center', marginRight: 15}}>
                      <TouchableOpacity onPress={() => {this.reader(prop)}} style={styless.scrollViewContentImage}>
                        <Image style={styless.favoriteContent} source={require("../../assets/alound.png")} />
                      </TouchableOpacity>
                    </View>
                    <View style={{justifyContent: 'center', marginRight: 5}}>
                      <TouchableOpacity onPress={() => {this.updateLove(prop, key)}} style={styless.scrollViewContentImage}>
                        <Image style={styless.favoriteContent} source={favorit_image} />
                      </TouchableOpacity>
                    </View>
                  </View>
                </TouchableOpacity>
              );
            })}
          </ScrollView>
        </View>
      );
    } else {
      return(
        <View style={{flex: 1, backgroundColor: '#4fc1e9', justifyContent: 'center'}}>
          <Text style={{fontSize: 20, color: 'white', textAlign: 'center' }}>Your search did not match any words</Text>
        </View>
      );
    }
  }
  reader(prop) {
    var file_name = prop.en_us_audio;
    const track = new Sound(file_name, null, (e) => {
      if (e) {
        console.log('error loading track:', e)
      } else {
        track.play((success) => {
          if (success) {
            console.log('successfully finished playing');
          } else {
            console.log('playback failed due to audio decoding errors');
            // reset the player to its uninitialized state (android only)
            // this is the only option to recover after an error occured and use the player again
            //track.release();
          }
          track.release();
        });
      }
    })
  }
  resetResult(value) {
    this.setState({
      datas: value,
    });
  }
  updateGameType(value){
    this.gameType = value;
  }
  updateLove(value, index){
    //console.log("hello abcdef");
      var dataTemp = this.state.datas;
      var isFavorite = value.is_love;
      var idItem = value.id;
      if(isFavorite) {
        dataTemp[index].is_love = !dataTemp[index].is_love;
        let sql = "DELETE FROM `folder` WHERE voc_id="+idItem;
        console.log(sql);
        db1.transaction((tx) => {
          tx.executeSql(sql, [], (tx, results) => {
            this.setState({
              datas: dataTemp,
            });
          });
        });
      } else {
        dataTemp[index].is_love = !dataTemp[index].is_love;
        let sql = "INSERT INTO folder (`voc_id`) VALUES ('"+idItem+"')";
        console.log(sql);
        db1.transaction((tx) => {
          tx.executeSql(sql, [], (tx, results) => {
            this.setState({
              datas: dataTemp,
            });
          });
        });
      }
  }
  playGame(){
    this.props.reloadMain(this.gameType);
  }
}

const styless = StyleSheet.create({
  subHeader: {
    height: 30,
    justifyContent: 'center',
    backgroundColor: '#3bafda',
  },
  subHeaderTest: {
    fontSize: 20,
    color: 'white',
    textAlign: 'center'
  },
  scrollView: {
    flex: 3
  },
  scrollViewContent: {
    flexDirection: 'row',
    padding: 10,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderBottomColor: '#2ea5dd',
    borderTopColor: '#75d2f0',
    backgroundColor: '#4fc1e9',
  },
  scrollViewContentText: {
    flex: 1,
    flexDirection: 'row',
  },
  scrollViewContentTextContent: {
    fontSize: 20,
    color: 'white',
    marginLeft: 10,
    fontWeight: 'bold',
  },
  scrollViewContentTextContentRe: {
    fontSize: 15,
    color: 'white',
    marginLeft: 10,
  },
  scrollViewContentImage: {
    width: 25,
    height: 25,
    justifyContent: 'center',
  },
  favoriteContent: {
    width: 25,
    height: 25,
  },
});
