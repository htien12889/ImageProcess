/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  View, TouchableOpacity, Image, Text, ScrollView
} from 'react-native';
import HeaderSearch from './HeaderSearch.js';

export default class SearchPage extends Component<Props> {
  constructor(props) {
    super(props);
    this.gameType = this.props.gameType;
    console.log(this.gameType);
    this.state = {
      datas: this.props.datas,
    }
  }

  render() {
    return(
      <View style={{flex: 1, backgroundColor: '#3bafda'}}>
        <HeaderSearch 
          ref="mainView"
          title={this.props.mainTitle} 
          background={'black'} 
          reloadMain={(value1, value2) => {this.props.reloadMain(value1, value2)}}
          back={() => {this.props.back()}}/>
        
      </View>
    );
  }
  reRender(){
    this.refs.mainView.reRenderView();
  }
  resetResult(value) {
    this.setState({
      datas: value,
    });
  }
  updateGameType(value){
    this.gameType = value;
  }
  updateLove(value, index){
    //console.log("hello abcdef");
      var dataTemp = this.state.datas;
      var isFavorite = value.is_love;
      var idItem = value.id;
      if(isFavorite) {
        dataTemp[index].is_love = !dataTemp[index].is_love;
        let sql = "DELETE FROM `folder` WHERE voc_id="+idItem;
        console.log(sql);
        db1.transaction((tx) => {
          tx.executeSql(sql, [], (tx, results) => {
            this.setState({
              datas: dataTemp,
            });
          });
        });
      } else {
        dataTemp[index].is_love = !dataTemp[index].is_love;
        let sql = "INSERT INTO folder (`voc_id`) VALUES ('"+idItem+"')";
        console.log(sql);
        db1.transaction((tx) => {
          tx.executeSql(sql, [], (tx, results) => {
            this.setState({
              datas: dataTemp,
            });
          });
        });
      }
  }
  playGame(){
    this.props.reloadMain(this.gameType);
  }
}

const styless = StyleSheet.create({
  subHeader: {
    height: 30,
    justifyContent: 'center',
    backgroundColor: '#3bafda',
  },
  subHeaderTest: {
    fontSize: 20,
    color: 'white',
    textAlign: 'center'
  },
  scrollView: {
    flex: 3
  },
  scrollViewContent: {
    flexDirection: 'row',
    padding: 10,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderBottomColor: '#2ea5dd',
    borderTopColor: '#75d2f0',
    backgroundColor: '#4fc1e9',
  },
  scrollViewContentText: {
    flex: 1,
    flexDirection: 'row',
  },
  scrollViewContentTextContent: {
    fontSize: 20,
    color: 'white',
    marginLeft: 10,
    fontWeight: 'bold',
  },
  scrollViewContentTextContentRe: {
    fontSize: 15,
    color: 'white',
    marginLeft: 10,
  },
  scrollViewContentImage: {
    width: 25,
    height: 25,
    justifyContent: 'center',
  },
  favoriteContent: {
    width: 25,
    height: 25,
  },
});