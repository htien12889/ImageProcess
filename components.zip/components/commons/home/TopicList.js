/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  View, TouchableOpacity, Image, Text, ScrollView
} from 'react-native';
import {
  WIDTH_ITEM_TOPIC, WIDTH_ITEM_GAME, HEIGHT_ITEM_TOPIC,
  HEIGHT_ITEM_GAME, WIDTH_ITEM_SILE_TOPIC, WIDTH_ITEM_SILE_GAME,
  RADIUS_TOPIC, RADIUS_GAME, GAME_LIST
} from '../Constant.js';
import styles from '../styles.js';
import Game from './Game.js';
export default class TopicList extends Component<Props> {
	constructor(props) {
		super(props);
		this.gameType = this.props.gameType;
		console.log(this.gameType);
		this.state = {
			datas: this.props.datas,
			chooseIndex: this.props.chooseIndex,
		}
	}

	render() {
		console.log(this.state.chooseIndex);
		if(this.state.datas.length > 0) {
			return(
				<View style={{flex: 1, backgroundColor: '#4fc1e9', borderTopWidth: 1, borderColor: '#6fd0ef'}}>
					<View style={styless.subHeader}>
						<Text style={styless.subHeaderTest}>{this.props.title}</Text>
					</View>
					<ScrollView style={styless.scrollView}>
						{this.state.datas.map((prop, key) => {
				          //console.log(prop);
				          	if(key == this.state.chooseIndex) {
				          		return (
									<TouchableOpacity key={key} style={[styless.scrollViewContent, {backgroundColor: '#3bafda'}]} onPress={() => {this.updateChooseIndex(key)}}>
										<View style={styless.scrollViewContentText}>
											<Image style={{resizeMode: 'contain', width: 50, height: 50}} source={{ uri: prop.thumbnail }} />
											<View style={{justifyContent: 'center'}}>
												<Text style={styless.scrollViewContentTextContent}>{prop.topic_name}</Text>
											</View>
										</View>
									</TouchableOpacity>
								);
				          	} else {
				          		return (
									<TouchableOpacity key={key} style={styless.scrollViewContent} onPress={() => {this.updateChooseIndex(key)}}>
										<View style={styless.scrollViewContentText}>
											<Image style={{resizeMode: 'contain', width: 50, height: 50}} source={{ uri: prop.thumbnail }} />
											<View style={{justifyContent: 'center'}}>
												<Text style={styless.scrollViewContentTextContent}>{prop.topic_name}</Text>
											</View>
										</View>
									</TouchableOpacity>
								);
				          	}

				        })}
					</ScrollView>
					<Game
						style={{flex: 1}}
			            widthItem={WIDTH_ITEM_GAME}
			            heightItem={HEIGHT_ITEM_GAME}
			            widthItemSlide={WIDTH_ITEM_SILE_GAME}
			            radius={RADIUS_GAME}
			            slideDatas={GAME_LIST}
			            firstItem={this.gameType - 1}
			            updateData={(value) => {this.updateGameType(value)}}/>
			        <View style={styles.bottomViewHome}>
						<TouchableOpacity style={styles.bottomButtonViewHome} onPress={() => {this.playGame()}}>
							<Image style={styles.bottomImageViewHome} source={require("../../assets/play.png")} />
						</TouchableOpacity>
					</View>
				</View>
			);
		} else {
			return(
		        <View style={{flex: 1, backgroundColor: '#4fc1e9', justifyContent: 'center'}}>
		          <Text style={{fontSize: 20, color: 'white', textAlign: 'center' }}>Your search did not match any topics</Text>
		        </View>
		      );
		}
	}
	updateChooseIndex(key) {
		this.setState({
			chooseIndex: key
		});
	}
	resetResult(value) {
		this.setState({
			datas: value,
		});
	}
	updateGameType(value){
		this.gameType = value;
	}

	playGame(){
		console.log(this.gameType);
		this.props.reloadMain(this.state.datas[this.state.chooseIndex].id, this.gameType);
	}
}

const styless = StyleSheet.create({
  subHeader: {
    height: 30,
    justifyContent: 'center',
    backgroundColor: '#3bafda',
  },
  subHeaderTest: {
    fontSize: 20,
    color: 'white',
    textAlign: 'center'
  },
  scrollView: {
  	flex: 3
  },
  scrollViewContent: {
  	flexDirection: 'row',
    padding: 10,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderBottomColor: '#2ea5dd',
    borderTopColor: '#75d2f0',
    backgroundColor: '#4fc1e9',
  },
  scrollViewContentText: {
  	flex: 1,
  	flexDirection: 'row',
  },
  scrollViewContentTextContent: {
  	fontSize: 20,
  	color: 'white',
  	marginLeft: 10,
  	fontWeight: 'bold',
  },
  scrollViewContentTextContentRe: {
  	fontSize: 15,
  	color: 'white',
  	marginLeft: 10,
  },
  scrollViewContentImage: {
  	width: 25,
  	height: 25,
  	justifyContent: 'center',
  },
  favoriteContent: {
  	width: 25,
  	height: 25,
  },
});
