import React from 'react';
import {StackNavigator} from 'react-navigation';
import Home from './Home.js';
import Main from './Main.js';
import Result from './Result.js';
export const HomeStack = StackNavigator ({
  HomeScreens: {
    screen: Home,
    navigationOptions:{
      header: null
    }
  },
  MainScreens: {
    screen: Main,
    navigationOptions:{
      header: null
    }
  },
  ResultScreens: {
    screen: Result,
    navigationOptions:{
      header: null
    }
  },
});
