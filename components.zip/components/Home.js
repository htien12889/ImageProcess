/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  View
} from 'react-native';
import Header from './commons/home/Header.js';
import Content from './commons/home/Content.js';
import Game from './commons/home/Game.js';
export default class Home extends Component<Props> {
  render() {
    return (
      <View style={{flex: 1, backgroundColor: '#ffffff'}}>
      	<Header />
        <Content 
          widthItem={250}
          heightItem={250}
          widthItemSlide={250} 
          radius={128}/>
        <Game 
          widthItem={150}
          heightItem={150} 
          widthItemSlide={200} 
          radius={75}/>
      </View>
    );
  }
}

