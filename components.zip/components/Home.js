/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  View, TouchableOpacity, Image
} from 'react-native';
import styles from './commons/styles.js';
import {
  WIDTH_ITEM_TOPIC, WIDTH_ITEM_GAME, HEIGHT_ITEM_TOPIC,
  HEIGHT_ITEM_GAME, WIDTH_ITEM_SILE_TOPIC, WIDTH_ITEM_SILE_GAME,
  RADIUS_TOPIC, RADIUS_GAME, db, GAME_LIST
} from './commons/Constant.js';
import Header from './commons/home/Header.js';
import Content from './commons/home/Content.js';
import Game from './commons/home/Game.js';

export default class Home extends Component<Props> {
  constructor(props) {
    super(props);
    this.gameType = 1;
    this.topicID = 18;
    this.state = {
      slideDatas: [],
      gameDatas: [],
    };
    this.getDatas();
  }
  getDatas(){
    db.transaction((tx) => {
      tx.executeSql("SELECT * FROM categories WHERE parent_id<>'0' and parent_id<>'1' and status='1'", [], (tx, results) => {
        var array = [];
        var len = results.rows.length;
        let j = 0;
        for (let i = 0; i < len; i++) {
          if(results.rows.item(i).id == '1') {
            continue;
          }
          array[j] = {
            id: results.rows.item(i).id,
            thumbnail: "http://vnsupa.com/hoangtien/images/" + results.rows.item(i).image,
            title: results.rows.item(i).title,
          }
          j += 1;
        }
        this.setState({
          slideDatas: array,
          gameDatas: GAME_LIST,
        });
      });
    });
  }
  render() {
    if(this.state.slideDatas.length !== 0) {
      return (
        <View style={{flex: 1, backgroundColor: '#ffffff'}}>
          <Header />
          <Content
            widthItem={WIDTH_ITEM_TOPIC}
            heightItem={HEIGHT_ITEM_TOPIC}
            widthItemSlide={WIDTH_ITEM_SILE_TOPIC}
            radius={RADIUS_TOPIC}
            firstItem={0}
            slideDatas={this.state.slideDatas}
            updateData={(value) => {this.updateTopicType(value)}}/>
          <Game
            widthItem={WIDTH_ITEM_GAME}
            heightItem={HEIGHT_ITEM_GAME}
            widthItemSlide={WIDTH_ITEM_SILE_GAME}
            radius={RADIUS_GAME}
            firstItem={0}
            slideDatas={this.state.gameDatas}
            updateData={(value) => {this.updateGameType(value)}}/>
          <View style={styles.bottomViewHome}>
            <TouchableOpacity style={styles.bottomButtonViewHome} onPress={() => {this.playGame()}}>
              <Image style={styles.bottomImageViewHome} source={require("./assets/play.png")} />
            </TouchableOpacity>
          </View>
        </View>
      );
    } else {
      return(
        <View></View>
      );
    }
  }
  updateTopicType(value){
    this.topicID = value;
    console.log("Topic" + value);
  }
  updateGameType(value){
    this.gameType = value;
    console.log("Game" + value);
  }
  playGame(){
    this.props.navigation.navigate('MainScreens', {gameType: this.gameType, topicID: this.topicID});
  }
}
