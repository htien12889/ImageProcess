/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  View, TouchableOpacity, Image, Animated, Dimensions, StatusBar,
  Alert, Linking
} from 'react-native';
import styles from './commons/styles.js';
import {
  WIDTH_ITEM_TOPIC, WIDTH_ITEM_GAME, HEIGHT_ITEM_TOPIC,
  HEIGHT_ITEM_GAME, WIDTH_ITEM_SILE_TOPIC, WIDTH_ITEM_SILE_GAME,
  RADIUS_TOPIC, RADIUS_GAME, db, GAME_LIST
} from './commons/Constant.js';
import Header from './commons/home/Header.js';
import Content from './commons/home/Content.js';
import Game from './commons/home/Game.js';
import SearchPage from './commons/home/SearchPage.js';
const deviceWidth = Dimensions.get('window').width;
const deviceHeight = Dimensions.get('window').height;
export default class Home extends Component<Props> {
  constructor(props) {
    super(props);
    this.gameType = 1;
    this.topicID = 18;
    this.state = {
      slideDatas: [],
      gameDatas: [],
    };
    this.getDatas();
  }
  getDatas(){
    db.transaction((tx) => {
      tx.executeSql("SELECT * FROM categories WHERE parent_id<>'0' and parent_id<>'1' and status='1'", [], (tx, results) => {
        var array = [];
        var len = results.rows.length;
        let j = 0;
        for (let i = 0; i < len; i++) {
          if(results.rows.item(i).id == '1') {
            continue;
          }
          var gameArray = [];
          gameArray[0] = results.rows.item(i).game1 + i*2 + "%";
          gameArray[1] = results.rows.item(i).game2 + i*3 + "%";
          gameArray[2] = results.rows.item(i).game3 + i*4 + "%";
          gameArray[3] = results.rows.item(i).game4 + i*5 + "%";
          gameArray[4] = results.rows.item(i).game5 + i*6 + "%";
          array[j] = {
            id: results.rows.item(i).id,
            thumbnail: "asset:/images/" + results.rows.item(i).image,
            title: results.rows.item(i).title,
            gamePercent: gameArray
          }
          j += 1;
        }
        console.log(array);
        this.setState({
          marginSlide: new Animated.Value(0),
          slideDatas: array,
          gameDatas: GAME_LIST,
        });
      });
    });
  }
  render() {
    if(this.state.slideDatas.length !== 0) {
      return (
        <Animated.View style={{marginLeft: this.state.marginSlide,width: deviceWidth * 2, height: deviceHeight - StatusBar.currentHeight, backgroundColor: '#4fc1e9', flexDirection: 'row'}}>
          <View style={{width: deviceWidth, height: deviceHeight - StatusBar.currentHeight}}>
            <Header ref="header" search={() => {this.search()}}/>
            <Content
              ref="content"
              reviewClick={() => {this.reviewClick()}}
              widthItem={WIDTH_ITEM_TOPIC}
              heightItem={HEIGHT_ITEM_TOPIC}
              widthItemSlide={WIDTH_ITEM_SILE_TOPIC}
              radius={RADIUS_TOPIC}
              firstItem={0}
              slideDatas={this.state.slideDatas}
              updateData={(value, gamePercent) => {this.updateTopicType(value, gamePercent)}}/>
            <Game
              ref="game"
              widthItem={WIDTH_ITEM_GAME}
              heightItem={HEIGHT_ITEM_GAME}
              widthItemSlide={WIDTH_ITEM_SILE_GAME}
              radius={RADIUS_GAME}
              firstItem={0}
              slideDatas={this.state.gameDatas}
              gamePercent={this.state.slideDatas[0].gamePercent}
              updateDataGame={(value) => {this.updateGameType(value)}}/>
            <View style={styles.bottomViewHome}>
              <TouchableOpacity style={styles.bottomButtonViewHome} onPress={() => {this.playGame()}}>
                <Image style={styles.bottomImageViewHome} source={require("./assets/play.png")} />
              </TouchableOpacity>
            </View>
          </View>
          <View style={{width: deviceWidth, height: deviceHeight - StatusBar.currentHeight}}>
            <SearchPage
              ref="searchPage" 
              reloadMain={(value1, value2) => {this.playGameBySearch(value1, value2)}}
              back={() => {this.back()}}/>
          </View>
        </Animated.View>
      );
    } else {
      return(
        <View></View>
      );
    }
  }
  reviewClick(){
    Alert.alert(
      'Alert',
      'Do you want this app? Please rate us 5 stars. Thank you very much.',
      [
        {text: 'Cancle', onPress: () => {console.log("ok")}},
        {text: 'OK', onPress: () => {Linking.openURL('https://play.google.com/store/apps/details?id=tienjoneey.com.jlpt');}},
      ]
    );
  }
  playGameBySearch(value1, value2) {
    Animated.timing(
      this.state.marginSlide,
      {
        toValue: 0,
        duration: 0,
      }
    ).start(() => {
      this.refs.searchPage.reRender();
    });
    this.props.navigation.navigate('MainScreens', {gameType: value2, topicID: value1});
  }
  search(){
    Animated.timing(
      this.state.marginSlide,
      {
        toValue: -deviceWidth,
        duration: 250,
      }
    ).start();
  }
  back(){
    //this.refs.header.reRender();
    Animated.timing(
      this.state.marginSlide,
      {
        toValue: 0,
        duration: 250,
      }
    ).start(() => {
      this.refs.searchPage.reRender();
    });
  }
  SearchFilterFunction(text) {
    db.transaction((tx) => {
      tx.executeSql("SELECT * FROM categories WHERE parent_id<>'0' and parent_id<>'1' and status='1' and title like '%"+text+"%'", [], (tx, results) => {
        var array = [];
        var len = results.rows.length;
        let j = 0;
        for (let i = 0; i < len; i++) {
          if(results.rows.item(i).id == '1') {
            continue;
          }
          array[j] = {
            id: results.rows.item(i).id,
            thumbnail: "asset:/images/" + results.rows.item(i).image,
            title: results.rows.item(i).title,
          }
          j += 1;
        }
        this.refs.content.contentRender(array);
      });
    });
  }
  updateTopicType(value, gamePercent){
    console.log(gamePercent);
    this.topicID = value;
    this.refs.game.renderGames(gamePercent);
    console.log("Topic" + value);
  }
  updateGameType(value){
    this.gameType = value;
    console.log("Game" + value);
  }
  playGame(){
    this.props.navigation.navigate('MainScreens', {gameType: this.gameType, topicID: this.topicID});
    //this.props.navigation.navigate('MainScreens', {gameType: this.gameType + 1, topicID: this.topicID});
  }
}
