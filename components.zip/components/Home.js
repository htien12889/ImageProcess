/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  StyleSheet,
  View, TouchableOpacity, Image
} from 'react-native';
import Header from './commons/home/Header.js';
import Content from './commons/home/Content.js';
import Game from './commons/home/Game.js';
export default class Home extends Component<Props> {
  render() {
    return (
      <View style={{flex: 1, backgroundColor: '#ffffff'}}>
      	<Header />
        <Content
          widthItem={150}
          heightItem={150}
          widthItemSlide={150}
          radius={128}/>
        <Game
          widthItem={100}
          heightItem={100}
          widthItemSlide={100}
          radius={75}/>
        <View style={{height: 50, backgroundColor: '#3bafda', justifyContent: 'center', alignItems: 'center'}}>
          <TouchableOpacity style={{width: 50, height: 50, borderRadius: 25}}>
            <Image style={{width: 50, height: 50}} source={require("./assets/play.png")} />
          </TouchableOpacity>
        </View>
      </View>
    );
  }
}
