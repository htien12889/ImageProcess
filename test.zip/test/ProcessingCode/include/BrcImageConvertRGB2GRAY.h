﻿/**
 * @file 	BrcImageConvert.h
 * @brief 	RGBグレースケール変換ヘッダファイル
 * @author 	kyoshitake
 * @date 	2016/06/22
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef IMAGE_CONVERT_RGB_GRAY_H
#define IMAGE_CONVERT_RGB_GRAY_H

#include "BrcType.h"

#ifdef __cplusplus
extern "C" {
#endif

	extern SI32 ConvertRGB_GRAY(UI32 width, UI32 height, void *pInData, void *pOutData, brcBool rgbReversal);
	extern SI32 ConvertRGBA_GRAY(UI32 width, UI32 height, void *pInData, void *pOutData, brcBool rgbReversal);
	extern SI32 ConvertRGB565_GRAY(UI32 width, UI32 height, void *pInData, void *pOutData, brcBool bigEndian);

#ifdef __cplusplus
}
#endif

#endif // IMAGE_CONVERT_RGB_GRAY_H
