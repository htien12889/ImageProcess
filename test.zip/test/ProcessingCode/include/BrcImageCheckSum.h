/** 
 * @file 	BrcImageCheckSum.h
 * @brief 	Image check sum header file
 * @author 	ayesu
 * @date 	2016/07/20
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef IMAGE_CheckSum_H
#define IMAGE_CheckSum_H

#include "BrcType.h"

#ifdef __cplusplus
extern "C" {
#endif

	extern SI32 CheckSum(UI32 width, UI32 height, void *pInRGB, void *checkCode);

#ifdef __cplusplus
}
#endif

#endif // IMAGE_CheckSum_H

