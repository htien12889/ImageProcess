﻿/**
 * @file 	BrcImageErrorCheck.h
 * @brief 	画像誤り検出
 * @author 	ayesu
 * @date 	2016/07/20
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef IMAGE_ERROR_CHECK_H
#define IMAGE_ERROR_CHECK_H

#include "BrcType.h"

#ifdef __cplusplus
extern "C" {
#endif
	extern SI32 CheckSum(UI32 width, UI32 height, void *pInRGB, void *checkCode);
	extern SI32 CRCCheck(UI32 width, UI32 height, void *pInRGB, void *checkCode);
#ifdef __cplusplus
}
#endif

#endif // IMAGE_ERROR_CHECK_H

