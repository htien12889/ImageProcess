﻿/**
 * @file 	BrcImageConvertColorSpace.h
 * @brief 	色空間変換ヘッダファイル
 * @author 	ykobayashi
 * @date 	2016/08/03
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef IMAGE_CONVERT_COLOR_SPACE_H
#define IMAGE_CONVERT_COLOR_SPACE_H

#include "BrcType.h"
#include "BrcImageLightingPreference.h"

#ifdef __cplusplus
extern "C" {
#endif

	extern SI32 ConvertRGB2XYZ(UI32 width, UI32 height, void *pInRGB, FP32 *pX, FP32 *pY, FP32 *pZ, eCorrectionState emCorrectionState, TT_RGBState *pRGBState);
	extern SI32 ConvertXYZ2Lab(UI32 width, UI32 height, FP32 *pX, FP32 *pY, FP32 *pZ, FP32 *pL, FP32 *pa, FP32 *pb, TT_LightingSourceState *pLightingSourceState);

#ifdef __cplusplus
}
#endif

#endif // IMAGE_CONVERT_COLOR_SPACE_H
