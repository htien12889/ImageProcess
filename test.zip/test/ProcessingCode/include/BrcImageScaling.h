﻿/**
 * @file	BrcImageScaling.h
 * @brief	画像拡大縮小ヘッダファイル
 * @author	tfujii
 * @date	2016/07/21
 * @par		Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef IMAGE_SCALING_H
#define IMAGE_SCALING_H

#include "BrcType.h"
#include "BrcImageProcessingCommon.h"

#ifdef __cplusplus
extern "C" {
#endif
	extern SI32 ScalingImage(void *pInRGB, UI32 inWidth, UI32 inHeight, void *pOutRGB, UI32 outWidth, UI32 outHeight);
#ifdef __cplusplus
}
#endif

#endif // IMAGE_SCALING_H
