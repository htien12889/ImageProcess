/**
 * @file	BrcImageDilationErosion.h
 * @brief�@	�c���A���k�������Ăяo���w�b�_�t�@�C��
 * @author 	ykobayashi
 * @date 	2016/08/09
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef DILATION_EROSION_H
#define DILATION_EROSION_H

#include "BrcType.h"

#ifdef __cplusplus
extern "C" {
#endif

	extern SI32 BinaryDilation(UI32 width, UI32 height, void *pInImage, void *pOutImage);
	extern SI32 BinaryErosion(UI32 width, UI32 height, void *pInImage, void *pOutImage);

#ifdef __cplusplus
}
#endif

#endif // DILATION_EROSION_H