﻿/**
 * @file 	BrcJpegConvert.h
 * @brief 	JPEG変換ヘッダファイル
 * @author 	kyoshitake
 * @date 	2016/06/22
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef JPEG_CONVERT_H
#define JPEG_CONVERT_H

#include "BrcJpegConvertInterface.h"

#ifdef __cplusplus
extern "C" {
#endif
	extern SI32 EncodeJPEGFile(UI32 width, UI32 height, void *pInImage, void *pOutJpeg, UI32 *sizeOfOutJpeg, JpegPropertyT *pProperty, enum JpegSampling jSampling);
	extern SI32 DecodeJPEGFile(UI32 width, UI32 height, void *pInJpeg, void *pOutImage, JpegPropertyT *pProperty);
#ifdef __cplusplus
}
#endif

#endif // JPEG_CONVERT_H
