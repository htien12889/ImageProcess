﻿/**
* @file 	BrcImageProcessingRGB.h
* @brief 	画像処理ライブラリRGBヘッダファイル
* @author 	kyoshitake
* @date 	2016/06/22
* @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
*/
#ifndef IMAGE_PROCESSING_RGB_H
#define IMAGE_PROCESSING_RGB_H

/**
* @brief RGBピクセルバイト数
*/
#define PIXEL_BYTE_RGB		3		///< RGBバイト数
#define PIXEL_BYTE_RGBA		4		///< RGBAバイト数
#define PIXEL_BYTE_RGB565	2		///< RGB565バイト数
#define PIXEL_BYTE_MONO		1		///< グレースケール

/**
* @brief RGBピクセルビット数
*/
#define PIXEL_BIT_RGB		24		///< RGBビット数
#define PIXEL_BIT_RGBA		32		///< RGBAビット数
#define PIXEL_BIT_RGB565	16		///< RGB565ビット数
#define PIXEL_BIT_MONO		8		///< グレースケール

#define	BITSHIFT_RGB565_R	11
#define	BITSHIFT_RGB565_G	5
#define	BITSHIFT_RGB565_B	0

#define	BYTESHIFT_RGB565_R	3
#define	BYTESHIFT_RGB565_GH	BITSHIFT_RGB565_G
#define	BYTESHIFT_RGB565_GL	BITSHIFT_RGB565_G
#define	BYTESHIFT_RGB565_B	BITSHIFT_RGB565_B

#define	BITMASK_RGB565_R	0x1f
#define	BITMASK_RGB565_G	0x3f
#define	BITMASK_RGB565_B	0x1f
#define	BITMASK_FULLSET		0xFf

#define	BYTEMASK_RGB565_R	0xf8
#define	BYTEMASK_RGB565_GH	0x07
#define	BYTEMASK_RGB565_GL	0xe0
#define	BYTEMASK_RGB565_B	BITMASK_RGB565_B

/**
* @enum RGB_OFFSET
* @brief RGBの位置
*/
enum RGB_OFFSET {
	RGB_OFFSET_R = 0,		///< RGBのRの位置
	RGB_OFFSET_G,			///< RGBのGの位置
	RGB_OFFSET_B			///< RGBのBの位置
};

/**
* @enum BGR_OFFSET
* @brief RGBの位置
*/
enum BGR_OFFSET {
	BGR_OFFSET_B = 0,		///< BGRのBの位置
	BGR_OFFSET_G,			///< BGRのGの位置
	BGR_OFFSET_R			///< BGRのRの位置
};

/**
* @enum RGBA_OFFSET
* @brief RGBAの位置
*/
enum RGBA_OFFSET {
	RGBA_OFFSET_R = 0,		///< RGBAのRの位置
	RGBA_OFFSET_G,			///< RGBAのGの位置
	RGBA_OFFSET_B,			///< RGBAのBの位置
	RGBA_OFFSET_A			///< RGBAのAの位置
};

/**
* @enum ABGR_OFFSET
* @brief RGBAの位置
*/
enum ABGR_OFFSET {
	ABGR_OFFSET_B = 0,		///< ABGRのBの位置
	ABGR_OFFSET_G,			///< ABGRのGの位置
	ABGR_OFFSET_R,			///< ABGRのRの位置
	ABGR_OFFSET_A			///< ABGRのAの位置
};

/**
* @enum XRGB_OFFSET
* @brief XRGBの位置
*/
enum XRGB_OFFSET {
	XRGB_OFFSET_X = 0,		///< XBGRのXの位置
	XRGB_OFFSET_R,			///< XBGRのRの位置
	XRGB_OFFSET_G,			///< XBGRのGの位置
	XRGB_OFFSET_B			///< XBGRのBの位置
};

/**
* @enum XBGR_OFFSET
* @brief XRGBの位置
*/
enum XBGR_OFFSET {
	XBGR_OFFSET_X = 0,		///< XBGRのXの位置
	XBGR_OFFSET_B,			///< XBGRのBの位置
	XBGR_OFFSET_G,			///< XBGRのGの位置
	XBGR_OFFSET_R			///< XBGRのRの位置
};


/** GET_RGB定義
* @brief RGB取得
*/
#define GET_RGB(rgb,index,offset)		(*(((UI08*)(rgb))+((index)*PIXEL_BYTE_RGB)+(offset)))
#define GET_RGBA(rgb,index,offset)		(*(((UI08*)(rgb))+((index)*PIXEL_BYTE_RGBA)+(offset)))
#define GET_RGB565(rgb,index,offset)	(*(((UI08*)(rgb))+((index)*PIXEL_BYTE_RGB565+(offset))))
#define GET_RGB565BE(rgb,index)			((GET_RGB565(rgb,index,0)<<8)+GET_RGB565(rgb,index,1))
#define GET_RGB565BE_R(rgb,index)		((GET_RGB565BE(rgb,index)>>BITSHIFT_RGB565_R)&BITMASK_RGB565_R)
#define GET_RGB565BE_G(rgb,index)		((GET_RGB565BE(rgb,index)>>BITSHIFT_RGB565_G)&BITMASK_RGB565_G)
#define GET_RGB565BE_B(rgb,index)		((GET_RGB565BE(rgb,index)>>BITSHIFT_RGB565_B)&BITMASK_RGB565_B)
#define GET_RGB565LE(rgb,index)			((GET_RGB565(rgb,index,1)<<8)+GET_RGB565(rgb,index,0))
#define GET_RGB565LE_R(rgb,index)		((GET_RGB565BE(rgb,index)>>BITSHIFT_RGB565_R)&BITMASK_RGB565_R)
#define GET_RGB565LE_G(rgb,index)		((GET_RGB565BE(rgb,index)>>BITSHIFT_RGB565_G)&BITMASK_RGB565_G)
#define GET_RGB565LE_B(rgb,index)		((GET_RGB565BE(rgb,index)>>BITSHIFT_RGB565_B)&BITMASK_RGB565_B)

#define GET_RGB565_R(rgb,index,enndian)	(enndian?GET_RGB565BE_R(rgb,index):GET_RGB565LE_R(rgb,index))
#define GET_RGB565_G(rgb,index,enndian)	(enndian?GET_RGB565BE_G(rgb,index):GET_RGB565LE_G(rgb,index))
#define GET_RGB565_B(rgb,index,enndian)	(enndian?GET_RGB565BE_B(rgb,index):GET_RGB565LE_B(rgb,index))

/** SET_RGB定義
* @brief RGB設定
*/
#define SET_RGB565BE(rgb,index,value)	((GET_RGB565(rgb,index,0)=((value)>>8)&BITMASK_FULLSET);GET_RGB565(rgb,index,1)=((velue)&BITMASK_FULLSET))
#define SET_RGB565BE_R(rgb,index,r)		(GET_RGB565(rgb,index,0)=((GET_RGB565(rgb,index,0)&(!BYTEMASK_RGB565_R))|((r<<BYTESHIFT_RGB565_R)&BYTEMASK_RGB565_R)))
#define SET_RGB565BE_GH(rgb,index,g)	(GET_RGB565(rgb,index,0)=((GET_RGB565(rgb,index,0)&(!BYTEMASK_RGB565_GH))|((g>>BYTESHIFT_RGB565_GH)&BYTEMASK_RGB565_GH)))
#define SET_RGB565BE_GL(rgb,index,g)	(GET_RGB565(rgb,index,1)=((GET_RGB565(rgb,index,1)&(!BYTEMASK_RGB565_GL))|((g<<BYTESHIFT_RGB565_GL)&BYTEMASK_RGB565_GL)))
#define SET_RGB565BE_B(rgb,index,b)		(GET_RGB565(rgb,index,1)=((GET_RGB565(rgb,index,1)&(!BYTEMASK_RGB565_B))|((b<<BYTESHIFT_RGB565_B)&BYTEMASK_RGB565_B)))
#define SET_RGB565LE(rgb,index,value)	((GET_RGB565(rgb,index,1)=((value)>>8)&BITMASK_FULLSET);GET_RGB565(rgb,index,0)=((velue)&BITMASK_FULLSET))
#define SET_RGB565LE_R(rgb,index,r)		(GET_RGB565(rgb,index,1)=((GET_RGB565(rgb,index,1)&(!BYTEMASK_RGB565_R))|((r<<BYTESHIFT_RGB565_R)&BYTEMASK_RGB565_R)))
#define SET_RGB565LE_GH(rgb,index,g)	(GET_RGB565(rgb,index,1)=((GET_RGB565(rgb,index,1)&(!BYTEMASK_RGB565_GH))|((g>>BYTESHIFT_RGB565_GH)&BYTEMASK_RGB565_GH)))
#define SET_RGB565LE_GL(rgb,index,g)	(GET_RGB565(rgb,index,0)=((GET_RGB565(rgb,index,0)&(!BYTEMASK_RGB565_GL))|((g<<BYTESHIFT_RGB565_GL)&BYTEMASK_RGB565_GL)))
#define SET_RGB565LE_B(rgb,index,b)		(GET_RGB565(rgb,index,0)=((GET_RGB565(rgb,index,0)&(!BYTEMASK_RGB565_B))|((b<<BYTESHIFT_RGB565_B)&BYTEMASK_RGB565_B)))

/**　RGB->YUV計算定義
* @brief RGB-YUV計算
*/
// Old version
/*#define CALC_RGB2YUV_Y(r,g,b)	((0.299*(r))+(0.587*(g))+(0.114*(b)))
#define CALC_RGB2YUV_U(r,g,b)	((-0.169*(r))-(0.331*(g))+(0.500*(b)))
#define CALC_RGB2YUV_V(r,g,b)	((0.500*(r))-(0.419*(g))-(0.081*(b)))	*/
/*#define CALC_RGB2YUV_Y(r,g,b)	(((SI32)((0.299*65536 + 0.5)*r + (0.587*65536 + 0.5)*g + (0.114*65536 + 0.5)*b) >> 16))
#define CALC_RGB2YUV_U(r,g,b)	(((SI32)((-0.16874*65536 + 0.5)*r - (0.33126*65536 + 0.5)*g + (0.5*65536 + 0.5)*b) >> 16) + 128)
#define CALC_RGB2YUV_V(r,g,b)	(((SI32)((0.5*65536 + 0.5)*r - (0.41869*65536 + 0.5)*g - (0.08131*65536 + 0.5)*b) >> 16) + 128)*/
// New version
/*#define CALC_RGB2YUV_Y(r,g,b)	(( (  66 * (r) + 129 * (g) +  25 * (b) + 128) >> 8) +  16)
#define CALC_RGB2YUV_U(r,g,b)	(( ( -38 * (r) -  74 * (g) + 112 * (b) + 128) >> 8) + 128)
#define CALC_RGB2YUV_V(r,g,b)	(( ( 112 * (r) -  94 * (g) -  18 * (b) + 128) >> 8) + 128)*/
/*#define CALC_RGB2YUV_Y(r,g,b)	((0.257*(r))+(0.504*(g))+(0.098*(b))+16)
#define CALC_RGB2YUV_U(r,g,b)	((0.439*(r))-(0.368*(g))-(0.071*(b))+128)
#define CALC_RGB2YUV_V(r,g,b)	(-(0.148*(r))-(0.291*(g))+(0.439*(b))+128)*/
#define COEFF_0		4899
#define COEFF_1		9617
#define COEFF_2		1868
#define COEFF_3		8061
#define COEFF_4		14369
#define DELTA_CV	2097152
#define DESCALE_CONV(x,n)		(((x) + (1 << ((n)-1))) >> (n))
#define CALC_RGB2YUV_Y(r,g,b)	(SI32)DESCALE_CONV((COEFF_0 * (b)+COEFF_1 * (g)+COEFF_2 * (r)), 14)
#define CALC_RGB2YUV_U(r,y)		(SI32)DESCALE_CONV((COEFF_3 * (r - y) + DELTA_CV), 14)
#define CALC_RGB2YUV_V(b,y)		(SI32)DESCALE_CONV((COEFF_4 * (b - y) + DELTA_CV), 14)


/**
* @enum FormatRGB
*/
typedef enum{
	RGB = 0,	///< RGB(24bit)フォーマット
	RGBA,		///< RGBA(32bit)フォーマット
	RGB565,		///< RGB(16bit)フォーマット
	FormatRGB_MAX
} FormatRGB;

#endif // IMAGE_PROCESSING_RGB_H
