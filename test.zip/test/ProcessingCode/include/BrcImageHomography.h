﻿/**
 * @file 	BrcImageHomography.h
 * @brief 	射影変換ヘッダファイル
 * @author 	kyoshitake
 * @date 	2016/06/22
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef IMAGE_HOMOGRAPHY_H
#define IMAGE_HOMOGRAPHY_H

#include "BrcType.h"

#ifdef __cplusplus
extern "C" {
#endif
	extern SI32 Homography(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, FP32 angleX, FP32 angleY);
#ifdef __cplusplus
}
#endif

#endif // IMAGE_HOMOGRAPHY_H
