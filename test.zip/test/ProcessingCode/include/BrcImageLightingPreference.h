﻿/** 
 * @file 	BrcImageLightingPreference.h
 * @brief 	色空間変換で使用する列挙型、構造体の定義用ヘッダファイル
 * @author 	ykobayashi
 * @date 	2016/08/03
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef IMAGE_LIGHTING_PREFERENCE_H
#define IMAGE_LIGHTING_PREFERENCE_H

#include "BrcType.h"

/// RGBの規格の列挙型
typedef enum
{
	emsRGB = 0,
	emAdobeRGB
}eRGBType;

/// 明るさの補正設定の列挙型
typedef enum
{
	emLinear = 0,
	emCorrectionsRGB,
	emCorrectionAdobeRGB
}eCorrectionState;

/// 標準光源設定判断用の列挙型
typedef enum
{
	emD50 = 0,
	emD65,
	emC
}eLightingSource;

/// RGBの設定の構造体
typedef struct
{
	eRGBType        emRGBType;           /// RGBの規格
	eLightingSource emLightginSourceRGB; /// RGBの標準光源
} TT_RGBState;

/// どの標準光源からどの標準光源へ変換するかを持つ構造体
typedef struct
{
	eLightingSource emLightingSourceXYZ; /// XYZの標準光源
	eLightingSource emLightingSourceLab; /// Labの標準光源
} TT_LightingSourceState;

#endif // IMAGE_LIGHTING_PREFERENCE_H