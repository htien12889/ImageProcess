﻿/**
 * @file 	BrcImageExtractColor.h
 * @brief 	色成分抽出ヘッダファイル
 * @author 	ayesu
 * @date 	2016/07/15
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef IMAGE_EXTRACT_COLOR_H
#define IMAGE_EXTRACT_COLOR_H

#include "BrcType.h"

#ifdef __cplusplus
extern "C" {
#endif
	extern SI32 ExtractColorComponent(UI32 width, UI32 height, void *pInRGB, void *pOutRed, void *pOutGreen, void *pOutBlue);
#ifdef __cplusplus
}
#endif

#endif // IMAGE_EXTRACT_COLOR_H
