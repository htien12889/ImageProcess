/**
 * @file 	BrcHardwareFeatures.h
 * @brief 	Hardware features header file
 * @author 	EMT-BrycenVN
 * @date 	2017/01/11
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */

#ifndef HARDWARE_FEATURES_H
#define HARDWARE_FEATURES_H

#include "BrcType.h"

/* CPU features and intrinsics support */
#define CPU_NONE             0
#define CPU_MMX              1
#define CPU_SSE              2
#define CPU_SSE2             3
#define CPU_SSE3             4
#define CPU_SSSE3            5
#define CPU_SSE4_1           6
#define CPU_SSE4_2           7
#define CPU_POPCNT           8

#define CPU_AVX              10
#define CPU_AVX2             11
#define CPU_FMA3             12

#define CPU_AVX_512F         13
#define CPU_AVX_512BW        14
#define CPU_AVX_512CD        15
#define CPU_AVX_512DQ        16
#define CPU_AVX_512ER        17
#define CPU_AVX_512IFMA512   18
#define CPU_AVX_512PF        19
#define CPU_AVX_512VBMI      20
#define CPU_AVX_512VL        21

#define CPU_NEON   100

#define CV_HARDWARE_MAX_FEATURE 255

#ifdef __cplusplus
extern "C" {
#endif
	extern brcBool CheckHardwareSupport(UI32 feature);
#ifdef __cplusplus
}
#endif

#endif // HARDWARE_FEATURES_H