﻿/**
 * @file 	BrcImageProcessingCommon.h
 * @brief 	画像処理ライブラリ共通ヘッダファイル
 * @author 	kyoshitake
 * @date 	2016/06/22
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef IMAGE_PROCESSING_COMMON_H
#define IMAGE_PROCESSING_COMMON_H

#include <errno.h>
#include "BrcType.h"
#include "BrcImageProcessingRGB.h"
#include "BrcImageProcessingYUV.h"

#define	SUCCESS						0

#define	BYTE_FULLSET				255
#define	BYTE_RESET					0
#define RGB_TYPE_IMAGE				1
#define	RGBA_TYPE_IMAGE				2
#define OFFSET_RGB_TYPE_IMAGE		3
#define OFFSET_RGBA_TYPE_IMAGE		4
#define PUBLIC
#define PRIVATE	static
#define GET_HALF_SIZE_IMAGE(value)	(SI32)((SI32)(value) / 2)
#define GET_HALF_KERNEL(value)		(SI32)((SI32)(value) / 2)
#define CLIP(x)						(UI08)((UI32)x <= 255 ? x : x > 0 ? 255 : 0)
#define RGB_CHANNELS				3
/**
 * @struct BrcSize
 * @brief サイズ構造体
 */
typedef struct{
	UI32	width;		///< 幅
	UI32	height;		///< 高さ
} BrcSize;

/**
 * @struct BrcLocation
 * @brief 位置構造体
 */
typedef struct{
	SI32	left;		///< 左位置
	SI32	top;		///< 上位置
} BrcLocation;

/**
 * @struct BrcColor
 * @brief RGB構造体
 */
typedef struct{
	UI08	red;		///< 赤色
	UI08	green;		///< 緑色
	UI08	blue;		///< 青色
} BrcRGB;

/**
* @struct BrcColor
* @brief BGR構造体
*/
typedef struct{
	UI08	blue;		///< 青色
	UI08	green;		///< 緑色
	UI08	red;		///< 赤色
} BrcBGR;

#endif // IMAGE_PROCESSING_COMMON_H