﻿/**
 * @file 	BrcImageBinarization.h
 * @brief 	二値化ヘッダファイル
 * @author 	kyoshitake
 * @date 	2016/06/22
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef IMAGE_BINARIZATION_H
#define IMAGE_BINARIZATION_H

#include "BrcType.h"

#ifdef __cplusplus
extern "C" {
#endif

	extern SI32 BinarizeByPtileMethod(UI32 width, UI32 height, void *pInRGB, void *pOutMono, UI32 threshold);
	extern SI32 BinarizeByModeMethod(UI32 width, UI32 height, void *pInRGB, void *pOutMono);
	extern SI32 BinarizeByDAMethod(UI32 width, UI32 height, void *pInRGB, void *pOutMono);
	extern SI32 BinarizeBySMTMethod(UI32 width, UI32 height, void *pInRGB, void *pOutMono, UI32 threshold);
	extern SI32 BinarizeByEDMethod(UI32 width, UI32 height, void *pInRGB, void *pOutMono, UI32 threshold);
	extern SI32 BinarizeByEDFSMethod(UI32 width, UI32 height, void *pInRGB, void *pOutMono, UI32 threshold);
	extern SI32 BinarizeByEDJJNMethod(UI32 width, UI32 height, void *pInRGB, void *pOutMono, UI32 threshold);

#ifdef __cplusplus
}
#endif

#endif // IMAGE_BINARIZATION_H
