/**
 * @file	BrcImageInterpolation.h
 * @brief	�s�N�Z���l���
 * @author	tfujii
 * @date	2016/09/08
 * @par		Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
*/
#ifndef BRC_IMAGE_INTERPOLATION
#define BRC_IMAGE_INTERPOLATION

#include "BrcType.h"

#ifdef __cplusplus
extern "C" {
#endif
	extern void BiCubicInterpolate(
		SI32 colMax, SI32 rowMax, UI32 channels, UI08 *img, 
		FP32 positionX, FP32 positionY, SI32 *pOutPixel);
#ifdef __cplusplus
}
#endif

#endif
