/**
 * @file 	BrcImageConvert.h
 * @brief 	画像変換ヘッダファイル
 * @author 	kyoshitake
 * @date 	2016/06/22
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef IMAGE_CONVERT_H
#define IMAGE_CONVERT_H

#include "BrcType.h"
#include "BrcImageProcessingRGB.h"
#include "BrcImageProcessingYUV.h"

#ifdef __cplusplus
extern "C" {
#endif
	extern SI32 ConvertRGB2YUV(UI32 width, UI32 height, void *pInRGB, FormatRGB rgbFormat, void *pOutYUV, FormatYUV yuvFormat);
	extern SI32 ConvertYUV2RGB(UI32 width, UI32 height, void *pInYUV, FormatYUV yuvFormat, void *pOutRGB, FormatRGB rgbFormat);
#ifdef __cplusplus
}
#endif

#endif // IMAGE_CONVERT_H
