﻿/**
 * @file 	BrcImageInvert.h
 * @brief 	画像反転ヘッダファイル
 * @author 	kyoshitake
 * @date 	2016/06/22
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
*/
#ifndef IMAGE_INVERT_H
#define IMAGE_INVERT_H

#include "BrcType.h"

#ifdef __cplusplus
extern "C" {
#endif
	extern SI32 InvertHorizontally(UI32 width, UI32 height, void *pInRGB, void *pOutRGB);
	extern SI32 InvertVertically(UI32 width, UI32 height, void *pInRGB, void *pOutRGB);
#ifdef __cplusplus
}
#endif

#endif // IMAGE_INVERT_H
