﻿/** 
 * @file 	BrcJpegConvertInterface.h
 * @brief 	JPEG変換I/Fヘッダファイル
 * @author 	kyoshitake
 * @date 	2016/06/22
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef JPEG_CONVERT_INTERFACE_H
#define JPEG_CONVERT_INTERFACE_H

#include "BrcType.h"

enum JpegSampling { YCbCr444 = 0, YCbCr422, YCbCr420 };

typedef struct{
	void *pData;
	int	  size;
} TSegmentInfo;

#define MAX_NUMBER_OF_SEGMENT	8

/**
 * @struct JpegProperty_T
 */
typedef struct {
    SI32	canDecode;			///< 復号可能性（復号時のみ）
    SI32	vSize;				///< 元画像横画素数
    SI32	hSize;				///< 元画像縦画素数
    SI32	dimension;			///< 成分数
    SI32	samplePrecision;	///< サンプル精度
    SI08	comment[256];		///< コメント
    SI32	format;				///< フォーマット種別　0:不明 1:JFIF 2:JFXX
    UI08	majorVersion;		///< バージョン小数点：整数部 
    UI08	minorVersion;		///< バージョン小数点：小数部 
    SI32	units;				///< 密度単位　0:無し 1:dots/inch 2:dots/cm
    SI32	hDensity;			///< 横密度
    SI32	vDensity;			///< 縦密度
    SI32	hThumbnail;			///< サムネイル横画素数
    SI32	vThumbnail;			///< サムネイル縦画素数
    SI32	extensionCode;		///< 拡張コード　0x10:JPEG
	TSegmentInfo	segDQT[MAX_NUMBER_OF_SEGMENT];
	TSegmentInfo	segDHT[MAX_NUMBER_OF_SEGMENT];
	int		mRestartInterval;
} JpegPropertyT;

#endif // JPEG_CONVERT_INTERFACE_H
