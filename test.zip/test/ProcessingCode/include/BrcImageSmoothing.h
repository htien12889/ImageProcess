﻿/**
 * @file 	BrcImageSmoothing.h
 * @brief 	画像平滑化ヘッダファイル
 * @author 	ayesu
 * @date 	2016/07/16
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef IMAGE_SMOOTHING_H
#define IMAGE_SMOOTHING_H

#include "BrcType.h"

#ifdef __cplusplus
extern "C" {
#endif
	extern SI32 SmoothingFilter(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, UI32 expansion);
	extern SI32 SmoothingMedianFilter(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, UI32 expansion);
	extern SI32 SmoothingGaussianFilter(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, UI32 expansion, UI32 borderType);
#ifdef __cplusplus
}
#endif

#endif // IMAGE_SMOOTHING_H
