/**
 * @file 	BrcImageIntegral.h
 * @brief�@	�ϕ��摜�쐬(BrcImageIntegral.c)�̃w�b�_�t�@�C��
 * @author 	ykobayashi
 * @date 	2016/08/29
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef INTEGRAL_H
#define INTEGRAL_H

#include "BrcType.h"

#ifdef __cplusplus
extern "C" {
#endif

	extern SI32 IntegralImage(UI32 width, UI32 height, void *pInImage, void *pOutIntegralImage);
	extern SI32 IntegralSquareImage(UI32 width, UI32 height, void *pInImage, void *pOutIntegralImage, void *pOutSquareIntegralImage);

#ifdef __cplusplus
}
#endif


#endif // INTEGRAL_H