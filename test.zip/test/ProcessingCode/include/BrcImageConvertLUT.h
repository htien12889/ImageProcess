/**
 * @file	BrcImageConvertLUT.h
 * @brief	���b�N�A�b�v�e�[�u���ϊ��w�b�_�t�@�C��
 * @author	tfujii
 * @date	2016/08/16
 * @par		Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef IMAGE_CONVERT_LUT
#define IMAGE_CONVERT_LUT

#include "BrcType.h"

#ifdef __cplusplus
extern "C" {
#endif
	extern SI32 ConvertLUT(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, const UI32 *plut);
#ifdef __cplusplus
}
#endif

#endif
