﻿/**
 * @file 	BrcImageDifferential.h
 * @brief 	微分変換ヘッダファイル
 * @author 	etsuchida
 * @date 	2016/08/02
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef IMAGE_DIFFERENTIAL_H
#define IMAGE_DIFFERENTIAL_H

#include "BrcType.h"

#ifdef __cplusplus
extern "C" {
#endif
	extern SI32 DetectEdge(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, UI32 method, UI32 borderType);
	extern SI32 ExtractOutline(UI32 width, UI32 height, void *pInRGB, void *pOutRGB);
	extern SI32 BinaryTrackOutline(UI32 width, UI32 height, void *pInRGB, void *pOutRGB);
#ifdef __cplusplus
}
#endif

#endif // IMAGE_DIFFERENTIAL_H
