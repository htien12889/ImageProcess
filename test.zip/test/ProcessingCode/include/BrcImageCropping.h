﻿/**
 * @file 	BrcImageCropping.h
 * @brief 	画像クロッピングヘッダファイル
 * @author 	kyoshitake
 * @date 	2016/06/22
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef IMAGE_CROPPING_H
#define IMAGE_CROPPING_H

#include "BrcType.h"

#ifdef __cplusplus
extern "C" {
#endif
	extern SI32 CroppingImage(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, UI32 left, UI32 top, UI32 right, UI32 bottom);
#ifdef __cplusplus
}
#endif

#endif // IMAGE_CROPPING_H
