﻿/**
 * @file 	BrcImageAffineTransform.h
 * @brief 	アフィン変換ヘッダファイル
 * @author 	tfujii
 * @date 	2016/08/30
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef IMAGE_AFFINEL_TRANSFORM_H
#define IMAGE_AFFINEL_TRANSFORM_H

#include "BrcType.h"

// define USE_AFFINE_SCALING

#ifdef __cplusplus
extern "C" {
#endif

#ifdef USE_AFFINE_SCALING
	extern SI32 AffineTransformScaling(UI32 inWidth, UI32 inHeight, void *pInRGB, UI32 outWidth, UI32 outHeight, void *pOutRGB);
#endif
	extern SI32 TiltByAffineTransform(UI32 inWidth, UI32 inHeight, void *pInRGB,
		UI32 outWidth, UI32 outHeight, void *pOutRGB, FP32 angleX, FP32 angleY);
	extern SI32 RotateByAffineTransform(UI32 inWidth, UI32 inHeight, void *pInRGB,
		UI32 outWidth, UI32 outHeight, void *pOutRGB, FP32 angle);
	extern SI32 ShiftByAffineTransform(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, SI32 moveX, SI32 moveY);
	extern SI32 GetSkewedImageSize(UI32 inWidth, UI32 inHeight, UI32 *pOutWidth, UI32 *pOutHeight, FP32 angleX, FP32 angleY);
	extern SI32 GetRotatedImageSize(UI32 inWidth, UI32 inHeight, UI32 *pOutWidth, UI32 *pOutHeight, FP32 angle);
	extern SI32 GetShiftedImageSize(UI32 inWidth, UI32 inHeight, UI32 *pOutWidth, UI32 *pOutHeight, SI32 moveX, SI32 moveY);

#ifdef __cplusplus
}
#endif

#endif // IMAGE_AFFINEL_TRANSFORM_H
