﻿/**
 * @file	BrcImageAdjustBrightness.h
 * @brief 	明るさ調整ヘッダファイル
 * @author 	kyoshitake
 * @date 	2016/06/22
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef IMAGE_ADJUST_BRIGHTNESS_H
#define IMAGE_ADJUST_BRIGHTNESS_H

#include "BrcType.h"

#ifdef __cplusplus
extern "C" {
#endif

	extern SI32 AdjustBrightnessHSV(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, SI32 brightnessIncrement);
	extern SI32 AdjustBrightnessYUV(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, SI32 brightnessIncrement);

#ifdef __cplusplus
}
#endif

#endif // IMAGE_ADJUST_BRIGHTNESS_H
