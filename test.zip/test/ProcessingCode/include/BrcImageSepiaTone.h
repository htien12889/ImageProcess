﻿/**
 * @file 	BrcImageSepiaTone.h
 * @brief 	セピア調化ヘッダファイル
 * @author 	kyoshitake
 * @date 	2016/06/22
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef IMAGE_SEPIA_TONE_H
#define IMAGE_SEPIA_TONE_H

#include "BrcType.h"

#ifdef __cplusplus
extern "C" {
#endif
	extern SI32 ConvertSepiaTone(UI32 width, UI32 height, void *pInRGB, void *pOutRGB);
#ifdef __cplusplus
}
#endif

#endif // IMAGE_SEPIA_TONE_H
