﻿/**
 * @file 	BrcImageConvert.h
 * @brief 	RGB変換ヘッダファイル
 * @author 	kyoshitake
 * @date 	2016/06/22
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef IMAGE_CONVERT_RGB_RGB_H
#define IMAGE_CONVERT_RGB_RGB_H

#include "BrcType.h"

#ifdef __cplusplus
extern "C" {
#endif

	extern SI32 ConvertRGB_RGBA(UI32 width, UI32 height, void *pInData, void *pOutData, brcBool rgbReversal);
	extern SI32 ConvertRGB_RGB565(UI32 width, UI32 height, void *pInData, void *pOutData, brcBool rgbReversal, brcBool bigEndian);
	extern SI32 ConvertRGBA_RGB(UI32 width, UI32 height, void *pInData, void *pOutData, brcBool rgbReversal);
	extern SI32 ConvertRGBA_RGB565(UI32 width, UI32 height, void *pInData, void *pOutData, brcBool rgbReversal, brcBool bigEndian);
	extern SI32 ConvertRGB565_RGB(UI32 width, UI32 height, void *pInData, void *pOutData, brcBool rgbReversal, brcBool bigEndian);
	extern SI32 ConvertRGB565_RGBA(UI32 width, UI32 height, void *pInData, void *pOutData, brcBool rgbReversal, brcBool bigEndian);

#ifdef __cplusplus
}
#endif

#endif // IMAGE_CONVERT_RGB_RGB_H
