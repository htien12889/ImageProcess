﻿/**
 * @file 	BrcImageCorrectGamma.h
 * @brief 	ガンマ補正ヘッダファイル
 * @author 	tfujii
 * @date 	2016/08/05
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef IMAGE_CORRECT_GAMMA_H
#define IMAGE_CORRECT_GAMMA_H

#include "BrcType.h"

#ifdef __cplusplus
extern "C" {
#endif
	extern SI32 CorrectGamma(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, FP64 gammaValue);
#ifdef __cplusplus
}
#endif

#endif // IMAGE_CORRECT_GAMMA_H
