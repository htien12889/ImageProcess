﻿/**
 * @file	BrcImageAdjustContrast.h
 * @brief	コントラスト調整ヘッダファイル
 * @author	tfujii
 * @date	2016/07/29
 * @par		Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef IMAGE_ADJUST_CONTRAST_H
#define IMAGE_ADJUST_CONTRAST_H

#include "BrcType.h"

#ifdef __cplusplus
extern "C" {
#endif

	extern SI32 AdjustContrast(UI32 width, UI32 height, void *pInRGB, void *pOutQGB, FP64 strengthOfContrast);

#ifdef __cplusplus
}
#endif

#endif // IMAGE_ADJUST_CONTRAST_H
