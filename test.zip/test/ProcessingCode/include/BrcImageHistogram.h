﻿/**
 * @file 	BrcImageHistogram.h
 * @brief 	ヒストグラムヘッダファイル
 * @author 	kyoshitake
 * @date 	2016/06/22
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef IMAGE_HISTOGRAM_H
#define IMAGE_HISTOGRAM_H

#include "BrcType.h"

#ifdef __cplusplus
extern "C" {
#endif
	extern SI32 GetRGBHistogram(UI32 width, UI32 height, void *pInRGB, UI32 max, UI32 *pRed, UI32 *pGreen, UI32 *pBlue, UI32 *pValue);
	extern SI32 GetHSVHistogram(UI32 width, UI32 height, void *pInRGB, UI32 max, UI32 *pHue, UI32 *pSaturation, UI32 *pValue);
	extern SI32 GetDensityHistogram(UI32 width, UI32 height, void *pInRGB, UI32 max, UI32 *pDensity);
	extern SI32 StretchHistogram(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, UI32 min, UI32 max);
	extern SI32 FlattenHistogram(UI32 width, UI32 height, void *pInRGB, void *pOutRGB);
#ifdef __cplusplus
}
#endif

#endif // IMAGE_HISTOGRAM_H
