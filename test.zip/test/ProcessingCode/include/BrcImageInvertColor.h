﻿/**
 * @file 	BrcImageInvertColor.h
 * @brief 	ネガポジ変換ヘッダファイル
 * @author 	kyoshitake
 * @date 	2016/06/22
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef IMAGE_INVERT_COLOR_H
#define IMAGE_INVERT_COLOR_H

#include "BrcType.h"

#ifdef __cplusplus
extern "C" {
#endif
	extern SI32 InvertColor(UI32 width, UI32 height, void *pInRGB, void *pOutRGB);
#ifdef __cplusplus
}
#endif

#endif // IMAGE_INVERT_COLOR_H
