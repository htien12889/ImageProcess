﻿/**
 * @file 	BrcImageConvertYUV2RGB.h
 * @brief 	YUV->RGB変換ヘッダファイル
 * @author 	kyoshitake
 * @date 	2016/06/22
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef IMAGE_CONVERT_YUV_RGB_H
#define IMAGE_CONVERT_YUV_RGB_H

#include "BrcType.h"

#ifdef __cplusplus
extern "C" {
#endif
	extern SI32 ConvertYUV444_RGB(UI32 width, UI32 height, void *pInYUV, void *pOutRGB, brcBool rgbReversal);
	extern SI32 ConvertYUV444_RGBA(UI32 width, UI32 height, void *pInYUV, void *pOutRGB, brcBool rgbReversal);
	extern SI32 ConvertYUV444_RGB565(UI32 width, UI32 height, void *pInYUV, void *pOutRGB, brcBool bigEndian);
	extern SI32 ConvertYUV422_RGB(UI32 width, UI32 height, void *pInYUV, void *pOutRGB, brcBool rgbReversal);
	extern SI32 ConvertYUV422_RGBA(UI32 width, UI32 height, void *pInYUV, void *pOutRGB, brcBool rgbReversal);
	extern SI32 ConvertYUV422_RGB565(UI32 width, UI32 height, void *pInYUV, void *pOutRGB, brcBool bigEndian);
	extern SI32 ConvertYUV422sp_RGB(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutRGB, brcBool rgbReversal);
	extern SI32 ConvertYUV422sp_RGBA(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutRGB, brcBool rgbReversal);
	extern SI32 ConvertYUV422sp_RGB565(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutRGB, brcBool bigEndian);
	extern SI32 ConvertYUV420sp_RGB(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutRGB, brcBool rgbReversal);
	extern SI32 ConvertYUV420sp_RGBA(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutRGB, brcBool rgbReversal);
	extern SI32 ConvertYUV420sp_RGB565(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutRGB, brcBool bigEndian);
#ifdef __cplusplus
}
#endif

#endif // IMAGE_CONVERT_YUV_RGB_H
