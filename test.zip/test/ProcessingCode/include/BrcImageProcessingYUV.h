﻿/** 
 * @file 	BrcImageProcessingYUV.h
 * @brief 	画像処理ライブラリYUVヘッダファイル
 * @author 	kyoshitake
 * @date 	2016/06/22
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef IMAGE_PROCESSING_YUV_H
#define IMAGE_PROCESSING_YUV_H

/**
 * @brief YUVピクセルバイト数
 */
#define PIXEL_BYTE_YUV444		3		///< YUV444バイト数
#define	PIXEL_BYTE_YUV422		2
#define	PIXEL_BYTE_YUV422Y		2
#define	PIXEL_BYTE_YUV422UV		4
#define	PIXEL_BYTE_YUV422SP_UV	2
#define	PIXEL_BYTE_YUV420SP_UV	2

/**
 * @brief YUVピクセルビット数
 */
#define PIXEL_BIT_YUV444		24		///< YUV444ビット数
#define PIXEL_BIT_YUV422		16		///< YUV422ビット数
#define PIXEL_BIT_YUV420		12		///< YUV420ビット数

/**
 * @enum YUV444_OFFSET
 * @brief YUV444の位置
 */
enum YUV444_OFFSET {
	YUV444_OFFSET_Y = 0,	///< YUV444のUの位置
	YUV444_OFFSET_U,		///< YUV444のYの位置
	YUV444_OFFSET_V			///< YUV444のVの位置
};

/**
 * @enum YUV422_OFFSET
 * @brief YUV422の位置
 */
enum YUV422_OFFSET {
	YUV422_OFFSET_YUYV_Y = 0,	///< YUV422YUYVのY位置
	YUV422_OFFSET_UYVY_Y,		///< YUV422UYVYのY位置
	YUV422_OFFSET_UYVY_U = 0,	///< YUV422UYVYのU位置
	YUV422_OFFSET_YUYV_U,		///< YUV422YUYVのU位置
	YUV422_OFFSET_UYVY_V = 0,	///< YUV422UYVYのV位置
	YUV422_OFFSET_YUYV_V,		///< YUV422YUYVのV位置

	YUV422SP_OFFSET_UV_U = 0,	///< YUV422SPのU位置
	YUV422SP_OFFSET_UV_V,		///< YUV422SPのV位置

	YUV422_OFFSET_UYVY	 = 0,	///< YUV422UYVYのV位置
	YUV422_OFFSET_YUYV			///< YUV422YUYVのV位置
};

/**
 * @enum YUV420_OFFSET
 * @brief YUV420の位置
 */
enum YUV420_OFFSET {
	YUV420SP_OFFSET_UV_U = 0,	///< YUV420SPのU位置
	YUV420SP_OFFSET_UV_V		///< YUV420SPのV位置
};


/*
 * ・YUV444(Interleaved)
 *　 ピクセル単位サイズ		24ビット
 *   ピクセル単位バイト配置	U0,Y0,V0 U1,Y1,V1 
 * ・YUV422(Interleaved)
 *　 ピクセル単位サイズ		16ビット
 *   ピクセル単位バイト配置	U0,Y0,V0,Y1 
 * ・YUV422SP(Semi-Planer)
 *　 ピクセル単位サイズ		16ビット
 *   ピクセル単位バイト配置	Y0,Y1,Y2,Y3	(Y-Planer) 
 *                          -----------
 *							U0,V0,U1,V1	(UV-Planer) 
 * ・YUV420SP(Semi-Planer)
 *　 ピクセル単位サイズ		12ビット
 *   ピクセル単位バイト配置	Y0,Y1		(Y-Planer) 
 *                          Y2,Y3
 *                          -----------
 *							U0,V0		(UV-Planer) 
 */

/** @def PIXEL_INDEX_YUV444(row,column,width)
 * YUV444 offset
 */
#define	PIXEL_INDEX_YUV444(x,y,w)				((UI32)((((y)*(w)) + (x))))
#define	PIXEL_OFFSET_YUV444(index)				(PIXEL_BYTE_YUV444*(index))

/** @def PIXEL_INDEX_YUV422(row,column,width)
 * YUV422 offset
 */
#define	PIXEL_INDEX_YUV422(x,y,w)				((UI32)((((y)*(w)) + (x))))
#define	PIXEL_OFFSET_YUV422_Y(index,offset)		(PIXEL_BYTE_YUV422Y*(index)+(offset))
#define	PIXEL_OFFSET_YUV422_U(index,offset)		(PIXEL_BYTE_YUV422UV*((index)>>1)+(offset))
#define	PIXEL_OFFSET_YUV422_V(index,offset)		(PIXEL_BYTE_YUV422UV*((index)>>1)+(offset)+2)
#define	PIXEL_OFFSET_YUV422SP_Y(index)			(index)
#define	PIXEL_OFFSET_YUV422SP_UV(index,offset)	((((index)>>1)*PIXEL_BYTE_YUV422SP_UV)+offset)

/** @def PIXEL_INDEX_YUV420SP_Y
 * YUV420 offset
 */
#define	PIXEL_INDEX_YUV420SP_Y(x,y,w)			((UI32)((((y)*(w)) + (x))))
#define	PIXEL_INDEX_YUV420SP_UV(x,y,w)			((UI32)(((((y)>>1)*((w)>>1)) + ((x)>>1))))
#define	PIXEL_OFFSET_YUV420SP_Y(index)			(index)
#define	PIXEL_OFFSET_YUV420SP_UV(index,offset)	((((index)>>1)*PIXEL_BYTE_YUV422SP_UV)+offset)

/**　GET_YUV定義
 * @brief YUV取得
 */
#define GET_YUV444(p,index,offset)				(*(((UI08*)p)+PIXEL_OFFSET_YUV444(index)+offset))

#define GET_YUV422_Y(p,index,offset)			(*(((UI08*)p)+PIXEL_OFFSET_YUV422_Y(index,offset)))
#define GET_YUV422_U(p,index,offset)			(*(((UI08*)p)+PIXEL_OFFSET_YUV422_U(index,offset)))
#define GET_YUV422_V(p,index,offset)			(*(((UI08*)p)+PIXEL_OFFSET_YUV422_V(index,offset)))
#define GET_YUV422SP_Y(p,index)					(*(((UI08*)p)+PIXEL_OFFSET_YUV422SP_Y(index)))
#define GET_YUV422SP_UV(p,index,offset)			(*(((UI08*)p)+PIXEL_OFFSET_YUV422SP_UV(index,offset)))

#define GET_YUV420SP_Y(p,index)					(*(((UI08*)p)+PIXEL_OFFSET_YUV420SP_Y(index)))
#define GET_YUV420SP_UV(p,index,offset)			(*(((UI08*)p)+PIXEL_OFFSET_YUV420SP_UV(index,offset)))

/**　YUV->RGB計算定義
 * @brief YUV->RGB計算
 */
// Old version
/*#define CALC_YUV2RGB_R(y,u,v)	((1.0*(y))+(1.402*(v)))			
#define CALC_YUV2RGB_G(y,u,v)	((1.0*(y))-(0.344*(u))-(0.714*(v)))	
#define CALC_YUV2RGB_B(y,u,v)	((1.0*(y))+(1.772*(u)))	*/ 
// New version
//#define CALC_YUV2RGB_R(y, u, v) (( 298 * ( (y) - 16  )                       + 409 * ( (v) - 128 ) + 128) >> 8)
//#define CALC_YUV2RGB_G(y, u, v) (( 298 * ( (y) - 16  ) - 100 * ( (u) - 128 ) - 208 * ( (v) - 128 ) + 128) >> 8)
//#define CALC_YUV2RGB_B(y, u, v) (( 298 * ( (y) - 16  ) + 516 * ( (u) - 128 )                       + 128) >> 8)

#define DESCALE_CONV(x,n)		(((x) + (1 << ((n)-1))) >> (n))
#define DELTA_CONV				128
#define COEFF_00				22987
#define COEFF_01				-11698
#define COEFF_02				-5636
#define COEFF_03				29049
#define YUV_SHIFT				14
#define CALC_YUV2RGB_R(y, u, v) ((y) + DESCALE_CONV(((u) - DELTA_CONV)*COEFF_03, YUV_SHIFT))
#define CALC_YUV2RGB_G(y, u, v) ((y) + DESCALE_CONV(((u) - DELTA_CONV)*COEFF_02 + ((v) - DELTA_CONV)*COEFF_01, YUV_SHIFT))
#define CALC_YUV2RGB_B(y, u, v) ((y) + DESCALE_CONV(((v) - DELTA_CONV)*COEFF_00, YUV_SHIFT))

/*#define CALC_YUV2RGB_R(y,u,v)	((SI32)((1.000*65536 + 0.5)*(SI32)(y)+(1.40200*65536 + 0.5)*((SI32)v - 128)) >> 16)			
#define CALC_YUV2RGB_G(y,u,v)	((SI32)((1.000*65536 + 0.5)*(SI32)(y)-(0.34414*65536 + 0.5)*((SI32)u - 128)-(0.71414*65536 + 0.5)*((SI32)v - 128)) >> 16)
#define CALC_YUV2RGB_B(y,u,v)	((SI32)((1.000*65536 + 0.5)*(SI32)(y)+(1.77200*65536 + 0.5)*((SI32)u - 128)) >> 16)*/

/**
 * @enum FormatYUV
 */
typedef enum{
	YUV444 = 0,	///< YUV444フォーマット
	YUV422,		///< YUV422フォーマット
	YUV420		///< YUV420フォーマット
} FormatYUV;

#endif // IMAGE_PROCESSING_YUV_H
