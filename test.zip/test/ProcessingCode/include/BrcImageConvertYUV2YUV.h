﻿/**
 * @file 	BrcImageConvertYUV2YUV.h
 * @brief 	YUV変換ヘッダファイル
 * @author 	kyoshitake
 * @date 	2016/06/22
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#ifndef IMAGE_CONVERT_YUV_YUV_H
#define IMAGE_CONVERT_YUV_YUV_H

#include "BrcType.h"

#ifdef __cplusplus
extern "C" {
#endif
	extern SI32 ConvertYUV444_YUV422(UI32 width, UI32 height, void *pInYUV, void *pOutYUV);
	extern SI32 ConvertYUV444_YUV422sp(UI32 width, UI32 height, void *pInYUV, void *pOutY, void *pOutUV);
	extern SI32 ConvertYUV444_YUV420sp(UI32 width, UI32 height, void *pInYUV, void *pOutY, void *pOutUV);
	extern SI32 ConvertYUV422_YUV444(UI32 width, UI32 height, void *pInYUV, void *pOutYUV);
	extern SI32 ConvertYUV422_YUV422sp(UI32 width, UI32 height, void *pInYUV, void *pOutY, void *pOutUV);
	extern SI32 ConvertYUV422_YUV420sp(UI32 width, UI32 height, void *pInYUV, void *pOutY, void *pOutUV);
	extern SI32 ConvertYUV422sp_YUV444(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutYUV);
	extern SI32 ConvertYUV422sp_YUV422(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutYUV);
	extern SI32 ConvertYUV422sp_YUV420sp(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutY, void *pOutUV);
	extern SI32 ConvertYUV420sp_YUV444(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutYUV);
	extern SI32 ConvertYUV420sp_YUV422(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutYUV);
	extern SI32 ConvertYUV420sp_YUV422sp(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutY, void *pOutUV);
#ifdef __cplusplus
}
#endif

#endif // IMAGE_CONVERT_YUV_YUV_H
