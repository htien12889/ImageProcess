﻿/**
* @file 	BrcImageConvertRGB2YUV.c
* @brief 	画像変換シースファイル
* @author 	kyoshitake
* @date 	2016/06/22
* @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
*/
#include "BrcType.h"
#include "BrcImageProcessingCommon.h"
#include "BrcImageProcessingRGB.h"
#include "BrcImageProcessingYUV.h"
//#include "BrcMemoryUsage.h"

#define TRUE	1
#define FALSE	0
#define BITSHIFT_VALUE_3 	3
#define BITSHIFT_VALUE_8 	8

/** ConvertRGB_YUV444(UI32 width, UI32 height, void *pInRGB, void *pOutYUV, brcBool rgbReversal)
* @brief RGB->YUV444変換
* @param[in]	width	画像幅
* @param[in]	height	画像高さ
* @param[in]	pInRGB	入力画像領域のポインタ
* @param[out]	pOutYUV	出力画像領域のポインタ
* @param[in]	rgbReversal	RGB反転 true:BGR false:RGB
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertRGB_YUV444(UI32 width, UI32 height, void *pInRGB, void *pOutYUV, brcBool rgbReversal)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInRGB != brcNull) && (pOutYUV != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInRGB;
		UI08	*pOutByte = (UI08*)pOutYUV;
		UI32	offsetR = (rgbReversal ? BGR_OFFSET_R : RGB_OFFSET_R);
		UI32	offsetG = (rgbReversal ? BGR_OFFSET_G : RGB_OFFSET_G);
		UI32	offsetB = (rgbReversal ? BGR_OFFSET_B : RGB_OFFSET_B);
		UI32	row;
		UI32	column;
		SI32	r, g, b;

		for (row = 0; row < height; row++){
			for (column = 0; column < width; column++, pInByte += PIXEL_BYTE_RGB, pOutByte += PIXEL_BYTE_YUV444){
				r = (*(pInByte + offsetR));
				g = (*(pInByte + offsetG));
				b = (*(pInByte + offsetB));
				*(pOutByte + YUV444_OFFSET_Y) = (UI08)CLIP(CALC_RGB2YUV_Y(r, g, b));
				*(pOutByte + YUV444_OFFSET_U) = (UI08)CLIP(CALC_RGB2YUV_U(r, *(pOutByte + YUV444_OFFSET_Y)));
				*(pOutByte + YUV444_OFFSET_V) = (UI08)CLIP(CALC_RGB2YUV_V(b, *(pOutByte + YUV444_OFFSET_Y)));
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertRGB_YUV422(UI32 width, UI32 height, void *pInRGB, void *pOutYUV, brcBool rgbReversal)
* @brief RGB->YUV422変換
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInRGB		入力画像領域のポインタ
* @param[out]	pOutYUV		出力画像領域のポインタ
* @param[in]	rgbReversal	RGB反転 true:BGR false:RGB
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertRGB_YUV422(UI32 width, UI32 height, void *pInRGB, void *pOutYUV, brcBool rgbReversal)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInRGB != brcNull) && (pOutYUV != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInRGB;
		UI08	*pOutByte = (UI08*)pOutYUV;
		UI32	offsetR = (rgbReversal ? BGR_OFFSET_R : RGB_OFFSET_R);
		UI32	offsetG = (rgbReversal ? BGR_OFFSET_G : RGB_OFFSET_G);
		UI32	offsetB = (rgbReversal ? BGR_OFFSET_B : RGB_OFFSET_B);
		UI32	row;
		UI32	column;
		UI08	r, g, b;
		for (row = 0; row < height; row++){
			for (column = 0; column < width; column++, pInByte += PIXEL_BYTE_RGB, pOutByte += PIXEL_BYTE_YUV422){
				r = (*(pInByte + offsetR));
				g = (*(pInByte + offsetG));
				b = (*(pInByte + offsetB));
				*(pOutByte + YUV422_OFFSET_UYVY_Y) = (UI08)CLIP(CALC_RGB2YUV_Y(r, g, b));
				if (column % 2){	// 奇数桁か？	// Old version: Check row; New version: Check column!
					*(pOutByte + YUV422_OFFSET_UYVY_V) = (UI08)CLIP(CALC_RGB2YUV_V(b, *(pOutByte + YUV422_OFFSET_UYVY_Y)));
				}
				else{			// 偶数桁
					*(pOutByte + YUV422_OFFSET_UYVY_U) = (UI08)CLIP(CALC_RGB2YUV_U(r, *(pOutByte + YUV422_OFFSET_UYVY_Y)));
				}
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertRGB_YUV422sp(UI32 width, UI32 height, void *pInRGB, void *pOutY, void *pOutUV, brcBool rgbReversal)
* @brief RGB->YUV422sp変換
* @param[in]	width	画像幅
* @param[in]	height	画像高さ
* @param[in]	pInRGB	入力画像領域のポインタ
* @param[out]	pOutY	出力Y画像領域のポインタ
* @param[out]	pOutUV	出力UV画像領域のポインタ
* @param[in]	rgbReversal	RGB反転 true:BGR false:RGB
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertRGB_YUV422sp(UI32 width, UI32 height, void *pInRGB, void *pOutY, void *pOutUV, brcBool rgbReversal)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInRGB != brcNull) && (pOutY != brcNull) && (pOutUV != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInRGB;
		UI08	*pOutByteY = (UI08*)pOutY;
		UI08	*pOutByteUV = (UI08*)pOutUV;
		UI32	offsetR = (rgbReversal ? BGR_OFFSET_R : RGB_OFFSET_R);
		UI32	offsetG = (rgbReversal ? BGR_OFFSET_G : RGB_OFFSET_G);
		UI32	offsetB = (rgbReversal ? BGR_OFFSET_B : RGB_OFFSET_B);
		UI32	row;
		UI32	column;
		UI08	r, g, b;
		for (row = 0; row < height; row++){
			for (column = 0; column < width; column++, pInByte += PIXEL_BYTE_RGB, pOutByteY++){
				r = (*(pInByte + offsetR));
				g = (*(pInByte + offsetG));
				b = (*(pInByte + offsetB));
				*pOutByteY = (UI08)CLIP(CALC_RGB2YUV_Y(r, g, b));
				if (column % 2){	// 奇数桁か？
					*(pOutByteUV + YUV422SP_OFFSET_UV_U) = (UI08)CLIP(CALC_RGB2YUV_U(r, *pOutByteY));
					*(pOutByteUV + YUV422SP_OFFSET_UV_V) = (UI08)CLIP(CALC_RGB2YUV_V(b, *pOutByteY));
					pOutByteUV += PIXEL_BYTE_YUV422;
				}
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertRGB_YUV420sp(UI32 width, UI32 height, void *pInRGB, void *pOutYUV, brcBool rgbReversal)
* @brief RGB->YUV420sp変換
* @param[in]	width	画像幅
* @param[in]	height	画像高さ
* @param[in]	pInRGB	入力画像領域のポインタ
* @param[out]	pOutY	出力Y画像領域のポインタ
* @param[out]	pOutUV	出力UV画像領域のポインタ
* @param[in]	rgbReversal	RGB反転 true:BGR false:RGB
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertRGB_YUV420sp(UI32 width, UI32 height, void *pInRGB, void *pOutY, void *pOutUV, brcBool rgbReversal)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInRGB != brcNull) && (pOutY != brcNull) && (pOutUV != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInRGB;
		UI08	*pOutByteY = (UI08*)pOutY;
		UI08	*pOutByteUV = (UI08*)pOutUV;
		UI32	offsetR = (rgbReversal ? BGR_OFFSET_R : RGB_OFFSET_R);
		UI32	offsetG = (rgbReversal ? BGR_OFFSET_G : RGB_OFFSET_G);
		UI32	offsetB = (rgbReversal ? BGR_OFFSET_B : RGB_OFFSET_B);
		UI32	row;
		UI32	column;
		UI08	r, g, b;
		for (row = 0; row < height; row++){
			for (column = 0; column < width; column++, pInByte += PIXEL_BYTE_RGB, pOutByteY++){
				r = (*(pInByte + offsetR));
				g = (*(pInByte + offsetG));
				b = (*(pInByte + offsetB));
				*pOutByteY = (UI08)CLIP(CALC_RGB2YUV_Y(r, g, b));
				if ((row % 2) && (column % 2)){	// 奇数行＆奇数桁か？
					*(pOutByteUV + YUV420SP_OFFSET_UV_U) = (UI08)CLIP(CALC_RGB2YUV_U(r, *pOutByteY));
					*(pOutByteUV + YUV420SP_OFFSET_UV_V) = (UI08)CLIP(CALC_RGB2YUV_V(b, *pOutByteY));
					pOutByteUV += PIXEL_BYTE_YUV420SP_UV;
				}
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertRGBA_YUV444(UI32 width, UI32 height, void *pInRGB, void *pOutYUV, brcBool rgbReversal)
* @brief RGBA->YUV444変換
* @param[in]	width	画像幅
* @param[in]	height	画像高さ
* @param[in]	pInRGB	入力画像領域のポインタ
* @param[out]	pOutYUV	出力画像領域のポインタ
* @param[in]	rgbReversal	RGB反転 true:ABGR false:RGBA
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertRGBA_YUV444(UI32 width, UI32 height, void *pInRGB, void *pOutYUV, brcBool rgbReversal)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInRGB != brcNull) && (pOutYUV != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInRGB;
		UI08	*pOutByte = (UI08*)pOutYUV;
		UI32	offsetR = (rgbReversal ? ABGR_OFFSET_R : RGBA_OFFSET_R);
		UI32	offsetG = (rgbReversal ? ABGR_OFFSET_G : RGBA_OFFSET_G);
		UI32	offsetB = (rgbReversal ? ABGR_OFFSET_B : RGBA_OFFSET_B);
		UI32	row;
		UI32	column;
		UI08	r, g, b;
		for (row = 0; row < height; row++){
			for (column = 0; column < width; column++, pInByte += PIXEL_BYTE_RGBA, pOutByte += PIXEL_BYTE_YUV444){
				r = (*(pInByte + offsetR));
				g = (*(pInByte + offsetG));
				b = (*(pInByte + offsetB));
				*(pOutByte + YUV444_OFFSET_Y) = (UI08)CLIP(CALC_RGB2YUV_Y(r, g, b));
				*(pOutByte + YUV444_OFFSET_U) = (UI08)CLIP(CALC_RGB2YUV_U(r, *(pOutByte + YUV444_OFFSET_Y)));
				*(pOutByte + YUV444_OFFSET_V) = (UI08)CLIP(CALC_RGB2YUV_V(b, *(pOutByte + YUV444_OFFSET_Y)));
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertRGBA_YUV422(UI32 width, UI32 height, void *pInRGB, void *pOutYUV, brcBool rgbReversal)
* @brief RGBA->YUV422変換
* @param[in]	width	画像幅
* @param[in]	height	画像高さ
* @param[in]	pInRGB	入力画像領域のポインタ
* @param[out]	pOutYUV	出力画像領域のポインタ
* @param[in]	rgbReversal	RGB反転 true:ABGR false:RGBA
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertRGBA_YUV422(UI32 width, UI32 height, void *pInRGB, void *pOutYUV, brcBool rgbReversal)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInRGB != brcNull) && (pOutYUV != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInRGB;
		UI08	*pOutByte = (UI08*)pOutYUV;
		UI32	offsetR = (rgbReversal ? ABGR_OFFSET_R : RGBA_OFFSET_R);
		UI32	offsetG = (rgbReversal ? ABGR_OFFSET_G : RGBA_OFFSET_G);
		UI32	offsetB = (rgbReversal ? ABGR_OFFSET_B : RGBA_OFFSET_B);
		UI32	row;
		UI32	column;
		UI08	r, g, b;
		for (row = 0; row < height; row++){
			// Old version: for (column = 0; column < width; column++, pInByte += PIXEL_BYTE_RGB, pOutByte += PIXEL_BYTE_YUV422){			
			for (column = 0; column < width; column++, pInByte += PIXEL_BYTE_RGBA, pOutByte += PIXEL_BYTE_YUV422){
				r = (*(pInByte + offsetR));
				g = (*(pInByte + offsetG));
				b = (*(pInByte + offsetB));
				*(pOutByte + YUV422_OFFSET_UYVY_Y) = (UI08)CLIP(CALC_RGB2YUV_Y(r, g, b));
				if (column % 2){	// 奇数桁か？
					*(pOutByte + YUV422_OFFSET_UYVY_V) = (UI08)CLIP(CALC_RGB2YUV_V(b, *(pOutByte + YUV422_OFFSET_UYVY_Y)));
				}
				else{			// 偶数桁
					*(pOutByte + YUV422_OFFSET_UYVY_U) = (UI08)CLIP(CALC_RGB2YUV_U(r, *(pOutByte + YUV422_OFFSET_UYVY_Y)));
				}
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertRGBA_YUV422sp(UI32 width, UI32 height, void *pInRGB, void *pOutY, void *pOutUV, brcBool rgbReversal)
* @brief RGBA->YUV422sp変換
* @param[in]	width	画像幅
* @param[in]	height	画像高さ
* @param[in]	pInRGB	入力画像領域のポインタ
* @param[out]	pOutY	出力Y画像領域のポインタ
* @param[out]	pOutUV	出力UV画像領域のポインタ
* @param[in]	rgbReversal	RGB反転 true:ABGR false:RGBA
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertRGBA_YUV422sp(UI32 width, UI32 height, void *pInRGB, void *pOutY, void *pOutUV, brcBool rgbReversal)
{
#if __tracking
	Memory_Start();
#endif

	SI32	err = ((0 < width) && (0 < height) && (pInRGB != brcNull) && (pOutY != brcNull) && (pOutUV != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInRGB;
		UI08	*pOutByteY = (UI08*)pOutY;
		UI08	*pOutByteUV = (UI08*)pOutUV;
		UI32	offsetR = (rgbReversal ? ABGR_OFFSET_R : RGBA_OFFSET_R);
		UI32	offsetG = (rgbReversal ? ABGR_OFFSET_G : RGBA_OFFSET_G);
		UI32	offsetB = (rgbReversal ? ABGR_OFFSET_B : RGBA_OFFSET_B);
		UI32	row;
		UI32	column;
		UI08	r, g, b;
		for (row = 0; row < height; row++){
			for (column = 0; column < width; column++, pInByte += PIXEL_BYTE_RGBA, pOutByteY++){
				r = (*(pInByte + offsetR));
				g = (*(pInByte + offsetG));
				b = (*(pInByte + offsetB));
				*pOutByteY = (UI08)CLIP(CALC_RGB2YUV_Y(r, g, b));
				if (column % 2){	// 奇数桁か？
					*(pOutByteUV + YUV422SP_OFFSET_UV_U) = (UI08)CLIP(CALC_RGB2YUV_U(r, *pOutByteY));
					*(pOutByteUV + YUV422SP_OFFSET_UV_V) = (UI08)CLIP(CALC_RGB2YUV_V(b, *pOutByteY));
					pOutByteUV += PIXEL_BYTE_YUV422;
				}
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertRGBA_YUV420sp(UI32 width, UI32 height, void *pInRGB, void *pOutY, void *pOutUV, brcBool rgbReversal)
* @brief RGBA->YUV420sp変換
* @param[in]	width	画像幅
* @param[in]	height	画像高さ
* @param[in]	pInRGB	入力画像領域のポインタ
* @param[out]	pOutY	出力Y画像領域のポインタ
* @param[out]	pOutUV	出力UV画像領域のポインタ
* @param[in]	rgbReversal	RGB反転 true:ABGR false:RGBA
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertRGBA_YUV420sp(UI32 width, UI32 height, void *pInRGB, void *pOutY, void *pOutUV, brcBool rgbReversal)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInRGB != brcNull) && (pOutY != brcNull) && (pOutUV != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInRGB;
		UI08	*pOutByteY = (UI08*)pOutY;
		UI08	*pOutByteUV = (UI08*)pOutUV;
		UI32	offsetR = (rgbReversal ? ABGR_OFFSET_R : RGBA_OFFSET_R);
		UI32	offsetG = (rgbReversal ? ABGR_OFFSET_G : RGBA_OFFSET_G);
		UI32	offsetB = (rgbReversal ? ABGR_OFFSET_B : RGBA_OFFSET_B);
		UI32	row;
		UI32	column;
		UI08	r, g, b;
		for (row = 0; row < height; row++){
			for (column = 0; column < width; column++, pInByte += PIXEL_BYTE_RGBA, pOutByteY++){
				r = (*(pInByte + offsetR));
				g = (*(pInByte + offsetG));
				b = (*(pInByte + offsetB));
				*pOutByteY = (UI08)CLIP(CALC_RGB2YUV_Y(r, g, b));
				if ((row % 2) && (column % 2)){	// 奇数行＆奇数桁か？
					*(pOutByteUV + YUV420SP_OFFSET_UV_U) = (UI08)CLIP(CALC_RGB2YUV_U(r, *pOutByteY));
					*(pOutByteUV + YUV420SP_OFFSET_UV_V) = (UI08)CLIP(CALC_RGB2YUV_V(b, *pOutByteY));
					pOutByteUV += PIXEL_BYTE_YUV420SP_UV;
				}
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertRGB565_YUV444(UI32 width, UI32 height, void *pInRGB, void *pOutYUV, brcBool bigEndian)
* @brief RGB565->YUV444変換
* @param[in]	width	画像幅
* @param[in]	height	画像高さ
* @param[in]	pInRGB	入力画像領域のポインタ
* @param[out]	pOutYUV	出力画像領域のポインタ
* @param[in]	bigEndian	エンディアン指定 true:ビッグエンディアン false:リトルエンディアン
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertRGB565_YUV444(UI32 width, UI32 height, void *pInRGB, void *pOutYUV, brcBool bigEndian)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInRGB != brcNull) && (pOutYUV != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInRGB;
		UI08	*pOutByte = (UI08*)pOutYUV;
		UI32	MSB = (bigEndian ? FALSE : TRUE);
		UI32	LSB = (bigEndian ? TRUE : FALSE);
		UI32	row;
		UI32	column;
		UI16	value;
		UI08	r, g, b;
		for (row = 0; row < height; row++){
			for (column = 0; column < width; column++, pInByte += PIXEL_BYTE_RGB565, pOutByte += PIXEL_BYTE_YUV444){
				// Old version
				/*UI16	value = ((*(pInByte + MSB)) << 8) + (*(pInByte + LSB));
				UI08	r = (UI08)((value >> BITSHIFT_RGB565_R)&BITMASK_RGB565_R);
				UI08	g = (UI08)((value >> BITSHIFT_RGB565_G)&BITMASK_RGB565_G);
				UI08	b = (UI08)((value >> BITSHIFT_RGB565_B)&BITMASK_RGB565_B);*/
				// New version
				value = ((*(pInByte + MSB)) << BITSHIFT_VALUE_8) + (*(pInByte + LSB));
				r = (UI08)((value & 0xF800) >> BITSHIFT_VALUE_8);
				g = (UI08)((value & 0x07E0) >> BITSHIFT_VALUE_3);
				b = (UI08)((value & 0x001F) << BITSHIFT_VALUE_3);

				*(pOutByte + YUV444_OFFSET_Y) = (UI08)CLIP(CALC_RGB2YUV_Y(r, g, b));
				*(pOutByte + YUV444_OFFSET_U) = (UI08)CLIP(CALC_RGB2YUV_U(r, *(pOutByte + YUV444_OFFSET_Y)));
				*(pOutByte + YUV444_OFFSET_V) = (UI08)CLIP(CALC_RGB2YUV_V(b, *(pOutByte + YUV444_OFFSET_Y)));
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertRGB565_YUV422(UI32 width, UI32 height, void *pInRGB, void *pOutYUV, brcBool bigEndian)
* @brief RGB565->YUV422変換
* @param[in]	width	画像幅
* @param[in]	height	画像高さ
* @param[in]	pInRGB	入力画像領域のポインタ
* @param[out]	pOutYUV	出力画像領域のポインタ
* @param[in]	bigEndian	エンディアン指定 true:ビッグエンディアン false:リトルエンディアン
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertRGB565_YUV422(UI32 width, UI32 height, void *pInRGB, void *pOutYUV, brcBool bigEndian)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height)
		&& (pInRGB != brcNull) && (pOutYUV != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInRGB;
		UI08	*pOutByte = (UI08*)pOutYUV;
		UI32	MSB = (bigEndian ? FALSE : TRUE);
		UI32	LSB = (bigEndian ? TRUE : FALSE);
		UI32	row;
		UI32	column;
		UI16	value;
		UI08	r, g, b;
		for (row = 0; row < height; row++){
			for (column = 0; column < width; column++, pInByte += PIXEL_BYTE_RGB565, pOutByte += PIXEL_BYTE_YUV422){
				// Old version
				/*UI16	value = ((*(pInByte + MSB)) << 8) + (*(pInByte + LSB));
				UI08	r = (UI08)((value >> BITSHIFT_RGB565_R)&BITMASK_RGB565_R);
				UI08	g = (UI08)((value >> BITSHIFT_RGB565_G)&BITMASK_RGB565_G);
				UI08	b = (UI08)((value >> BITSHIFT_RGB565_B)&BITMASK_RGB565_B);*/
				// New version
				value = ((*(pInByte + MSB)) << BITSHIFT_VALUE_8) + (*(pInByte + LSB));
				r = (UI08)((value & 0xF800) >> BITSHIFT_VALUE_8);
				g = (UI08)((value & 0x07E0) >> BITSHIFT_VALUE_3);
				b = (UI08)((value & 0x001F) << BITSHIFT_VALUE_3);

				*(pOutByte + YUV422_OFFSET_UYVY_Y) = (UI08)CLIP(CALC_RGB2YUV_Y(r, g, b));
				if (column % 2){	// 奇数桁か？
					*(pOutByte + YUV422_OFFSET_UYVY_V) = (UI08)CLIP(CALC_RGB2YUV_V(b, *(pOutByte + YUV422_OFFSET_UYVY_Y)));
				}
				else{			// 偶数桁
					*(pOutByte + YUV422_OFFSET_UYVY_U) = (UI08)CLIP(CALC_RGB2YUV_U(r, *(pOutByte + YUV422_OFFSET_UYVY_Y)));
				}
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertRGB565_YUV422sp(UI32 width, UI32 height, void *pInRGB, void *pOutY, void *pOutUV, brcBool bigEndian)
* @brief RGB565->YUV422変換
* @param[in]	width	画像幅
* @param[in]	height	画像高さ
* @param[in]	pInRGB	入力画像領域のポインタ
* @param[out]	pOutY	出力Y画像領域のポインタ
* @param[out]	pOutUV	出力UV画像領域のポインタ
* @param[in]	bigEndian	エンディアン指定 true:ビッグエンディアン false:リトルエンディアン
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertRGB565_YUV422sp(UI32 width, UI32 height, void *pInRGB, void *pOutY, void *pOutUV, brcBool bigEndian)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height)
		&& (pInRGB != brcNull) && (pOutY != brcNull) && (pOutUV != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInRGB;
		UI08	*pOutByteY = (UI08*)pOutY;
		UI08	*pOutByteUV = (UI08*)pOutUV;
		UI32	MSB = (bigEndian ? FALSE : TRUE);
		UI32	LSB = (bigEndian ? TRUE : FALSE);
		UI32	row;
		UI32	column;
		UI16	value;
		UI08	r, g, b;
		for (row = 0; row < height; row++){
			for (column = 0; column < width; column++, pInByte += PIXEL_BYTE_RGB565, pOutByteY++){
				// Old version
				/*UI16	value = ((*(pInByte + MSB)) << 8) + (*(pInByte + LSB));
				UI08	r = (UI08)((value >> BITSHIFT_RGB565_R)&BITMASK_RGB565_R);
				UI08	g = (UI08)((value >> BITSHIFT_RGB565_G)&BITMASK_RGB565_G);
				UI08	b = (UI08)((value >> BITSHIFT_RGB565_B)&BITMASK_RGB565_B);*/
				// New version
				value = ((*(pInByte + MSB)) << BITSHIFT_VALUE_8) + (*(pInByte + LSB));
				r = (UI08)((value & 0xF800) >> BITSHIFT_VALUE_8);
				g = (UI08)((value & 0x07E0) >> BITSHIFT_VALUE_3);
				b = (UI08)((value & 0x001F) << BITSHIFT_VALUE_3);
				*pOutByteY = (UI08)CLIP(CALC_RGB2YUV_Y(r, g, b));
				if (column % 2){	// 奇数桁？
					*(pOutByteUV + YUV422SP_OFFSET_UV_U) = (UI08)CLIP(CALC_RGB2YUV_U(r, *pOutByteY));
					*(pOutByteUV + YUV422SP_OFFSET_UV_V) = (UI08)CLIP(CALC_RGB2YUV_V(b, *pOutByteY));
					pOutByteUV += PIXEL_BYTE_YUV422SP_UV;
				}
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertRGB565_YUV420sp(UI32 width, UI32 height, void *pInRGB, void *pOutY, void *pOutUV, brcBool bigEndian)
* @brief RGB565->YUV420sp変換
* @param[in]	width	画像幅
* @param[in]	height	画像高さ
* @param[in]	pInRGB	入力画像領域のポインタ
* @param[out]	pOutY	出力Y画像領域のポインタ
* @param[out]	pOutUV	出力UV画像領域のポインタ
* @param[in]	bigEndian	エンディアン指定 true:ビッグエンディアン false:リトルエンディアン
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertRGB565_YUV420sp(UI32 width, UI32 height, void *pInRGB, void *pOutY, void *pOutUV, brcBool bigEndian)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height)
		&& (pInRGB != brcNull) && (pOutY != brcNull) && (pOutUV != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInRGB;
		UI08	*pOutByteY = (UI08*)pOutY;
		UI08	*pOutByteUV = (UI08*)pOutUV;
		UI32	MSB = (bigEndian ? FALSE : TRUE);
		UI32	LSB = (bigEndian ? TRUE : FALSE);
		UI32	row;
		UI32	column;
		UI16	value;
		UI08	r, g, b;
		for (row = 0; row < height; row++){
			for (column = 0; column < width; column++, pInByte += PIXEL_BYTE_RGB565, pOutByteY++){
				// Old version
				/*UI16	value = ((*(pInByte + MSB)) << 8) + (*(pInByte + LSB));
				UI08	r = (UI08)((value >> BITSHIFT_RGB565_R)&BITMASK_RGB565_R);
				UI08	g = (UI08)((value >> BITSHIFT_RGB565_G)&BITMASK_RGB565_G);
				UI08	b = (UI08)((value >> BITSHIFT_RGB565_B)&BITMASK_RGB565_B);*/
				// New version
				value = ((*(pInByte + MSB)) << BITSHIFT_VALUE_8) + (*(pInByte + LSB));
				r = (UI08)((value & 0xF800) >> BITSHIFT_VALUE_8);
				g = (UI08)((value & 0x07E0) >> BITSHIFT_VALUE_3);
				b = (UI08)((value & 0x001F) << BITSHIFT_VALUE_3);
				*pOutByteY = (UI08)CLIP(CALC_RGB2YUV_Y(r, g, b));
				if ((row % 2) && (column % 2)){	// 奇数行＆奇数桁か？
					*(pOutByteUV + YUV420SP_OFFSET_UV_U) = (UI08)CLIP(CALC_RGB2YUV_U(r, *pOutByteY));
					*(pOutByteUV + YUV420SP_OFFSET_UV_V) = (UI08)CLIP(CALC_RGB2YUV_V(b, *pOutByteY));
					pOutByteUV += PIXEL_BYTE_YUV420SP_UV;
				}
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}