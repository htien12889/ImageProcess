﻿/**
 * @file 	BrcImageAffineTransform.c
 * @brief 	アフィン変換ソースファイル
 * @author 	kyoshitake
 * @date 	2016/06/22
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#include <float.h>
#include <limits.h>
#include <math.h>
#include <string.h>
#include "BrcImageInterpolation.h"
#include "BrcImageProcessingCommon.h"
#include "BrcMemoryUsage.h"

#define RECTANGLE_CORNER_NUM		4
#define PI_FP32						3.14159265f
#define INTER_BITS					5
#define INTER_TAB_SIZE				32
#define AB_SCALES					1024        // 1 << 10
#define CLIP(x, min, max)			((x) > (max) ? (max) : (x) < (min) ? (min) : (x))
#define BOUNDARY_SCALE_ANGLE(angle) ((angle) / 2.0f)
#define BICUBIC_INDEX(tab, alpha)   ((tab) + (alpha) * 16)
#define BICUBIC_COEFFS				-0.75f
#define COEFFS_INDEX_0(a, x)		((((a) * ((x) + 1) - 5 * (a)) * ((x) + 1) + 8 * (a)) * ((x) + 1) - 4 * (a))	
#define COEFFS_INDEX_1(a, x)		((((a) + 2) * (x) - ((a) + 3)) * (x) * (x) + 1)
#define COEFFS_INDEX_2(a, x)		((((a) + 2) * (1 - (x)) - ((a) + 3)) * (1 - (x)) * (1 - (x)) + 1)
#define SCALE(value)				(1.0f / (value))

PRIVATE void initInterTab1D(FP32 *tab, SI32 tabsz);
PRIVATE void interpolateCubic(FP32 x, FP32 *coeffs);
PRIVATE void initBicubic(FP32 *tab);

/** TiltByAffineTransform( UI32 inWidth, UI32 inHeight, void *pInRGB,
*		UI32 outWidth, UI32 outHeight, void *pOutRGB, FP32 angleX, FP32 angleY)
* @brief 斜形
* @param[in]	inWidth		in 画像幅
* @param[in]	inHeight	in 画像高さ
* @param[in]	pInRGB		入力画像領域のポインタ
* @param[in]	outWidth	out 画像幅
* @param[in]	outHeight	out 画像高さ
* @param[out]	pOutRGB		出力画像領域のポインタ
* @param[in]	angleX		横方向傾斜度（-90.0～90.0）
* @param[in]	angleY		縦方向傾斜度（-90.0～90.0）
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 TiltByAffineTransform(UI32 inWidth, UI32 inHeight, void *pInRGB,
	UI32 outWidth, UI32 outHeight, void *pOutRGB, FP32 angleX, FP32 angleY)
{
#if __tracking
	Memory_Start();
#endif
	static const FP32	boundarySkewAngle = BOUNDARY_SCALE_ANGLE(PI_FP32);
	SI32	err = ((0 < inWidth) && (0 < inHeight) && (0 < outWidth) && (0 < outHeight)
		&& (pInRGB != brcNull) && (pOutRGB != brcNull)
		&& (-boundarySkewAngle < angleX) && (angleX < boundarySkewAngle)
		&& (-boundarySkewAngle < angleY) && (angleY < boundarySkewAngle) ? SUCCESS : EINVAL);
	if (err == 0){
		FP32	tx = tanf((FP32)-angleX);		/// 正接
		FP32	ty = tanf((FP32)-angleY);		/// 正接
		FP32	det = (FP32)(1.0 - tx * ty);	/// アフィン変換せん断の行列式
		/// 逆変換が存在する(せん断しても潰れてなくならない)
		if (fabs(det) >= FLT_EPSILON){
			FP32	invPosX, invPosY;						/// 逆変換先の座標
			SI32	interpolationVal[RGB_CHANNELS];			/// 補間ピクセル値
			UI08	*pInCurrent = (UI08*)pInRGB;
			UI08	*pOutCurrent = (UI08*)pOutRGB;			/// 出力画像へのアクセス
			UI32	sizeOutputImage = outWidth * RGB_CHANNELS * outHeight;
			FP32	tab[16384] = { 0 };
			UI32	i, j;									/// ピクセル値番号
			SI32	positionXScale, positionYScale, x, y, xx, yy, alpha, sstep, sx, sy, k, m;
			FP32    sum;
			FP32    *tabIndex;
			UI08    *pPixelImg;
			// initialize BicubicInterpolation value
			initBicubic(tab);
			for (i = 0; i < outHeight; ++i){
				for (j = 0; j < outWidth; ++j){
					/// アフィン変換
					invPosX = (FP32)(j + (tx * i));
					invPosY = (FP32)((ty * j) + i);
					invPosX /= det;
					invPosY /= det;
					positionXScale = (SI32)(invPosX * AB_SCALES);
					positionYScale = (SI32)(invPosY * AB_SCALES);
					x = positionXScale >> INTER_BITS;
					y = positionYScale >> INTER_BITS;
					xx = x >> INTER_BITS;
					yy = y >> INTER_BITS;
					alpha = ((y & (INTER_TAB_SIZE - 1))*INTER_TAB_SIZE + (x & (INTER_TAB_SIZE - 1)));
					sstep = inWidth*RGB_CHANNELS;
					tabIndex = BICUBIC_INDEX(tab, alpha);
					sx = xx - 1, sy = yy - 1;
					pPixelImg = pInCurrent + sy*sstep + sx*RGB_CHANNELS;
					sum = BYTE_RESET;
					if ((0 <= (xx - 1)) && ((xx + 3) < (SI32)inWidth) && (0 <= (yy - 1)) && ((yy + 3) < (SI32)inHeight)){
						for (k = 0; k < RGB_CHANNELS; k++){
							sum = (pPixelImg[0] * tabIndex[0]) + (pPixelImg[RGB_CHANNELS] * tabIndex[1])
								+ (pPixelImg[RGB_CHANNELS * 2] * tabIndex[2]) + (pPixelImg[RGB_CHANNELS * 3] * tabIndex[3]);
							pPixelImg += sstep;
							sum += (pPixelImg[0] * tabIndex[4]) + (pPixelImg[RGB_CHANNELS] * tabIndex[5])
								+ (pPixelImg[RGB_CHANNELS * 2] * tabIndex[6]) + (pPixelImg[RGB_CHANNELS * 3] * tabIndex[7]);
							pPixelImg += sstep;
							sum += (pPixelImg[0] * tabIndex[8]) + (pPixelImg[RGB_CHANNELS] * tabIndex[9])
								+ (pPixelImg[RGB_CHANNELS * 2] * tabIndex[10]) + (pPixelImg[RGB_CHANNELS * 3] * tabIndex[11]);
							pPixelImg += sstep;
							sum += (pPixelImg[0] * tabIndex[12]) + (pPixelImg[RGB_CHANNELS] * tabIndex[13])
								+ (pPixelImg[RGB_CHANNELS * 2] * tabIndex[14]) + (pPixelImg[RGB_CHANNELS * 3] * tabIndex[15]);
							pPixelImg += 1 - sstep * RGB_CHANNELS;
							interpolationVal[k] = (SI32)sum;
						}
						*(pOutCurrent++) = (UI08)CLIP(interpolationVal[0], BYTE_RESET, BYTE_FULLSET);
						*(pOutCurrent++) = (UI08)CLIP(interpolationVal[1], BYTE_RESET, BYTE_FULLSET);
						*(pOutCurrent++) = (UI08)CLIP(interpolationVal[2], BYTE_RESET, BYTE_FULLSET);
					}
					else {
						SI32 x[4], y[4];
						UI08 k;
						if ((sx >= (SI32)inWidth) || (sx + 4 < 0) || (sy >= (SI32)inHeight) || (sy + 4 < 0)){
							pOutCurrent += RGB_CHANNELS;
							continue;
						}
						for (k = 0; k < 4; k++){
							//Get values x outside image
							if ((sx + k) < (SI32)inWidth && (sx + k) >= 0){
								x[k] = (sx + k) * RGB_CHANNELS;
							}
							else {
								if (sx + k >= (SI32)inWidth){
									x[k] = (inWidth - 1) * RGB_CHANNELS;
								}
								else {
									x[k] = BYTE_RESET;
								}
							}
							//Get values y outside image
							if ((sy + k) < (SI32)inHeight && (sy + k) >= 0){
								y[k] = (sy + k);
							}
							else {
								if (sy + k >= (SI32)inHeight){
									y[k] = (inHeight - 1);
								}
								else {
									y[k] = BYTE_RESET;
								}
							}
						}
						SI32 yi;
						UI08 *src;
						for (k = 0; k < RGB_CHANNELS; k++, pInCurrent++, tabIndex -= 16){
							sum = BYTE_RESET;
							for (m = 0; m < 4; m++, tabIndex += 4){
								yi = y[m];
								src = pInCurrent + yi * sstep;
								if (yi < BYTE_RESET){
									continue;
								}
								if (x[0] >= BYTE_RESET){
									sum += (src[x[0]]) * tabIndex[0];
								}
								if (x[1] >= BYTE_RESET){
									sum += (src[x[1]]) * tabIndex[1];
								}
								if (x[2] >= BYTE_RESET){
									sum += (src[x[2]]) * tabIndex[2];
								}
								if (x[3] >= BYTE_RESET){
									sum += (src[x[3]]) * tabIndex[3];
								}
							}
							*(pOutCurrent++) = (UI08)CLIP(sum, BYTE_RESET, BYTE_FULLSET);
						}
						pInCurrent -= RGB_CHANNELS;
					}
				}
			}
		}
		else {
			err = EINVAL;
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** RotateByAffineTransform(UI32 inWidth, UI32 inHeight, void *pInRGB,
* 		UI32 outWidth, UI32 outHeight, void *pOutRGB, FP32 angle)
* @brief 斜形
* @param[in]	inWidth		in 画像幅
* @param[in]	inHeight	in 画像高さ
* @param[in]	pInRGB		入力画像領域のポインタ
* @param[in]	outWidth	out 画像幅
* @param[in]	outHeight	out 画像高さ
* @param[out]	pOutRGB		出力画像領域のポインタ
* @param[in]	angle		回転度数（rad), (-π～π）
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 RotateByAffineTransform(UI32 inWidth, UI32 inHeight, void *pInRGB,
	UI32 outWidth, UI32 outHeight, void *pOutRGB, FP32 angle)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < inWidth) && (0 < inHeight) && (0 < outWidth) && (0 < outHeight)
		&& (pInRGB != brcNull) && (pOutRGB != brcNull) && (-PI_FP32 <= angle) && (angle <= PI_FP32) ? SUCCESS : EINVAL);

	if (err == 0){
		FP32		invPosX, invPosY;								/// 逆変換先の座標
		FP32		c = cosf((FP32)-angle);							/// 余弦の値(逆変換)
		FP32		s = sinf((FP32)-angle);							/// 正弦の値(逆変換)
		SI32		interpolationVal[RGB_CHANNELS];
		UI08		*pInCurrent = (UI08*)pInRGB;					/// 補間ピクセル値
		UI08		*pOutCurrent = (UI08*)pOutRGB;					/// 出力画像へのアクセス
		UI32		sizeOutputImage = outWidth * RGB_CHANNELS * outHeight;
		FP32		tab[16384] = { 0 };
		FP32		cox = (FP32)(outWidth >> 1);
		FP32		coy = (FP32)(outHeight >> 1);
		FP32		cix = (FP32)(inWidth >> 1);
		FP32		ciy = (FP32)(inHeight >> 1);
		FP32		deltaX, deltaY;
		SI32		x, y, xValue, yValue, sx, sy;
		UI32		sstep = inWidth * RGB_CHANNELS;
		SI32		alpha;
		FP32		*w;
		UI08		*src;

		// initialize BicubicInterpolation value
		initBicubic(tab);

		/// 出力画像のピクセルを埋めていく
		UI32		i, j, k;
		for (i = 0; i < outHeight; ++i){
			for (j = 0; j < outWidth; ++j){
				/// アフィン逆変換
				deltaX = (FP32)((FP32)j - cox);
				deltaY = (FP32)((FP32)i - coy);
				invPosX = (FP32)((deltaX * c) - (deltaY * s) + cix);
				invPosY = (FP32)((deltaX * s) + (deltaY * c) + ciy);

				x = (SI32)(invPosX * AB_SCALES);
				y = (SI32)(invPosY * AB_SCALES);
				x = x >> INTER_BITS;
				y = y >> INTER_BITS;
				alpha = (SI32)((y & (INTER_TAB_SIZE - 1))*INTER_TAB_SIZE + (x & (INTER_TAB_SIZE - 1)));
				xValue = x >> INTER_BITS;
				yValue = y >> INTER_BITS;
				w = BICUBIC_INDEX(tab, alpha);
				sx = xValue - 1, sy = yValue - 1;
				src = pInCurrent + (sy <= 0 ? 0 : sy) * sstep + (sx <= 0 ? 0 : sx) * RGB_CHANNELS;

				// remapbicubic
				if ((0.0 <= sx) && (sx < (SI32)(inWidth - 3)) && (0.0 <= sy) && (sy < (SI32)(inHeight - 3))){
					for (k = 0; k < RGB_CHANNELS; k++){
						SI32 sum = (SI32)(src[0] * w[0] + src[RGB_CHANNELS] * w[1] + src[RGB_CHANNELS * 2] * w[2] + src[RGB_CHANNELS * 3] * w[3]);
						src += sstep;
						sum += (SI32)(src[0] * w[4] + src[RGB_CHANNELS] * w[5] + src[RGB_CHANNELS * 2] * w[6] + src[RGB_CHANNELS * 3] * w[7]);
						src += sstep;
						sum += (SI32)(src[0] * w[8] + src[RGB_CHANNELS] * w[9] + src[RGB_CHANNELS * 2] * w[10] + src[RGB_CHANNELS * 3] * w[11]);
						src += sstep;
						sum += (SI32)(src[0] * w[12] + src[RGB_CHANNELS] * w[13] + src[RGB_CHANNELS * 2] * w[14] + src[RGB_CHANNELS * 3] * w[15]);
						src += 1 - sstep * RGB_CHANNELS;
						interpolationVal[k] = sum;
					}
					*(pOutCurrent++) = (UI08)CLIP(interpolationVal[0], BYTE_RESET, BYTE_FULLSET);
					*(pOutCurrent++) = (UI08)CLIP(interpolationVal[1], BYTE_RESET, BYTE_FULLSET);
					*(pOutCurrent++) = (UI08)CLIP(interpolationVal[2], BYTE_RESET, BYTE_FULLSET);
				}
				else{
					// Check boder values
					SI32 x[4], y[4];
					if ((sx >= (SI32)inWidth || sx + 4 <= 0 || sy >= (SI32)inHeight || sy + 4 <= 0)){
						pOutCurrent += RGB_CHANNELS;
						continue;
					}
					UI08 k, i;
					// Calculate boder values 
					for (k = 0; k < 4; k++){
						// calculate x boder values
						if ((sx + k) < (SI32)inWidth && (sx + k) >= 0){
							x[k] = (sx + k) * RGB_CHANNELS;
						}
						else if (sx + k >= (SI32)inWidth){
							x[k] = (inWidth - 1) * RGB_CHANNELS;
						}
						else {
							x[k] = BYTE_RESET;
						}
						// calculate y boder values
						if ((sy + k) < (SI32)inHeight && (sy + k) >= 0){
							y[k] = (sy + k);
						}
						else if (sy + k >= (SI32)inHeight){
							y[k] = (inHeight - 1);
						}
						else {
							y[k] = BYTE_RESET;
						}
					}

					SI32 sum, yi;
					for (k = 0; k < RGB_CHANNELS; k++, pInCurrent++, w -= 16){
						sum = 0;
						for (i = 0; i < 4; i++, w += 4){
							yi = y[i];
							src = pInCurrent + yi*sstep;
							if (yi < 0){
								continue;
							}
							if (x[0] >= BYTE_RESET){
								sum += (SI32)(src[x[0]] * w[0]);
							}
							if (x[1] >= BYTE_RESET){
								sum += (SI32)(src[x[1]] * w[1]);
							}
							if (x[2] >= BYTE_RESET){
								sum += (SI32)(src[x[2]] * w[2]);
							}
							if (x[3] >= BYTE_RESET){
								sum += (SI32)(src[x[3]] * w[3]);
							}
						}
						interpolationVal[k] = sum;
					}
					pInCurrent -= RGB_CHANNELS;

					*(pOutCurrent++) = (UI08)CLIP(interpolationVal[0], BYTE_RESET, BYTE_FULLSET);
					*(pOutCurrent++) = (UI08)CLIP(interpolationVal[1], BYTE_RESET, BYTE_FULLSET);
					*(pOutCurrent++) = (UI08)CLIP(interpolationVal[2], BYTE_RESET, BYTE_FULLSET);
				}
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** AffineTransformShift(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, SI32 moveX, SI32 moveY)
* @brief 斜形
* @param[in]	width	画像幅
* @param[in]	height	画像高さ
* @param[in]	pInRGB	入力画像領域のポインタ
* @param[out]	pOutRGB	出力画像領域のポインタ
* @param[in]	moveX	横移動量
* @param[in]	moveY	縦移動量
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ShiftByAffineTransform(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, SI32 moveX, SI32 moveY)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height)
		&& (pInRGB != brcNull) && (pOutRGB != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInBegin, *pOutBegin;										/// 画像のピクセルを指す
		UI32	bytesOfWidth = width * RGB_CHANNELS * sizeof(UI08);			/// 入力画像の横幅のバイト数
		UI32	initialPointX = ((moveX < 0) ? 0 : abs(moveX));				/// コピーの開始点
		UI32	initialPointY = ((moveY < 0) ? 0 : abs(moveY));				/// コピーの開始点
		UI32	inNextRow = width * RGB_CHANNELS;							/// 次の行へ進む数
		UI32	outNextRow = (width + abs(moveX)) * RGB_CHANNELS;			/// 次の行へ進む数
		UI32	i;

		pInBegin = (UI08*)pInRGB;
		pOutBegin = (UI08*)pOutRGB + ((initialPointY * (width + abs(moveX)) + initialPointX) * RGB_CHANNELS);

		for (i = 0; i < height; ++i){
			memcpy(pOutBegin, pInBegin, bytesOfWidth);
			pInBegin += inNextRow;
			pOutBegin += outNextRow;
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** GetSkewedImageSize(UI32 inWidth, UI32 inHeight, UI32 *pOutWidth, UI32 *pOutHeight, FP64 angleX, FP64 angleY)
* @brief		せん断後の画像サイズを計算
* @param[in]	inWidth		変換前の幅
* @param[in]	inHeight	変換前の高さ
* @param[out]	pOutWidth	変換後の幅
* @param[out]	pOutHeight	変換後の高さ
* @param[in]	angleX		横方向にせん断する角(rad)
* @param[in]	angleY		縦方向にせん断する角(rad)
* @return 		0:正常，その他:異常
*/
PUBLIC SI32 GetSkewedImageSize(UI32 inWidth, UI32 inHeight, UI32 *pOutWidth, UI32 *pOutHeight, FP32 angleX, FP32 angleY)
{
	static const FP32	boundarySkewAngle = BOUNDARY_SCALE_ANGLE(PI_FP32);
	SI32	err = ((0 < inWidth) && (0 < inHeight)
		&& (pOutWidth != NULL) && (pOutHeight != NULL)
		&& (-boundarySkewAngle < angleX) && (angleX < boundarySkewAngle)
		&& (-boundarySkewAngle < angleY) && (angleY < boundarySkewAngle) ? SUCCESS : EINVAL);
	if (err == 0){
		FP32	tX = tanf((FP32)angleX);					/// 正接
		FP32	tY = tanf((FP32)angleY);					/// 正接
		*pOutWidth = (UI32)(inWidth + (tX * inHeight));
		*pOutHeight = (UI32)((inWidth * tY) + inHeight);
	}
	return err;
}

/** interpolateCubic(FP32 x, FP32* coeffs)
* @brief		calculate bi-cubic
* @param[in]	x			x coordinates
* @param[in]	coeffs		coefficients
* @return 		none
*/
PRIVATE void interpolateCubic(FP32 x, FP32 *coeffs)
{
	const FP32 a = BICUBIC_COEFFS;
	coeffs[0] = COEFFS_INDEX_0(a, x);
	coeffs[1] = COEFFS_INDEX_1(a, x);
	coeffs[2] = COEFFS_INDEX_2(a, x);
	coeffs[3] = 1.f - coeffs[0] - coeffs[1] - coeffs[2];
}

/** initInterTab1D(FP32* tab, SI32 tabsz)
* @brief		initialize inter tab
* @param[in]	tab		inter tab
* @param[in]	tabsz	inter tab size
* @return 		none
*/
PRIVATE void initInterTab1D(FP32 *tab, SI32 tabsz)
{
	FP32 scale = SCALE(tabsz);
	SI32 i;
	for (i = 0; i < tabsz; i++, tab += 4){
		interpolateCubic(i * scale, tab);
	}
}

/** initBicubic(FP32* tab, SI32 tabsz)
* @brief		initialize bicubic
* @param[in]	tab		inter tab
* @return 		none
*/
PRIVATE void initBicubic(FP32 *tab)
{
	FP32 tabs[128];
	initInterTab1D(tabs, INTER_TAB_SIZE);
	SI32 i, j, k1, k2;
	SI32 ksize = 4;
	FP32 vy, v;
	for (i = 0; i < INTER_TAB_SIZE; i++){
		for (j = 0; j < INTER_TAB_SIZE; j++, tab += ksize * ksize){
			for (k1 = 0; k1 < ksize; k1++){
				vy = tabs[(i * ksize) + k1];
				for (k2 = 0; k2 < ksize; k2++){
					v = vy * tabs[(j * ksize) + k2];
					tab[(k1 * ksize) + k2] = v;
				}
			}
		}
	}
}

/** GetRotatedImageSize( UI32 inWidth, UI32 inHeight, UI32 *pOutWidth, UI32 *pOutHeight, FP32 angle)
* @brief		回転後の画像サイズを計算
* @param[in]	inWidth		変換前の幅
* @param[in]	inHeight	変換前の高さ
* @param[out]	pOutWidth	変換後の幅
* @param[out]	pOutHeight	変換後の高さ
* @param[in]	angle		回転角(rad)
* @return		0:正常，その他:異常
*/
PUBLIC SI32 GetRotatedImageSize(UI32 inWidth, UI32 inHeight, UI32 *pOutWidth, UI32 *pOutHeight, FP32 angle)
{
	SI32	err = ((0 < inWidth) && (0 < inHeight)
		&& (pOutWidth != NULL) && (pOutHeight != NULL)
		&& (-PI_FP32 <= angle) && (angle <= PI_FP32) ? SUCCESS : EINVAL);

	if (err == 0){
		FP32	c = cosf((float)angle);													/// 余弦の値(順変換)
		FP32	s = sinf((float)angle);													/// 正弦の値(順変換)
		SI32	xMin = INT_MAX, xMax = INT_MIN;											/// x座標の範囲
		SI32	yMin = INT_MAX, yMax = INT_MIN;											/// y座標の範囲
		SI32	rotatedPositionX, rotatedPositionY;										/// 回転後の座標
		UI32	cornerPositionsX[RECTANGLE_CORNER_NUM] = { 0, --inWidth, 0, inWidth };	/// 四隅のx座標
		UI32	cornerPositionsY[RECTANGLE_CORNER_NUM] = { 0, 0, --inHeight, inHeight };	/// 四隅のy座標
		UI32	*pX = cornerPositionsX;													/// x座標を走査するためのポインタ
		UI32	*pY = cornerPositionsY;													/// y座標を走査するためのポインタ
		UI32	*pXEnd = cornerPositionsX + RECTANGLE_CORNER_NUM;
		UI32	*pYEnd = cornerPositionsY + RECTANGLE_CORNER_NUM;
		/// 四隅の座標に対する走査
		for (; pX != pXEnd; ++pX, ++pY){
			/// 回転
			rotatedPositionX = (SI32)(((FP32)(*pX) * c) - ((FP32)(*pY) * s));
			rotatedPositionY = (SI32)(((FP32)(*pX) * s) + ((FP32)(*pY) * c));
			/// x,y座標の最大値,最小値を求める
			if (xMin > rotatedPositionX){
				xMin = rotatedPositionX;
			}
			if (xMax < rotatedPositionX){
				xMax = rotatedPositionX;
			}
			if (yMin > rotatedPositionY){
				yMin = rotatedPositionY;
			}
			if (yMax < rotatedPositionY){
				yMax = rotatedPositionY;
			}
		}
		*pOutWidth = (UI32)(xMax - xMin + 5);
		*pOutHeight = (UI32)(yMax - yMin + 5);
	}
	return err;
}

/** GetShiftedImageSize( UI32 inWidth, UI32 inHeight, UI32 *pOutWidth, UI32 *pOutHeight, SI32 moveX, SI32 moveY)
* @brief		回転後の画像サイズを計算
* @param[in]	inWidth		変換前の幅
* @param[in]	inHeight	変換前の高さ
* @param[out]	pOutWidth	変換後の幅
* @param[out]	pOutHeight	変換後の高さ
* @param[in]	moveX		横方向の移動
* @param[in]	moveY		縦方向の移動
* @return 		none
*/
PUBLIC void GetShiftedImageSize(UI32 inWidth, UI32 inHeight, UI32 *pOutWidth, UI32 *pOutHeight, SI32 moveX, SI32 moveY)
{
	SI32	err = ((0 < inWidth) && (0 < inHeight)
		&& (pOutWidth != NULL) && (pOutHeight != NULL)
		&& ((SI32)inWidth - 1 > moveX) && ((SI32)inHeight - 1 > moveY) ? SUCCESS : EINVAL);
	if (err == 0){
		*pOutWidth = inWidth + abs((int)moveX);
		*pOutHeight = inHeight + abs((int)moveY);
	}
}