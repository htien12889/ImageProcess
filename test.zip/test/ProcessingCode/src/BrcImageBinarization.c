﻿/**
* @file 	BrcImageBinarization.c
* @brief 	二値化ソースファイル
* @author 	EMT-BrycenVN
* @date 	2016/06/22
* @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
*/
#include <stdlib.h>
#include <string.h>
#include "BrcType.h"
#include "BrcImageProcessingCommon.h"

#define pGrayscale(R,G,B)			((0.2989*R)+(0.5870*G)+(0.1140*B))
#define UPER_SMT_EDM_EDFS_EDJJN		255
#define LOWER_SMT_EDM_EDFS_EDJJN	0
#define UPER_PTILE					100
#define LOWER_PTILE					0
#define BLACK						0
#define WHITE						1
#define BASE_KERNEL					4
#define SIMPLE_KERNEL				16
#define LARGER_KERNEL				48
#define SIZE_OF_CHANEL				256

/** BinarizeByPtileMethod(UI32 width, UI32 height, void *pInRGB, void *pOutMono, UI32 threshold)
* @brief P-タイル法二値化
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInRGB		入力画像領域のポインタ
* @param[out]	pOutMono	出力画像領域のポインタ
* @param[in]	threshold	閾値
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 BinarizeByPtileMethod(UI32 width, UI32 height, void *pInRGB, void *pOutMono, UI32 threshold)
{
	SI32	err = ((0 < (SI32)width) && (0 < (SI32)height)
		&& (pInRGB != brcNull) && (pOutMono != brcNull) && ((SI32)threshold <= UPER_PTILE) 
		&& ((SI32)threshold >= LOWER_PTILE) ? SUCCESS : EINVAL);
	if (err == 0){
		BrcBGR *pInImage = (BrcBGR*)pInRGB;
		UI08 *pOutImage = (UI08*)pOutMono;
		UI32 i;
		UI32 bThreshold = 0;
		UI32 density[SIZE_OF_CHANEL] = { 0 };
		UI08 p;
		for (i = 0; i < width * height; i++) {
			p = (UI08)pGrayscale(pInImage[i].red, pInImage[i].green, pInImage[i].blue);
			density[p]++;	// density histogram
		}
		UI32 temp = 0;
		UI32 sum = 0;
		for (i = 0; i < SIZE_OF_CHANEL; i++){
			sum += density[i];
			temp = (UI32)(((FP32)sum / (width * height)) * UPER_PTILE);
			if (temp >= threshold){
				bThreshold = i;
				break;
			}
		}
		/* Setup binary data */
		for (i = 0; i < width * height; i++){
			p = (UI08)pGrayscale(pInImage[i].red, pInImage[i].green, pInImage[i].blue);
			if ((UI32)p < bThreshold) {
				pOutImage[i] = BLACK;
			}
			else {
				pOutImage[i] = WHITE;
			}
		}
	}
	return err;
}

/** BinarizeByModeMethod(UI32 width, UI32 height, void *pInRGB, void *pOutMono)
* @brief モード法二値化
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInRGB		入力画像領域のポインタ
* @param[out]	pOutMono	出力画像領域のポインタ
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 BinarizeByModeMethod(UI32 width, UI32 height, void *pInRGB, void *pOutMono)
{
	SI32	err = ((0 < (SI32)width) && (0 < (SI32)height)
		&& (pInRGB != brcNull) && (pOutMono != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		BrcBGR *pInImage = (BrcBGR*)pInRGB;
		UI08 *pOutImage = (UI08*)pOutMono;
		UI32 i, k, j;
		UI32 threshold = 0;
		UI32 iHisto[SIZE_OF_CHANEL] = { 0 };
		UI32 tmpHisto[SIZE_OF_CHANEL] = { 0 };
		UI08 p;
		UI32 iter = 0;
		for (i = 0; i < width * height; i++) {
			p = (UI08)pGrayscale(pInImage[i].red, pInImage[i].green, pInImage[i].blue);
			iHisto[p]++;	// density histogram
		}
		/* Temporary histogram */
		for (i = 0; i < SIZE_OF_CHANEL; i++){
			tmpHisto[i] = iHisto[i];
		}
		/* The histogram is iteratively smoothed until only two peaks remain (bimodal histogram)
		* Images with histograms having extremely unequal peaks or a broad and
		* flat valley are unsuitable for this method.
		*/
		UI32 bimodalFlag = 0;
		while (bimodalFlag == 0){
			/* Smooth with a 3 point running mean filter */
			for (i = 1; i < 255; i++){
				tmpHisto[i] = (iHisto[i - 1] + iHisto[i] + iHisto[i + 1]) / 3;
			}
			tmpHisto[0] = (iHisto[0] + iHisto[1]) / 3;	// outside
			tmpHisto[255] = (iHisto[254] + iHisto[255]) / 3;	// outside
			for (j = 0; j < SIZE_OF_CHANEL; j++){
				iHisto[j] = tmpHisto[j];
			}
			/* Check bimodal histogram. bimodalFlag = 0 is not yet bimodal histogram. */
			UI32 modes = 0;
			for (k = 1; k < 255; k++){
				if (iHisto[k - 1] < iHisto[k] && iHisto[k + 1] < iHisto[k]) {
					modes++;
					if (modes > 2){
						bimodalFlag = 0;
						break;
					}
				}
			}
			if (modes == 2){
				bimodalFlag = 1;
			}
			iter++;
			if (iter > 10000) {
				threshold = 0;
				break;	// Threshold not found after 10000 iterations.
			}
		}
		/* The threshold is the low point between the two peaks. */
		UI32 gi = 0;
		UI32 gj = 0;
		for (i = 1; i < 255; i++){
			if (iHisto[i - 1] < iHisto[i] && iHisto[i + 1] < iHisto[i]){
				gi += i;
				break;
			}
		}
		for (i = 1; i < 255; i++){
			if (iHisto[i - 1] < iHisto[i] && iHisto[i + 1] < iHisto[i] && i != gi){
				gj += i;
				break;
			}
		}
		/* Find the lowest point */
		UI32 i1, i2;
		if (gi > gj){
			i1 = gj;
			i2 = gi;
		}
		else{
			i1 = gi;
			i2 = gj;
		}
		threshold = i1;
		for (i = i1 + 1; i <= i2; i++){
			if (iHisto[i] <= iHisto[threshold]){
				threshold = i;
			}
		}
		/* Setup binary data */
		for (i = 0; i < width * height; i++){
			p = (UI08)pGrayscale(pInImage[i].red, pInImage[i].green, pInImage[i].blue);
			if ((UI32)p < threshold) {
				pOutImage[i] = BLACK;
			}
			else{
				pOutImage[i] = WHITE;
			}
		}
	}
	return err;
}

/** BinarizeByDAMethod(UI32 width, UI32 height, void *pInRGB, void *pOutMono)
* @brief 判別分析法二値化
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInRGB		入力画像領域のポインタ
* @param[out]	pOutMono	出力画像領域のポインタ
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 BinarizeByDAMethod(UI32 width, UI32 height, void *pInRGB, void *pOutMono)
{
	SI32	err = ((0 < (SI32)width) && (0 < (SI32)height)
		&& (pInRGB != brcNull) && (pOutMono != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		BrcBGR *pInImage = (BrcBGR*)pInRGB;
		UI08 *pOutImage = (UI08*)pOutMono;
		UI32 i;
		UI32 threshold = 0;
		UI32 density[SIZE_OF_CHANEL] = { 0 };
		UI08 p;
		for (i = 0; i < width * height; i++){
			p = (UI08)pGrayscale(pInImage[i].red, pInImage[i].green, pInImage[i].blue);
			density[p]++;	// density histogram
		}
		UI32 sum = 0;
		for (i = 1; i < SIZE_OF_CHANEL; ++i){
			sum += i * density[i];
		}
		UI32 sumB = 0;
		UI32 wB = 0;
		UI32 wF = 0;
		FP32 mB, mF;
		FP32 max = 0.0;
		FP32 between = 0.0;
		UI32 threshold1 = 0;
		UI32 threshold2 = 0;
		for (i = 0; i < SIZE_OF_CHANEL; ++i){
			wB += density[i];
			if (wB == 0){
				continue;
			}
			wF = (width * height) - wB;
			if (wF == 0){
				break;
			}
			sumB += i * density[i];
			mB = (FP32)sumB / wB;
			mF = (FP32)(sum - sumB) / wF;
			between = wB * wF * (mB - mF) * (mB - mF);
			if (between >= max){
				threshold1 = i;
				if (between > max){
					threshold2 = i;
				}
				max = between;
			}
		}
		threshold = (threshold1 + threshold2) / 2;
		/* Setup binary data */
		for (i = 0; i < width * height; i++){
			p = (UI08)pGrayscale(pInImage[i].red, pInImage[i].green, pInImage[i].blue);
			if ((UI32)p < threshold){
				pOutImage[i] = BLACK;
			}
			else {
				pOutImage[i] = WHITE;
			}
		}
	}
	return err;
}

/** BinarizeBySMTMethod(UI32 width, UI32 height, void *pInRGB, void *pOutMono, UI32 threshold)
* @brief 単一手動閾値方式二値化
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInRGB		入力画像領域のポインタ
* @param[out]	pOutMono	出力画像領域のポインタ
* @param[in]	threshold	閾値
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 BinarizeBySMTMethod(UI32 width, UI32 height, void *pInRGB, void *pOutMono, UI32 threshold)
{
	SI32	err = ((0 < (SI32)width) && (0 < (SI32)height)
		&& (pInRGB != brcNull) && (pOutMono != brcNull) && ((SI32)threshold <= UPER_SMT_EDM_EDFS_EDJJN) && ((SI32)threshold >= LOWER_SMT_EDM_EDFS_EDJJN) ? SUCCESS : EINVAL);
	if (err == 0){
		BrcBGR *pInImage = (BrcBGR*)pInRGB;
		UI08 *pOutImage = (UI08*)pOutMono;
		UI32 i;
		UI08 p;
		for (i = 0; i < width * height; i++){
			p = (UI08)pGrayscale(pInImage[i].red, pInImage[i].green, pInImage[i].blue);
			if ((UI32)p < threshold) {
				pOutImage[i] = BLACK;
			}
			else {
				pOutImage[i] = WHITE;
			}
		}
	}
	return err;
}

/** BinarizeByEDMethod(UI32 width, UI32 height, void *pInRGB, void *pOutMono, UI32 threshold)
* @brief 誤差分散法二値化
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInRGB		入力画像領域のポインタ
* @param[out]	pOutMono	出力画像領域のポインタ
* @param[in]	threshold	閾値
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 BinarizeByEDMethod(UI32 width, UI32 height, void *pInRGB, void *pOutMono, UI32 threshold)
{
	SI32	err = ((0 < (SI32)width) && (0 < (SI32)height)
		&& (pInRGB != brcNull) && (pOutMono != brcNull) && ((SI32)threshold <= UPER_SMT_EDM_EDFS_EDJJN)
		&& ((SI32)threshold >= LOWER_SMT_EDM_EDFS_EDJJN) ? SUCCESS : EINVAL);
	if (err == 0){
		BrcBGR *pInImage = (BrcBGR*)pInRGB;
		UI08 *pOutImage = (UI08*)pOutMono;
		UI32 i, h, w;
		/* Convert pixels to grayscale */
		for (i = 0; i < width * height; i++){
			pOutImage[i] = (UI08)pGrayscale(pInImage[i].red, pInImage[i].green, pInImage[i].blue);
		}
		SI32 quantError;
		UI32 k;
		UI08 temp;
		for (h = 0; h < height; h++){
			for (w = 0; w < width; w++){
				k = w + (h * width);
				/* 1. Compute the value of the output pixel */
				temp = pOutImage[k];
				if (temp < threshold){
					pOutImage[k] = BLACK;
				}
				else{
					pOutImage[k] = WHITE;
				}
				/* 2. Compute the error value */
				quantError = temp - 255 * pOutImage[k];
				/* 3. Distribute the error */
				if ((w <= width - 2) && (h <= height - 2)){	// normal distribution
					pOutImage[k + 1] += quantError * 2 / BASE_KERNEL;
					pOutImage[k + width] += quantError * 1 / BASE_KERNEL;
					pOutImage[k + width + 1] += quantError * 1 / BASE_KERNEL;
				}
				else if ((w == width - 1) && (h != height - 1)){	// last column except last pixel
					pOutImage[k + width] += quantError * 1 / BASE_KERNEL;
				}
				else if ((h == height - 1) && (w != width - 1)){	// last row except last pixel
					pOutImage[k + 1] += quantError * 2 / BASE_KERNEL;
				}
				else{	// last pixel
					break;
				}
			}
		}
	}
	return err;
}

/** BinarizeByEDFSMethod(UI32 width, UI32 height, void *pInRGB, void *pOutMono, UI32 threshold)
* @brief Floyd&Steinberg型誤差分散法二値化
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInRGB		入力画像領域のポインタ
* @param[out]	pOutMono	出力画像領域のポインタ
* @param[in]	threshold	閾値
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 BinarizeByEDFSMethod(UI32 width, UI32 height, void *pInRGB, void *pOutMono, UI32 threshold)
{
	SI32	err = ((0 < (SI32)width) && (0 < (SI32)height)
		&& (pInRGB != brcNull) && (pOutMono != brcNull) && ((SI32)threshold <= UPER_SMT_EDM_EDFS_EDJJN) 
		&& ((SI32)threshold >= LOWER_SMT_EDM_EDFS_EDJJN) ? SUCCESS : EINVAL);
	if (err == 0){
		BrcBGR *pInImage = (BrcBGR*)pInRGB;
		UI08 *pOutImage = (UI08*)pOutMono;
		UI32 i, h, w;
		/* Convert pixels to grayscale */
		for (i = 0; i < width * height; i++){
			pOutImage[i] = (UI08)pGrayscale(pInImage[i].red, pInImage[i].green, pInImage[i].blue);
		}
		SI32 quantError;
		UI32 k;
		UI08 temp;
		for (h = 0; h < height; h++){
			for (w = 0; w < width; w++){
				k = w + (h * width);
				/* 1. Compute the value of the output pixel */
				temp = pOutImage[k];
				if (temp < threshold){
					pOutImage[k] = BLACK;
				}
				else{
					pOutImage[k] = WHITE;
				}
				/* 2. Compute the error value */
				quantError = temp - 255 * pOutImage[k];
				/* 3. Distribute the error */
				if ((w >= 1) && (w <= width - 2) && (h <= height - 2)){	// normal distribution
					pOutImage[k + 1] += quantError * 7 / SIMPLE_KERNEL;
					pOutImage[k + width - 1] += quantError * 3 / SIMPLE_KERNEL;
					pOutImage[k + width] += quantError * 5 / SIMPLE_KERNEL;
					pOutImage[k + width + 1] += quantError * 1 / SIMPLE_KERNEL;
				}
				else if ((w == 0) && (h != height - 1)){ //	first column except last pixel in that column
					pOutImage[k + 1] += quantError * 7 / SIMPLE_KERNEL;
					pOutImage[k + width] += quantError * 5 / SIMPLE_KERNEL;
					pOutImage[k + width + 1] += quantError * 1 / SIMPLE_KERNEL;
				}
				else if ((w == width - 1) && (h != height - 1)){	// last column except last pixel
					pOutImage[k + width - 1] += quantError * 3 / SIMPLE_KERNEL;
					pOutImage[k + width] += quantError * 5 / SIMPLE_KERNEL;
				}
				else if ((h == height - 1) && (w != width - 1)){	// last row except last pixel
					pOutImage[k + 1] += quantError * 7 / SIMPLE_KERNEL;
				}
				else{	// last pixel
					break;
				}
			}
		}
	}
	return err;
}

/** BinarizeByEDJJNMethod(UI32 width, UI32 height, void *pInRGB, void *pOutMono, UI32 threshold)
* @brief Jarvice,Judice&Ninke型誤差分散法二値化
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInRGB		入力画像領域のポインタ
* @param[out]	pOutMono	出力画像領域のポインタ
* @param[in]	threshold	閾値
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 BinarizeByEDJJNMethod(UI32 width, UI32 height, void *pInRGB, void *pOutMono, UI32 threshold)
{
	SI32	err = ((0 < (SI32)width) && (0 < (SI32)height)
		&& (pInRGB != brcNull) && (pOutMono != brcNull) && ((SI32)threshold <= UPER_SMT_EDM_EDFS_EDJJN) 
		&& ((SI32)threshold >= LOWER_SMT_EDM_EDFS_EDJJN) ? SUCCESS : EINVAL);
	if (err == 0){
		BrcBGR *pInImage = (BrcBGR*)pInRGB;
		UI08 *pOutImage = (UI08*)pOutMono;
		UI32 i, h, w;
		/* Convert pixels to grayscale */
		for (i = 0; i < width * height; i++){
			pOutImage[i] = (UI08)pGrayscale(pInImage[i].red, pInImage[i].green, pInImage[i].blue);
		}
		SI32 quantError;
		UI32 k;
		UI08 temp;
		for (h = 0; h < height; h++){
			for (w = 0; w < width; w++){
				k = w + (h * width);
				/* 1. Compute the value of the output pixel */
				temp = pOutImage[k];
				if (temp < threshold){
					pOutImage[k] = BLACK;
				}
				else {
					pOutImage[k] = WHITE;
				}
				/* 2. Compute the error value */
				quantError = temp - 255 * pOutImage[k];
				/* 3. Distribute the error */
				if ((w >= 2) && (w <= width - 3) && (h <= height - 3)){	// normal distribution
					pOutImage[k + 1] += quantError * 7 / LARGER_KERNEL;
					pOutImage[k + 2] += quantError * 5 / LARGER_KERNEL;
					pOutImage[k + width - 2] += quantError * 1 / SIMPLE_KERNEL;
					pOutImage[k + width - 1] += quantError * 5 / LARGER_KERNEL;
					pOutImage[k + width] += quantError * 7 / LARGER_KERNEL;
					pOutImage[k + width + 1] += quantError * 5 / LARGER_KERNEL;
					pOutImage[k + width + 2] += quantError * 1 / SIMPLE_KERNEL;
					pOutImage[k + 2 * width - 2] += quantError * 1 / LARGER_KERNEL;
					pOutImage[k + 2 * width - 1] += quantError * 1 / SIMPLE_KERNEL;
					pOutImage[k + 2 * width] += quantError * 5 / LARGER_KERNEL;
					pOutImage[k + 2 * width + 1] += quantError * 1 / SIMPLE_KERNEL;
					pOutImage[k + 2 * width + 2] += quantError * 1 / LARGER_KERNEL;
				}
				else if ((w == 0) && (h <= height - 3)){			// first column except 2 last pixel in that column
					pOutImage[k + 1] += quantError * 7 / LARGER_KERNEL;
					pOutImage[k + 2] += quantError * 5 / LARGER_KERNEL;
					pOutImage[k + width] += quantError * 7 / LARGER_KERNEL;
					pOutImage[k + width + 1] += quantError * 5 / LARGER_KERNEL;
					pOutImage[k + width + 2] += quantError * 1 / SIMPLE_KERNEL;
					pOutImage[k + 2 * width] += quantError * 5 / LARGER_KERNEL;
					pOutImage[k + 2 * width + 1] += quantError * 1 / SIMPLE_KERNEL;
					pOutImage[k + 2 * width + 2] += quantError * 1 / LARGER_KERNEL;
				}
				else if ((w == 1) && (h <= height - 3)){			// second column except 2 last pixel in that column
					pOutImage[k + 1] += quantError * 7 / LARGER_KERNEL;
					pOutImage[k + 2] += quantError * 5 / LARGER_KERNEL;
					pOutImage[k + width - 1] += quantError * 5 / LARGER_KERNEL;
					pOutImage[k + width] += quantError * 7 / LARGER_KERNEL;
					pOutImage[k + width + 1] += quantError * 5 / LARGER_KERNEL;
					pOutImage[k + width + 2] += quantError * 1 / SIMPLE_KERNEL;
					pOutImage[k + 2 * width - 1] += quantError * 1 / SIMPLE_KERNEL;
					pOutImage[k + 2 * width] += quantError * 5 / LARGER_KERNEL;
					pOutImage[k + 2 * width + 1] += quantError * 1 / SIMPLE_KERNEL;
					pOutImage[k + 2 * width + 2] += quantError * 1 / LARGER_KERNEL;
				}
				else if ((w == width - 2) && (h <= height - 3)){	// left column of last column except 2 last pixel in that column
					pOutImage[k + 1] += quantError * 7 / LARGER_KERNEL;
					pOutImage[k + width - 2] += quantError * 1 / SIMPLE_KERNEL;
					pOutImage[k + width - 1] += quantError * 5 / LARGER_KERNEL;
					pOutImage[k + width] += quantError * 7 / LARGER_KERNEL;
					pOutImage[k + width + 1] += quantError * 5 / LARGER_KERNEL;
					pOutImage[k + 2 * width - 2] += quantError * 1 / LARGER_KERNEL;
					pOutImage[k + 2 * width - 1] += quantError * 1 / SIMPLE_KERNEL;
					pOutImage[k + 2 * width] += quantError * 5 / LARGER_KERNEL;
					pOutImage[k + 2 * width + 1] += quantError * 1 / 16;
				}
				else if ((w == width - 1) && (h <= height - 3)){	// last column except 2 last pixel in that column
					pOutImage[k + width - 2] += quantError * 1 / SIMPLE_KERNEL;
					pOutImage[k + width - 1] += quantError * 5 / LARGER_KERNEL;
					pOutImage[k + width] += quantError * 7 / LARGER_KERNEL;
					pOutImage[k + 2 * width - 2] += quantError * 1 / LARGER_KERNEL;
					pOutImage[k + 2 * width - 1] += quantError * 1 / SIMPLE_KERNEL;
					pOutImage[k + 2 * width] += quantError * 5 / LARGER_KERNEL;
				}
				else if ((w == 0) && (h == height - 2)){			// top of (last pixel of first column)
					pOutImage[k + 1] += quantError * 7 / LARGER_KERNEL;
					pOutImage[k + 2] += quantError * 5 / LARGER_KERNEL;
					pOutImage[k + width] += quantError * 7 / LARGER_KERNEL;
					pOutImage[k + width + 1] += quantError * 5 / LARGER_KERNEL;
					pOutImage[k + width + 2] += quantError * 1 / SIMPLE_KERNEL;
				}
				else if ((w == 1) && (h == height - 2)){			// right of [top of (last pixel of first column)
					pOutImage[k + 1] += quantError * 7 / LARGER_KERNEL;
					pOutImage[k + 2] += quantError * 5 / LARGER_KERNEL;
					pOutImage[k + width - 1] += quantError * 5 / LARGER_KERNEL;
					pOutImage[k + width] += quantError * 7 / LARGER_KERNEL;
					pOutImage[k + width + 1] += quantError * 5 / LARGER_KERNEL;
					pOutImage[k + width + 2] += quantError * 1 / SIMPLE_KERNEL;
				}
				else if ((h == height - 2) && (w < width - 2)){		// top of last row
					pOutImage[k + 1] += quantError * 7 / LARGER_KERNEL;
					pOutImage[k + 2] += quantError * 5 / LARGER_KERNEL;
					pOutImage[k + width - 2] += quantError * 1 / SIMPLE_KERNEL;
					pOutImage[k + width - 1] += quantError * 5 / LARGER_KERNEL;
					pOutImage[k + width] += quantError * 7 / LARGER_KERNEL;
					pOutImage[k + width + 1] += quantError * 5 / LARGER_KERNEL;
					pOutImage[k + width + 2] += quantError * 1 / SIMPLE_KERNEL;
				}
				else if ((w == width - 2) && (h == height - 2)){	// top of (left of last pixel)
					pOutImage[k + 1] += quantError * 7 / LARGER_KERNEL;
					pOutImage[k + width - 1] += quantError * 5 / LARGER_KERNEL;
					pOutImage[k + width] += quantError * 7 / LARGER_KERNEL;
					pOutImage[k + width + 1] += quantError * 5 / LARGER_KERNEL;
				}
				else if ((w == width - 1) && (h == height - 2)) {	// top of last pixel
					pOutImage[k + width - 2] += quantError * 1 / SIMPLE_KERNEL;
					pOutImage[k + width - 1] += quantError * 5 / LARGER_KERNEL;
					pOutImage[k + width] += quantError * 7 / LARGER_KERNEL;
				}
				else if ((h == height - 1) && (w < width - 2)){		// last row except 2 last pixel
					pOutImage[k + 1] += quantError * 7 / LARGER_KERNEL;
					pOutImage[k + 2] += quantError * 5 / LARGER_KERNEL;
				}
				else if ((w == width - 2) && (h == height - 1)){	// left of last pixel
					pOutImage[k + 1] += quantError * 7 / LARGER_KERNEL;
				}
				else {												// last pixel
					break;
				}
			}
		}
	}
	return err;
}
