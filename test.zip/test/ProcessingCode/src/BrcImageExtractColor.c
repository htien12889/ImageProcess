﻿/**
 * @file 	BrcImageExtractColor.c
 * @brief 	色成分抽出ソースファイル
 * @author 	ayesu
 * @date 	2016/07/15
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#include "BrcType.h"
#include "BrcImageProcessingCommon.h"
#include "BrcMemoryUsage.h"

/** ExtractColorComponent(UI32 width, UI32 height, void *pInRGB, void *pOutRed, void *pOutGreen, void *pOutBlue)
 * @brief 色成分抽出
 * @param[in]	width		画像幅
 * @param[in]	height		画像高さ
 * @param[in]	pInRGB		入力画像領域のポインタ
 * @param[out]	pOutRed		赤画像領域のポインタ
 * @param[out]	pOutGreen	緑画像領域のポインタ
 * @param[out]	pOutBlue	青画像領域のポインタ
 * @return		0:成功 0以外:失敗
 */
PUBLIC SI32 ExtractColorComponent(UI32 width, UI32 height, void *pInRGB, void *pOutRed, void *pOutGreen, void *pOutBlue)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInRGB != brcNull) && (pOutRed != brcNull) && (pOutGreen != brcNull) && (pOutBlue != brcNull) ? SUCCESS : EINVAL);

	if(err == 0){
		
		UI32	j;					///Loop用
		UI32	i;					///Loop用
		SI08	*pInimage;			///	インプット画像
		SI08	*pOutRedimage;		/// アウトプット赤画像
		SI08	*pOutGreenimage;	/// アウトプット緑画像
		SI08	*pOutBlueimage;		/// アウトプット青画像

		SI32	index;				///	画像の位置用

		UI08	*pInWork;			///	元画像用ポインター
		UI08	*pOutBlueWork;		///	青画像用ポインター
		UI08	*pOutGreenWork;		///	緑成分用ポインター
		UI08	*pOutRedWork;		///	赤成分用ポインター

		for (j = 0; j < height; j++) {
			for (i = 0; i < width * RGB_CHANNELS; i += RGB_CHANNELS){

				pInimage			= (SI08*)pInRGB;						
				pOutRedimage		= (SI08*)pOutRed;					    
				pOutGreenimage		= (SI08*)pOutGreen;				        
				pOutBlueimage		= (SI08*)pOutBlue;				        

				index = (width * j * RGB_CHANNELS) + i;

				pInWork			= pInimage + index;						
				pOutBlueWork	= pOutBlueimage + index;				
				pOutGreenWork	= pOutGreenimage + index;				
				pOutRedWork		= pOutRedimage + index;					
				
				//!青成分画像作成
				*pOutBlueWork				= *pInWork;				
				pOutBlueWork++;

				*pOutBlueWork				= 0;
				pOutBlueWork++;

				*pOutBlueWork				= 0;
				pInWork++;
				pOutBlueWork++;

				//!緑成分画像作成
				*pOutGreenWork				= 0;
				pOutGreenWork++;

				*pOutGreenWork				= *pInWork;
				pOutGreenWork++;

				*pOutGreenWork				= 0;
				pInWork++;
				pOutGreenWork++;

				//!赤成分画像作成
				*pOutRedWork				= 0;
				pOutRedWork++;

				*pOutRedWork				= 0;
				pOutRedWork++;

				*pOutRedWork				= *pInWork;
				pInWork++;
				pOutRedWork++;
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}
