﻿/**
* @file 	BrcHardwareFeatures.c
* @brief 	Hardware features source file
* @author 	EMT-BrycenVN
* @date 	2017/01/11
* @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
*/

#include "BrcType.h"
#include "BrcImageProcessingCommon.h"
#include "BrcHardwareFeatures.h"
#include "string.h"

#define GET_BITS_FROM_9_TO_12(value) (SI32)(((SI32)(value) >> 8) & 15)
#define _MSC_VER_NUM			1400
#define X86FAMILY_NUM			6
#define CPU_MMX_BIT_POSITION	23
#define CPU_SSE_BIT_POSITION	25
#define CPU_SSE2_BIT_POSITION	26
#define CPU_SSE3_BIT_POSITION	0
#define CPU_SSSE3_BIT_POSITION	9
#define CPU_FMA3_BIT_POSITION	12
#define CPU_SSE4_1_BIT_POSITION 19
#define CPU_SSE4_2_BIT_POSITION 20
#define CPU_POPCNT_BIT_POSITION 23
#define CPU_AVX_1_BIT_POSITION	27
#define CPU_AVX_2_BIT_POSITION	28

#if defined _MSC_VER
#if _MSC_VER >= _MSC_VER_NUM
#include <intrin.h>
#elif defined _M_IX86
static void __cpuid(SI32 *cpuid_data, SI32)
{
	__asm
	{
		push ebx
			push edi
			mov edi, cpuid_data
			mov eax, 1
			cpuid
			mov[edi], eax
			mov[edi + 4], ebx
			mov[edi + 8], ecx
			mov[edi + 12], edx
			pop edi
			pop ebx
	}
}
#endif
#endif

/**
* @struct BrcHWFeatures
* @brief Hardware features
*/
typedef struct {
	SI32 x86Family;
	brcBool	have[CV_HARDWARE_MAX_FEATURE + 1];
} BrcHWFeatures;

/** BrcHWFeatures initialize(void)
* @brief Initialize hardware features
* @param[in]	none
* @return 		BrcHWFeatures
*/
PRIVATE BrcHWFeatures initialize(void)
{
	BrcHWFeatures f;
	memset(f.have, 0, sizeof(f.have));
	f.x86Family = 0;

	SI32 cpuIdData[4] = { 0 };
#if defined _MSC_VER && (defined _M_IX86 || defined _M_X64)
	__cpuid(cpuIdData, 1);
#elif defined __GNUC__ && (defined __i386__ || defined __x86_64__)
#ifdef __x86_64__
	asm __volatile__
		(
		"movl $1, %%eax\n\t"
		"cpuid\n\t"
		:[eax]"=a"(cpuIdData[0]), [ebx]"=b"(cpuIdData[1]), [ecx]"=c"(cpuIdData[2]), [edx]"=d"(cpuIdData[3])
		:
		: "cc"
		);
#else
	asm volatile
		(
		"pushl %%ebx\n\t"
		"movl $1,%%eax\n\t"
		"cpuid\n\t"
		"popl %%ebx\n\t"
		: "=a"(cpuIdData[0]), "=c"(cpuIdData[2]), "=d"(cpuIdData[3])
		:
		: "cc"
		);
#endif
#endif
	f.x86Family = GET_BITS_FROM_9_TO_12(cpuIdData[0]);
	if (f.x86Family >= X86FAMILY_NUM) {
		f.have[CPU_MMX] = (cpuIdData[3] & (1 << CPU_MMX_BIT_POSITION)) != 0;
		f.have[CPU_SSE] = (cpuIdData[3] & (1 << CPU_SSE_BIT_POSITION)) != 0;
		f.have[CPU_SSE2] = (cpuIdData[3] & (1 << CPU_SSE2_BIT_POSITION)) != 0;
		f.have[CPU_SSE3] = (cpuIdData[2] & (1 << CPU_SSE3_BIT_POSITION)) != 0;
		f.have[CPU_SSSE3] = (cpuIdData[2] & (1 << CPU_SSSE3_BIT_POSITION)) != 0;
		f.have[CPU_FMA3] = (cpuIdData[2] & (1 << CPU_FMA3_BIT_POSITION)) != 0;
		f.have[CPU_SSE4_1] = (cpuIdData[2] & (1 << CPU_SSE4_1_BIT_POSITION)) != 0;
		f.have[CPU_SSE4_2] = (cpuIdData[2] & (1 << CPU_SSE4_2_BIT_POSITION)) != 0;
		f.have[CPU_POPCNT] = (cpuIdData[2] & (1 << CPU_POPCNT_BIT_POSITION)) != 0;
		f.have[CPU_AVX] = (((cpuIdData[2] & (1 << CPU_AVX_2_BIT_POSITION)) != 0) && ((cpuIdData[2] & (1 << CPU_AVX_1_BIT_POSITION)) != 0));
	}
	return f;
}

/** CheckHardwareSupport(UI32 feature)
* @brief Check hardware features
* @param[in]	feature to check
* @return 		true:support, false: not support
*/
PUBLIC brcBool CheckHardwareSupport(UI32 feature)
{
	BrcHWFeatures currentFeatures = initialize();
	return currentFeatures.have[feature];
}