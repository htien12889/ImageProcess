﻿/**
 * @file	BrcImageInterpolation.c
 * @brief	ピクセル値補間
 * @author	tfujii
 * @date	2016/09/08
 * @par		Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#include <string.h>
#include "BrcImageInterpolation.h"

#define BI_CUBIC_INTERPOLATION_KERNEL_SIZE	4
#define SHARPNESS							-1.0f
#define SQUARE(x)							((x) * (x))			/// 二乗
#define CUBE(x)								((x) * (x) * (x))	/// 三乗

#define CUBIC_FUNC1(x)																				\
	((SHARPNESS + 2.0f) * CUBE(x) - \
	(SHARPNESS + 3.0f) * SQUARE(x) + 1.0f)						/// キュービック関数(|x| < 1)

#define CUBIC_FUNC2(x)																				\
	(SHARPNESS * CUBE(x) - \
	5.0f * SHARPNESS * SQUARE(x) + \
	8.0f * SHARPNESS * (x)-4.0f * SHARPNESS)					/// キュービック関数2(1 ≦ |x| < 2)

#define CLIP(x, min, max)																			\
	((x) < (min) ? (min) : (max) < (x) ? (max) : (x))			/// クリッピング

/** BiCubicInterpolate(SI32 colMax, SI32 rowMax, UI32 channels, UI08 *img, FP32 positionX, FP32 positionY, SI32 *pOutPixel)
* @brief		バイキュービック補間
* @param[in]	colMax			補間値算出元画像の列番号最大値
* @param[in]	rowMax			補間値算出元画像の行番号最大値
* @param[in]	channels		Image channels
* @param[in]	img				補間値算出元画像
* @param[in]	positionX		補間の中心座標(x)
* @param[in]	positionY		補間の中心座標(y)
* @param[out]	pOutPixel		補間値(ピクセルをまとめて)
*/
void BiCubicInterpolate(
	SI32 colMax, SI32 rowMax, UI32 channels, UI08 *img,
	FP32 positionX, FP32 positionY, SI32 *pOutPixel)
{
	const FP32	decimalPartX = positionX - (FP32)((UI32)positionX);		/// positionXの小数部
	const FP32	decimalPartY = positionY - (FP32)((UI32)positionY);		/// positionYの小数部
	FP32		argument;
	FP32		funcValuesX[BI_CUBIC_INTERPOLATION_KERNEL_SIZE];		/// キュービック関数の戻り値用記憶域(x座標用)
	FP32		funcValuesY[BI_CUBIC_INTERPOLATION_KERNEL_SIZE];		/// キュービック関数の戻り値用記憶域(y座標用)
	FP32		biFuncVal;												/// バイキュービック値
	FP32		*pFuncValX;												/// funcValuesX用反復子
	FP32		*pFuncValY;												/// funcValuesY用反復子

	UI08		*pPixelRow;												/// 行の先頭アドレス
	UI08		*pPixelFirst;											/// ピクセル用反復子
	UI08		*pPixelLast;											/// ピクセル用反復子

	const SI32	colBegin = (UI32)positionX - 1;							/// 列番号の開始位置
	const SI32	colEnd = colBegin + BI_CUBIC_INTERPOLATION_KERNEL_SIZE;	/// 列番号の終了位置
	const SI32	rowBegin = (UI32)positionY - 1;							/// 行番号の開始位置
	const SI32	rowEnd = rowBegin + BI_CUBIC_INTERPOLATION_KERNEL_SIZE;	/// 行番号の終了位置
	SI32		i, j;													/// ピクセルの位置
	SI32		*pOPixFirst;

	/// 中心positionXに対する各ピクセルの座標から得たキュービック関数の戻り値を記憶
	argument = (FP32)(1 + decimalPartX);	funcValuesX[0] = CUBIC_FUNC2(argument);
	funcValuesX[1] = CUBIC_FUNC1(decimalPartX);
	argument = (FP32)(1 - decimalPartX);	funcValuesX[2] = CUBIC_FUNC1(argument);
	argument = (FP32)(2 - decimalPartX);	funcValuesX[3] = CUBIC_FUNC2(argument);

	/// 中心positionYに対する各ピクセルの座標から得たキュービック関数の戻り値を記憶
	argument = (FP32)(1 + decimalPartY);	funcValuesY[0] = CUBIC_FUNC2(argument);
	funcValuesY[1] = CUBIC_FUNC1(decimalPartY);
	argument = (FP32)(1 - decimalPartY);	funcValuesY[2] = CUBIC_FUNC1(argument);
	argument = (FP32)(2 - decimalPartY);	funcValuesY[3] = CUBIC_FUNC2(argument);

	/// 出力用ピクセルを初期化
	memset(pOutPixel, 0, channels * sizeof(SI32));

	pFuncValY = funcValuesY;

	/// バイキュービック値とピクセル値の積和により補間値を求める(画像からはみ出した位置は外側)
	for (i = rowBegin; i < rowEnd; ++i){
		/// 読み込み用ピクセル参照位置を適切な行位置に設定：(行位置) = (行番号) * (画像の幅) * (チャネル数)
		pPixelRow = img + (CLIP(i, 0, rowMax) * (colMax + 1) * channels);

		pFuncValX = funcValuesX;

		for (j = colBegin; j < colEnd; ++j){
			/// 読み込み用ピクセル参照位置を適切な列位置へ移動：(列位置) = (列番号) * (チャネル数)
			pPixelFirst = pPixelRow + CLIP(j, 0, colMax) * channels;
			/// 読み込み用ピクセルの終了位置
			pPixelLast = pPixelFirst + channels;
			/// 書き込み用ピクセルの開始
			pOPixFirst = pOutPixel;
			/// ピクセル値に掛けるバイキュービック値
			biFuncVal = *pFuncValX * *pFuncValY;

			/// 各チャネルに和をとっていく
			for (; pPixelFirst != pPixelLast; ++pPixelFirst){
				*pOPixFirst += (SI32)(biFuncVal * *pPixelFirst);
				++pOPixFirst;
			}
			++pFuncValX;
		}
		++pFuncValY;
	}
}
