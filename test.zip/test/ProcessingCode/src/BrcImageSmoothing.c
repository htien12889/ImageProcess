﻿/**
* @file	BrcImageSmoothing.c
* @brief 	画像平滑化ソースファイル
* @author 	ayesu
* @date 	2016/07/16
* @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
*/
#include <stdio.h>
#include <stdbool.h>
#include <emmintrin.h>
#include <xmmintrin.h>
#include "BrcType.h"
#include "BrcMemoryUsage.h"
#include "BrcImageProcessingCommon.h"
#include "BrcHardwareFeatures.h"

#define _USE_MATH_DEFINES
#include <math.h>
#define kernelForMedian 81
#define SSE2	1
#define MAX(x, y) (((x) > (y)) ? (x) : (y))
#define MIN(x, y) (((x) < (y)) ? (x) : (y))
#define swapValue(t)  (swapValueFast[(t) + 256])
#define _h_coarse_size			17680
#define _h_fine_size			282640
#define KERNEL_3_COEFFICIENT_1 0.25f
#define KERNEL_3_COEFFICIENT_2 0.5f
#define KERNEL_3_COEFFICIENT_3 0.25f

#define KERNEL_5_COEFFICIENT_1 0.0625f
#define KERNEL_5_COEFFICIENT_2 0.25f
#define KERNEL_5_COEFFICIENT_3 0.375f
#define KERNEL_5_COEFFICIENT_4 0.25f
#define KERNEL_5_COEFFICIENT_5 0.0625f

#define KERNEL_7_COEFFICIENT_1 0.03125f
#define KERNEL_7_COEFFICIENT_2 0.109375f
#define KERNEL_7_COEFFICIENT_3 0.21875f
#define KERNEL_7_COEFFICIENT_4 0.28125f
#define KERNEL_7_COEFFICIENT_5 0.21875f
#define KERNEL_7_COEFFICIENT_6 0.109375f
#define KERNEL_7_COEFFICIENT_7 0.03125f
#define SIGMA_CALCULATION(kSize) (FP64)((((UI32)kSize - 1)*0.5 - 1)*0.3 + 0.8)
#define CLIP(x, mmin, mmax)		((x) < (mmin) ? (mmin) : (mmax) < (x) ? (mmax) : (x)) 

PRIVATE void swap(UI08 medianValue[kernelForMedian], UI08 num1, UI08 num2);
PRIVATE __m128i load(const UI08 *ptr);
PRIVATE void change(__m128i *a, __m128i *b);
PRIVATE void store(UI08 *ptr, __m128i val);
PRIVATE UI08 medianFilter3(UI08 medianValue[kernelForMedian]);
PRIVATE UI08 medianFilter5(UI08 medianValue[kernelForMedian]);
PRIVATE void medianFilter(UI08 *_src, UI08 *_dst, SI32 width, SI32 height, SI32 m);
PRIVATE void getKernelGaus(FP32* kernel, UI32 expansion);
PRIVATE void conv(BrcBGR *pInImage, FP32 *kernel, FP32 *redBuff, FP32 *greenBuff, FP32 *blueBuff, UI32 borderType, UI32 width, UI32 expansion);
PRIVATE void hFirstConv(BrcBGR *pInImage, FP32 *kernel, FP32 *redBuff, FP32 *greenBuff, FP32 *blueBuff, UI32 borderType, UI32 width, UI32 expansion);
PRIVATE void hConv(BrcBGR *pInImage, FP32 *kernel, FP32 *redBuff, FP32 *greenBuff, FP32 *blueBuff, UI32 borderType, UI32 width, UI32 expansion);
PRIVATE void vConv(FP32 *redBuff, FP32 *greenBuff, FP32 *blueBuff, FP32 *kernel, UI32 width, UI32 expansion, BrcBGR *pOutImage);
PRIVATE void copyToBuff(FP32 *redBuff, FP32 *greenBuff, FP32 *blueBuff, UI32 width, UI32 expansion, SI32 over, UI32 borderType);
PRIVATE void normalConv(UI32 width, UI32 height, UI32 expansion, FP32 *kernel, void *pInRGB, void *pOutRGB);
PRIVATE void medianFilterForLargeKernelandImage(UI08 *_src, UI08 *_dst, SI32 width, SI32 height, SI32 m);
PRIVATE void histogram_add(UI16 x[16], UI16 y[16]);
PRIVATE void histogram_sub(UI16 x[16], UI16 y[16]);
PRIVATE void histogram_muladd(SI32 a, UI16 x[16], UI16 y[16]);

const UI08 swapValueFast[] = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
	16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31,
	32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47,
	48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63,
	64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79,
	80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95,
	96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111,
	112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127,
	128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143,
	144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159,
	160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175,
	176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191,
	192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207,
	208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223,
	224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239,
	240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255
};

typedef struct
{
	UI16 coarse[16];
	UI16 fine[16][16];
} Histogram;

/** SmoothingFilter(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, UI32 expansion)
* @brief 平均化フィルタ
* @param[in]	width		画像幅
* @param[in]	height		画像縦
* @param[in]	pInRGB		入力画像領域のポインタ
* @param[out]	pOutRGB		出力画像領域のポインタ
* @param[in]	expansion	平滑範囲
* @return		0:成功 0以外:失敗
*/
PUBLIC SI32 SmoothingFilter(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, UI32 expansion)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height)
		&& (pInRGB != brcNull) && (pOutRGB != brcNull) && ((SI32)expansion > 0) ? SUCCESS : EINVAL);
	if (err == 0){

		SI08			*pInimage = (SI08*)pInRGB;						    	///	インプット画像
		SI08			*pOutimage = (SI08*)pOutRGB;							/// アウトプット画像

		UI08			*pInWork;												//!インプット画像用
		UI08			*pOutWork;												//!アウトプット画像用

		UI08			*pInForSmooth;											//!注目画素の周り画素の位置の移動用ポンター

		//! B、R、Gの位置移動Loop用
		SI32			indexRGB = 0;

		//! カーネルにより位置の計算
		UI32			halfKernel = expansion / 2;
		UI32			kernel = expansion;

		//! Loop用
		SI32			k = 0;
		SI32			index;

		//!足し算のR、G、B用
		SI32		sumForR = 0;
		SI32		sumForG = 0;
		SI32		sumForB = 0;

		//!仮結果用
		SI32		tempResult = 0;

		//!kernelサイズによって注目画素と周りの画素の位置の計算用
		SI32		kernelIndex = 0;
		SI32		xx = 0;
		UI32		yy = 0;

		//!Loop用
		UI32		i = 0;
		UI32		j = 0;
		SI32		x = 0;
		UI32		y = 0;

		//!kernelによって周りの画素の位置計算用
		SI32		kernelForX = 0;
		SI32		kernelForY = 0;

		//!画像「R、G、B」の幅サイズ計算
		SI32		rgbWidth = width * RGB_CHANNELS;

		//!kernelによって処理する画素の数計算
		SI32		noKernel = kernel * kernel;

		for (y = 0; y < height; y++){
			for (x = 0; x < rgbWidth; x += RGB_CHANNELS){

				//!注目する画素の位置計算
				index = (rgbWidth * y) + x;
				pInWork = pInimage + index;
				pOutWork = pOutimage + index;

				//!注目画素のR、G、B用Loop
				for (indexRGB = 0; indexRGB < RGB_CHANNELS; indexRGB++) {

					//!カーネルによって注目画素の周りの処理する画素の計算用
					for (j = 0; j < kernel; j++){
						for (i = 0; i < kernel; i++){

							//! kernelによって注目画素と周り処理する画素の位置計算
							//! kernel 3の場合、for X は　-3,0,3 と　forY　-1,0,1のような位置計算
							//! kernel 5の場合、for X は　-6,-3,0,3,6と　forY　-2,-1,0,1,2 のような位置計算

							if (i <= halfKernel && j <= halfKernel) {
								kernelForX = (SI32)(i * RGB_CHANNELS);
								kernelForY = (SI32)(j);

							}
							else {
								kernelForX = (halfKernel - i) * RGB_CHANNELS;
								kernelForY = (halfKernel - j);
							}
							//!周りの処理する画素の位置計算用For X and Y
							xx = (x + indexRGB) + (kernelForX);
							yy = y + (kernelForY);

							//!画像の端の場合、処理しなくて注目画素の値に詰める処理
							// Edited by EMT-VN 2016.10.18
							// Previous version: if ((xx < 0) || (yy < 0) || (xx > RGB_width) || (yy > height)){
							// Edited version: if ((xx < 0) || (yy < 0) || (xx >= RGB_width) || (yy >= height)){
							if ((xx < 0) || (yy < 0) || (xx >= rgbWidth) || (yy >= height)){
								kernelIndex = (rgbWidth * y) + (x + indexRGB);
							}
							//!画像の端じゃない場合、注目画素と周りの画素の値で詰める
							else {
								kernelIndex = (rgbWidth * yy) + xx;
							}

							pInForSmooth = pInimage + kernelIndex;

							//!仮結果計算用
							tempResult += (*pInForSmooth);
						}
					}
					pInWork++;

					//!B、G、Rを分けて計算する
					if (0 == indexRGB) {
						sumForB = tempResult;
					}
					else if (1 == indexRGB) {
						sumForG = tempResult;
					}
					else{
						sumForR = tempResult;
					}
					tempResult = 0;
				}

				//!足し算した値をカーネル数「処理した画素数」と割り算する
				*pOutWork = (sumForB / noKernel);
				pOutWork++;
				*pOutWork = (sumForG / noKernel);
				pOutWork++;
				*pOutWork = (sumForR / noKernel);
				pOutWork++;

				sumForB = 0;
				sumForG = 0;
				sumForR = 0;
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** SmoothingMedianFilter(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, UI32 expansion)
* @brief メディアンフィルタ
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInRGB		入力画像領域のポインタ
* @param[out]	pOutRGB		出力画像領域のポインタ
* @param[in]	expansion	平滑範囲
* @return		0:成功 0以外:失敗
*/
PUBLIC SI32 SmoothingMedianFilter(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, UI32 expansion)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height)
		&& (pInRGB != brcNull) && (pOutRGB != brcNull) && ((SI32)expansion > 0) ? SUCCESS : EINVAL);
	if (err == 0){

		SI08		*pInimage = (SI08*)pInRGB;								///	インプット画像
		SI08		*pOutimage = (SI08*)pOutRGB;							/// アウトプット画像
		SI32		kernel = expansion;
		SI32		kernelRGB = RGB_CHANNELS*(GET_HALF_KERNEL(kernel));
		SI32		x, x0, x1, x2, x3, x4;
		SI32		y = 0;
		SI32		k = 0;
		SI32		l = 0;
		SI32		rgbWidth = width * RGB_CHANNELS;
		SI32		rgbSubWidth;
		if (kernel == 3 && CheckHardwareSupport(CPU_SSE2)){
			UI08		*row[3];
			UI08		p[9];
			UI08		*rowk;
			for (y = 0; y < (SI32)height; y++){
				row[0] = pInimage + MAX(y - 1, 0) * rgbWidth;
				row[1] = pInimage + y * rgbWidth;
				row[2] = pInimage + MIN(y + 1, (SI32)height - 1) * rgbWidth;
				rgbSubWidth = (rgbWidth - (SI32)sizeof(__m128i) - RGB_CHANNELS);
				for (x = 0; x < kernelRGB; x++){
					x0 = x >= RGB_CHANNELS ? (x - RGB_CHANNELS) : x;
					x2 = x < (rgbWidth - RGB_CHANNELS) ? (x + RGB_CHANNELS) : x;
					for (k = 0; k < kernel; k++){
						rowk = row[k];
						p[k * kernel] = *(rowk + x0);
						p[k * kernel + 1] = *(rowk + x);
						p[k * kernel + 2] = *(rowk + x2);
					}
					*pOutimage = medianFilter3(p);
					pOutimage++;
				}
				for (; x < rgbSubWidth; x += sizeof(__m128i)){
					__m128i		p[9];
					for (k = 0; k < kernel; k++){
						rowk = row[k];
						p[k * kernel] = load(rowk + x - RGB_CHANNELS);
						p[k * kernel + 1] = load(rowk + x);
						p[k * kernel + 2] = load(rowk + x + RGB_CHANNELS);
					}
					change(&p[1], &p[2]); change(&p[4], &p[5]); change(&p[7], &p[8]); change(&p[0], &p[1]);
					change(&p[3], &p[4]); change(&p[6], &p[7]); change(&p[1], &p[2]); change(&p[4], &p[5]);
					change(&p[7], &p[8]); change(&p[0], &p[3]); change(&p[5], &p[8]); change(&p[4], &p[7]);
					change(&p[3], &p[6]); change(&p[1], &p[4]); change(&p[2], &p[5]); change(&p[4], &p[7]);
					change(&p[4], &p[2]); change(&p[6], &p[4]); change(&p[4], &p[2]);
					store(pOutimage, p[4]);
					pOutimage += sizeof(__m128i);
				}
				for (; x < rgbWidth; x++){
					x0 = x >= RGB_CHANNELS ? (x - RGB_CHANNELS) : x;
					x2 = x < (rgbWidth - RGB_CHANNELS) ? (x + RGB_CHANNELS) : x;
					for (k = 0; k < kernel; k++){
						rowk = row[k];
						p[k * kernel] = *(rowk + x0);
						p[k * kernel + 1] = *(rowk + x);
						p[k * kernel + 2] = *(rowk + x2);
					}
					*pOutimage = medianFilter3(p);
					pOutimage++;
				}
			}
		}
		else if (kernel == 5 && CheckHardwareSupport(CPU_SSE2)){
			UI08		*row[5];
			UI08		*rowk;
			UI08		p[25];
			for (y = 0; y < (SI32)height; y++){
				row[0] = pInimage + MAX(y - 2, 0) * rgbWidth;
				row[1] = pInimage + MAX(y - 1, 0) * rgbWidth;
				row[2] = pInimage + y * rgbWidth;
				row[3] = pInimage + MIN(y + 1, (SI32)height - 1) * rgbWidth;
				row[4] = pInimage + MIN(y + 2, (SI32)height - 1) * rgbWidth;
				rgbSubWidth = (rgbWidth - (SI32)sizeof(__m128i) - RGB_CHANNELS * 2);
				for (x = 0; x < kernelRGB; x++){
					x1 = x >= RGB_CHANNELS ? (x - RGB_CHANNELS) : x;
					x0 = x >= (RGB_CHANNELS * 2) ? (x - RGB_CHANNELS * 2) : x1;
					x3 = x < (rgbWidth - RGB_CHANNELS) ? (x + RGB_CHANNELS) : x;
					x4 = x < (rgbWidth - RGB_CHANNELS * 2) ? (x + RGB_CHANNELS * 2) : x3;
					for (k = 0; k < kernel; k++) {
						rowk = row[k];
						p[k * kernel] = *(rowk + x0);
						p[k * kernel + 1] = *(rowk + x1);
						p[k * kernel + 2] = *(rowk + x);
						p[k * kernel + 3] = *(rowk + x3);
						p[k * kernel + 4] = *(rowk + x4);
					}
					*pOutimage = medianFilter5(p);
					pOutimage++;
				}
				for (; x < rgbSubWidth; x += sizeof(__m128i)){
					__m128i p[25];
					for (k = 0; k < kernel; k++){
						rowk = row[k];
						p[k * kernel] = load(rowk + x - RGB_CHANNELS * 2);
						p[k * kernel + 1] = load(rowk + x - RGB_CHANNELS);
						p[k * kernel + 2] = load(rowk + x);
						p[k * kernel + 3] = load(rowk + x + RGB_CHANNELS);
						p[k * kernel + 4] = load(rowk + x + RGB_CHANNELS * 2);
					}
					change(&p[1], &p[2]); change(&p[0], &p[1]); change(&p[1], &p[2]); change(&p[4], &p[5]); change(&p[3], &p[4]);
					change(&p[4], &p[5]); change(&p[0], &p[3]); change(&p[2], &p[5]); change(&p[2], &p[3]); change(&p[1], &p[4]);
					change(&p[1], &p[2]); change(&p[3], &p[4]); change(&p[7], &p[8]); change(&p[6], &p[7]); change(&p[7], &p[8]);
					change(&p[10], &p[11]); change(&p[9], &p[10]); change(&p[10], &p[11]); change(&p[6], &p[9]); change(&p[8], &p[11]);
					change(&p[8], &p[9]); change(&p[7], &p[10]); change(&p[7], &p[8]); change(&p[9], &p[10]); change(&p[0], &p[6]);
					change(&p[4], &p[10]); change(&p[4], &p[6]); change(&p[2], &p[8]); change(&p[2], &p[4]); change(&p[6], &p[8]);
					change(&p[1], &p[7]); change(&p[5], &p[11]); change(&p[5], &p[7]); change(&p[3], &p[9]); change(&p[3], &p[5]);
					change(&p[7], &p[9]); change(&p[1], &p[2]); change(&p[3], &p[4]); change(&p[5], &p[6]); change(&p[7], &p[8]);
					change(&p[9], &p[10]); change(&p[13], &p[14]); change(&p[12], &p[13]); change(&p[13], &p[14]); change(&p[16], &p[17]);
					change(&p[15], &p[16]); change(&p[16], &p[17]); change(&p[12], &p[15]); change(&p[14], &p[17]); change(&p[14], &p[15]);
					change(&p[13], &p[16]); change(&p[13], &p[14]); change(&p[15], &p[16]); change(&p[19], &p[20]); change(&p[18], &p[19]);
					change(&p[19], &p[20]); change(&p[21], &p[22]); change(&p[23], &p[24]); change(&p[21], &p[23]); change(&p[22], &p[24]);
					change(&p[22], &p[23]); change(&p[18], &p[21]); change(&p[20], &p[23]); change(&p[20], &p[21]); change(&p[19], &p[22]);
					change(&p[22], &p[24]); change(&p[19], &p[20]); change(&p[21], &p[22]); change(&p[23], &p[24]); change(&p[12], &p[18]);
					change(&p[16], &p[22]); change(&p[16], &p[18]); change(&p[14], &p[20]); change(&p[20], &p[24]); change(&p[14], &p[16]);
					change(&p[18], &p[20]); change(&p[22], &p[24]); change(&p[13], &p[19]); change(&p[17], &p[23]); change(&p[17], &p[19]);
					change(&p[15], &p[21]); change(&p[15], &p[17]); change(&p[19], &p[21]); change(&p[13], &p[14]); change(&p[15], &p[16]);
					change(&p[17], &p[18]); change(&p[19], &p[20]); change(&p[21], &p[22]); change(&p[23], &p[24]); change(&p[0], &p[12]);
					change(&p[8], &p[20]); change(&p[8], &p[12]); change(&p[4], &p[16]); change(&p[16], &p[24]); change(&p[12], &p[16]);
					change(&p[2], &p[14]); change(&p[10], &p[22]); change(&p[10], &p[14]); change(&p[6], &p[18]); change(&p[6], &p[10]);
					change(&p[10], &p[12]); change(&p[1], &p[13]); change(&p[9], &p[21]); change(&p[9], &p[13]); change(&p[5], &p[17]);
					change(&p[13], &p[17]); change(&p[3], &p[15]); change(&p[11], &p[23]); change(&p[11], &p[15]); change(&p[7], &p[19]);
					change(&p[7], &p[11]); change(&p[11], &p[13]); change(&p[11], &p[12]);
					store(pOutimage, p[12]);
					pOutimage += sizeof(__m128i);
				}
				for (; x < rgbWidth; x++){
					x1 = x >= RGB_CHANNELS ? (x - RGB_CHANNELS) : x;
					x0 = x >= (RGB_CHANNELS * 2) ? (x - RGB_CHANNELS * 2) : x1;
					x3 = x < (rgbWidth - RGB_CHANNELS) ? (x + RGB_CHANNELS) : x;
					x4 = x < (rgbWidth - RGB_CHANNELS * 2) ? (x + RGB_CHANNELS * 2) : x3;
					for (k = 0; k < kernel; k++) {
						rowk = row[k];
						p[k * kernel] = *(rowk + x0);
						p[k * kernel + 1] = *(rowk + x1);
						p[k * kernel + 2] = *(rowk + x);
						p[k * kernel + 3] = *(rowk + x3);
						p[k * kernel + 4] = *(rowk + x4);
					}
					*pOutimage = medianFilter5(p);
					pOutimage++;
				}
			}
		}
		else {
			double img_size_mp = (double)(width*height) / (1 << 20);
			if (expansion <= (UI32)(3 + (img_size_mp < 1 ? 12 : img_size_mp < 4 ? 6 : 2)*(!CheckHardwareSupport(CPU_SSE2) ? 1 : 3))){
				medianFilter(pInimage, pOutimage, width, height, expansion);
			}
			else{
				medianFilterForLargeKernelandImage(pInimage, pOutimage, width, height, expansion);
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** swap(UI08 medianValue[kernelForMedian], UI08 num1, UI08 num2)
* @brief Swap value medianValue[num1] and medianValue[num2] with condittion medianValue[num1] > medianValue[num2]
* @param[in]	medianValue		array for swap
* @param[in]	num1			index array
* @param[in]	num2			index array
* @return		none
*/
PRIVATE void swap(UI08 medianValue[kernelForMedian], UI08 num1, UI08 num2)
{
	UI08 t = swapValue(medianValue[num1] - medianValue[num2]);
	medianValue[num2] += t;
	medianValue[num1] -= t;
}

/** load(const UI08 *ptr)
* @brief Load data with data type __m128i
* @param[in]	ptr		pointer of input data
* @return _mm_loadu_si128
*/
PRIVATE __m128i load(const UI08 *ptr)
{
	return _mm_loadu_si128((const __m128i*)ptr);
}

/** change(__m128i *a, __m128i *b)
* @brief Change value a and b with data type __m128i
* @param[in,out]	a		value a
* @param[in,out]	b		value b
* @return			none
*/
PRIVATE void change(__m128i *a, __m128i *b)
{
	__m128i t = *a;
	*a = _mm_min_epu8(*a, *b);
	*b = _mm_max_epu8(*b, t);
}

/** store(UI08 *ptr, __m128i val)
* @brief Save val to ptr
* @param[in]	val		value val
* @param[out]	ptr		value ptr
* @return		none
*/
PRIVATE void store(UI08 *ptr, __m128i val)
{
	_mm_storeu_si128((__m128i*)ptr, val);
}

/** histogram_add(UI16 x[16], UI16 y[16])
* @brief Calculate the sum of 2 arrays
* @param[in]		x		array x
* @param[in/out]	y		array y
* @return		none
*/
PRIVATE void histogram_add(UI16 x[16], UI16 y[16])
{
	SI32 i;
	for (i = 0; i < 16; ++i)
		y[i] = (UI16)(y[i] + x[i]);
}

/** histogram_sub(UI16 x[16], UI16 y[16])
* @brief Calculate the sub of 2 arrays
* @param[in]		x		array x
* @param[in/out]	y		array y
* @return		none
*/
PRIVATE void histogram_sub(UI16 x[16], UI16 y[16])
{
	SI32 i;
	for (i = 0; i < 16; ++i)
		y[i] = (UI16)(y[i] - x[i]);
}

/** histogram_muladd(SI32 a, UI16 x[16], UI16 y[16])
* @brief Calculate the sum of 2 arrays with coefficient a
* @param[in]		a		value a
* @param[in]		x		array x
* @param[in/out]	y		array y
* @return		none
*/
PRIVATE void histogram_muladd(SI32 a, UI16 x[16], UI16 y[16])
{
	for (SI32 i = 0; i < 16; ++i)
		y[i] = (UI16)(y[i] + a * x[i]);
}

/** medianFilter3(UI08 medianValue[kernelForMedian])
* @brief Calculate median value
* @param[in,out]	medianValue[kernelForMedian]	pointer of medianValue
* @return median value
*/
PRIVATE UI08 medianFilter3(UI08 medianValue[kernelForMedian])
{
	swap(medianValue, 1, 2); swap(medianValue, 4, 5); swap(medianValue, 7, 8); swap(medianValue, 0, 1);
	swap(medianValue, 3, 4); swap(medianValue, 6, 7); swap(medianValue, 1, 2); swap(medianValue, 4, 5);
	swap(medianValue, 7, 8); swap(medianValue, 0, 3); swap(medianValue, 5, 8); swap(medianValue, 4, 7);
	swap(medianValue, 3, 6); swap(medianValue, 1, 4); swap(medianValue, 2, 5); swap(medianValue, 4, 7);
	swap(medianValue, 4, 2); swap(medianValue, 6, 4); swap(medianValue, 4, 2);
	return medianValue[4];
}

/** medianFilter5(UI08 medianValue[kernelForMedian])
* @brief Calculate median value
* @param[in,out]	medianValue[kernelForMedian]	pointer of medianValue
* @return median value
*/
PRIVATE UI08 medianFilter5(UI08 medianValue[kernelForMedian])
{
	swap(medianValue, 1, 2); swap(medianValue, 0, 1); swap(medianValue, 1, 2); swap(medianValue, 4, 5); swap(medianValue, 3, 4);
	swap(medianValue, 4, 5); swap(medianValue, 0, 3); swap(medianValue, 2, 5); swap(medianValue, 2, 3); swap(medianValue, 1, 4);
	swap(medianValue, 1, 2); swap(medianValue, 3, 4); swap(medianValue, 7, 8); swap(medianValue, 6, 7); swap(medianValue, 7, 8);
	swap(medianValue, 10, 11); swap(medianValue, 9, 10); swap(medianValue, 10, 11); swap(medianValue, 6, 9); swap(medianValue, 8, 11);
	swap(medianValue, 8, 9); swap(medianValue, 7, 10); swap(medianValue, 7, 8); swap(medianValue, 9, 10); swap(medianValue, 0, 6);
	swap(medianValue, 4, 10); swap(medianValue, 4, 6); swap(medianValue, 2, 8); swap(medianValue, 2, 4); swap(medianValue, 6, 8);
	swap(medianValue, 1, 7); swap(medianValue, 5, 11); swap(medianValue, 5, 7); swap(medianValue, 3, 9); swap(medianValue, 3, 5);
	swap(medianValue, 7, 9); swap(medianValue, 1, 2); swap(medianValue, 3, 4); swap(medianValue, 5, 6); swap(medianValue, 7, 8);
	swap(medianValue, 9, 10); swap(medianValue, 13, 14); swap(medianValue, 12, 13); swap(medianValue, 13, 14); swap(medianValue, 16, 17);
	swap(medianValue, 15, 16); swap(medianValue, 16, 17); swap(medianValue, 12, 15); swap(medianValue, 14, 17); swap(medianValue, 14, 15);
	swap(medianValue, 13, 16); swap(medianValue, 13, 14); swap(medianValue, 15, 16); swap(medianValue, 19, 20); swap(medianValue, 18, 19);
	swap(medianValue, 19, 20); swap(medianValue, 21, 22); swap(medianValue, 23, 24); swap(medianValue, 21, 23); swap(medianValue, 22, 24);
	swap(medianValue, 22, 23); swap(medianValue, 18, 21); swap(medianValue, 20, 23); swap(medianValue, 20, 21); swap(medianValue, 19, 22);
	swap(medianValue, 22, 24); swap(medianValue, 19, 20); swap(medianValue, 21, 22); swap(medianValue, 23, 24); swap(medianValue, 12, 18);
	swap(medianValue, 16, 22); swap(medianValue, 16, 18); swap(medianValue, 14, 20); swap(medianValue, 20, 24); swap(medianValue, 14, 16);
	swap(medianValue, 18, 20); swap(medianValue, 22, 24); swap(medianValue, 13, 19); swap(medianValue, 17, 23); swap(medianValue, 17, 19);
	swap(medianValue, 15, 21); swap(medianValue, 15, 17); swap(medianValue, 19, 21); swap(medianValue, 13, 14); swap(medianValue, 15, 16);
	swap(medianValue, 17, 18); swap(medianValue, 19, 20); swap(medianValue, 21, 22); swap(medianValue, 23, 24); swap(medianValue, 0, 12);
	swap(medianValue, 8, 20); swap(medianValue, 8, 12); swap(medianValue, 4, 16); swap(medianValue, 16, 24); swap(medianValue, 12, 16);
	swap(medianValue, 2, 14); swap(medianValue, 10, 22); swap(medianValue, 10, 14); swap(medianValue, 6, 18); swap(medianValue, 6, 10);
	swap(medianValue, 10, 12); swap(medianValue, 1, 13); swap(medianValue, 9, 21); swap(medianValue, 9, 13); swap(medianValue, 5, 17);
	swap(medianValue, 13, 17); swap(medianValue, 3, 15); swap(medianValue, 11, 23); swap(medianValue, 11, 15); swap(medianValue, 7, 19);
	swap(medianValue, 7, 11); swap(medianValue, 11, 13); swap(medianValue, 11, 12);
	return medianValue[12];
}

/** medianFilter(UI08 *_src, UI08 *_dst, SI32 width, SI32 height, SI32 m)
* @brief 平均化フィルタ
* @param[in]	_src		入力画像領域のポインタ
* @param[out]	_dst		出力画像領域のポインタ
* @param[in]	width		画像幅
* @param[in]	height		画像縦
* @param[in]	m			平滑範囲
* @return		none
*/
PRIVATE void medianFilter(UI08 *_src, UI08 *_dst, SI32 width, SI32 height, SI32 m)
{
#define N  16
	SI32     zone0[4][N];
	SI32     zone1[4][N*N];
	SI32     n2 = (m*m) / 2;
	SI32	 halfKernel = GET_HALF_KERNEL(m);
	SI32     step = width*RGB_CHANNELS;
	UI08	 *src = _src;
	UI08	 *dst = _dst;
	SI32	 x, y, k, t, c, s;
	const UI08 *srcMax = src + height*(step);

#define UPDATE_ACC01( pix, cn, op ) \
			{								\
	SI32 p = (pix);					\
	zone1[cn][p] op;				\
	zone0[cn][p >> 4] op;			\
			}
	UI08 *dstCur;
	const UI08 *srcTop;
	const UI08 *srcBotton;
	SI32 start;
	SI32 end;
	for (x = 0; x < halfKernel; x++, src += RGB_CHANNELS, dst += RGB_CHANNELS){
		dstCur = dst;
		srcTop = src;
		srcBotton = src;

		// init accumulator
		memset(zone0, 0, sizeof(zone0[0])*RGB_CHANNELS);
		memset(zone1, 0, sizeof(zone1[0])*RGB_CHANNELS);
		start = 0;
		for (y = 0; y <= halfKernel; y++){
			for (c = 0; c < RGB_CHANNELS; c++){
				if (y > 0){
					for (k = 0; k < ((halfKernel - x)*RGB_CHANNELS); k += RGB_CHANNELS){
						UPDATE_ACC01((srcBotton - x*RGB_CHANNELS)[c], c, ++);
					}
					start = 0;
					for (k = ((halfKernel - x)*RGB_CHANNELS); k < m*RGB_CHANNELS; k += RGB_CHANNELS){
						UPDATE_ACC01((srcBotton - x*RGB_CHANNELS)[start + c], c, ++);
						start += RGB_CHANNELS;
					}
				}
				else {
					for (k = 0; k < ((halfKernel - x)*RGB_CHANNELS); k += RGB_CHANNELS){
						UPDATE_ACC01((srcBotton - x*RGB_CHANNELS)[c], c, += (halfKernel + 1));
					}
					start = 0;
					for (k = ((halfKernel - x)*RGB_CHANNELS); k < m*RGB_CHANNELS; k += RGB_CHANNELS){
						UPDATE_ACC01((srcBotton - x*RGB_CHANNELS)[start + c], c, += (halfKernel + 1));
						start += RGB_CHANNELS;
					}
				}
			}
			if (y < height - 1){
				srcBotton += step;
			}
		}
		for (y = 0; y < height; y++, dstCur += step){
			// find median
			for (c = 0; c < RGB_CHANNELS; c++){
				s = 0;
				for (k = 0;; k++){
					t = s + zone0[c][k];
					if (t > n2) {
						break;
					}
					s = t;
				}

				for (k *= N;; k++){
					s += zone1[c][k];
					if (s > n2) {
						break;
					}
				}
				dstCur[c] = (UI08)k;
			}

			if (y + 1 == height){
				break;
			}

			for (k = 0; k < ((halfKernel - x)*RGB_CHANNELS); k += RGB_CHANNELS){
				UPDATE_ACC01((srcTop - x*RGB_CHANNELS)[0], 0, --);
				UPDATE_ACC01((srcTop - x*RGB_CHANNELS)[1], 1, --);
				UPDATE_ACC01((srcTop - x*RGB_CHANNELS)[2], 2, --);

				UPDATE_ACC01((srcBotton - x*RGB_CHANNELS)[0], 0, ++);
				UPDATE_ACC01((srcBotton - x*RGB_CHANNELS)[1], 1, ++);
				UPDATE_ACC01((srcBotton - x*RGB_CHANNELS)[2], 2, ++);
			}
			start = 0;
			for (k = ((halfKernel - x)*RGB_CHANNELS); k < m*RGB_CHANNELS; k += RGB_CHANNELS){
				UPDATE_ACC01((srcTop - x*RGB_CHANNELS)[start], 0, --);
				UPDATE_ACC01((srcTop - x*RGB_CHANNELS)[start + 1], 1, --);
				UPDATE_ACC01((srcTop - x*RGB_CHANNELS)[start + 2], 2, --);

				UPDATE_ACC01((srcBotton - x*RGB_CHANNELS)[start], 0, ++);
				UPDATE_ACC01((srcBotton - x*RGB_CHANNELS)[start + 1], 1, ++);
				UPDATE_ACC01((srcBotton - x*RGB_CHANNELS)[start + 2], 2, ++);
				start += RGB_CHANNELS;
			}

			if (srcBotton + step < srcMax){
				srcBotton += step;
			}
			if (y >= m / 2){
				srcTop += step;
			}
		}
	}

	src = _src;
	for (x = halfKernel; x < width - halfKernel; x++, src += RGB_CHANNELS, dst += RGB_CHANNELS){
		dstCur = dst;
		srcTop = src;
		srcBotton = src;

		// init accumulator
		memset(zone0, 0, sizeof(zone0[0]) * RGB_CHANNELS);
		memset(zone1, 0, sizeof(zone1[0]) * RGB_CHANNELS);

		for (y = 0; y <= m / 2; y++){
			for (c = 0; c < RGB_CHANNELS; c++){
				if (y > 0){
					for (k = 0; k < m * RGB_CHANNELS; k += RGB_CHANNELS){
						UPDATE_ACC01(srcBotton[k + c], c, ++);
					}
				}
				else{
					for (k = 0; k < m * RGB_CHANNELS; k += RGB_CHANNELS){
						UPDATE_ACC01(srcBotton[k + c], c, += m / 2 + 1);
					}
				}
			}

			if (y < height - 1){
				srcBotton += step;
			}
		}

		for (y = 0; y < height; y++, dstCur += step){
			// find median
			for (c = 0; c < RGB_CHANNELS; c++){
				s = 0;
				for (k = 0;; k++){
					t = s + zone0[c][k];
					if (t > n2){
						break;
					}
					s = t;
				}
				for (k *= N;; k++){
					s += zone1[c][k];
					if (s > n2) {
						break;
					}
				}
				dstCur[c] = (UI08)k;
			}
			if (y + 1 == height){
				break;
			}
			for (k = 0; k < m * RGB_CHANNELS; k += RGB_CHANNELS){
				UPDATE_ACC01(srcTop[k], 0, --);
				UPDATE_ACC01(srcTop[k + 1], 1, --);
				UPDATE_ACC01(srcTop[k + 2], 2, --);

				UPDATE_ACC01(srcBotton[k], 0, ++);
				UPDATE_ACC01(srcBotton[k + 1], 1, ++);
				UPDATE_ACC01(srcBotton[k + 2], 2, ++);
			}
			if (srcBotton + step < srcMax){
				srcBotton += step;
			}
			if (y >= m / 2){
				srcTop += step;
			}
		}
	}

	for (x = width - halfKernel; x < width; x++, src += RGB_CHANNELS, dst += RGB_CHANNELS){
		dstCur = dst;
		srcTop = src;
		srcBotton = src;

		// init accumulator
		memset(zone0, 0, sizeof(zone0[0]) * RGB_CHANNELS);
		memset(zone1, 0, sizeof(zone1[0]) * RGB_CHANNELS);
		for (y = 0; y <= m / 2; y++){
			for (c = 0; c < RGB_CHANNELS; c++){
				if (y > 0){
					for (k = 0; k < (halfKernel + (width - x)) * RGB_CHANNELS; k += RGB_CHANNELS){
						UPDATE_ACC01(srcBotton[k + c], c, ++);
					}
					end = 0;
					for (k = (halfKernel + (width - x)) * RGB_CHANNELS; k < m * RGB_CHANNELS; k += RGB_CHANNELS){
						end += RGB_CHANNELS;
						UPDATE_ACC01(srcBotton[k + c - end], c, ++);
					}
				}
				else{
					for (k = 0; k < (halfKernel + (width - x)) * RGB_CHANNELS; k += RGB_CHANNELS){
						UPDATE_ACC01(srcBotton[k + c], c, += m / 2 + 1);
					}
					end = 0;
					for (k = (halfKernel + (width - x)) * RGB_CHANNELS; k < m * RGB_CHANNELS; k += RGB_CHANNELS){
						end += RGB_CHANNELS;
						UPDATE_ACC01(srcBotton[k + c - end], c, += m / 2 + 1);
					}
				}
			}
			if (y < height - 1){
				srcBotton += step;
			}
		}
		for (y = 0; y < height; y++, dstCur += step){
			// find median
			for (c = 0; c < RGB_CHANNELS; c++){
				s = 0;
				for (k = 0;; k++){
					t = s + zone0[c][k];
					if (t > n2) {
						break;
					}
					s = t;
				}

				for (k *= N;; k++){
					s += zone1[c][k];
					if (s > n2) {
						break;
					}
				}
				dstCur[c] = (UI08)k;
			}

			if (y + 1 == height){
				break;
			}
			for (k = 0; k < (halfKernel + (width - x)) * RGB_CHANNELS; k += RGB_CHANNELS){
				UPDATE_ACC01(srcTop[k], 0, --);
				UPDATE_ACC01(srcTop[k + 1], 1, --);
				UPDATE_ACC01(srcTop[k + 2], 2, --);

				UPDATE_ACC01(srcBotton[k], 0, ++);
				UPDATE_ACC01(srcBotton[k + 1], 1, ++);
				UPDATE_ACC01(srcBotton[k + 2], 2, ++);
			}
			end = 0;
			for (k = (halfKernel + (width - x)) * RGB_CHANNELS; k < m * RGB_CHANNELS; k += RGB_CHANNELS){
				end += RGB_CHANNELS;
				UPDATE_ACC01(srcTop[k - end], 0, --);
				UPDATE_ACC01(srcTop[k + 1 - end], 1, --);
				UPDATE_ACC01(srcTop[k + 2 - end], 2, --);

				UPDATE_ACC01(srcBotton[k - end], 0, ++);
				UPDATE_ACC01(srcBotton[k + 1 - end], 1, ++);
				UPDATE_ACC01(srcBotton[k + 2 - end], 2, ++);
			}

			if (srcBotton + step < srcMax){
				srcBotton += step;
			}
			if (y >= m / 2){
				srcTop += step;
			}
		}
	}
#undef N
#undef UPDATE_ACC	
}

/** medianFilterForLargeKernelandImage(UI08 *_src, UI08 *_dst, SI32 width, SI32 height, SI32 kernel)
* @brief 平均化フィルタ
* @param[in]	_src		入力画像領域のポインタ
* @param[out]	_dst		出力画像領域のポインタ
* @param[in]	width		画像幅
* @param[in]	height		画像縦
* @param[in]	kernel			平滑範囲
* @return		none
*/
PRIVATE void medianFilterForLargeKernelandImage(UI08 *_src, UI08 *_dst, SI32 width, SI32 height, SI32 kernel){
#define N  16
#define UPDATE_ACC01( pix, chanel, op )		\
	{										\
		SI32 p = (pix);						\
		zone1[chanel][p] op;				\
		zone0[chanel][p >> 4] op;			\
	}
#define COP(c,j,x,op)						\
    h_coarse[ 16*(n*c+j) + (x>>4) ] op,		\
    h_fine[ 16 * (n*(16*c+(x>>4)) + j) + (x & 0xF) ] op

	SI32    zone0[4][N];
	SI32    zone1[4][N*N];
	SI32    n2 = (kernel*kernel) / 2;
	SI32	halfKernel = GET_HALF_KERNEL(kernel);
	SI32	step = width * RGB_CHANNELS;
	UI08	*src1 = _src;
	UI08	*dst1 = _dst;
	SI32	x, y, t, c, s, i, j, k, end, start;
	SI32	STRIPE_SIZE = min(width, 512 / RGB_CHANNELS);
	const	UI08 *srcMax = src1 + height*(step);
	UI08	*dstCur;
	const	UI08 *srcTop;
	const	UI08 *srcBotton;
	Histogram  H[4];
	UI16	luc[4][16];
	UI16	h_coarse[_h_coarse_size];
	UI16	h_fine[_h_fine_size];

	for (x = 0; x < halfKernel; x++, src1 += RGB_CHANNELS, dst1 += RGB_CHANNELS){
		dstCur = dst1;
		srcTop = src1;
		srcBotton = src1;

		// init accumulator
		memset(zone0, 0, sizeof(zone0[0])*RGB_CHANNELS);
		memset(zone1, 0, sizeof(zone1[0])*RGB_CHANNELS);
		start = 0;
		for (y = 0; y <= halfKernel; y++){
			for (c = 0; c < RGB_CHANNELS; c++){
				if (y > 0){
					for (k = 0; k < ((halfKernel - x)*RGB_CHANNELS); k += RGB_CHANNELS){
						UPDATE_ACC01((srcBotton - x*RGB_CHANNELS)[c], c, ++);
					}
					start = 0;
					for (k = ((halfKernel - x)*RGB_CHANNELS); k < kernel*RGB_CHANNELS; k += RGB_CHANNELS){
						UPDATE_ACC01((srcBotton - x*RGB_CHANNELS)[start + c], c, ++);
						start += RGB_CHANNELS;
					}
				}
				else {
					for (k = 0; k < ((halfKernel - x)*RGB_CHANNELS); k += RGB_CHANNELS){
						UPDATE_ACC01((srcBotton - x*RGB_CHANNELS)[c], c, += (halfKernel + 1));
					}
					start = 0;
					for (k = ((halfKernel - x)*RGB_CHANNELS); k < kernel*RGB_CHANNELS; k += RGB_CHANNELS){
						UPDATE_ACC01((srcBotton - x*RGB_CHANNELS)[start + c], c, += (halfKernel + 1));
						start += RGB_CHANNELS;
					}
				}
			}
			if (y < height - 1){
				srcBotton += step;
			}
		}
		for (y = 0; y < height; y++, dstCur += step){
			// find median
			for (c = 0; c < RGB_CHANNELS; c++){
				s = 0;
				for (k = 0;; k++){
					t = s + zone0[c][k];
					if (t > n2) {
						break;
					}
					s = t;
				}

				for (k *= N;; k++){
					s += zone1[c][k];
					if (s > n2) {
						break;
					}
				}
				dstCur[c] = (UI08)k;
			}

			if (y + 1 == height){
				break;
			}

			for (k = 0; k < ((halfKernel - x)*RGB_CHANNELS); k += RGB_CHANNELS){
				UPDATE_ACC01((srcTop - x*RGB_CHANNELS)[0], 0, --);
				UPDATE_ACC01((srcTop - x*RGB_CHANNELS)[1], 1, --);
				UPDATE_ACC01((srcTop - x*RGB_CHANNELS)[2], 2, --);

				UPDATE_ACC01((srcBotton - x*RGB_CHANNELS)[0], 0, ++);
				UPDATE_ACC01((srcBotton - x*RGB_CHANNELS)[1], 1, ++);
				UPDATE_ACC01((srcBotton - x*RGB_CHANNELS)[2], 2, ++);
			}
			start = 0;
			for (k = ((halfKernel - x)*RGB_CHANNELS); k < kernel*RGB_CHANNELS; k += RGB_CHANNELS){
				UPDATE_ACC01((srcTop - x*RGB_CHANNELS)[start], 0, --);
				UPDATE_ACC01((srcTop - x*RGB_CHANNELS)[start + 1], 1, --);
				UPDATE_ACC01((srcTop - x*RGB_CHANNELS)[start + 2], 2, --);

				UPDATE_ACC01((srcBotton - x*RGB_CHANNELS)[start], 0, ++);
				UPDATE_ACC01((srcBotton - x*RGB_CHANNELS)[start + 1], 1, ++);
				UPDATE_ACC01((srcBotton - x*RGB_CHANNELS)[start + 2], 2, ++);
				start += RGB_CHANNELS;
			}

			if (srcBotton + step < srcMax){
				srcBotton += step;
			}
			if (y >= kernel / 2){
				srcTop += step;
			}
		}
	}
	SI32 block_end = 0;
	SI32 b, n, sum;
	UI16*	segment;
	const	UI08* p0;
	const	UI08* p1;
	const	UI08* src;
	UI08*	dst;
	const	UI08* p;
	for (x = 0; x < width - halfKernel; x += STRIPE_SIZE)
	{
		n = MIN(width - x, STRIPE_SIZE) + halfKernel * 2;
		src = _src + x*RGB_CHANNELS;
		dst = _dst + x*RGB_CHANNELS;

		memset(h_coarse, 0, 16 * n*RGB_CHANNELS*sizeof(h_coarse[0]));
		memset(h_fine, 0, 16 * 16 * n*RGB_CHANNELS*sizeof(h_fine[0]));

		// First row initialization
		for (c = 0; c < RGB_CHANNELS; c++)
		{
			for (j = 0; j < n; j++)
				COP(c, j, src[RGB_CHANNELS*j + c], += (halfKernel + 2));

			for (i = 1; i < halfKernel; i++)
			{
				p = src + step*MIN(i, height - 1);
				for (j = 0; j < n; j++)
					COP(c, j, p[RGB_CHANNELS*j + c], ++);
			}
		}

		for (i = 0; i < height; i++)
		{
			p0 = src + step * MAX(0, i - halfKernel - 1);
			p1 = src + step * MIN(height - 1, i + halfKernel);

			memset(H, 0, RGB_CHANNELS*sizeof(H[0]));
			memset(luc, 0, RGB_CHANNELS*sizeof(luc[0]));
			for (c = 0; c < RGB_CHANNELS; c++)
			{
				// Update column histograms for the entire row.
				for (j = 0; j < n; j++)
				{
					COP(c, j, p0[j*RGB_CHANNELS + c], --);
					COP(c, j, p1[j*RGB_CHANNELS + c], ++);
				}

				// First column initialization
				for (k = 0; k < 16; ++k)
					histogram_muladd(2 * halfKernel + 1, &h_fine[16 * n*(16 * c + k)], &H[c].fine[k][0]);
				
				for (j = 0; j < 2 * halfKernel; ++j)
					histogram_add(&h_coarse[16 * (n*c + j)], H[c].coarse);

				// Check block end
				if (width - x < STRIPE_SIZE + halfKernel){
					block_end = halfKernel;
				}

				for (j = halfKernel; j < n - (halfKernel + block_end); j++)
				{
					t = 2 * halfKernel*halfKernel + 2 * halfKernel;
					sum = 0;
					histogram_add(&h_coarse[16 * (n*c + MIN(j + halfKernel, n - 1))], H[c].coarse);

					// Find median at coarse level
					for (k = 0; k < 16; ++k)
					{
						sum += H[c].coarse[k];
						if (sum > t)
						{
							sum -= H[c].coarse[k];
							break;
						}
					}

					/* Update corresponding histogram segment */
					if (luc[c][k] <= j - halfKernel)
					{
						memset(&H[c].fine[k], 0, 16 * sizeof(UI16));
						for (luc[c][k] = (UI16)(j - halfKernel); luc[c][k] < MIN(j + halfKernel + 1, n); ++luc[c][k])
							histogram_add(&h_fine[16 * (n*(16 * c + k) + luc[c][k])], H[c].fine[k]);

						if (luc[c][k] < j + halfKernel + 1)
						{
							histogram_muladd(j + halfKernel + 1 - n, &h_fine[16 * (n*(16 * c + k) + (n - 1))], &H[c].fine[k][0]);
							luc[c][k] = (UI16)(j + halfKernel + 1);
						}
					}
					else
					{
						for (; luc[c][k] < j + halfKernel + 1; ++luc[c][k])
						{
							histogram_sub(&h_fine[16 * (n*(16 * c + k) + MAX(luc[c][k] - 2 * halfKernel - 1, 0))], H[c].fine[k]);
							histogram_add(&h_fine[16 * (n*(16 * c + k) + MIN(luc[c][k], n - 1))], H[c].fine[k]);
						}
					}

					histogram_sub(&h_coarse[16 * (n*c + MAX(j - halfKernel, 0))], H[c].coarse);

					/* Find median in segment */
					segment = H[c].fine[k];
					for (b = 0; b < 16; b++)
					{
						sum += segment[b];
						if (sum > t)
						{
							dst[step*i + RGB_CHANNELS*j + c] = (UI08)(16 * k + b);
							break;
						}
					}
				}
			}
		}
	}

	src1 = _src;
	dst1 = _dst;
	src1 += (width - 2 * halfKernel)*RGB_CHANNELS;
	dst1 += (width - halfKernel)*RGB_CHANNELS;

	for (x = width - halfKernel; x < width; x++, src1 += RGB_CHANNELS, dst1 += RGB_CHANNELS){
		dstCur = dst1;
		srcTop = src1;
		srcBotton = src1;

		// init accumulator
		memset(zone0, 0, sizeof(zone0[0]) * RGB_CHANNELS);
		memset(zone1, 0, sizeof(zone1[0]) * RGB_CHANNELS);
		for (y = 0; y <= kernel / 2; y++){
			for (c = 0; c < RGB_CHANNELS; c++){
				if (y > 0){
					for (k = 0; k < (halfKernel + (width - x)) * RGB_CHANNELS; k += RGB_CHANNELS){
						UPDATE_ACC01(srcBotton[k + c], c, ++);
					}
					end = 0;
					for (k = (halfKernel + (width - x)) * RGB_CHANNELS; k < kernel * RGB_CHANNELS; k += RGB_CHANNELS){
						end += RGB_CHANNELS;
						UPDATE_ACC01(srcBotton[k + c - end], c, ++);
					}
				}
				else{
					for (k = 0; k < (halfKernel + (width - x)) * RGB_CHANNELS; k += RGB_CHANNELS){
						UPDATE_ACC01(srcBotton[k + c], c, += kernel / 2 + 1);
					}
					end = 0;
					for (k = (halfKernel + (width - x)) * RGB_CHANNELS; k < kernel * RGB_CHANNELS; k += RGB_CHANNELS){
						end += RGB_CHANNELS;
						UPDATE_ACC01(srcBotton[k + c - end], c, += kernel / 2 + 1);
					}
				}
			}
			if (y < height - 1){
				srcBotton += step;
			}
		}
		for (y = 0; y < height; y++, dstCur += step){
			// find median
			for (c = 0; c < RGB_CHANNELS; c++){
				s = 0;
				for (k = 0;; k++){
					t = s + zone0[c][k];
					if (t > n2) {
						break;
					}
					s = t;
				}

				for (k *= N;; k++){
					s += zone1[c][k];
					if (s > n2) {
						break;
					}
				}
				dstCur[c] = (UI08)k;
			}

			if (y + 1 == height){
				break;
			}
			for (k = 0; k < (halfKernel + (width - x)) * RGB_CHANNELS; k += RGB_CHANNELS){
				UPDATE_ACC01(srcTop[k], 0, --);
				UPDATE_ACC01(srcTop[k + 1], 1, --);
				UPDATE_ACC01(srcTop[k + 2], 2, --);

				UPDATE_ACC01(srcBotton[k], 0, ++);
				UPDATE_ACC01(srcBotton[k + 1], 1, ++);
				UPDATE_ACC01(srcBotton[k + 2], 2, ++);
			}
			end = 0;
			for (k = (halfKernel + (width - x)) * RGB_CHANNELS; k < kernel * RGB_CHANNELS; k += RGB_CHANNELS){
				end += RGB_CHANNELS;
				UPDATE_ACC01(srcTop[k - end], 0, --);
				UPDATE_ACC01(srcTop[k + 1 - end], 1, --);
				UPDATE_ACC01(srcTop[k + 2 - end], 2, --);

				UPDATE_ACC01(srcBotton[k - end], 0, ++);
				UPDATE_ACC01(srcBotton[k + 1 - end], 1, ++);
				UPDATE_ACC01(srcBotton[k + 2 - end], 2, ++);
			}

			if (srcBotton + step < srcMax){
				srcBotton += step;
			}
			if (y >= kernel / 2){
				srcTop += step;
			}
		}
	}
#undef N
#undef UPDATE_ACC
#undef COP
}

/** getKernelGaus(FP32* kernel, UI32 expansion)
* @brief Calculate and get the Gaussian kernel
* @param[in]	expansion	size of kernel
* @param[out]	kernel		kernel output
* @return		none
*/
PRIVATE void getKernelGaus(FP32* kernel, UI32 expansion)
{
	if (expansion == 3){
		kernel[0] = KERNEL_3_COEFFICIENT_1;
		kernel[1] = KERNEL_3_COEFFICIENT_2;
		kernel[2] = KERNEL_3_COEFFICIENT_3;
	}
	else if (expansion == 5){
		kernel[0] = KERNEL_5_COEFFICIENT_1;
		kernel[1] = KERNEL_5_COEFFICIENT_2;
		kernel[2] = KERNEL_5_COEFFICIENT_3;
		kernel[3] = KERNEL_5_COEFFICIENT_4;
		kernel[4] = KERNEL_5_COEFFICIENT_5;
	}
	else if (expansion == 7){
		kernel[0] = KERNEL_7_COEFFICIENT_1;
		kernel[1] = KERNEL_7_COEFFICIENT_2;
		kernel[2] = KERNEL_7_COEFFICIENT_3;
		kernel[3] = KERNEL_7_COEFFICIENT_4;
		kernel[4] = KERNEL_7_COEFFICIENT_5;
		kernel[5] = KERNEL_7_COEFFICIENT_6;
		kernel[6] = KERNEL_7_COEFFICIENT_7;
	}
	else {
		FP64 sigmaX = ((expansion - 1)*0.5 - 1)*0.3 + 0.8;
		FP64 scale2X = -0.5 / (sigmaX*sigmaX);
		FP64 sum = 0;
		SI32 i;
		for (i = 0; i < (SI32)expansion; i++)
		{
			FP64 x = i - (expansion - 1)*0.5;
			FP64 t = exp(scale2X*x*x);
			kernel[i] = (FP32)t;
			sum += kernel[i];
		}

		sum = 1. / sum;
		for (i = 0; i < (SI32)expansion; i++)
		{
			kernel[i] = (FP32)(kernel[i] * sum);
		}

	}
}
/** conv(BrcBGR *pInImage, FP32 *kernel, FP32 *redBuff, FP32 *greenBuff, FP32 *blueBuff, UI32 borderType, UI32 width, UI32 expansion)
* @brief Calculate x-asis following convolution data
* @param[in]	pInImage		Input image pointer
* @param[in]	kernel			The Gaussian kernel
* @param[out]	redBuff			The buffer store x-asis following data convolution of red chanel
* @param[out]	greenBuff		The buffer store x-asis following data convolution of green chanel
* @param[out]	blueBuff		The buffer store x-asis following data convolution of blue chanel
* @param[in]	borderType		The border type for output image
* @param[in]	width			The width of output image
* @param[in]	expansion		The size of kernel
* @return		none
*/
PRIVATE void conv(BrcBGR *pInImage, FP32 *kernel, FP32 *redBuff, FP32 *greenBuff, FP32 *blueBuff, UI32 borderType, UI32 width, UI32 expansion)
{
	SI32 i, j, k;
	BrcBGR *inPoint;
	// Various border types, image boundaries are denoted with '|'
	// BORDER_CONSTANT		= 0,		//!< `000000|abcdefgh|000000`
	// BORDER_REPLICATE		= 1,		//!< `aaaaaa|abcdefgh|hhhhhhh`
	// BORDER_REFLECT		= 2,		//!< `fedcba|abcdefgh|hgfedcb`
	// BORDER_REFLECT_101	= 3,		//!< `gfedcb|abcdefgh|gfedcba`
	// BORDER_DEFAULT		= BORDER_REFLECT_101
	if (borderType == 0){
		for (i = 0; i < (SI32)(expansion / 2); i++){
			k = 0;
			*redBuff = 0;
			*greenBuff = 0;
			*blueBuff = 0;
			for (j = (SI32)(expansion / 2) - i; j < (SI32)expansion; j++){
				*redBuff += (*(pInImage + k)).red * kernel[j];
				*greenBuff += (*(pInImage + k)).green * kernel[j];
				*blueBuff += (*(pInImage + k)).blue * kernel[j];
				k++;
			}
			redBuff++;
			greenBuff++;
			blueBuff++;
		}
	}
	else if (borderType == 1){
		inPoint = pInImage;
		for (i = 0; i < (SI32)(expansion / 2); i++){
			*redBuff = 0;
			*greenBuff = 0;
			*blueBuff = 0;
			k = 0;
			for (j = 0; j < (SI32)(expansion / 2) - i; j++){
				*redBuff += (*inPoint).red * kernel[j];
				*greenBuff += (*inPoint).green * kernel[j];
				*blueBuff += (*inPoint).blue * kernel[j];
			}
			for (; j < (SI32)expansion; j++){
				*redBuff += (*(pInImage + k)).red * kernel[j];
				*greenBuff += (*(pInImage + k)).green * kernel[j];
				*blueBuff += (*(pInImage + k)).blue * kernel[j];
				k++;
			}
			redBuff++;
			greenBuff++;
			blueBuff++;
		}
	}
	else{
		if (borderType == 2)
			inPoint = pInImage + ((expansion / 2) - 1);
		else
			inPoint = pInImage + (expansion / 2);
		for (i = 0; i < (SI32)(expansion / 2); i++){
			*redBuff = 0;
			*greenBuff = 0;
			*blueBuff = 0;
			k = 0;
			for (j = 0; j < (SI32)(expansion / 2) - i; j++){
				*redBuff += (*(inPoint - j)).red * kernel[j];
				*greenBuff += (*(inPoint - j)).green * kernel[j];
				*blueBuff += (*(inPoint - j)).blue * kernel[j];
			}
			for (; j < (SI32)expansion; j++){
				*redBuff += (*(pInImage + k)).red * kernel[j];
				*greenBuff += (*(pInImage + k)).green * kernel[j];
				*blueBuff += (*(pInImage + k)).blue * kernel[j];
				k++;
			}
			inPoint--;
			redBuff++;
			greenBuff++;
			blueBuff++;
		}
	}
	inPoint = pInImage;
	for (; i < (SI32)width - (SI32)(expansion / 2); i++){
		*redBuff = 0;
		*greenBuff = 0;
		*blueBuff = 0;

		for (j = 0; j < (SI32)expansion; j++){
			*redBuff += (*(inPoint + j)).red * kernel[j];
			*greenBuff += (*(inPoint + j)).green * kernel[j];
			*blueBuff += (*(inPoint + j)).blue * kernel[j];
		}
		inPoint++;
		redBuff++;
		greenBuff++;
		blueBuff++;
	}

	k = 1;
	if (borderType == 0){
		for (; i < (SI32)width; i++){
			*redBuff = 0;
			*greenBuff = 0;
			*blueBuff = 0;
			for (j = 0; j < (SI32)(expansion)-k; j++){
				*redBuff += (*(inPoint + j)).red * kernel[j];
				*greenBuff += (*(inPoint + j)).green * kernel[j];
				*blueBuff += (*(inPoint + j)).blue * kernel[j];
			}
			k++;
			inPoint++;
			redBuff++;
			greenBuff++;
			blueBuff++;
		}
	}
	else if (borderType == 1){
		pInImage += (width - 1);
		for (; i < (SI32)width; i++){
			*redBuff = 0;
			*greenBuff = 0;
			*blueBuff = 0;
			for (j = 0; j < (SI32)(expansion)-k; j++){
				*redBuff += (*(inPoint + j)).red * kernel[j];
				*greenBuff += (*(inPoint + j)).green * kernel[j];
				*blueBuff += (*(inPoint + j)).blue * kernel[j];
			}
			for (; j < (SI32)expansion; j++){
				*redBuff += (*(pInImage)).red * kernel[j];
				*greenBuff += (*(pInImage)).green * kernel[j];
				*blueBuff += (*(pInImage)).blue * kernel[j];
			}
			k++;
			inPoint++;
			redBuff++;
			greenBuff++;
			blueBuff++;
		}
	}
	else {
		if (borderType == 2)
			pInImage += (width - 1);
		else
			pInImage += (width - 2);
		UI32 over;
		for (; i < (SI32)width; i++){
			*redBuff = 0;
			*greenBuff = 0;
			*blueBuff = 0;
			for (j = 0; j < (SI32)(expansion)-k; j++){
				*redBuff += (*(inPoint + j)).red * kernel[j];
				*greenBuff += (*(inPoint + j)).green * kernel[j];
				*blueBuff += (*(inPoint + j)).blue * kernel[j];
			}
			over = 0;
			for (; j < (SI32)expansion; j++){
				*redBuff += (*(pInImage - over)).red * kernel[j];
				*greenBuff += (*(pInImage - over)).green * kernel[j];
				*blueBuff += (*(pInImage - over)).blue * kernel[j];
				over++;
			}
			k++;
			inPoint++;
			redBuff++;
			greenBuff++;
			blueBuff++;
		}
	}
}

/** hFirstConv(BrcBGR *pInImage, FP32 *kernel, FP32 *redBuff, FP32 *greenBuff, FP32 *blueBuff, UI32 borderType, UI32 width, UI32 expansion)
* @brief Calculate x-asis following convolution data for first row
* @param[in]	pInImage		Input image pointer
* @param[in]	kernel			The Gaussian kernel
* @param[out]	redBuff			The buffer store x-asis following data convolution of red chanel
* @param[out]	greenBuff		The buffer store x-asis following data convolution of green chanel
* @param[out]	blueBuff		The buffer store x-asis following data convolution of blue chanel
* @param[in]	borderType		The border type for output image
* @param[in]	width			The width of output image
* @param[in]	expansion		The size of kernel
* @return		none
*/
PRIVATE void hFirstConv(BrcBGR *pInImage, FP32 *kernel, FP32 *redBuff, FP32 *greenBuff, FP32 *blueBuff, UI32 borderType, UI32 width, UI32 expansion)
{
	SI32 j, i;
	redBuff += (expansion / 2) * width;
	greenBuff += (expansion / 2) * width;
	blueBuff += (expansion / 2) * width;
	// Various border types, image boundaries are denoted with '|'
	// BORDER_CONSTANT		= 0,		//!< `000000|abcdefgh|000000`
	// BORDER_REPLICATE		= 1,		//!< `aaaaaa|abcdefgh|hhhhhhh`
	// BORDER_REFLECT		= 2,		//!< `fedcba|abcdefgh|hgfedcb`
	// BORDER_REFLECT_101	= 3,		//!< `gfedcb|abcdefgh|gfedcba`
	// BORDER_DEFAULT		= BORDER_REFLECT_101
	for (j = (expansion / 2); j < (SI32)expansion; j++) {
		conv(pInImage, kernel, redBuff, greenBuff, blueBuff, borderType, width, expansion);
		pInImage += width;
		redBuff += width;
		greenBuff += width;
		blueBuff += width;
	}
	redBuff -= width * expansion;
	greenBuff -= width * expansion;
	blueBuff -= width * expansion;
	if (borderType == 0){
		memset((void*)(redBuff), 0, width * sizeof(FP32) * (expansion / 2));
		memset((void*)(greenBuff), 0, width * sizeof(FP32) * (expansion / 2));
		memset((void*)(blueBuff), 0, width * sizeof(FP32) * (expansion / 2));
	}
	else if (borderType == 1){
		for (j = 0; j < (SI32)(expansion / 2); j++)
		{
			memcpy((void*)(redBuff + (j * width)), (void*)(redBuff + (expansion / 2) * width), width * sizeof(FP32));
			memcpy((void*)(greenBuff + (j * width)), (void*)(greenBuff + (expansion / 2) * width), width * sizeof(FP32));
			memcpy((void*)(blueBuff + (j * width)), (void*)(blueBuff + (expansion / 2) * width), width * sizeof(FP32));
		}
	}
	else if (borderType == 2){
		i = 0;
		for (j = (expansion / 2) - 1; j >= 0; j--){
			memcpy((void*)(redBuff + (j * width)), (void*)(redBuff + (((expansion / 2) + i)) * width), width * sizeof(FP32));
			memcpy((void*)(greenBuff + (j * width)), (void*)(greenBuff + (((expansion / 2) + i)) * width), width * sizeof(FP32));
			memcpy((void*)(blueBuff + (j * width)), (void*)(blueBuff + (((expansion / 2) + i)) * width), width * sizeof(FP32));
			i++;
		}
	}
	else {
		i = 1;
		for (j = (expansion / 2) - 1; j >= 0; j--){
			memcpy((void*)(redBuff + (j * width)), (void*)(redBuff + (((expansion / 2) + i)) * width), width * sizeof(FP32));
			memcpy((void*)(greenBuff + (j * width)), (void*)(greenBuff + (((expansion / 2) + i)) * width), width * sizeof(FP32));
			memcpy((void*)(blueBuff + (j * width)), (void*)(blueBuff + (((expansion / 2) + i)) * width), width * sizeof(FP32));
			i++;
		}
	}
}

/** hConv(BrcBGR *pInImage, FP32 *kernel, FP32 *redBuff, FP32 *greenBuff, FP32 *blueBuff, UI32 borderType, UI32 width, UI32 expansion)
* @brief Calculate x-asis following convolution data for first row
* @param[in]	pInImage		Input image pointer
* @param[in]	kernel			The Gaussian kernel
* @param[out]	redBuff			The buffer store x-asis following data convolution of red chanel
* @param[out]	greenBuff		The buffer store x-asis following data convolution of green chanel
* @param[out]	blueBuff		The buffer store x-asis following data convolution of blue chanel
* @param[in]	borderType		The border type for output image
* @param[in]	width			The width of output image
* @param[in]	expansion		The size of kernel
* @return		none
*/
PRIVATE void hConv(BrcBGR *pInImage, FP32 *kernel, FP32 *redBuff, FP32 *greenBuff, FP32 *blueBuff, UI32 borderType, UI32 width, UI32 expansion)
{
	redBuff += (expansion - 1) * width;
	greenBuff += (expansion - 1) * width;
	blueBuff += (expansion - 1) * width;
	conv(pInImage, kernel, redBuff, greenBuff, blueBuff, borderType, width, expansion);
}

/** vConv(FP32 *redBuff, FP32 *greenBuff, FP32 *blueBuff, FP32 *kernel, UI32 width, UI32 expansion, BrcBGR *pOutImage)
* @brief Convoluation R, G, B chanel y-asis following
* @param[in]	redBuff			The buffer store x-asis following data convolution of red chanel
* @param[in]	greenBuff		The buffer store x-asis following data convolution of green chanel
* @param[in]	blueBuff		The buffer store x-asis following data convolution of blue chanel
* @param[in]	kernel			The Gaussian kernel
* @param[in]	width			The width of output image
* @param[in]	expansion		The size of kernel
* @param[out]	pOutImage		Output image pointer
* @return		none
*/
PRIVATE void vConv(FP32 *redBuff, FP32 *greenBuff, FP32 *blueBuff, FP32 *kernel, UI32 width, UI32 expansion, BrcBGR *pOutImage)
{
	UI32 i, j;
	FP32 pixelValueR, pixelValueG, pixelValueB;
	for (i = 0; i < width; i++){
		pixelValueR = pixelValueG = pixelValueB = 0;
		for (j = 0; j < expansion; j++)
		{
			pixelValueR += kernel[j] * (*(redBuff + (j * width)));
			pixelValueG += kernel[j] * (*(greenBuff + (j * width)));
			pixelValueB += kernel[j] * (*(blueBuff + (j * width)));
		}
		(*pOutImage).red = (UI08)CLIP(pixelValueR, BYTE_RESET, BYTE_FULLSET);
		(*pOutImage).green = (UI08)CLIP(pixelValueG, BYTE_RESET, BYTE_FULLSET);
		(*pOutImage).blue = (UI08)CLIP(pixelValueB, BYTE_RESET, BYTE_FULLSET);
		redBuff++;
		greenBuff++;
		blueBuff++;
		pOutImage++;
	}
}

/** copyToBuff(FP32 *redBuff, FP32 *greenBuff, FP32 *blueBuff, UI32 width, UI32 expansion, SI32 over, UI32 borderType)
* @brief Copy data and reoder R, G, B chanel buffer
* @param[out]	redBuff			The buffer store x-asis following data convolution of red chanel
* @param[out]	greenBuff		The buffer store x-asis following data convolution of green chanel
* @param[out]	blueBuff		The buffer store x-asis following data convolution of blue chanel
* @param[in]	width			The width of output image
* @param[in]	expansion		The size of kernel
* @param[in]	over			The overflow data
* @param[in]	borderType		The border type for output image
* @return		none
*/
PRIVATE void copyToBuff(FP32 *redBuff, FP32 *greenBuff, FP32 *blueBuff, UI32 width, UI32 expansion, SI32 over, UI32 borderType)
{
	SI32 i;

	memcpy((void*)(redBuff), (void*)(redBuff + width), width * sizeof(FP32) * (expansion - over));
	memcpy((void*)(greenBuff), (void*)(greenBuff + width), width * sizeof(FP32) * (expansion - over));
	memcpy((void*)(blueBuff), (void*)(blueBuff + width), width * sizeof(FP32) * (expansion - over));

	if (borderType == 0){
		memset((void*)(redBuff + (expansion - over) * width), 0, width * sizeof(FP32));
		memset((void*)(greenBuff + (expansion - over) * width), 0, width * sizeof(FP32));
		memset((void*)(blueBuff + (expansion - over) * width), 0, width * sizeof(FP32));
	}
	else if (borderType == 1){
		//Do nothing
	}
	else if (borderType == 2){
		SI32 j = over + 1;
		for (i = over; i >= 1; i--){
			memcpy((void*)(redBuff + (expansion - i) * width), (void*)(redBuff + (expansion - j) * width), width * sizeof(FP32));
			memcpy((void*)(greenBuff + (expansion - i) * width), (void*)(greenBuff + (expansion - j) * width), width * sizeof(FP32));
			memcpy((void*)(blueBuff + (expansion - i) * width), (void*)(blueBuff + (expansion - j) * width), width * sizeof(FP32));
			j++;
		}
	}
	else {
		SI32 j = over + 2;
		for (i = over; i >= 1; i--){
			memcpy((void*)(redBuff + (expansion - i) * width), (void*)(redBuff + (expansion - j) * width), width * sizeof(FP32));
			memcpy((void*)(greenBuff + (expansion - i) * width), (void*)(greenBuff + (expansion - j) * width), width * sizeof(FP32));
			memcpy((void*)(blueBuff + (expansion - i) * width), (void*)(blueBuff + (expansion - j) * width), width * sizeof(FP32));
			j++;
		}
	}
}
/** normalConv(UI32 width, UI32 height, UI32 expansion, FP32 *kernel, void *pInRGB, void *pOutRGB)
* @brief Convolution with small image
* @param[in]	width			The width of output image
* @param[in]	height			The height of output image
* @param[in]	expansion		The size of kernel
* @param[in]	pInRGB			Input image pointer
* @param[out]	pInRGB			Output image pointer
* @return		none
*/
PRIVATE void normalConv(UI32 width, UI32 height, UI32 expansion, FP32 *kernel, void *pInRGB, void *pOutRGB)
{
	BrcBGR* pIn = (BrcBGR*)pInRGB;
	BrcBGR* pOut = (BrcBGR*)pOutRGB;

	UI32 x, y;
	SI32 i, j;
	FP32 sumR, sumG, sumB;
	SI32 pixelValue;
	SI32 startLoop = -(SI32)(expansion / 2), endLoop = (SI32)(expansion / 2) + 1;
	SI32 kernelHafl = (SI32)(expansion / 2);
	for (y = 0; y < height; y++){
		for (x = 0; x < width; x++){
			sumR = sumG = sumB = 0;
			for (i = startLoop; i < endLoop; i++)
			{
				for (j = startLoop; j < endLoop; j++)
				{
					if (((SI32)x + j >= 0) && ((SI32)y + i >= 0) && ((SI32)y + i < (SI32)height) && ((SI32)x + j < (SI32)width)){
						sumR += pIn[((y + i) * width) + (x + j)].red * kernel[((i + kernelHafl) * expansion) + (j + kernelHafl)];
						sumG += pIn[((y + i) * width) + (x + j)].green * kernel[((i + kernelHafl) * expansion) + (j + kernelHafl)];
						sumB += pIn[((y + i) * width) + (x + j)].blue * kernel[((i + kernelHafl) * expansion) + (j + kernelHafl)];
					}
				}
			}
			pixelValue = (UI08)CLIP(sumR, BYTE_RESET, BYTE_FULLSET);
			(*pOut).red = pixelValue;
			pixelValue = (UI08)CLIP(sumG, BYTE_RESET, BYTE_FULLSET);
			(*pOut).green = pixelValue;
			pixelValue = (UI08)CLIP(sumB, BYTE_RESET, BYTE_FULLSET);
			(*pOut).blue = pixelValue;
			pOut++;
		}
	}
}

/** SmoothingGaussianFilter(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, UI32 expansion, UI32 borderType)
* @brief Gaussian filter
* @param[in]	width		width of image
* @param[in]	height		height of image
* @param[in]	pInRGB		pointer to rgb data input
* @param[out]	pOutRGB		pointer to rgb data output
* @param[in]	expansion	size of gaussian kernel
* @param[in]	borderType	pixel extrapolation method (0,1,2,3)
* @return		0	Success !0 Failure
*/
PUBLIC SI32 SmoothingGaussianFilter(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, UI32 expansion, UI32 borderType)
{
#if __tracking
	Memory_Start();
#endif

	SI32	err = ((0 < width) && (0 < height) && ((SI32)expansion % 2 != 0) && ((SI32)expansion > 1)
		&& (pInRGB != brcNull) && (pOutRGB != brcNull) && (borderType == 0 || borderType == 1 || borderType == 2 || borderType == 3) ? SUCCESS : EINVAL);
	if (err == 0){

		SI32 kSizeX, kSizeY;
		kSizeX = kSizeY = expansion;
		UI32 sizeOutputImage = width * height * RGB_CHANNELS;
		UI32	sizeBuff = (width * sizeof(FP32) * RGB_CHANNELS * expansion) + (sizeof(FP32) * expansion);
		UI32	heightOver;
		if (sizeBuff % (width * RGB_CHANNELS)){
			heightOver = (sizeBuff / (width * RGB_CHANNELS)) + 1;
		}
		else {
			heightOver = sizeBuff / (width * RGB_CHANNELS);
		}
		// Processing data
		if (heightOver > (height / 2)){
			FP32 kernelTemp[7] = { 0 };
			FP32 kernel[49] = { 0 };
			UI32 i, j;
			if (expansion == 3){
				kernelTemp[0] = KERNEL_3_COEFFICIENT_1;
				kernelTemp[1] = KERNEL_3_COEFFICIENT_2;
				kernelTemp[2] = KERNEL_3_COEFFICIENT_3;
			}
			else if (expansion == 5){
				kernelTemp[0] = KERNEL_5_COEFFICIENT_1;
				kernelTemp[1] = KERNEL_5_COEFFICIENT_2;
				kernelTemp[2] = KERNEL_5_COEFFICIENT_3;
				kernelTemp[3] = KERNEL_5_COEFFICIENT_4;
				kernelTemp[4] = KERNEL_5_COEFFICIENT_5;
			}
			else {
				expansion = 7;
				kernelTemp[0] = KERNEL_7_COEFFICIENT_1;
				kernelTemp[1] = KERNEL_7_COEFFICIENT_2;
				kernelTemp[2] = KERNEL_7_COEFFICIENT_3;
				kernelTemp[3] = KERNEL_7_COEFFICIENT_4;
				kernelTemp[4] = KERNEL_7_COEFFICIENT_5;
				kernelTemp[5] = KERNEL_7_COEFFICIENT_6;
				kernelTemp[6] = KERNEL_7_COEFFICIENT_7;
			}
			for (i = 0; i < expansion; i++){
				for (j = 0; j < expansion; j++){
					kernel[i * expansion + j] = kernelTemp[j] * kernelTemp[i];
				}
			}
			normalConv(width, height, expansion, kernel, pInRGB, pOutRGB);
		}
		else {
			BrcBGR *pInImage = (BrcBGR *)pInRGB;
			BrcBGR *pOutImage = (BrcBGR *)pOutRGB;
			UI32	buffPos = sizeOutputImage - (width * heightOver * RGB_CHANNELS);
			SI32 i, j = 1;
			FP32	*kernel, *redBuff, *greenBuff, *blueBuff, *buf;
			buf = (FP32*)((UI08*)pOutRGB + buffPos);
			redBuff = buf;
			greenBuff = redBuff + (width * expansion);
			blueBuff = greenBuff + (width * expansion);
			kernel = blueBuff + (width * expansion);
			getKernelGaus(kernel, expansion);

			hFirstConv(pInImage, kernel, redBuff, greenBuff, blueBuff, borderType, width, expansion);
			vConv(redBuff, greenBuff, blueBuff, kernel, width, expansion, pOutImage);

			for (i = 1; i < (SI32)(height - heightOver); i++){
				memcpy((void*)(redBuff), (void*)(redBuff + width), width * sizeof(FP32) * (expansion - 1));
				memcpy((void*)(greenBuff), (void*)(greenBuff + width), width * sizeof(FP32) * (expansion - 1));
				memcpy((void*)(blueBuff), (void*)(blueBuff + width), width * sizeof(FP32) * (expansion - 1));

				hConv(pInImage + ((i + (expansion / 2)) * width), kernel, redBuff, greenBuff, blueBuff, borderType, width, expansion);
				vConv(redBuff, greenBuff, blueBuff, kernel, width, expansion, pOutImage + (i * width));
			}
			memcpy((void*)(pInRGB), (void*)(buf), width * heightOver * RGB_CHANNELS);
			redBuff = pInRGB;
			greenBuff = redBuff + (width * expansion);
			blueBuff = greenBuff + (width * expansion);
			kernel = blueBuff + (width * expansion);

			for (; i < (SI32)(height - (expansion / 2)); i++){
				memcpy((void*)(redBuff), (void*)(redBuff + width), width * sizeof(FP32) * (expansion - 1));
				memcpy((void*)(greenBuff), (void*)(greenBuff + width), width * sizeof(FP32) * (expansion - 1));
				memcpy((void*)(blueBuff), (void*)(blueBuff + width), width * sizeof(FP32) * (expansion - 1));

				hConv(pInImage + ((i + (expansion / 2)) * width), kernel, redBuff, greenBuff, blueBuff, borderType, width, expansion);
				vConv(redBuff, greenBuff, blueBuff, kernel, width, expansion, pOutImage + (i * width));
			}

			for (; i < (SI32)height; i++){
				copyToBuff(redBuff, greenBuff, blueBuff, width, expansion, j, borderType);
				vConv(redBuff, greenBuff, blueBuff, kernel, width, expansion, pOutImage + (i * width));
				j++;
			}

		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}