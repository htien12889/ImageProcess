﻿/** 
 * @file BrcImageHomography.c
 * @brief
 * @author EMT-BrycenVN
 * @date 2016/11/08
 * @par Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#include <math.h>
#include "BrcType.h"
#include "BrcImageProcessingCommon.h"
#include "BrcMemoryUsage.h"

#define PI			3.14
#define MAX_ANGLE	60
#define PROJECTION_MATRIX	{ 1, 0, -(FP32)(width) / 2, 0, 1, -(FP32)(height) / 2, 0, 0, 0, 0, 0, 1 }
#define ROTATION_MATRIX_X	{ 1, 0, 0, 0, 0, (FP32)cos(angleX), (FP32)-sin(angleX), 0, 0, (FP32)sin(angleX), (FP32)cos(angleX), 0, 0, 0, 0, 1 }
#define ROTATION_MATRIX_Y	{ (FP32)cos(angleY), 0, (FP32)-sin(angleY), 0, 0, 1, 0, 0, (FP32)sin(angleY), 0, (FP32)cos(angleY), 0, 0, 0, 0, 1 }
#define ROTATION_MATRIX_Z	{ (FP32)cos(0), 0, (FP32)-sin(0), 0, 0, 1, 0, 0, (FP32)sin(0), 0, (FP32)cos(0), 0, 0, 0, 0, 1 }
#define GET_VALUE(value)	((FP32)((value) * 300) / 336)
#define TRANSLATION_MATRIX	{ 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, dZ, 0, 0, 0, 1 }
#define MATRIX_2D			{ dZ, 0, (FP32)width / 2, 0, 0, dZ, (FP32)height / 2, 0, 0, 0, 1, 0 }
#define X_VALUE_INDEX0		20
#define X_VALUE_INDEX1		10
#define X_VALUE_INDEX2		3
#define X_VALUE_INDEX3		9
#define Y_VALUE_INDEX0		10
#define Y_VALUE_INDEX1		1
#define Y_VALUE_INDEX2		8
#define Y_VALUE_INDEX3		10

PRIVATE SI32 homographyCore(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, FP32 *pX, FP32 *pY, FP32 *pU, FP32 *pV);
PRIVATE void calcHomograpyMat(FP32 *pX, FP32 *pY, FP32 *pU, FP32 *pV, FP32 *pMat);
PRIVATE SI32 solveLinerEquation(FP32 *pA, FP32 *pB, FP32 *pX, UI32 dimRow, UI32 dimCol);
PRIVATE void lerp(SI32 w, SI32 h, UI08 *image, FP32 x, FP32 y, FP32 pix[3]);
PRIVATE SI32 multiMatrix(FP32 *output, FP32 *matrixA, FP32 *matrixB, SI32 rowA, SI32 colA, SI32 rowB, SI32 colB);

/** Homography(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, FP32 angleX, FP32 angleY)
* @brief 射影変換（TBD）
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInRGB		入力画像領域のポインタ
* @param[out]	pOutRGB		出力画像領域のポインタ
* @param[in]	angleX
* @param[in]	angleY
* @return		0:成功 0以外:失敗
*/
PUBLIC SI32 Homography(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, FP32 angleX, FP32 angleY)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height)
		&& (pInRGB != brcNull) && (pOutRGB != brcNull) && (angleX >= (FP32)((FP32)-MAX_ANGLE * PI) / 180) && (angleX <= (FP32)((FP32)MAX_ANGLE * PI) / 180)
		&& (angleY >= (FP32)((FP32)-MAX_ANGLE * PI) / 180) && (angleY <= (FP32)((FP32)MAX_ANGLE * PI) / 180) ? SUCCESS : EINVAL);
	FP32 pX[4], pY[4], pU[4], pV[4];
	if (err == 0){
		// Projection 2D -> 3D matrix
		FP32 A1[12] = PROJECTION_MATRIX;
		// Rotation matrices around the X, Y, and Z axis
		FP32 rX[16] = ROTATION_MATRIX_X;
		FP32 rY[16] = ROTATION_MATRIX_Y;
		FP32 rZ[16] = ROTATION_MATRIX_Z;
		// Composed rotation matrix with (RX, RY, RZ)
		FP32 rTemp[16] = { 0 };
		FP32 R[16] = { 0 };
		FP32 dZ = GET_VALUE(width);
		err = multiMatrix(rTemp, rX, rY, 4, 4, 4, 4);
		if (err != 0){
			return err;
		}
		err = multiMatrix(R, rTemp, rZ, 4, 4, 4, 4);
		if (err != 0){
			return err;
		}
		// Translation matrix
		FP32 T[16] = TRANSLATION_MATRIX;
		FP32 rXA1[12] = { 0 };
		err = multiMatrix(rXA1, R, A1, 4, 4, 4, 3);
		if (err != 0){
			return err;
		}
		FP32 tXrXA1[12] = { 0 };
		err = multiMatrix(tXrXA1, T, rXA1, 4, 4, 4, 3);
		if (err != 0){
			return err;
		}
		// 3D -> 2D matrix
		FP32 A2[12] = MATRIX_2D;
		FP32 trans[9] = { 0 };
		err = multiMatrix(trans, A2, tXrXA1, 3, 4, 4, 3);
		if (err != 0){
			return err;
		}
		pX[0] = X_VALUE_INDEX0; pY[0] = Y_VALUE_INDEX0;
		pX[1] = X_VALUE_INDEX1; pY[1] = Y_VALUE_INDEX1;
		pX[2] = X_VALUE_INDEX2; pY[2] = Y_VALUE_INDEX2;
		pX[3] = X_VALUE_INDEX3; pY[3] = Y_VALUE_INDEX3;
		pU[0] = (FP32)(pX[0] * trans[0] + pY[0] * trans[1] + trans[2]) / (pX[0] * trans[6] + pY[0] * trans[7] + trans[8]);
		pV[0] = (FP32)(pX[0] * trans[3] + pY[0] * trans[4] + trans[5]) / (pX[0] * trans[6] + pY[0] * trans[7] + trans[8]);
		pU[1] = (FP32)(pX[1] * trans[0] + pY[1] * trans[1] + trans[2]) / (pX[1] * trans[6] + pY[1] * trans[7] + trans[8]);
		pV[1] = (FP32)(pX[1] * trans[3] + pY[1] * trans[4] + trans[5]) / (pX[1] * trans[6] + pY[1] * trans[7] + trans[8]);
		pU[2] = (FP32)(pX[2] * trans[0] + pY[2] * trans[1] + trans[2]) / (pX[2] * trans[6] + pY[2] * trans[7] + trans[8]);
		pV[2] = (FP32)(pX[2] * trans[3] + pY[2] * trans[4] + trans[5]) / (pX[2] * trans[6] + pY[2] * trans[7] + trans[8]);
		pU[3] = (FP32)(pX[3] * trans[0] + pY[3] * trans[1] + trans[2]) / (pX[3] * trans[6] + pY[3] * trans[7] + trans[8]);
		pV[3] = (FP32)(pX[3] * trans[3] + pY[3] * trans[4] + trans[5]) / (pX[3] * trans[6] + pY[3] * trans[7] + trans[8]);

		err = homographyCore(width, height, pInRGB, pOutRGB, pX, pY, pU, pV);
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** multiMatrix(FP32 *output, FP32 *matrixA, FP32 *matrixB, SI32 rowA, SI32 colA, SI32 rowB, SI32 colB)
* @brief Multiply two matrices
* @param[out]	output		result matrix
* @param[in]	matrixA		pointer to matrixA
* @param[in]	matrixB		pointer to matrixB
* @param[in]	rowA		number of row of matrixA
* @param[in]	colA		number of column of matrixA
* @param[in]	rowB		number of row of matrixB
* @param[in]	colB		number of column of matrixB
* @return		0			Success !0 Failure
*/
PRIVATE SI32 multiMatrix(FP32 *output, FP32 *matrixA, FP32 *matrixB, SI32 rowA, SI32 colA, SI32 rowB, SI32 colB)
{
	SI32	err = ((colA == rowB) ? SUCCESS : EINVAL);
	SI32 i, j, k;
	// EINVAL: Cannot multiply 2 matrices
	if (err == 0){
		for (i = 0; i < rowA; i++){
			for (j = 0; j < colB; j++){
				output[colB * i + j] = 0;
				for (k = 0; k < colA; k++){
					output[colB * i + j] += matrixA[colA * i + k] * matrixB[colB * k + j];
				}
			}
		}
	}
	return err;
}

/** homographyCore(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, FP32 *pX, FP32 *pY, FP32 *pU, FP32 *pV)
* @brief Perform homography based on 8 points
* @param[in]	width		image width
* @param[in]	height		image height
* @param[in]	pInRGB		pointer of input image
* @param[out]	pOutRGB		pointer of output image
* @param[in]	pX			4 x coordinates input
* @param[in]	pY			4 y coordinates input
* @param[in]	pU			4 x coordinates output
* @param[in]	pV			4 y coordinates output
* @return		0			Success !0 Failure
*/
PRIVATE SI32 homographyCore(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, FP32 *pX, FP32 *pY, FP32 *pU, FP32 *pV)
{
	SI32	err = ((0 < width) && (0 < height) && (pInRGB != brcNull) && (pOutRGB != brcNull)
		&& (pX != brcNull) && (pY != brcNull) && (pU != brcNull) && (pV != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		FP32 pMat[9];
		SI08 *pIn = (SI08*)pInRGB;
		SI08 *pOut = (SI08*)pOutRGB;
		UI32 i, j, k;
		FP32 u, v, w, x, y;
		FP32 pix[3];
		calcHomograpyMat(pX, pY, pU, pV, pMat);
		for (i = 0; i < height; i++) {
			for (j = 0; j < width; j++) {
				u = pMat[0] * j + pMat[1] * i + pMat[2];
				v = pMat[3] * j + pMat[4] * i + pMat[5];
				w = pMat[6] * j + pMat[7] * i + pMat[8];
				x = u / w;
				y = v / w;
				lerp((SI32)width, (SI32)height, pIn, x, y, pix);
				for (k = 0; k < 3; k++) {
					*(pOut + k) = (UI08)(pix[k] + 0.5);
				}
				pOut = pOut + 3;
			}
		}
	}
	return err;
}

/** lerp(SI32 w, SI32 h, UI08 *image, FP32 x, FP32 y, FP32 pix[3])
* @brief Linear interpolation
* @param[in]	w		image width
* @param[in]	h		image height
* @param[in]	image	pointer of input image
* @param[in]	x		x coordinates
* @param[in]	y		y coordinates
* @param[out]	pix		rgb value of pixel
* @return		none
*/
PRIVATE void lerp(SI32 w, SI32 h, UI08 *image, FP32 x, FP32 y, FP32 pix[3])
{
	if (x < 0 || y < 0 || x >= w - 1 || y >= h - 1) {
		pix[0] = pix[1] = pix[2] = 0.0;
	}
	else {
		SI32 r0 = (SI32)y;
		SI32 c0 = (SI32)x;
		SI32 r1 = r0 + 1;
		SI32 c1 = c0 + 1;
		UI08 *p00 = &image[3 * (r0*w + c0)];
		UI08 *p10 = &image[3 * (r0*w + c1)];
		UI08 *p01 = &image[3 * (r1*w + c0)];
		UI08 *p11 = &image[3 * (r1*w + c1)];
		FP32 s = x - c0;
		FP32 top[3], bot[3];
		SI32 k;
		for (k = 0; k < 3; k++) {
			top[k] = (1 - s)*p00[k] + s*p10[k];
			bot[k] = (1 - s)*p01[k] + s*p11[k];
		}
		FP32 t = y - r0;
		for (k = 0; k < 3; k++){
			pix[k] = (1 - t)*top[k] + t*bot[k];
		}
	}
}

/** calcHomograpyMat(FP32 *pX, FP32 *pY, FP32 *pU, FP32 *pV, FP32 *pMat)
* @brief Calculation of homography
* @param[in]	pX			4 x coordinates input
* @param[in]	pY			4 y coordinates input
* @param[in]	pU			4 x coordinates output
* @param[in]	pV			4 y coordinates output
* @param[out]	pMat		transform matrix
* @return		none
*/
PRIVATE void calcHomograpyMat(FP32 *pX, FP32 *pY, FP32 *pU, FP32 *pV, FP32 *pMat)
{
	FP32 a[64], b[8];
	FP32 x, y, xA, yA;
	UI32 i, j = 0;
	UI32 index = 0;
	for (i = 0; i < 8; i++){
		x = pX[j]; y = pY[j]; xA = pU[j]; yA = pV[j];
		a[index++] = x; a[index++] = y; a[index++] = 1; a[index++] = 0;
		a[index++] = 0; a[index++] = 0; a[index++] = -x*xA; a[index++] = -y*xA;
		b[i] = xA;
		i++;
		a[index++] = 0; a[index++] = 0; a[index++] = 0; a[index++] = x;
		a[index++] = y; a[index++] = 1; a[index++] = -x*yA; a[index++] = -y*yA;
		b[i] = yA;
		j++;
	}
	solveLinerEquation(a, b, pMat, 8, 1);
}

/** solveLinerEquation(FP32 *pA, FP32 *pB, FP32 *pX, UI32 dimRow, UI32 dimCol)
* @brief Solving Linear Equations
* @param[in]	pA			pointer to matrix A
* @param[in]	pB			pointer to matrix B
* @param[out]	pX			pointer to result matrix
* @param[in]	dimRow		number of row
* @param[in]	dimCol		number of column
* @return		0			Success !0 Failure
*/
PRIVATE SI32 solveLinerEquation(FP32 *pA, FP32 *pB, FP32 *pX, UI32 dimRow, UI32 dimCol)
{
	SI32	err = ((pA != brcNull) && (pB != brcNull) && (pX != brcNull) && (dimRow <= 8) && (dimCol == 1) ? SUCCESS : EINVAL);
	if (err == 0){
		SI32 i, j, n, k, l;
		FP32 a[8][8];
		FP32 sum = 0;
		FP64 p = 0;
		SI32 mutate[8];
		// Convert pA[] into a[8][8]
		for (i = 0; i < 8; i++){
			mutate[i] = i;
		}
		for (i = 0; i < 8; i++){
			for (j = 0; j < 8; j++){
				a[i][j] = pA[i * 8 + j];
			}
		}
		FP32 tmp;
		SI32 temp;
		for (j = 0; j <= 8 - 1; j++){
			for (i = 0; i <= j; i++){
				sum = 0;
				for (k = 0; k <= i - 1; k++){
					sum += a[i][k] * a[k][j];
				}	//Calculate Sum
				a[i][j] = a[i][j] - sum;
			}	//Compute Above And On Diagonal

			p = fabs(a[j][j]);	//Initial Pivot Value
			n = j;	//Initial Pivot Row
			sum = 0;	//Clear Sum
			for (i = j + 1; i <= 8 - 1; i++){
				sum = 0;
				for (k = 0; k <= j - 1; k++){
					sum += a[i][k] * a[k][j];
				}   //Calculate Sum
				a[i][j] = a[i][j] - sum;
				if (fabs(a[i][j]) > p){
					p = fabs(a[i][j]);
					n = i;
				}   //If Better Pivot, Record It
			}   //Computer Below Diagonal
			sum = 0; //Clear Sum
			if (p == 0){
				break;
			}	//Singular Matrix, Abort
			if (n != j){
				for (l = 0; l < 8; l++){
					tmp = a[n][l];
					a[n][l] = a[j][l];
					a[j][l] = tmp;
				}
				temp = mutate[n];
				mutate[n] = mutate[j];
				mutate[j] = temp;
			}	//Diagonal Pivot
			for (i = j + 1; i <= 8 - 1; i++){
				a[i][j] = a[i][j] / a[j][j];
			}	//Pivot Below Diagonal
		}
		FP32 y[8];
		y[0] = pB[mutate[0]];
		for (i = 1; i < 8; i++){
			sum = 0;
			for (j = 0; j <= i - 1; j++){
				sum += (a[i][j]) * (y[j]);
			}
			y[i] = pB[mutate[i]] - sum;
			sum = 0;
		}
		pX[7] = (y[7]) / (a[7][7]);
		for (i = 6; i >= 0; i--){
			sum = 0;
			for (j = i + 1; j <= 7; j++){
				sum += (a[i][j]) * (pX[j]);
			}
			pX[i] = (1 / (a[i][i])) * (y[i] - sum);
			sum = 0;
		}
		pX[8] = 1.0;
	}
	return err;
}