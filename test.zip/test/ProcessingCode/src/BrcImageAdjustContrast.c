﻿/**
 * @file	BrcImageAdjustContrast.c
 * @brief	コントラスト調整ヘッダファイル
 * @author	tfujii
 * @date	2016/07/29
 * @par		Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */

#include <math.h>
#include "BrcType.h"
#include "BrcImageProcessingCommon.h"
#include "BrcMemoryUsage.h"

#define USE_TANGENT						/// strengthToGrad関数内で正接関数を使用(未定義の場合は有理関数)
#define LUT_NUM							256
#define UPPER_STRENGTH_OF_CONTRAST		100.0
#define LOWER_STRENGTH_OF_CONTRAST		-100.0
#define BOUNDARY_1(grad, n)				(UI32)((((grad) - 1.0) * (n) / (2.0 * (grad))) + 1.0)
#define BOUNDARY_2(grad, n)				(UI32)(((grad) + 1.0) * (n) / (2.0 * (grad)))

PRIVATE FP64 strengthToGrad(FP64 strength, UI32 maxGrad);
PRIVATE void makeContrastLUT(UI32 *lut, UI32 num, FP64 strengthOfContrast);

/** AdjustContrast(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, FP64 strengthOfContrast)
 * @brief		コントラスト調整
 * @param[in]	width				画像幅
 * @param[in]	height				画像高さ
 * @param[in]	pInRGB				入力画像領域のポインタ
 * @param[out]	pOutRGB				出力画像領域のポインタ
 * @param[in]	strengthOfContrast	コントラスト調整値(定義域：[-100, 100])
 * @return		0:成功 0以外:失敗
 */
PUBLIC SI32 AdjustContrast(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, FP64 strengthOfContrast)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height)
		&& (pInRGB != brcNull) && (pOutRGB != brcNull) && (strengthOfContrast <= UPPER_STRENGTH_OF_CONTRAST)
		&& (strengthOfContrast >= LOWER_STRENGTH_OF_CONTRAST) ? SUCCESS : EINVAL);
	if(err == 0){
		UI32	lut[LUT_NUM];								/// ルックアップテーブル
		UI32	num = height * width * RGB_CHANNELS;		/// 画像のサイズ(要素数)
		UI08	*pIn = (UI08*)pInRGB;						/// 入力画像の走査用ポインタ
		UI08	*pOut = (UI08*)pOutRGB;						/// 出力画像の走査用ポインタ
		UI08	*pInEnd = (UI08*)pInRGB + num;				/// 画像の終了を表すアドレスを記憶
		/// コントラスト強度を元に輝度変換用LUTのデータを作成
		makeContrastLUT(lut, LUT_NUM, strengthOfContrast);
		/// ピクセル値を変換
		while (pIn != pInEnd){
			*(pOut++) = lut[*(pIn++)];
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** strengthToGrad(FP64 strength, UI32 maxGrad)
* @brief	コントラスト強度からトーンカーブのファクタ(一次関数の傾き)への変換
*			制約条件：(-100, 0), (0, 1), (100, maxGrad)を通るカーブを描く
* @param	strength	コントラスト強度
* @param	maxGrad		一次関数の傾きの上限
* @return 	strength calculated
*/
PRIVATE FP64 strengthToGrad(FP64 strength, UI32 maxGrad)
{
	/// 正接関数版
#ifdef		USE_TANGENT
	FP64	alpha = sqrt(maxGrad / (maxGrad - 2.0));
	return  (alpha * tan((1.0 / UPPER_STRENGTH_OF_CONTRAST) * atan(1.0 / alpha) * (strength + UPPER_STRENGTH_OF_CONTRAST)));
	/// 有理関数版
#else
	FP64	maxGradSub2 = maxGrad - 2.0;
	FP64	a = (-200.0 * maxGrad * (maxGrad - 1)) / (maxGradSub2 * maxGradSub2);
	FP64	p = (100.0 * maxGrad) / maxGradSub2;
	FP64	q = -(maxGrad / maxGradSub2);
	return  (a / (strength - p) + q);
#endif
}

/** makeContrastLUT(UI32 *lut, UI32 num, FP64 strengthOfContrast)
* @brief		コントラスト調整に基づくピクセル値変換のためのルックアップテーブルを生成
* @param[out]	lut					ルックアップテーブル
* @param[in]	num					ピクセルビット値の上限(そのままルックアップテーブルの長さになる)
* @param[in]	strengthOfContrast	コントラスト強度
* @return		なし
*/
PRIVATE void makeContrastLUT(UI32 *lut, UI32 num, FP64 strengthOfContrast)
{
	UI32	i;
	UI32	n = num - 1;
	FP64	grad = strengthToGrad(strengthOfContrast, n);		/// 一次関数の傾き
	FP64	paraTrans = (FP64)n / 2.0;							/// 原点からの平行移動
	/// 一次関数の傾きが1より大きいときクリッピングが生じる
	if (grad > 1.0) {
		/// クリッピング境界を算出
		UI32	boundary1 = BOUNDARY_1(grad, n);
		UI32	boundary2 = BOUNDARY_2(grad, n);
		/// 0未満の値をとる区間は0を割り当てる
		for (i = 0; i < boundary1; ++i){
			lut[i] = 0;
		}
		/// クリッピングの発生しない区間は一次関数で割り当てる
		for (; i < boundary2; ++i){
			lut[i] = (UI32)(grad * ((FP64)i - paraTrans) + paraTrans);
		}
		/// nより大きな値をとる区間はnを割り当てる
		for (; i < num; ++i){
			lut[i] = n;
		}
	}
	/// 傾きが1以下のときは0からnまですべて一次関数で割り当てる
	else {
		for (i = 0; i < num; ++i){
			lut[i] = (UI32)(grad * ((FP64)i - paraTrans) + paraTrans);
		}
	}
}

