﻿/**
* @file	BrcImageDifferential.c
* @brief 	微分変換ソースファイル
* @author 	etstuchida
* @date 	2016/09/01
* @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
*/
#include <errno.h>
#include <math.h>
#include <stdio.h>
#include "BrcType.h"
#include "BrcImageProcessingCommon.h"
#include "BrcMemoryUsage.h"

#define CLIP(x, mmin, mmax)		((x) < (mmin) ? (mmin) : (mmax) < (x) ? (mmax) : (x)) 
#define CALC_RGB2GRAY(r, g, b)	((0.299 * (r)) + (0.587 * (g)) + (0.114 * (b)))
#define CALC_KERNEL_Y_BORDERTYPE0_PATITION_A(pointer)			(*pointer * 2 + *(pointer + 1))
#define CALC_KERNEL_X_BORDERTYPE0_PATITION_A(pointer)			(0 - *(pointer + 1))
#define CALC_KERNEL_Y_BORDERTYPE1_2_PATITION_A(pointer)			(*pointer * 3 + *(pointer + 1))
#define CALC_KERNEL_X_BORDERTYPE1_2_PATITION_A(pointer)			(*pointer - *(pointer + 1))
#define CALC_KERNEL_Y_BORDERTYPE3_PATITION_A(pointer)			(*pointer * 2 + *(pointer + 1) * 2)
#define CALC_KERNEL_Y_PATITION_B(pointer)						(*pointer + *(pointer + 1) * 2 + *(pointer + 2))
#define CALC_KERNEL_X_PATITION_B(pointer)						(*pointer - *(pointer + 2))
#define CALC_KERNEL_Y_BORDERTYPE0_PATITION_C(pointer, value)	(*pointer + *(value) * 2)
#define CALC_KERNEL_Y_BORDERTYPE1_2_PATITION_C(pointer, value)  (*pointer + *(value) * 3)
#define CALC_KERNEL_Y_BORDERTYPE3_PATITION_C(pointer)			(*pointer * 2 + *(pointer + 1) * 2)
#define NUMBER_OF_BUFF_ROW										3
#define NUMBER_OF_BUFF_TYPE										2
#define KERNEL_SIZE												3
#define GX_GY													SI32 gX[9] = {1, 0, -1, 2, 0, -2, 1, 0, -1}; SI32 gY[9] = {1, 2, 1, 0, 0, 0, -1, -2, -1};

PRIVATE void trackBlack(UI08 *pIn, UI08 *pOut, UI32 width, UI32 height, SI32 x, SI32 y);
PRIVATE void calculateSurroundingDifference(SI32* tmp, UI32 width);
PRIVATE void nextXy(SI32* x, SI32* y, UI08 preciousVector, UI08 afterVector);
PRIVATE void fillBlack(UI08 **pTmpIn, UI08 **pTmpOut, SI32 accessIncrement);
PRIVATE SI32 pixelAccessCheck(SI32 x, SI32 y, UI32 width, UI32 height);
PRIVATE void store(UI08* pOut, UI08 pixelValue);
PRIVATE void normalConvGray(UI32 width, UI32 height, void *pInRGB, void *pOutRGB);
PRIVATE void normalConvRGB(UI32 width, UI32 height, void *pInRGB, void *pOutRGB);
PRIVATE void normalConv(UI32 width, UI32 height, void *pInRGB, void *pOutRGB);
PRIVATE void firstGrayConvert(BrcBGR *pInImage, UI08 *gray, UI32 width, UI32 borderType);
PRIVATE void grayConv(BrcBGR *pInImage, UI08 *gray, UI32 width);
PRIVATE void grayConvert(BrcBGR *pInImage, UI08 *gray, UI32 width);
PRIVATE void hGrayFirstConv(UI08 *gray, SI32 *buffX, SI32 *buffY, UI32 borderType, UI32 width);
PRIVATE void hGrayConv(UI08 *gray, SI32 *buffX, SI32 *buffY, UI32 borderType, UI32 width);
PRIVATE void convGray(UI08 *gray, SI32 *buffX, SI32 *buffY, UI32 borderType, UI32 width);
PRIVATE void vRGBConv(SI32 *buffX, SI32 *buffY, UI32 width, BrcBGR *pOut);
PRIVATE void vConv(SI32 *buffX, SI32 *buffY, UI32 width, BrcBGR *pOut);
PRIVATE void hRGBConv(BrcBGR *pIn, SI32 *buffX, SI32 *buffY, UI32 borderType, UI32 width);
PRIVATE void hConv(BrcBGR *pIn, SI32 *buffX, SI32 *buffY, UI32 borderType, UI32 width);
PRIVATE void hRGBFirstConv(BrcBGR *pIn, SI32 *buffX, SI32 *buffY, UI32 borderType, UI32 width);
PRIVATE void convRGB(BrcBGR *pIn, SI32 *buffX, SI32 *buffY, UI32 borderType, UI32 width);
PRIVATE void hFirstConv(BrcBGR *pIn, SI32 *buffX, SI32 *buffY, UI32 borderType, UI32 width);
PRIVATE void conv(BrcBGR *pIn, SI32 *buffX, SI32 *buffY, UI32 borderType, UI32 width);

//! 注目画素と八近傍画素のxの差(並びはBOTTOMLEFTから反時計回り)
static const SI08 g_xDifference[8] = { -1, 0, 1, 1, 1, 0, -1, -1 };

//! 注目画素と八近傍画素のyの差(並びはBOTTOMLEFTから反時計回り)
static const SI08 g_yDifference[8] = { -1, -1, -1, 0, 1, 1, 1, 0 };

/** @def SURROUNDING_EIGHT_PIXEL_POSITION
* 八近傍中のポジション
*/
typedef enum{
	BOTTOM_LEFT,
	BOTTOM,
	BOTTOM_RIGHT,
	RIGHT,
	TOP_RIGHT,
	TOP,
	TOP_LEFT,
	LEFT
}SURROUNDING_EIGHT_PIXEL_POSITION;

/** @def PIXELSTATE
* ピクセルの状態
*/
typedef enum{
	BLACK,
	WHITE
}PIXELSTATE;

/** conv(BrcBGR *pIn, SI32 *buffX, SI32 *buffY, UI32 borderType, UI32 width)
* @brief Calculate x-asis following convolution data
* @param[in]	pIn				Input image pointer
* @param[out]	buffX			The buffer store x-asis following data convolution of Gx kernel
* @param[out]	buffY			The buffer store x-asis following data convolution of Gy kernel
* @param[in]	borderType		The border type for output image
* @param[out]	width			The width of output image
* @return		none
*/
PRIVATE void conv(BrcBGR *pIn, SI32 *buffX, SI32 *buffY, UI32 borderType, UI32 width)
{
	SI32 i;
	if (borderType == 0){
		*buffX = 0 - (*(pIn + 1)).blue;						// kernel X
		*buffY = (*pIn).blue * 2 + (*(pIn + 1)).blue;	// kernel Y
		pIn++;
		buffX++;
		buffY++;
	}
	else if (borderType == 1 || borderType == 2){
		*buffX = (*pIn).blue - (*(pIn + 1)).blue;		// kernel X
		*buffY = (*pIn).blue * 3 + (*(pIn + 1)).blue;	// kernel Y
		pIn++;
		buffX++;
		buffY++;
	}
	else {
		*buffX = BYTE_RESET;														// kernel X
		*buffY = (*pIn).blue * 2 + (*(pIn + 1)).blue * 2;	// kernel Y
		pIn++;
		buffX++; // X
		buffY++;
	}

	for (i = 1; i < (SI32)width - 1; i++){
		*buffX = (*(pIn - 1)).blue - (*(pIn + 1)).blue;		// kernel X
		*buffY = (*(pIn - 1)).blue + (*pIn).blue * 2 + (*(pIn + 1)).blue;	// kernel Y
		pIn++;
		buffX++; // X
		buffY++;
	}

	if (borderType == 0){
		*buffX = (*(pIn - 1)).blue;		// kernel X
		*buffY = (*(pIn - 1)).blue + (*pIn).blue * 2;	// kernel Y
		pIn++;
		buffX++; // X
		buffY++;
	}
	else if (borderType == 1 || borderType == 2){
		*buffX = (*(pIn - 1)).blue - (*pIn).blue;		// kernel X
		*buffY = (*(pIn - 1)).blue + (*pIn).blue * 3;	// kernel Y
		pIn++;
		buffX++; // X
		buffY++;
	}
	else {
		*buffX = BYTE_RESET;			// kernel X
		*buffY = (*pIn).blue * 2 + (*(pIn - 1)).blue * 2;	// kernel Y
		pIn++;
		buffX++; // X
		buffY++;
	}
}

/** hFirstConv(BrcBGR *pIn, SI32 *buffX, SI32 *buffY, UI32 borderType, UI32 width)
* @brief Calculate x-asis following convolution data for the first of image
* @param[in]	pIn				Input image pointer
* @param[out]	buffX			The buffer store x-asis following data convolution of Gx kernel
* @param[out]	buffY			The buffer store x-asis following data convolution of Gy kernel
* @param[in]	borderType		The border type for output image
* @param[out]	width			The width of output image
* @return		none
*/
PRIVATE void hFirstConv(BrcBGR *pIn, SI32 *buffX, SI32 *buffY, UI32 borderType, UI32 width)
{
	SI32 j;
	buffX += width;
	buffY += width;
	for (j = 1; j < 3; j++) {
		conv(pIn, buffX, buffY, borderType, width);
		pIn += width;
		buffX += width;
		buffY += width;
	}
	buffX -= width * 3;
	buffY -= width * 3;
	if (borderType == 0){
		memset((void*)(buffX), 0, width * sizeof(SI32));
		memset((void*)(buffY), 0, width * sizeof(SI32));
	}
	else if (borderType == 1 || borderType == 2){
		memcpy((void*)(buffX), (void*)(buffX + width), width * sizeof(SI32));
		memcpy((void*)(buffY), (void*)(buffY + width), width * sizeof(SI32));
	}
	else {
		memcpy((void*)(buffX), (void*)(buffX + (width * 2)), width * sizeof(SI32));
		memcpy((void*)(buffY), (void*)(buffY + (width * 2)), width * sizeof(SI32));
	}
}

/** convRGB(BrcBGR *pIn, SI32 *buffX, SI32 *buffY, UI32 borderType, UI32 width)
* @brief Calculate x-asis following convolution data for the first of image
* @param[in]	pIn				Input image pointer
* @param[out]	buffX			The buffer store x-asis following data convolution of Gx kernel
* @param[out]	buffY			The buffer store x-asis following data convolution of Gy kernel
* @param[in]	borderType		The border type for output image
* @param[out]	width			The width of output image
* @return		none
*/
PRIVATE void convRGB(BrcBGR *pIn, SI32 *buffX, SI32 *buffY, UI32 borderType, UI32 width)
{
	SI32 i;
	if (borderType == 0){
		*buffX = 0 - (*(pIn + 1)).blue;						// kernel X
		*(buffX + 1) = 0 - (*(pIn + 1)).green;						// kernel X
		*(buffX + 2) = 0 - (*(pIn + 1)).red;						// kernel X

		*buffY = (*pIn).blue * 2 + (*(pIn + 1)).blue;	// kernel Y
		*(buffY + 1) = (*pIn).green * 2 + (*(pIn + 1)).green;	// kernel Y
		*(buffY + 2) = (*pIn).red * 2 + (*(pIn + 1)).red;	// kernel Y
		pIn++;
		buffX += 3;
		buffY += 3;
	}
	else if (borderType == 1 || borderType == 2){
		*buffX = (*pIn).blue - (*(pIn + 1)).blue;		// kernel X
		*(buffX + 1) = (*pIn).green - (*(pIn + 1)).green;		// kernel X
		*(buffX + 2) = (*pIn).red - (*(pIn + 1)).red;		// kernel X

		*buffY = (*pIn).blue * 3 + (*(pIn + 1)).blue;	// kernel Y
		*(buffY + 1) = (*pIn).green * 3 + (*(pIn + 1)).green;	// kernel Y
		*(buffY + 2) = (*pIn).red * 3 + (*(pIn + 1)).red;	// kernel Y
		pIn++;
		buffX += 3;
		buffY += 3;
	}
	else {
		*buffX = BYTE_RESET;														// kernel X
		*(buffX + 1) = BYTE_RESET;												// kernel X
		*(buffX + 2) = BYTE_RESET;											// kernel X

		*buffY = (*pIn).blue * 2 + (*(pIn + 1)).blue * 2;							// kernel Y
		*(buffY + 1) = (*pIn).green * 2 + (*(pIn + 1)).green * 2;				// kernel Y
		*(buffY + 2) = (*pIn).red * 2 + (*(pIn + 1)).red * 2;				// kernel Y
		pIn++;
		buffX += 3; // X
		buffY += 3;
	}

	for (i = 1; i < (SI32)width - 1; i++){
		*buffX = (*(pIn - 1)).blue - (*(pIn + 1)).blue;		// kernel X
		*(buffX + 1) = (*(pIn - 1)).green - (*(pIn + 1)).green;		// kernel X
		*(buffX + 2) = (*(pIn - 1)).red - (*(pIn + 1)).red;		// kernel X 

		*buffY = (*(pIn - 1)).blue + (*pIn).blue * 2 + (*(pIn + 1)).blue;	// kernel Y
		*(buffY + 1) = (*(pIn - 1)).green + (*pIn).green * 2 + (*(pIn + 1)).green;	// kernel Y
		*(buffY + 2) = (*(pIn - 1)).red + (*pIn).red * 2 + (*(pIn + 1)).red;	// kernel Y
		pIn++;
		buffX += 3; // X
		buffY += 3;
	}

	if (borderType == 0){
		*buffX = (*(pIn - 1)).blue;		// kernel X
		*(buffX + 1) = (*(pIn - 1)).green;		// kernel X
		*(buffX + 2) = (*(pIn - 1)).red;		// kernel X

		*buffY = (*(pIn - 1)).blue + (*pIn).blue * 2;	// kernel Y
		*(buffY + 1) = (*(pIn - 1)).green + (*pIn).green * 2;	// kernel Y
		*(buffY + 2) = (*(pIn - 1)).red + (*pIn).red * 2;	// kernel Y
		pIn++;
		buffX += 3; // X
		buffY += 3;
	}
	else if (borderType == 1 || borderType == 2){
		*buffX = (*(pIn - 1)).blue - (*pIn).blue;		// kernel X
		*(buffX + 1) = (*(pIn - 1)).green - (*pIn).green;		// kernel X
		*(buffX + 2) = (*(pIn - 1)).red - (*pIn).red;		// kernel X

		*buffY = (*(pIn - 1)).blue + (*pIn).blue * 3;	// kernel Y
		*(buffY + 1) = (*(pIn - 1)).green + (*pIn).green * 3;	// kernel Y
		*(buffY + 2) = (*(pIn - 1)).red + (*pIn).red * 3;	// kernel Y

		pIn++;
		buffX += 3; // X
		buffY += 3;
	}
	else {
		*buffX = BYTE_RESET;			// kernel X
		*(buffX + 1) = BYTE_RESET;			// kernel X
		*(buffX + 2) = BYTE_RESET;			// kernel X

		*buffY = (*pIn).blue * 2 + (*(pIn - 1)).blue * 2;	// kernel Y
		*(buffY + 1) = (*pIn).green * 2 + (*(pIn - 1)).green * 2;	// kernel Y
		*(buffY + 2) = (*pIn).red * 2 + (*(pIn - 1)).red * 2;	// kernel Y
		pIn++;
		buffX += 3; // X
		buffY += 3;
	}
}

/** hRGBFirstConv(BrcBGR *pIn, SI32 *buffX, SI32 *buffY, UI32 borderType, UI32 width)
* @brief Calculate x-asis following convolution data of R, G, B chanel for the first of image
* @param[in]	pIn				Input image pointer
* @param[out]	buffX			The buffer store x-asis following data convolution of Gx kernel
* @param[out]	buffY			The buffer store x-asis following data convolution of Gy kernel
* @param[in]	borderType		The border type for output image
* @param[out]	width			The width of output image
* @return		none
*/
PRIVATE void hRGBFirstConv(BrcBGR *pIn, SI32 *buffX, SI32 *buffY, UI32 borderType, UI32 width)
{
	SI32 j;
	buffX += 3 * width;
	buffY += 3 * width;
	for (j = 1; j < 3; j++) {
		convRGB(pIn, buffX, buffY, borderType, width);
		pIn += width;
		buffX += 3 * width;
		buffY += 3 * width;
	}
	buffX -= width * 9;
	buffY -= width * 9;
	if (borderType == 0){
		memset((void*)(buffX), 0, width * sizeof(SI32) * 3);
		memset((void*)(buffY), 0, width * sizeof(SI32) * 3);
	}
	else if (borderType == 1 || borderType == 2){
		memcpy((void*)(buffX), (void*)(buffX + width * 3), width * sizeof(SI32) * 3);
		memcpy((void*)(buffY), (void*)(buffY + width * 3), width * sizeof(SI32) * 3);
	}
	else {
		memcpy((void*)(buffX), (void*)(buffX + (width * 6)), width * sizeof(SI32) * 3);
		memcpy((void*)(buffY), (void*)(buffY + (width * 6)), width * sizeof(SI32) * 3);
	}
}

/** hConv(BrcBGR *pIn, SI32 *buffX, SI32 *buffY, UI32 borderType, UI32 width)
* @brief Calculate x-asis following convolution data
* @param[in]	pIn				Input image pointer
* @param[out]	buffX			The buffer store x-asis following data convolution of Gx kernel
* @param[out]	buffY			The buffer store x-asis following data convolution of Gy kernel
* @param[in]	borderType		The border type for output image
* @param[out]	width			The width of output image
* @return		none
*/
PRIVATE void hConv(BrcBGR *pIn, SI32 *buffX, SI32 *buffY, UI32 borderType, UI32 width)
{
	buffX += width * 2;
	buffY += width * 2;
	conv(pIn, buffX, buffY, borderType, width);
}

/** hRGBConv(BrcBGR *pIn, SI32 *buffX, SI32 *buffY, UI32 borderType, UI32 width)
* @brief Calculate x-asis following convolution data of R, G, B chanel
* @param[in]	pIn				Input image pointer
* @param[out]	buffX			The buffer store x-asis following data convolution of Gx kernel
* @param[out]	buffY			The buffer store x-asis following data convolution of Gy kernel
* @param[in]	borderType		The border type for output image
* @param[out]	width			The width of output image
* @return		none
*/
PRIVATE void hRGBConv(BrcBGR *pIn, SI32 *buffX, SI32 *buffY, UI32 borderType, UI32 width)
{
	buffX += width * 6;
	buffY += width * 6;
	convRGB(pIn, buffX, buffY, borderType, width);
}

/** vConv(SI32 *buffX, SI32 *buffY, UI32 width, BrcBGR *pOut)
* @brief Calculate y-asis following convolution data
* @param[in]	buffX			The buffer store x-asis following data convolution of Gx kernel
* @param[in]	buffY			The buffer store x-asis following data convolution of Gy kernel
* @param[in]	width			The width of output image
* @param[out]	pOut			The pointer for output image
* @return		none
*/
PRIVATE void vConv(SI32 *buffX, SI32 *buffY, UI32 width, BrcBGR *pOut)
{
	UI32 i;
	SI32 sumX, sumY;
	UI08 pixelValue;
	for (i = 0; i < width; i++){
		sumX = (*buffX) + (*(buffX + width)) * 2 + (*(buffX + 2 * width));
		sumY = (*buffY) - (*(buffY + 2 * width));
		pixelValue = (UI08)CLIP(sqrt(sumX * sumX + sumY * sumY), BYTE_RESET, BYTE_FULLSET);
		(*pOut).blue = pixelValue;
		(*pOut).red = pixelValue;
		(*pOut).green = pixelValue;
		buffX++;
		buffY++;
		pOut++;
	}
}

/** vRGBConv(SI32 *buffX, SI32 *buffY, UI32 width, BrcBGR *pOut)
* @brief Calculate y-asis following convolution data of R, G, B chanel
* @param[in]	buffX			The buffer store x-asis following data convolution of Gx kernel
* @param[in]	buffY			The buffer store x-asis following data convolution of Gy kernel
* @param[in]	width			The width of output image
* @param[out]	pOut			The pointer for output image
* @return		none
*/
PRIVATE void vRGBConv(SI32 *buffX, SI32 *buffY, UI32 width, BrcBGR *pOut)
{
	UI32 i;
	SI32 sumX, sumY;
	UI08 pixelValue;
	for (i = 0; i < width; i++){
		sumX = (*buffX) + (*(buffX + 3 * width)) * 2 + (*(buffX + 6 * width));
		sumY = (*buffY) - (*(buffY + 6 * width));
		pixelValue = (UI08)CLIP(sqrt(sumX * sumX + sumY * sumY), BYTE_RESET, BYTE_FULLSET);
		(*pOut).blue = pixelValue;

		sumX = (*(buffX + 1)) + (*(buffX + 3 * width + 1)) * 2 + (*(buffX + 6 * width + 1));
		sumY = (*(buffY + 1)) - (*(buffY + 6 * width + 1));
		pixelValue = (UI08)CLIP(sqrt(sumX * sumX + sumY * sumY), BYTE_RESET, BYTE_FULLSET);
		(*pOut).green = pixelValue;

		sumX = (*(buffX + 2)) + (*(buffX + 3 * width + 2)) * 2 + (*(buffX + 6 * width + 2));
		sumY = (*(buffY + 2)) - (*(buffY + 6 * width + 2));
		pixelValue = (UI08)CLIP(sqrt(sumX * sumX + sumY * sumY), BYTE_RESET, BYTE_FULLSET);
		(*pOut).red = pixelValue;

		buffX += 3;
		buffY += 3;
		pOut++;
	}
}

/** convGray(UI08 *gray, SI32 *buffX, SI32 *buffY, UI32 borderType, UI32 width)
* @brief Calculate x-asis following convolution data of gray image
* @param[in]	gray			gray data pointer
* @param[out]	buffX			The buffer store x-asis following data convolution of Gx kernel
* @param[out]	buffY			The buffer store x-asis following data convolution of Gy kernel
* @param[in]	borderType		The border type for output image
* @param[in]	width			The width of output image
* @return		none
*/
PRIVATE void convGray(UI08 *gray, SI32 *buffX, SI32 *buffY, UI32 borderType, UI32 width)
{
	SI32 i;
	if (borderType == 0){
		*buffX = 0 - (*(gray + 1));						// kernel X
		*buffY = (*gray) * 2 + (*(gray + 1));	// kernel Y
		gray++;
		buffX++;
		buffY++;
	}
	else if (borderType == 1 || borderType == 2){
		*buffX = (*gray) - (*(gray + 1));		// kernel X
		*buffY = (*gray) * 3 + (*(gray + 1));	// kernel Y
		gray++;
		buffX++;
		buffY++;
	}
	else {
		*buffX = BYTE_RESET;														// kernel X
		*buffY = (*gray) * 2 + (*(gray + 1)) * 2;	// kernel Y
		gray++;
		buffX++; // X
		buffY++;
	}

	for (i = 1; i < (SI32)width - 1; i++){
		*buffX = (*(gray - 1)) - (*(gray + 1));		// kernel X
		*buffY = (*(gray - 1)) + (*gray) * 2 + (*(gray + 1));	// kernel Y
		gray++;
		buffX++; // X
		buffY++;
	}

	if (borderType == 0){
		*buffX = (*(gray - 1));		// kernel X
		*buffY = (*(gray - 1)) + (*gray) * 2;	// kernel Y
		gray++;
		buffX++; // X
		buffY++;
	}
	else if (borderType == 1 || borderType == 2){
		*buffX = (*(gray - 1)) - (*gray);		// kernel X
		*buffY = (*(gray - 1)) + (*gray) * 3;	// kernel Y
		gray++;
		buffX++; // X
		buffY++;
	}
	else {
		*buffX = BYTE_RESET;			// kernel X
		*buffY = (*gray) * 2 + (*(gray - 1)) * 2;	// kernel Y
		gray++;
		buffX++; // X
		buffY++;
	}
}

/** hGrayConv(UI08 *gray, SI32 *buffX, SI32 *buffY, UI32 borderType, UI32 width)
* @brief Calculate y-asis following convolution data of gray image
* @param[in]	gray			gray data pointer
* @param[in]	buffX			The buffer store x-asis following data convolution of Gx kernel
* @param[in]	buffY			The buffer store x-asis following data convolution of Gy kernel
* @param[in]	borderType		The border type for output image
* @param[in]	width			The width of output image
* @return		none
*/
PRIVATE void hGrayConv(UI08 *gray, SI32 *buffX, SI32 *buffY, UI32 borderType, UI32 width)
{
	buffX += width * 2;
	buffY += width * 2;
	gray += width * 2;
	convGray(gray, buffX, buffY, borderType, width);
}

/** hGrayFirstConv(UI08 *gray, SI32 *buffX, SI32 *buffY, UI32 borderType, UI32 width)
* @brief Calculate y-asis following convolution data of gray image for the first row
* @param[in]	gray			gray data pointer
* @param[in]	buffX			The buffer store x-asis following data convolution of Gx kernel
* @param[in]	buffY			The buffer store x-asis following data convolution of Gy kernel
* @param[in]	borderType		The border type for output image
* @param[in]	width			The width of output image
* @return		none
*/
PRIVATE void hGrayFirstConv(UI08 *gray, SI32 *buffX, SI32 *buffY, UI32 borderType, UI32 width)
{
	SI32 j;
	for (j = 0; j < 3; j++) {
		convGray(gray, buffX, buffY, borderType, width);
		gray += width;
		buffX += width;
		buffY += width;
	}
}

/** grayConvert(BrcBGR *pInImage, UI08 *gray, UI32 width)
* @brief Convert RGB -> GRAY for a row
* @param[in]	pInImage		input data pointer
* @param[out]	gray			gary buffer pointer
* @param[in]	width			The width of output image
* @return		none
*/
PRIVATE void grayConvert(BrcBGR *pInImage, UI08 *gray, UI32 width)
{
	UI32 i = 0;
	for (i = 0; i < width; i++){
		*gray = (UI08)(CALC_RGB2GRAY((*pInImage).red, (*pInImage).green, (*pInImage).blue) + 0.5f);
		pInImage++;
		gray++;
	}

}

/** grayConv(BrcBGR *pInImage, UI08 *gray, UI32 width)
* @brief Convert RGB -> GRAY
* @param[in]	pInImage		input data pointer
* @param[out]	gray			gary buffer pointer
* @param[in]	width			The width of output image
* @return		none
*/
PRIVATE void grayConv(BrcBGR *pInImage, UI08 *gray, UI32 width)
{
	gray += 2 * width;
	grayConvert(pInImage, gray, width);
}

/** firstGrayConvert(BrcBGR *pInImage, UI08 *gray, UI32 width, UI32 borderType)
* @brief Convert RGB -> GRAY for first row
* @param[in]	pInImage		input data pointer
* @param[out]	gray			gary buffer pointer
* @param[in]	width			The width of output image
* @param[in]	borderType		The border type for output image
* @return		none
*/
PRIVATE void firstGrayConvert(BrcBGR *pInImage, UI08 *gray, UI32 width, UI32 borderType)
{
	gray += width;
	SI32 j;
	for (j = 1; j < 3; j++) {
		grayConvert(pInImage, gray, width);
		pInImage += width;
		gray += width;
	}
	gray -= width * 3;
	gray -= width * 3;
	if (borderType == 0){
		memset((void*)(gray), 0, width);
	}
	else if (borderType == 1 || borderType == 2){
		memcpy((void*)(gray), (void*)(gray + width), width);
	}
	else {
		memcpy((void*)(gray), (void*)(gray + width * 2), width);
	}
}

/** normalConv(UI32 width, UI32 height, void *pInRGB, void *pOutRGB)
* @brief Convolution for small image
* @param[in]	width		Width of output image
* @param[in]	height		Height of output image
* @param[in]	pInRGB		Input image pointer
* @param[out]	pOutRGB		Output image pointer
* @return		none
*/
PRIVATE void normalConv(UI32 width, UI32 height, void *pInRGB, void *pOutRGB)
{
	BrcBGR* pIn = (BrcBGR*)pInRGB;
	BrcBGR* pOut = (BrcBGR*)pOutRGB;

	UI32 x, y;
	SI32 i, j, sumX, sumY;
	GX_GY;

	SI32 pixelValue;

	for (y = 0; y < height; y++){
		for (x = 0; x < width; x++){
			sumX = sumY = 0;
			for (i = -1; i < 2; i++)
			{
				for (j = -1; j < 2; j++)
				{
					if (((SI32)x + j >= 0) && ((SI32)y + i >= 0) && ((SI32)y + i < (SI32)height) && ((SI32)x + j < (SI32)width)){
						sumX += pIn[((y + i) * width) + (x + j)].blue * gX[((i + 1) * KERNEL_SIZE) + (j + 1)];
						sumY += pIn[((y + i) * width) + (x + j)].blue * gY[((i + 1) * KERNEL_SIZE) + (j + 1)];
					}
				}
			}
			pixelValue = (UI08)CLIP(sqrt(sumX * sumX + sumY * sumY), BYTE_RESET, BYTE_FULLSET);
			(*pOut).red = pixelValue;
			(*pOut).green = pixelValue;
			(*pOut).blue = pixelValue;
			pOut++;
		}
	}
}

/** normalConvRGB(UI32 width, UI32 height, void *pInRGB, void *pOutRGB)
* @brief Convolution for small image for RGB channel
* @param[in]	width		Width of output image
* @param[in]	height		Height of output image
* @param[in]	pInRGB		Input image pointer
* @param[out]	pOutRGB		Output image pointer
* @return		none
*/
PRIVATE void normalConvRGB(UI32 width, UI32 height, void *pInRGB, void *pOutRGB)
{
	BrcBGR* pIn = (BrcBGR*)pInRGB;
	BrcBGR* pOut = (BrcBGR*)pOutRGB;

	UI32 x, y;
	SI32 i, j, sumXR, sumYR, sumXG, sumYG, sumXB, sumYB;
	GX_GY;

	SI32 pixelValue;

	for (y = 0; y < height; y++){
		for (x = 0; x < width; x++){
			sumXR = sumYR = sumXG = sumYG = sumXB = sumYB = 0;
			for (i = -1; i < 2; i++)
			{
				for (j = -1; j < 2; j++)
				{
					if (((SI32)x + j >= 0) && ((SI32)y + i >= 0) && ((SI32)y + i < (SI32)height) && ((SI32)x + j < (SI32)width)){
						sumXR += pIn[((y + i) * width) + (x + j)].red * gX[((i + 1) * KERNEL_SIZE) + (j + 1)];
						sumYR += pIn[((y + i) * width) + (x + j)].red * gY[((i + 1) * KERNEL_SIZE) + (j + 1)];

						sumXG += pIn[((y + i) * width) + (x + j)].green * gX[((i + 1) * KERNEL_SIZE) + (j + 1)];
						sumYG += pIn[((y + i) * width) + (x + j)].green * gY[((i + 1) * KERNEL_SIZE) + (j + 1)];

						sumXB += pIn[((y + i) * width) + (x + j)].blue * gX[((i + 1) * KERNEL_SIZE) + (j + 1)];
						sumYB += pIn[((y + i) * width) + (x + j)].blue * gY[((i + 1) * KERNEL_SIZE) + (j + 1)];
					}
				}
			}
			pixelValue = (UI08)CLIP(sqrt(sumXR * sumXR + sumYR * sumYR), BYTE_RESET, BYTE_FULLSET);
			(*pOut).red = pixelValue;
			pixelValue = (UI08)CLIP(sqrt(sumXG * sumXG + sumYG * sumYG), BYTE_RESET, BYTE_FULLSET);
			(*pOut).green = pixelValue;
			pixelValue = (UI08)CLIP(sqrt(sumXB * sumXB + sumYB * sumYB), BYTE_RESET, BYTE_FULLSET);
			(*pOut).blue = pixelValue;
			pOut++;
		}
	}
}

/** normalConvGray(UI32 width, UI32 height, void *pInRGB, void *pOutRGB)
* @brief Convolution for small image for gray image
* @param[in]	width		Width of output image
* @param[in]	height		Height of output image
* @param[in]	pInRGB		Input image pointer
* @param[out]	pOutRGB		Output image pointer
* @return		none
*/
PRIVATE void normalConvGray(UI32 width, UI32 height, void *pInRGB, void *pOutRGB)
{
	BrcBGR* pIn = (BrcBGR*)pInRGB;
	BrcBGR* pOut = (BrcBGR*)pOutRGB;

	UI32 x, y;
	UI08 gray;
	SI32 i, j, sumX, sumY;
	GX_GY;

	SI32 pixelValue;

	for (y = 0; y < height; y++){
		for (x = 0; x < width; x++){
			sumX = sumY = 0;
			for (i = -1; i < 2; i++)
			{
				for (j = -1; j < 2; j++)
				{

					if (((SI32)x + j >= 0) && ((SI32)y + i >= 0) && ((SI32)y + i < (SI32)height) && ((SI32)x + j < (SI32)width)){
						gray = (UI08)(CALC_RGB2GRAY(pIn[((y + i) * width) + (x + j)].red, pIn[((y + i) * width) + (x + j)].green, pIn[((y + i) * width) + (x + j)].blue) + 0.5f);
						sumX += gray * gX[((i + 1) * KERNEL_SIZE) + (j + 1)];
						sumY += gray * gY[((i + 1) * KERNEL_SIZE) + (j + 1)];
					}
				}
			}
			pixelValue = (UI08)CLIP(sqrt(sumX * sumX + sumY * sumY), BYTE_RESET, BYTE_FULLSET);
			(*pOut).red = pixelValue;
			(*pOut).green = pixelValue;
			(*pOut).blue = pixelValue;
			pOut++;
		}
	}
}
/** DetectEdge(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, UI32 method, UI32 borderType)
* @brief エッジ検出（TBD）
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInRGB		入力画像領域のポインタ
* @param[out]	pOutRGB		出力画像領域のポインタ
* @param[in]	method		method to detect edge (1,2,3)
* @param[in]	borderType	image border (0,1,2,3)
* @return		0:成功 0以外:失敗
*/
PUBLIC SI32 DetectEdge(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, UI32 method, UI32 borderType)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height)
		&& (pInRGB != brcNull) && (pOutRGB != brcNull)
		&& (borderType == 0 || borderType == 1 || borderType == 2 || borderType == 3) && (method == 1 || method == 2 || method == 3) ? SUCCESS : EINVAL);

	if (err == 0){

		BrcBGR *pInImage = (BrcBGR*)pInRGB;
		BrcBGR *pOutImage = (BrcBGR*)pOutRGB;
		// Pointer to buffer memory zone, temp storage to keep intermediate result
		UI32 sizeOutputImage = width * height * RGB_CHANNELS;
		//memset((void*)(pOutRGB), 0, sizeOutputImage);

		// Method = 1: Convolution only one channel with x & y sobel kernel
		if (method == 1){
			// Sobel kernel 3x3: kCenter = 1
			UI32	sizeBuff = width * sizeof(SI32) * NUMBER_OF_BUFF_ROW * NUMBER_OF_BUFF_TYPE;
			UI32	heightOver;
			if (sizeBuff % (width * RGB_CHANNELS)){
				heightOver = (sizeBuff / (width * RGB_CHANNELS)) + 1;
			}
			else {
				heightOver = sizeBuff / (width * RGB_CHANNELS);
			}
			// PROCESSING DATA

			if (heightOver > (height / 2)){
				normalConv(width, height, pInRGB, pOutRGB);
			}
			else {
				UI32	buffPos = sizeOutputImage - (width * heightOver * RGB_CHANNELS);
				SI32	*tmp = (SI32*)((UI08*)pOutRGB + buffPos);
				UI32 i = 0;
				// store 1D sobel x convolution of 1 column for one channel
				SI32 *tmpX = tmp;
				// store 1D sobel y convolution of 1 column for one channel
				SI32 *tmpY = tmpX + (3 * width);
				hFirstConv(pInImage, tmpX, tmpY, borderType, width);
				vConv(tmpX, tmpY, width, pOutImage);
				for (i = 1; i < (height - heightOver); i++){
					memcpy((void*)(tmpX), (void*)(tmpX + width), width * sizeof(SI32) * 2);
					memcpy((void*)(tmpY), (void*)(tmpY + width), width * sizeof(SI32) * 2);

					hConv(pInImage + ((i + 1) * width), tmpX, tmpY, borderType, width);
					vConv(tmpX, tmpY, width, pOutImage + (i * width));
				}
				memcpy((void*)(pInRGB), (void*)(tmp), width * heightOver * RGB_CHANNELS);
				tmp = (SI32*)pInRGB;
				tmpX = tmp;
				tmpY = tmpX + (3 * width);
				for (; i < height - 1; i++){
					memcpy((void*)(tmpX), (void*)(tmpX + width), width * sizeof(SI32) * 2);
					memcpy((void*)(tmpY), (void*)(tmpY + width), width * sizeof(SI32) * 2);

					hConv(pInImage + ((i + 1) * width), tmpX, tmpY, borderType, width);
					vConv(tmpX, tmpY, width, pOutImage + i * width);
				}
				memcpy((void*)(tmpX), (void*)(tmpX + width), width * sizeof(SI32) * 2);
				memcpy((void*)(tmpY), (void*)(tmpY + width), width * sizeof(SI32) * 2);

				if (borderType == 0){
					memset((void*)(tmpX + (width * 2)), 0, width * sizeof(SI32));
					memset((void*)(tmpY + (width * 2)), 0, width * sizeof(SI32));
				}
				else if (borderType == 1 || borderType == 2){
					memcpy((void*)(tmpX + (width * 2)), (void*)(tmpX + width), width * sizeof(SI32));
					memcpy((void*)(tmpY + (width * 2)), (void*)(tmpY + width), width * sizeof(SI32));
				}
				else {
					memcpy((void*)(tmpX + (width * 2)), (void*)(tmpX), width * sizeof(SI32));
					memcpy((void*)(tmpY + (width * 2)), (void*)(tmpY), width * sizeof(SI32));
				}
				vConv(tmpX, tmpY, width, pOutImage + i * width);
			}

		}
		// Method = 2: Convolution 3 channel r,g,b with x & y sobel kernel
		else if (method == 2){

			// Sobel kernel 3x3: kCenter = 1
			UI32	sizeBuff = width * sizeof(SI32) * NUMBER_OF_BUFF_TYPE * NUMBER_OF_BUFF_ROW * RGB_CHANNELS;
			UI32	heightOver;
			if (sizeBuff % (width * RGB_CHANNELS)){
				heightOver = (sizeBuff / (width * RGB_CHANNELS)) + 1;
			}
			else {
				heightOver = sizeBuff / (width * RGB_CHANNELS);
			}
			// PROCESSING DATA
			if (heightOver > (height / 2)){
				normalConvRGB(width, height, pInRGB, pOutRGB);
			}
			else {
				UI32	buffPos = sizeOutputImage - (width * heightOver * RGB_CHANNELS);
				SI32	*tmp = (SI32*)((UI08*)pOutRGB + buffPos);

				UI32 i = 0;
				// store 1D sobel x convolution of 1 column for one channel
				SI32 *tmpX = tmp;
				// store 1D sobel y convolution of 1 column for one channel
				SI32 *tmpY = tmpX + (3 * width * RGB_CHANNELS);

				hRGBFirstConv(pInImage, tmpX, tmpY, borderType, width);
				vRGBConv(tmpX, tmpY, width, pOutImage);
				for (i = 1; i < (height - heightOver); i++){
					memcpy((void*)(tmpX), (void*)(tmpX + width * RGB_CHANNELS), width * sizeof(SI32) * RGB_CHANNELS * 2);
					memcpy((void*)(tmpY), (void*)(tmpY + width * RGB_CHANNELS), width * sizeof(SI32) * RGB_CHANNELS * 2);

					hRGBConv(pInImage + ((i + 1) * width), tmpX, tmpY, borderType, width);
					vRGBConv(tmpX, tmpY, width, pOutImage + i * width);
				}

				memcpy((void*)(pInRGB), (void*)(tmp), width * heightOver * RGB_CHANNELS);
				tmp = (SI32*)pInRGB;
				tmpX = tmp;
				tmpY = tmpX + (3 * width * RGB_CHANNELS);
				for (; i < height - 1; i++){
					memcpy((void*)(tmpX), (void*)(tmpX + width * RGB_CHANNELS), width * sizeof(SI32) * RGB_CHANNELS * 2);
					memcpy((void*)(tmpY), (void*)(tmpY + width * RGB_CHANNELS), width * sizeof(SI32) * RGB_CHANNELS * 2);

					hRGBConv(pInImage + ((i + 1) * width), tmpX, tmpY, borderType, width);
					vRGBConv(tmpX, tmpY, width, pOutImage + i * width);
				}
				memcpy((void*)(tmpX), (void*)(tmpX + width * RGB_CHANNELS), width * sizeof(SI32) * RGB_CHANNELS * 2);
				memcpy((void*)(tmpY), (void*)(tmpY + width * RGB_CHANNELS), width * sizeof(SI32) * RGB_CHANNELS * 2);

				if (borderType == 0){
					memset((void*)(tmpX + (width * 2 * RGB_CHANNELS)), 0, width * sizeof(SI32) * RGB_CHANNELS);
					memset((void*)(tmpY + (width * 2 * RGB_CHANNELS)), 0, width * sizeof(SI32) * RGB_CHANNELS);
				}
				else if (borderType == 1 || borderType == 2){
					memcpy((void*)(tmpX + (width * 2 * RGB_CHANNELS)), (void*)(tmpX + width * RGB_CHANNELS), width * sizeof(SI32) * RGB_CHANNELS);
					memcpy((void*)(tmpY + (width * 2 * RGB_CHANNELS)), (void*)(tmpY + width * RGB_CHANNELS), width * sizeof(SI32) * RGB_CHANNELS);
				}
				else {
					memcpy((void*)(tmpX + (width * 2 * RGB_CHANNELS)), (void*)(tmpX), width * sizeof(SI32) * RGB_CHANNELS);
					memcpy((void*)(tmpY + (width * 2 * RGB_CHANNELS)), (void*)(tmpY), width * sizeof(SI32) * RGB_CHANNELS);
				}
				vRGBConv(tmpX, tmpY, width, pOutImage + i * width);
			}


		}
		// Method = 3: Convolution grayscale with x & y sobel kernel
		else{
			// Sobel kernel 3x3: kCenter = 1
			UI32	sizeBuff = (width * sizeof(SI32) * NUMBER_OF_BUFF_TYPE * NUMBER_OF_BUFF_ROW) + (width * RGB_CHANNELS);
			UI32	heightOver;
			if (sizeBuff % (width * RGB_CHANNELS)){
				heightOver = (sizeBuff / (width * RGB_CHANNELS)) + 1;
			}
			else {
				heightOver = sizeBuff / (width * RGB_CHANNELS);
			}
			// PROCESSING DATA
			if (heightOver > (height / 2)){
				normalConvGray(width, height, pInRGB, pOutRGB);
			}
			else {
				UI32	buffPos = sizeOutputImage - (width * heightOver * RGB_CHANNELS);
				SI32	*tmp = (SI32*)((UI08*)pOutRGB + buffPos);

				UI32 i = 0;
				// store 1D sobel x convolution of 1 column for one channel
				SI32 *tmpX = tmp;
				// store 1D sobel y convolution of 1 column for one channel
				SI32 *tmpY = tmpX + (3 * width);
				UI08 *gray = (UI08*)(UI32*)tmpY + (3 * width * sizeof(SI32));

				firstGrayConvert(pInImage, gray, width, borderType);
				hGrayFirstConv(gray, tmpX, tmpY, borderType, width);
				vConv(tmpX, tmpY, width, pOutImage);
				for (i = 1; i < (height - heightOver); i++){
					memcpy((void*)(tmpX), (void*)(tmpX + width), width * sizeof(SI32) * 2);
					memcpy((void*)(tmpY), (void*)(tmpY + width), width * sizeof(SI32) * 2);
					memcpy((void*)(gray), (void*)(gray + width), width * sizeof(UI08) * 2);

					grayConv(pInImage + ((i + 1) * width), gray, width);
					hGrayConv(gray, tmpX, tmpY, borderType, width);
					vConv(tmpX, tmpY, width, pOutImage + i * width);
				}
				memcpy((void*)(pInRGB), (void*)(tmp), width * heightOver * RGB_CHANNELS);
				tmp = (SI32*)pInRGB;
				tmpX = tmp;
				tmpY = tmpX + (3 * width);
				gray = (UI08*)(UI32*)tmpY + (3 * width * sizeof(SI32));

				for (; i < height - 1; i++){
					memcpy((void*)(tmpX), (void*)(tmpX + width), width * sizeof(SI32) * 2);
					memcpy((void*)(tmpY), (void*)(tmpY + width), width * sizeof(SI32) * 2);
					memcpy((void*)(gray), (void*)(gray + width), width * sizeof(UI08) * 2);

					grayConv(pInImage + ((i + 1) * width), gray, width);
					hGrayConv(gray, tmpX, tmpY, borderType, width);
					vConv(tmpX, tmpY, width, pOutImage + i * width);
				}
				memcpy((void*)(tmpX), (void*)(tmpX + width), width * sizeof(SI32) * 2);
				memcpy((void*)(tmpY), (void*)(tmpY + width), width * sizeof(SI32) * 2);

				if (borderType == 0){
					memset((void*)(tmpX + (width * 2)), 0, width * sizeof(SI32));
					memset((void*)(tmpY + (width * 2)), 0, width * sizeof(SI32));
				}
				else if (borderType == 1 || borderType == 2){
					memcpy((void*)(tmpX + (width * 2)), (void*)(tmpX + width), width * sizeof(SI32));
					memcpy((void*)(tmpY + (width * 2)), (void*)(tmpY + width), width * sizeof(SI32));
				}
				else {
					memcpy((void*)(tmpX + (width * 2)), (void*)(tmpX), width * sizeof(SI32));
					memcpy((void*)(tmpY + (width * 2)), (void*)(tmpY), width * sizeof(SI32));
				}
				vConv(tmpX, tmpY, width, pOutImage + i * width);
			}

		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** TrackOutline(UI32 width, UI32 height, void *pInRGB, void *pOutRGB)
* @brief 輪郭追跡（TBD）
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInRGB		入力画像領域のポインタ
* @param[out]	pOutRGB		出力画像領域のポインタ
* @return		0:成功 0以外:失敗
*/
PUBLIC SI32 BinaryTrackOutline(UI32 width, UI32 height, void *pInImage, void *pOutImage)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height)
		&& (pInImage != brcNull) && (pOutImage != brcNull) ? SUCCESS : EINVAL);

	if (err == 0){
		UI08* pIn = (UI08*)pInImage;
		UI08* pOut = (UI08*)pOutImage;

		//! 画素走査用
		SI32 x, y;

		//! 画素の状態(黒or白)
		UI08 state = WHITE;

		for (y = 0; y < (SI32)height; y++){
			for (x = 0; x < (SI32)width; x++){
				if (state == WHITE){
					if (*pIn == BYTE_RESET){ //輪郭線外のときに、入力が黒だったら
						state = BLACK;
						//状態を黒(輪郭線内)に更新
						if (*pOut != BYTE_RESET){ //出力が黒でなかったら
							//今の画素の出力を黒にして、輪郭追跡開始
							store(pOut, BYTE_RESET);
							trackBlack(pIn, pOut, width, height, x, y);
						}
						else{
						}
					}
					else{
						// 入力が黒でないので今の画素の出力を白にする
						store(pOut, BYTE_FULLSET);
					}
				}
				else{
					if (*pOut != BYTE_RESET){ //画素の状態が黒のときに出力が黒でない→白画素に切り替わったor輪郭線内
						if (*pIn != BYTE_RESET){
							//入力画素が白→白画素に切り替わったので、状態を白(輪郭線外)に更新
							state = WHITE;
						}
						//白画素に切り替わったor輪郭線内なので今の画素の出力を白にする
						store(pOut, BYTE_FULLSET);
					}
				}
				//次の画素を指す
				pIn++;
				pOut++;
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** Store(UI08* pOut, UI08 pixelValue)
* @brief 画素値を出力画像領域に格納する
* @param[out]	pOut		出力画像領域のポインタ
* @param[in]	pixelValue	画素値
* @return		なし
*/
PRIVATE void store(UI08* pOut, UI08 pixelValue)
{
	//UI08 i;
	*pOut = pixelValue;
	//チャンネル数分、同じ値で書き込む
	/*for (i = 0; i < RGB_CHANNELS; i++){
	*(pOut + i) = pixelValue;
	}*/
}

/** TrackBlack(UI08 *pIn,UI08 *pOut,UI32 x,UI32 y,UI32 width)
* @brief 輪郭(黒画素)追跡をする。
* @param[in]	pIn			入力画像領域のポインタ
* @param[out]	pOut		出力画像領域のポインタ
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	x			画素のx座標
* @param[in]	y			画素のy座標
* @return		なし
*/
PRIVATE void trackBlack(UI08 *pIn, UI08 *pOut, UI32 width, UI32 height, SI32 x, SI32 y)
{
	//! 輪郭でない近傍画素の数(最大8)
	UI08 whitePixel = BYTE_RESET;

	//注目している入出力画素
	UI08 *pTmpIn;
	pTmpIn = pIn;
	UI08 *pTmpOut;
	pTmpOut = pOut;

	//! 注目画素から八近傍の計算結果格納用
	SI32 tmpDifference[8];

	//! 画素アクセスエラー判定用
	UI08 pixelAccessError;

	//! 注目画素と追跡画素の差(初期：左上画素との差)
	SI32 accessIncrement;

	//! 八近傍チェックの方向(初期方向：左上)
	UI08 preciousVector = TOP_LEFT;
	UI08 afterVector = TOP_LEFT;

	//注目画素から八近傍の差を計算して、次の追跡方向との差を格納する
	calculateSurroundingDifference(tmpDifference, width);
	accessIncrement = tmpDifference[preciousVector];

	//追跡方向(初期方向：左上)に応じてx,yの値を更新しておく
	nextXy(&x, &y, preciousVector, afterVector);

	//8近傍のいずれかに黒画素がある限り
	while ((whitePixel < 8)){
		//次調べる画素にアクセスしてもエラーが起こらないか確認する
		pixelAccessError = pixelAccessCheck(x, y, width, height);

		whitePixel++;

		switch (preciousVector)
		{
		case BOTTOM_LEFT:
			// Edited by EMT-VN 2016.10.18
			// Previous version: if (0 == pixelAccessError){
			if (0 == pixelAccessError){
				if (0 == *(pTmpIn + accessIncrement)){
					//追跡点の画素を黒く塗りつぶし、次の注目画素として移動する
					fillBlack(&pTmpIn, &pTmpOut, accessIncrement);

					//次に見る方向を更新
					preciousVector = BOTTOM_RIGHT;
					afterVector = preciousVector;

					//黒画素発見したので近傍の白画素の数をリセット
					whitePixel = BYTE_RESET;
				}
				else{
					//次に見る方向を更新
					afterVector = LEFT;
				}
			}
			else{
				//次に見る方向を更新
				afterVector = LEFT;
			}
			break;
		case BOTTOM:
			// Edited by EMT-VN 2016.10.18
			// Previous version: if (0 == pixelAccessError){
			if (0 == pixelAccessError){
				if (0 == *(pTmpIn + accessIncrement)){
					fillBlack(&pTmpIn, &pTmpOut, accessIncrement);
					preciousVector = BOTTOM_RIGHT;
					afterVector = preciousVector;
					whitePixel = BYTE_RESET;
				}
				else{
					afterVector = BOTTOM_LEFT;
				}
			}
			else{
				afterVector = BOTTOM_LEFT;
			}
			break;
		case BOTTOM_RIGHT:
			// Edited by EMT-VN 2016.10.18
			// Previous version: if (0 == pixelAccessError){
			if (0 == pixelAccessError){
				if (0 == *(pTmpIn + accessIncrement)){
					fillBlack(&pTmpIn, &pTmpOut, accessIncrement);
					preciousVector = TOP_RIGHT;
					afterVector = preciousVector;
					whitePixel = BYTE_RESET;
				}
				else{
					afterVector = BOTTOM;
				}
			}
			else{
				afterVector = BOTTOM;
			}
			break;
		case RIGHT:
			// Edited by EMT-VN 2016.10.18
			// Previous version: if (0 == pixelAccessError){
			if (0 == pixelAccessError){
				if (0 == *(pTmpIn + accessIncrement)){
					fillBlack(&pTmpIn, &pTmpOut, accessIncrement);
					preciousVector = TOP_RIGHT;
					afterVector = preciousVector;
					whitePixel = BYTE_RESET;
				}
				else{
					afterVector = BOTTOM_RIGHT;
				}
			}
			else{
				afterVector = BOTTOM_RIGHT;
			}
			break;
		case TOP_RIGHT:
			// Edited by EMT-VN 2016.10.18
			// Previous version: if (0 == pixelAccessError){
			if ((0 == pixelAccessError)){
				if (0 == *(pTmpIn + accessIncrement)){
					fillBlack(&pTmpIn, &pTmpOut, accessIncrement);
					preciousVector = TOP_LEFT;
					afterVector = preciousVector;
					whitePixel = BYTE_RESET;
				}
				else{
					afterVector = RIGHT;
				}
			}
			else{
				afterVector = RIGHT;
			}
			break;
		case TOP:
			// Edited by EMT-VN 2016.10.18
			// Previous version: if (0 == pixelAccessError){
			if ((0 == pixelAccessError)){
				if (0 == *(pTmpIn + accessIncrement)){
					fillBlack(&pTmpIn, &pTmpOut, accessIncrement);
					preciousVector = TOP_LEFT;
					afterVector = preciousVector;
					whitePixel = BYTE_RESET;
				}
				else{
					afterVector = TOP_RIGHT;
				}
			}
			else{
				afterVector = TOP_RIGHT;
			}
			break;
		case TOP_LEFT:
			// Edited by EMT-VN 2016.10.18
			// Previous version: if (0 == pixelAccessError){
			if ((0 == pixelAccessError)){
				if (0 == *(pTmpIn + accessIncrement)){
					fillBlack(&pTmpIn, &pTmpOut, accessIncrement);
					preciousVector = BOTTOM_LEFT;
					afterVector = preciousVector;
					whitePixel = BYTE_RESET;
				}
				else{
					afterVector = TOP;
				}
			}
			else{
				afterVector = TOP;
			}
			break;
		case LEFT:
			// Edited by EMT-VN 2016.10.18
			// Previous version: if (0 == pixelAccessError){
			if (0 == pixelAccessError){
				if (0 == *(pTmpIn + accessIncrement)){
					fillBlack(&pTmpIn, &pTmpOut, accessIncrement);
					preciousVector = BOTTOM_LEFT;
					afterVector = preciousVector;
					whitePixel = BYTE_RESET;
				}
				else{
					afterVector = TOP_LEFT;
				}
			}
			else{
				afterVector = TOP_LEFT;
			}
			break;
		default:
			break;
		}

		//次の追跡方向に応じてx、yの値を更新
		nextXy(&x, &y, preciousVector, afterVector);

		//追跡方向を更新
		preciousVector = afterVector;

		//注目画素と次の追跡画素の差を出す
		accessIncrement = tmpDifference[preciousVector];

		//注目画素と次見る画素が一致したらループから抜けるようにする
		if ((pTmpIn + accessIncrement) == pIn){
			whitePixel = 8;
		}
	}
}

/** PixelAccessCheck(UI08 x, UI08 y, UI32 width, UI32 height)
* @brief 画像外をアクセスしようとしていないかチェックする
* @param[in]	x			画素のx座標
* @param[in]	y			画素のy座標
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @return		err　0：画像外アクセスなし(成功)、それ以外：画像外アクセス失敗
*/
PRIVATE SI32 pixelAccessCheck(SI32 x, SI32 y, UI32 width, UI32 height)
{
	UI08 err = 0;
	//画像外をアクセスしていたらエラーとする
	// Edited by EMT-VN 2016.10.18
	// Previous version: if (x > (SI32)width || y > (SI32)height || x < 0 || y < 0) {
	if (x >= (SI32)width || y >= (SI32)height || x < 0 || y < 0) {
		err = EINVAL;
	}

	return err;
}

/** calculateAccessIncrement(SI32* accessIncrement, UI32 width, UI08 vector){
* @brief 注目画素から八近傍の差を計算する
* @param[out]	tmp			注目画素から八近傍の計算結果格納用
* @param[in]	width		画像幅
* @return		なし
*/
PRIVATE void calculateSurroundingDifference(SI32* tmp, UI32 width){
	UI08 i;
	for (i = 0; i < 8; i++){
		//注目画素からの八近傍の差を計算し格納する
		switch (i)
		{
		case(BOTTOM_LEFT) :
			tmp[i] = -1 * ((width + 1));
			break;
		case(BOTTOM) :
			tmp[i] = -1 * (width);
			break;
		case(BOTTOM_RIGHT) :
			tmp[i] = -1 * ((width - 1));
			break;
		case(RIGHT) :
			tmp[i] = 1;
			break;
		case(TOP_RIGHT) :
			tmp[i] = ((width + 1));
			break;
		case(TOP) :
			tmp[i] = width;
			break;
		case(TOP_LEFT) :
			tmp[i] = ((width - 1));
			break;
		case(LEFT) :
			tmp[i] = -1;
			break;
		default:
			break;
		}
	}
}

/** nextXY(SI32* x, SI32* y, UI08 vector){
* @brief 黒発見時、次に見る方向に応じてx、yの値も更新する
* @param[out]	x			画素のx座標
* @param[out]	y			画素のy座標
* @param[in]	vector		今の追跡方向
* @param[in]	vector		次の追跡方向
* @return		なし
*/
PRIVATE void nextXy(SI32* x, SI32* y, UI08 preciousVector, UI08 afterVector){
	//注目画画素と八近傍の座標の差を参照する
	if ((g_xDifference[preciousVector] == g_xDifference[afterVector]) && (g_yDifference[preciousVector] == g_yDifference[afterVector])){
		*x += g_xDifference[afterVector];
		*y += g_yDifference[afterVector];
	}
	else{
		*x += g_xDifference[afterVector] - g_xDifference[preciousVector];
		*y += g_yDifference[afterVector] - g_yDifference[preciousVector];
	}
}

/** FillBlack(UI08 **pTmpIn, UI08 **pTmpOut, SI32 accessIncrement){
* @brief 黒発見地点の出力画素を黒く塗りつぶし、そこを次の注目画素とする
* @param[out]	pTmpIn			注目している入力画素のポインタ
* @param[out]	pTmpOut			注目している出力画素のポインタ
* @param[in]	accessIncrement	注目画素と次の追跡画素の差
* @return		なし
*/
PRIVATE void fillBlack(UI08 **pTmpIn, UI08 **pTmpOut, SI32 accessIncrement){
	//黒く塗りつぶす
	store((*pTmpOut + accessIncrement), BYTE_RESET);
	//今黒があった地点を次の注目画素とする
	*pTmpIn += accessIncrement;
	*pTmpOut += accessIncrement;
}
