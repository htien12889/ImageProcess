﻿/**
 * @file 	BrcImageConvertYUV2YUV.c
 * @brief 	YUV変換シースファイル
 * @author 	kyoshitake
 * @date 	2016/06/22
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#include "BrcType.h"
#include "BrcImageProcessingCommon.h"
//#include "BrcMemoryUsage.h"

/** ConvertYUV444_YUV422(UI32 width, UI32 height, void *pInYUV, void *pOutYUV)
* @brief YUV444->YUV422変換
* @param[in]	width	画像幅
* @param[in]	height	画像高さ
* @param[in]	pInYUV	入力画像領域のポインタ
* @param[out]	pOutYUV	出力画像領域のポインタ
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertYUV444_YUV422(UI32 width, UI32 height, void *pInYUV, void *pOutYUV)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInYUV != brcNull) && (pOutYUV != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInYUV;
		UI08	*pOutByte = (UI08*)pOutYUV;
		UI32	row;
		UI32	column;
		for (row = 0; row < height; row++){
			for (column = 0; column < width; column++, pInByte += PIXEL_BYTE_YUV444, pOutByte += PIXEL_BYTE_YUV422){
				*(pOutByte + YUV422_OFFSET_UYVY_Y) = (*(pInByte + YUV444_OFFSET_Y));
				if (column % 2){	// 奇数桁？
					*(pOutByte + YUV422_OFFSET_UYVY_V) = (*(pInByte + YUV444_OFFSET_V));
				}
				else{			// 偶数桁
					*(pOutByte + YUV422_OFFSET_UYVY_U) = (*(pInByte + YUV444_OFFSET_U));
				}
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertYUV444_YUV422sp(UI32 width, UI32 height, void *pInYUV, void *pOutY, void *pOutUV)
* @brief YUV444->YUV422sp変換
* @param[in]	width	画像幅
* @param[in]	height	画像高さ
* @param[in]	pInYUV	入力画像領域のポインタ
* @param[out]	pOutY	出力Y画像領域のポインタ
* @param[out]	pOutUV	出力UV画像領域のポインタ
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertYUV444_YUV422sp(UI32 width, UI32 height, void *pInYUV, void *pOutY, void *pOutUV)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInYUV != brcNull) && (pOutY != brcNull) && (pOutUV != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInYUV;
		UI08	*pOutByteY = (UI08*)pOutY;
		UI08	*pOutByteUV = (UI08*)pOutUV;
		UI32	row;
		UI32	column;
		for (row = 0; row < height; row++){
			for (column = 0; column < width; column++, pInByte += PIXEL_BYTE_YUV444, pOutByteY++){
				*pOutByteY = (*(pInByte + YUV444_OFFSET_Y));
				if (column % 2){	// 奇数桁か？
					*(pOutByteUV + YUV422SP_OFFSET_UV_U) = (*(pInByte + YUV444_OFFSET_U));
					*(pOutByteUV + YUV422SP_OFFSET_UV_V) = (*(pInByte + YUV444_OFFSET_V));
					pOutByteUV += PIXEL_BYTE_YUV422;
				}
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertYUV444_YUV420sp(UI32 width, UI32 height, void *pInYUV, void *pOutY, void *pOutUV)
* @brief YUV444->YUV420sp変換
* @param[in]	width	画像幅
* @param[in]	height	画像高さ
* @param[in]	pInYUV	入力画像領域のポインタ
* @param[out]	pOutY	出力Y画像領域のポインタ
* @param[out]	pOutUV	出力UV画像領域のポインタ
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertYUV444_YUV420sp(UI32 width, UI32 height, void *pInYUV, void *pOutY, void *pOutUV)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInYUV != brcNull) && (pOutY != brcNull) && (pOutUV != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInYUV;
		UI08	*pOutByteY = (UI08*)pOutY;
		UI08	*pOutByteUV = (UI08*)pOutUV;
		UI32	row;
		UI32	column;
		for (row = 0; row < height; row++){
			for (column = 0; column < width; column++, pInByte += PIXEL_BYTE_YUV444, pOutByteY++){
				*pOutByteY = (*(pInByte + YUV444_OFFSET_Y));
				if ((row % 2) && (column % 2)){	// 奇数行＆奇数桁か？
					*(pOutByteUV + YUV420SP_OFFSET_UV_U) = (*(pInByte + YUV444_OFFSET_U));
					*(pOutByteUV + YUV420SP_OFFSET_UV_V) = (*(pInByte + YUV444_OFFSET_V));
					pOutByteUV += PIXEL_BYTE_YUV420SP_UV;
				}
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertYUV422_YUV444(UI32 width, UI32 height, void *pInYUV, void *pOutYUV)
* @brief YUV422->YUV444変換
* @param[in]	width	画像幅
* @param[in]	height	画像高さ
* @param[in]	pInYUV	入力画像領域のポインタ
* @param[out]	pOutYUV	出力画像領域のポインタ
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertYUV422_YUV444(UI32 width, UI32 height, void *pInYUV, void *pOutYUV)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInYUV != brcNull) && (pOutYUV != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInYUV;
		UI08	*pOutByte = (UI08*)pOutYUV;
		UI32	row;
		UI32	column;
		for (row = 0; row < height; row++){
			for (column = 0; column < width; column++, pInByte += PIXEL_BYTE_YUV422, pOutByte += PIXEL_BYTE_YUV444){
				*(pOutByte + YUV444_OFFSET_Y) = (*(pInByte + YUV422_OFFSET_UYVY_Y));
				if (column % 2){	// 奇数桁？
					*(pOutByte + YUV444_OFFSET_U) = (*(pInByte - PIXEL_BYTE_YUV422));
					*(pOutByte + YUV444_OFFSET_V) = (*(pInByte + YUV422_OFFSET_UYVY_V));
				}
				else{			// 偶数桁
					*(pOutByte + YUV444_OFFSET_U) = (*(pInByte + YUV422_OFFSET_UYVY_U));
					*(pOutByte + YUV444_OFFSET_V) = (*(pInByte + PIXEL_BYTE_YUV422));
				}
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertYUV422_YUV422sp(UI32 width, UI32 height, void *pInYUV, void *pOutY, void *pOutUV)
* @brief YUV422->YUV422sp変換
* @param[in]	width	画像幅
* @param[in]	height	画像高さ
* @param[in]	pInYUV	入力画像領域のポインタ
* @param[in]	pOutY	出力Y画像領域のポインタ
* @param[out]	pOutUV	出力UV画像領域のポインタ
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertYUV422_YUV422sp(UI32 width, UI32 height, void *pInYUV, void *pOutY, void *pOutUV)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInYUV != brcNull) && (pOutY != brcNull) && (pOutUV != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInYUV;
		UI08	*pOutByteY = (UI08*)pOutY;
		UI08	*pOutByteUV = (UI08*)pOutUV;
		UI32	row;
		UI32	column;
		for (row = 0; row < height; row++){
			for (column = 0; column < width; column++, pInByte += PIXEL_BYTE_YUV422, pOutByteY++){
				*pOutByteY = (*(pInByte + YUV422_OFFSET_UYVY_Y));
				if (column % 2){	// 奇数行？
					*(pOutByteUV + YUV422SP_OFFSET_UV_U) = (*(pInByte - PIXEL_BYTE_YUV422));
					*(pOutByteUV + YUV422SP_OFFSET_UV_V) = (*(pInByte + YUV422_OFFSET_UYVY_V));
					pOutByteUV += PIXEL_BYTE_YUV422SP_UV;
				}
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertYUV422_YUV420sp(UI32 width, UI32 height, void *pInYUV, void *pOutY, void *pOutUV)
* @brief YUV422->YUV420sp変換
* @param[in]	width	画像幅
* @param[in]	height	画像高さ
* @param[in]	pInYUV	入力画像領域のポインタ
* @param[out]	pOutY	出力Y画像領域のポインタ
* @param[out]	pOutUV	出力UV画像領域のポインタ
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertYUV422_YUV420sp(UI32 width, UI32 height, void *pInYUV, void *pOutY, void *pOutUV)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInYUV != brcNull) && (pOutY != brcNull) && (pOutUV != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInYUV;
		UI08	*pOutByteY = (UI08*)pOutY;
		UI08	*pOutByteUV = (UI08*)pOutUV;
		UI32	row;
		UI32	column;
		for (row = 0; row < height; row++){
			for (column = 0; column < width; column++, pInByte += PIXEL_BYTE_YUV422, pOutByteY++){
				*pOutByteY = (*(pInByte + YUV422_OFFSET_UYVY_Y));
				if ((row % 2) && (column % 2)){	// 奇数行＆奇数桁か？
					*(pOutByteUV + YUV420SP_OFFSET_UV_U) = (*(pInByte - PIXEL_BYTE_YUV422));
					*(pOutByteUV + YUV420SP_OFFSET_UV_V) = (*(pInByte + YUV422_OFFSET_UYVY_V));
					pOutByteUV += PIXEL_BYTE_YUV420SP_UV;
				}
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertYUV422sp_YUV444(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutYUV)
* @brief YUV422sp->YUV444変換
* @param[in]	width	画像幅
* @param[in]	height	画像高さ
* @param[in]	pInY	入力Y画像領域のポインタ
* @param[in]	pInUV	入力UV画像領域のポインタ
* @param[out]	pOutYUV	出力画像領域のポインタ
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertYUV422sp_YUV444(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutYUV)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInY != brcNull) && (pInUV != brcNull) && (pOutYUV != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByteY = (UI08*)pInY;
		UI08	*pInByteUV = (UI08*)pInUV;
		UI08	*pOutByte = (UI08*)pOutYUV;
		UI32	row;
		UI32	column;
		for (row = 0; row < height; row++){
			for (column = 0; column < width; column++, pInByteY++, pOutByte += PIXEL_BYTE_YUV444){
				*(pOutByte + YUV444_OFFSET_Y) = (*pInByteY);
				*(pOutByte + YUV444_OFFSET_U) = (*(pInByteUV + YUV422SP_OFFSET_UV_U));
				*(pOutByte + YUV444_OFFSET_V) = (*(pInByteUV + YUV422SP_OFFSET_UV_V));
				if (column % 2){	// 奇数桁？
					pInByteUV += PIXEL_BYTE_YUV422SP_UV;
				}
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertYUV422sp_YUV422(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutYUV)
* @brief YUV422sp->YUV420sp変換
* @param[in]	width	画像幅
* @param[in]	height	画像高さ
* @param[in]	pInY	入力Y画像領域のポインタ
* @param[in]	pInUV	入力UV画像領域のポインタ
* @param[out]	pOutYUV	出力画像領域のポインタ
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertYUV422sp_YUV422(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutYUV)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInY != brcNull) && (pInUV != brcNull) && (pOutYUV != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByteY = (UI08*)pInY;
		UI08	*pInByteUV = (UI08*)pInUV;
		UI08	*pOutByte = (UI08*)pOutYUV;
		UI32	row;
		UI32	column;
		for (row = 0; row < height; row++){
			for (column = 0; column < width; column++, pInByteY++, pOutByte += PIXEL_BYTE_YUV422){
				*(pOutByte + YUV422_OFFSET_UYVY_Y) = (*pInByteY);
				if (column % 2){	// 奇数桁か？
					*(pOutByte + YUV422_OFFSET_UYVY_V) = (*(pInByteUV + YUV422SP_OFFSET_UV_V));
					pInByteUV += PIXEL_BYTE_YUV422SP_UV;
				}
				else{			// 偶数桁
					*(pOutByte + YUV422_OFFSET_UYVY_U) = (*(pInByteUV + YUV422SP_OFFSET_UV_U));
				}
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertYUV422sp_YUV420sp(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutY, void *pOutUV)
* @brief YUV422sp->YUV420sp変換
* @param[in]	width	画像幅
* @param[in]	height	画像高さ
* @param[in]	pInY	入力Y画像領域のポインタ
* @param[in]	pInUV	入力UV画像領域のポインタ
* @param[out]	pOutY	出力Y画像領域のポインタ
* @param[out]	pOutUV	出力UV画像領域のポインタ
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertYUV422sp_YUV420sp(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutY, void *pOutUV)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height)
		&& (pInY != brcNull) && (pInUV != brcNull) && (pOutY != brcNull) && (pOutUV != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByteY = (UI08*)pInY;
		UI08	*pInByteUV = (UI08*)pInUV;
		UI08	*pOutByteY = (UI08*)pOutY;
		UI08	*pOutByteUV = (UI08*)pOutUV;
		UI32	row;
		UI32	column;
		for (row = 0; row < height; row++){
			for (column = 0; column < width; column++, pInByteY++, pOutByteY++){
				*pOutByteY = (*pInByteY);
				if (column % 2){	// 奇数桁か？
					if (row % 2){	// 奇数行か？
						*(pOutByteUV + YUV420SP_OFFSET_UV_U) = (*(pInByteUV + YUV422SP_OFFSET_UV_U));
						*(pOutByteUV + YUV420SP_OFFSET_UV_V) = (*(pInByteUV + YUV422SP_OFFSET_UV_V));
						pOutByteUV += PIXEL_BYTE_YUV420SP_UV;
					}
					pInByteUV += PIXEL_BYTE_YUV422SP_UV;
				}
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertYUV420sp_YUV444(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutYUV)
* @brief YUV420sp->YUV444変換
* @param[in]	width	画像幅
* @param[in]	height	画像高さ
* @param[in]	pInY	入力Y画像領域のポインタ
* @param[in]	pInUV	入力UV画像領域のポインタ
* @param[out]	pOutYUV	出力画像領域のポインタ
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertYUV420sp_YUV444(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutYUV)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInY != brcNull) && (pInUV != brcNull) && (pOutYUV != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByteY = (UI08*)pInY;
		UI08	*pInByteUV = (UI08*)pInUV;
		UI08	*pOutByte = (UI08*)pOutYUV;
		UI32	row;
		UI32	column;
		UI32	offSetYUV;
		for (row = 0; row < height; row++){
			offSetYUV = 0;
			for (column = 0; column < width; column++, pInByteY++, pOutByte += PIXEL_BYTE_YUV444){
				*(pOutByte + YUV444_OFFSET_Y) = (*pInByteY);
				*(pOutByte + YUV444_OFFSET_U) = (*(pInByteUV + YUV420SP_OFFSET_UV_U));
				*(pOutByte + YUV444_OFFSET_V) = (*(pInByteUV + YUV420SP_OFFSET_UV_V));
				// Old version
				//if ((row % 2) && (column % 2)){	// 奇数行＆奇数桁か？
				//	pInByteUV += PIXEL_BYTE_YUV420SP_UV;
				//}

				// New version
				if (column % 2){
					pInByteUV += PIXEL_BYTE_YUV420SP_UV;
					offSetYUV += PIXEL_BYTE_YUV420SP_UV;
				}
			}
			// New version
			if ((row % 2) == 0){
				pInByteUV -= offSetYUV;
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertYUV420sp_YUV422(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutYUV)
* @brief YUV420sp->YUV422変換
* @param[in]	width	画像幅
* @param[in]	height	画像高さ
* @param[in]	pInY	入力Y画像領域のポインタ
* @param[in]	pInUV	入力UV画像領域のポインタ
* @param[out]	pOutYUV	出力画像領域のポインタ
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertYUV420sp_YUV422(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutYUV)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInY != brcNull) && (pInUV != brcNull) && (pOutYUV != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByteY = (UI08*)pInY;
		UI08	*pInByteUV = (UI08*)pInUV;
		UI08	*pOutByte = (UI08*)pOutYUV;
		UI32	row;
		UI32	column;
		UI32	offSetYUV;
		for (row = 0; row < height; row++){
			offSetYUV = 0;
			for (column = 0; column < width; column++, pInByteY++, pOutByte += PIXEL_BYTE_YUV422){
				*(pOutByte + YUV422_OFFSET_UYVY_Y) = (*pInByteY);
				if (column % 2){	// 奇数桁か？
					*(pOutByte + YUV422_OFFSET_UYVY_V) = (*(pInByteUV + YUV420SP_OFFSET_UV_U));
					// Old version
					//if (row % 2){	// 奇数行か？
					//	pInByteUV += PIXEL_BYTE_YUV420SP_UV;
					//}

					// New version
					pInByteUV += PIXEL_BYTE_YUV420SP_UV;
					offSetYUV += PIXEL_BYTE_YUV420SP_UV;
				}
				else{			// 偶数桁
					*(pOutByte + YUV422_OFFSET_UYVY_U) = (*(pInByteUV + YUV420SP_OFFSET_UV_V));
				}
			}
			// New version
			if ((row % 2) == 0){
				pInByteUV -= offSetYUV;
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertYUV420sp_YUV422sp(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutY, void *pOutUV)
* @brief YUV420sp->YUV422sp変換
* @param[in]	width	画像幅
* @param[in]	height	画像高さ
* @param[in]	pInY	入力Y画像領域のポインタ
* @param[in]	pInUV	入力UV画像領域のポインタ
* @param[out]	pOutY	出力Y画像領域のポインタ
* @param[out]	pOutUV	出力UV画像領域のポインタ
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertYUV420sp_YUV422sp(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutY, void *pOutUV)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height)
		&& (pInY != brcNull) && (pInUV != brcNull) && (pOutY != brcNull) && (pOutUV != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByteY = (UI08*)pInY;
		UI08	*pInByteUV = (UI08*)pInUV;
		UI08	*pOutByteY = (UI08*)pOutY;
		UI08	*pOutByteUV = (UI08*)pOutUV;
		UI32	row;
		UI32	column;
		UI32	offSetYUV;
		for (row = 0; row < height; row++){
			offSetYUV = 0;
			for (column = 0; column < width; column++, pInByteY++, pOutByteY++){
				*pOutByteY = (*pInByteY);
				if (column % 2){	// 奇数桁か？
					*(pOutByteUV + YUV422SP_OFFSET_UV_U) = (*(pInByteUV + YUV420SP_OFFSET_UV_U));
					*(pOutByteUV + YUV422SP_OFFSET_UV_V) = (*(pInByteUV + YUV420SP_OFFSET_UV_V));
					// Old version:
					//if (row % 2){	// 奇数行か？
					//	pInByteUV += PIXEL_BYTE_YUV420SP_UV;
					//}

					// New version
					pInByteUV += PIXEL_BYTE_YUV420SP_UV;
					pOutByteUV += PIXEL_BYTE_YUV422SP_UV;
					offSetYUV += PIXEL_BYTE_YUV422SP_UV;
				}
			}
			// New version
			if ((row % 2) == 0){
				pInByteUV -= offSetYUV;
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}
