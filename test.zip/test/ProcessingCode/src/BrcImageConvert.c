/**
 * @file 	BrcImageConvert.c
 * @brief 	画像変換ソースファイル
 * @author 	EMT-BrycenVN
 * @date 	2016/06/22
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#include "BrcType.h"
#include "BrcImageProcessingCommon.h"
#include "BrcImageConvertRGB2YUV.h"
#include "BrcImageConvertYUV2RGB.h"
#include "errno.h"

/** ConvertRGB2YUV(UI32 width, UI32 height, void *pInRGB, FormatRGB rgbFormat, void *pOutYUV, FormatYUV yuvFormat)
 * @brief RGB->YUV変換
 * @param[in]	width		画像幅
 * @param[in]	height		画像高さ
 * @param[in]	pInRGB		入力画像領域のポインタ
 * @param[in]	rgbFormat	RGBフォーマットID
 * @param[out]	pOutYUV		出力画像領域のポインタ
 * @param[in]	yuvFormat	YUVフォーマットID
 * @return 		0:成功 0以外:失敗
 */
PUBLIC SI32 ConvertRGB2YUV(UI32 width, UI32 height, void *pInRGB, FormatRGB rgbFormat, void *pOutYUV, FormatYUV yuvFormat)
{
	SI32	err = ((0 < width) && (0 < height)
		&& (pInRGB != brcNull) && (pOutYUV != brcNull) ? SUCCESS : EINVAL);
	if(err == 0){
		///< TBD
	}
	return err;
}

/** ConvertYUV2RGB(UI32 width, UI32 height, void *pInYUV, FormatYUV yuvFormat, void *pOutRGB, FormatRGB rgbFormat)
 * @brief YUV->RGB変換
 * @param[in]	width		画像幅
 * @param[in]	height		画像高さ
 * @param[in]	pInYUV		入力画像領域のポインタ
 * @param[in]	yuvFormat	RGBフォーマットID
 * @param[out]	pOutRGB		出力画像領域のポインタ
 * @param[in]	rgbFormat	YUVフォーマットID
 * @return 		0:成功 0以外:失敗
 */
PUBLIC SI32 ConvertYUV2RGB(UI32 width, UI32 height, void *pInYUV, FormatYUV yuvFormat, void *pOutRGB, FormatRGB rgbFormat)
{
	SI32	err = ((0 < width) && (0 < height)
		&& (pInYUV != brcNull) && (pOutRGB != brcNull) ? SUCCESS : EINVAL);
	if(err == 0){
		///< TBD
	}
	return err;
}
