﻿/**
 * @file 	BrcImageConvertYUV2RGB.c
 * @brief 	画像変換シースファイル
 * @author 	kyoshitake
 * @date 	2016/06/22
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#include "BrcType.h"
#include "BrcImageProcessingCommon.h"
#include "BrcImageProcessingRGB.h"
#include "BrcImageProcessingYUV.h"
//#include "BrcMemoryUsage.h"

#define TRUE	1
#define FALSE	0
#define BITSHIFT_VALUE_2 	2
#define BITSHIFT_VALUE_3 	3
#define BITSHIFT_VALUE_5 	5
#define BITSHIFT_VALUE_8 	8
#define BITSHIFT_VALUE_11 	11

/** ConvertYUV444_RGB(UI32 width, UI32 height, void *pInYUV, void *pOutRGB, brcBool rgbReversal)
* @brief YUV444->RGB変換
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInYUV		入力画像領域のポインタ
* @param[out]	pOutRGB		出力画像領域のポインタ
* @param[in]	rgbReversal	RGB反転 true:BGR false:RGB
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertYUV444_RGB(UI32 width, UI32 height, void *pInYUV, void *pOutRGB, brcBool rgbReversal)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInYUV != brcNull) && (pOutRGB != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInYUV;
		UI08	*pOutByte = (UI08*)pOutRGB;
		UI32	offsetR = (rgbReversal ? BGR_OFFSET_R : RGB_OFFSET_R);
		UI32	offsetG = (rgbReversal ? BGR_OFFSET_G : RGB_OFFSET_G);
		UI32	offsetB = (rgbReversal ? BGR_OFFSET_B : RGB_OFFSET_B);
		UI32	row;
		UI32	column;
		UI08	y, u, v;
		for (row = 0; row < height; row++){
			for (column = 0; column < width; column++, pInByte += PIXEL_BYTE_YUV444, pOutByte += PIXEL_BYTE_RGB){
				y = (*(pInByte + YUV444_OFFSET_Y));
				u = (*(pInByte + YUV444_OFFSET_U));
				v = (*(pInByte + YUV444_OFFSET_V));
				*(pOutByte + offsetR) = (UI08)CLIP(CALC_YUV2RGB_R(y, u, v));
				*(pOutByte + offsetG) = (UI08)CLIP(CALC_YUV2RGB_G(y, u, v));
				*(pOutByte + offsetB) = (UI08)CLIP(CALC_YUV2RGB_B(y, u, v));
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertYUV444_RGBA(UI32 width, UI32 height, void *pInYUV, void *pOutRGB, brcBool rgbReversal)
* @brief YUV444->RGBA変換
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInYUV		入力画像領域のポインタ
* @param[out]	pOutRGB		出力画像領域のポインタ
* @param[in]	rgbReversal	RGB反転 true:BGR false:RGB
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertYUV444_RGBA(UI32 width, UI32 height, void *pInYUV, void *pOutRGB, brcBool rgbReversal)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInYUV != brcNull) && (pOutRGB != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInYUV;
		UI08	*pOutByte = (UI08*)pOutRGB;
		UI32	offsetR = (rgbReversal ? ABGR_OFFSET_R : RGBA_OFFSET_R);
		UI32	offsetG = (rgbReversal ? ABGR_OFFSET_G : RGBA_OFFSET_G);
		UI32	offsetB = (rgbReversal ? ABGR_OFFSET_B : RGBA_OFFSET_B);
		UI32	offsetA = (rgbReversal ? ABGR_OFFSET_A : RGBA_OFFSET_A);
		UI32	row;
		UI32	column;
		UI08	y, u, v;
		for (row = 0; row < height; row++){
			for (column = 0; column < width; column++, pInByte += PIXEL_BYTE_YUV444, pOutByte += PIXEL_BYTE_RGBA){
				y = (*(pInByte + YUV444_OFFSET_Y));
				u = (*(pInByte + YUV444_OFFSET_U));
				v = (*(pInByte + YUV444_OFFSET_V));
				*(pOutByte + offsetR) = (UI08)CLIP(CALC_YUV2RGB_R(y, u, v));
				*(pOutByte + offsetG) = (UI08)CLIP(CALC_YUV2RGB_G(y, u, v));
				*(pOutByte + offsetB) = (UI08)CLIP(CALC_YUV2RGB_B(y, u, v));
				*(pOutByte + offsetA) = (UI08)BYTE_FULLSET;
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertYUV444_RGB565(UI32 width, UI32 height, void *pInYUV, void *pOutRGB, brcBool bigEndian)
* @brief YUV444->RGB565変換
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInYUV		入力画像領域のポインタ
* @param[out]	pOutRGB		出力画像領域のポインタ
* @param[in]	bigEndian	エンディアン指定 true:ビッグエンディアン false:リトルエンディアン
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertYUV444_RGB565(UI32 width, UI32 height, void *pInYUV, void *pOutRGB, brcBool bigEndian)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInYUV != brcNull) && (pOutRGB != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInYUV;
		UI08	*pOutByte = (UI08*)pOutRGB;
		UI32	MSB = (bigEndian ? FALSE : TRUE);
		UI32	LSB = (bigEndian ? TRUE : FALSE);
		UI32	row;
		UI32	column;
		UI08	y, u, v;
		UI08	r, g, b;
		UI16	value;
		for (row = 0; row < height; row++){
			for (column = 0; column < width; column++, pInByte += PIXEL_BYTE_YUV444, pOutByte += PIXEL_BYTE_RGB565){
				y = (*(pInByte + YUV444_OFFSET_Y));
				u = (*(pInByte + YUV444_OFFSET_U));
				v = (*(pInByte + YUV444_OFFSET_V));
				r = (UI08)CLIP(CALC_YUV2RGB_R(y, u, v));
				g = (UI08)CLIP(CALC_YUV2RGB_G(y, u, v));
				b = (UI08)CLIP(CALC_YUV2RGB_B(y, u, v));
				
				// old version
				// UI16	value = (((UI16)r) << BITSHIFT_RGB565_R) + (((UI16)g) << BITSHIFT_RGB565_G) + (((UI16)b) << BITSHIFT_RGB565_B);
				// new version
				value = (((UI16)r >> BITSHIFT_VALUE_3) << BITSHIFT_VALUE_11) | 
					(((UI16)g >> BITSHIFT_VALUE_2) << BITSHIFT_VALUE_5) | ((UI16)b >> BITSHIFT_VALUE_3);

				*(pOutByte + MSB) = value >> BITSHIFT_VALUE_8;
				*(pOutByte + LSB) = value & 0xff;
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertYUV422_RGB(UI32 width, UI32 height, void *pInYUV, void *pOutRGB, brcBool rgbReversal)
* @brief YUV422->RGB変換
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInYUV		入力画像領域のポインタ
* @param[out]	pOutRGB		出力画像領域のポインタ
* @param[in]	rgbReversal	RGB反転 true:BGR false:RGB
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertYUV422_RGB(UI32 width, UI32 height, void *pInYUV, void *pOutRGB, brcBool rgbReversal)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInYUV != brcNull) && (pOutRGB != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInYUV;
		UI08	*pOutByte = (UI08*)pOutRGB;
		UI32	offsetR = (rgbReversal ? BGR_OFFSET_R : RGB_OFFSET_R);
		UI32	offsetG = (rgbReversal ? BGR_OFFSET_G : RGB_OFFSET_G);
		UI32	offsetB = (rgbReversal ? BGR_OFFSET_B : RGB_OFFSET_B);
		UI32	row;
		UI32	column;
		UI08	y, u, v;
		for (row = 0; row < height; row++){
			for (column = 0; column < width; column++, pInByte += PIXEL_BYTE_YUV422, pOutByte += PIXEL_BYTE_RGB){
				y = (*(pInByte + YUV422_OFFSET_UYVY_Y));
				if (column % 2){	// 奇数桁？
					u = (*(pInByte - PIXEL_BYTE_YUV422));
					v = (*(pInByte + YUV422_OFFSET_UYVY_V));
				}
				else{			// 偶数桁
					u = (*(pInByte + YUV422_OFFSET_UYVY_U));
					v = (*(pInByte + PIXEL_BYTE_YUV422));
				}
				*(pOutByte + offsetR) = (UI08)CLIP(CALC_YUV2RGB_R(y, u, v));
				*(pOutByte + offsetG) = (UI08)CLIP(CALC_YUV2RGB_G(y, u, v));
				*(pOutByte + offsetB) = (UI08)CLIP(CALC_YUV2RGB_B(y, u, v));
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertYUV422_RGBA(UI32 width, UI32 height, void *pInYUV, void *pOutRGB, brcBool rgbReversal)
* @brief YUV422->RGBA変換
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInYUV		入力画像領域のポインタ
* @param[out]	pOutRGB		出力画像領域のポインタ
* @param[in]	rgbReversal	RGB反転 true:BGR false:RGB
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertYUV422_RGBA(UI32 width, UI32 height, void *pInYUV, void *pOutRGB, brcBool rgbReversal)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInYUV != brcNull) && (pOutRGB != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInYUV;
		UI08	*pOutByte = (UI08*)pOutRGB;
		UI32	offsetR = (rgbReversal ? ABGR_OFFSET_R : RGBA_OFFSET_R);
		UI32	offsetG = (rgbReversal ? ABGR_OFFSET_G : RGBA_OFFSET_G);
		UI32	offsetB = (rgbReversal ? ABGR_OFFSET_B : RGBA_OFFSET_B);
		UI32	offsetA = (rgbReversal ? ABGR_OFFSET_A : RGBA_OFFSET_A);
		UI32	row;
		UI32	column;
		UI08	y, u, v;
		for (row = 0; row < height; row++){
			for (column = 0; column < width; column++, pInByte += PIXEL_BYTE_YUV422, pOutByte += PIXEL_BYTE_RGBA){
				y = (*(pInByte + YUV422_OFFSET_UYVY_Y));
				if (column % 2){	// 奇数桁？
					u = (*(pInByte - PIXEL_BYTE_YUV422));
					v = (*(pInByte + YUV422_OFFSET_UYVY_V));
				}
				else{			// 偶数桁
					u = (*(pInByte + YUV422_OFFSET_UYVY_U));
					v = (*(pInByte + PIXEL_BYTE_YUV422));
				}
				*(pOutByte + offsetR) = (UI08)CLIP(CALC_YUV2RGB_R(y, u, v));
				*(pOutByte + offsetG) = (UI08)CLIP(CALC_YUV2RGB_G(y, u, v));
				*(pOutByte + offsetB) = (UI08)CLIP(CALC_YUV2RGB_B(y, u, v));
				*(pOutByte + offsetA) = (UI08)BYTE_FULLSET;
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertYUV422_RGB565(UI32 width, UI32 height, void *pInYUV, void *pOutRGB, brcBool bigEndian)
* @brief YUV422->RGB565変換
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInYUV		入力画像領域のポインタ
* @param[out]	pOutRGB		出力画像領域のポインタ
* @param[in]	bigEndian	エンディアン指定 true:ビッグエンディアン false:リトルエンディアン
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertYUV422_RGB565(UI32 width, UI32 height, void *pInYUV, void *pOutRGB, brcBool bigEndian)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInYUV != brcNull) && (pOutRGB != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInYUV;
		UI08	*pOutByte = (UI08*)pOutRGB;
		UI32	MSB = (bigEndian ? FALSE : TRUE);
		UI32	LSB = (bigEndian ? TRUE : FALSE);
		UI32	row;
		UI32	column;
		UI08	y, u, v;
		UI08	r, g, b;
		UI16	value;
		for (row = 0; row < height; row++){
			for (column = 0; column < width; column++, pInByte += PIXEL_BYTE_YUV422, pOutByte += PIXEL_BYTE_RGB565){
				y = (*(pInByte + YUV422_OFFSET_UYVY_Y));
				if (column % 2){	// 奇数桁？
					u = (*(pInByte - PIXEL_BYTE_YUV422));
					v = (*(pInByte + YUV422_OFFSET_UYVY_V));
				}
				else{			// 偶数桁
					u = (*(pInByte + YUV422_OFFSET_UYVY_U));
					v = (*(pInByte + PIXEL_BYTE_YUV422));
				}
				r = (UI08)CLIP(CALC_YUV2RGB_R(y, u, v));
				g = (UI08)CLIP(CALC_YUV2RGB_G(y, u, v));
				b = (UI08)CLIP(CALC_YUV2RGB_B(y, u, v));
				// old version
				// UI16	value = (((UI16)r) << BITSHIFT_RGB565_R) + (((UI16)g) << BITSHIFT_RGB565_G) + (((UI16)b) << BITSHIFT_RGB565_B);
				// new version
				value = (((UI16)r >> BITSHIFT_VALUE_3) << BITSHIFT_VALUE_11) | 
					(((UI16)g >> BITSHIFT_VALUE_2) << BITSHIFT_VALUE_5) | ((UI16)b >> BITSHIFT_VALUE_3);
				*(pOutByte + MSB) = value >> BITSHIFT_VALUE_8;
				*(pOutByte + LSB) = value & 0xff;
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertYUV422sp_RGB(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutRGB, brcBool rgbReversal)
* @brief YUV422sp->RGB変換
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInY		入力Y画像領域のポインタ
* @param[in]	pInUV		入力UV画像領域のポインタ
* @param[out]	pOutRGB		出力画像領域のポインタ
* @param[in]	rgbReversal	RGB反転 true:BGR false:RGB
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertYUV422sp_RGB(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutRGB, brcBool rgbReversal)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInY != brcNull) && (pInUV != brcNull) && (pOutRGB != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByteY = (UI08*)pInY;
		UI08	*pInByteUV = (UI08*)pInUV;
		UI08	*pOutByte = (UI08*)pOutRGB;
		UI32	offsetR = (rgbReversal ? BGR_OFFSET_R : RGB_OFFSET_R);
		UI32	offsetG = (rgbReversal ? BGR_OFFSET_G : RGB_OFFSET_G);
		UI32	offsetB = (rgbReversal ? BGR_OFFSET_B : RGB_OFFSET_B);
		UI32	row;
		UI32	column;
		UI08	y, u, v;
		for (row = 0; row < height; row++){
			for (column = 0; column < width; column++, pInByteY++, pOutByte += PIXEL_BYTE_RGB){
				y = (*pInByteY);
				u = (*(pInByteUV + YUV422SP_OFFSET_UV_U));
				v = (*(pInByteUV + YUV422SP_OFFSET_UV_V));
				if (column % 2){	// 奇数桁か？
					pInByteUV += PIXEL_BYTE_YUV422SP_UV;
				}
				*(pOutByte + offsetR) = (UI08)CLIP(CALC_YUV2RGB_R(y, u, v));
				*(pOutByte + offsetG) = (UI08)CLIP(CALC_YUV2RGB_G(y, u, v));
				*(pOutByte + offsetB) = (UI08)CLIP(CALC_YUV2RGB_B(y, u, v));
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertYUV422sp_RGBA(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutRGB, brcBool rgbReversal)
* @brief YUV422sp->RGBA変換
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInY		入力Y画像領域のポインタ
* @param[in]	pInUV		入力UV画像領域のポインタ
* @param[out]	pOutRGB		出力画像領域のポインタ
* @param[in]	rgbReversal	RGB反転 true:BGR false:RGB
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertYUV422sp_RGBA(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutRGB, brcBool rgbReversal)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInY != brcNull) && (pInUV != brcNull) && (pOutRGB != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByteY = (UI08*)pInY;
		UI08	*pInByteUV = (UI08*)pInUV;
		UI08	*pOutByte = (UI08*)pOutRGB;
		UI32	offsetR = (rgbReversal ? ABGR_OFFSET_R : RGBA_OFFSET_R);
		UI32	offsetG = (rgbReversal ? ABGR_OFFSET_G : RGBA_OFFSET_G);
		UI32	offsetB = (rgbReversal ? ABGR_OFFSET_B : RGBA_OFFSET_B);
		UI32	offsetA = (rgbReversal ? ABGR_OFFSET_A : RGBA_OFFSET_A);
		UI32	row;
		UI32	column;
		UI08	y, u, v;
		for (row = 0; row < height; row++){
			for (column = 0; column < width; column++, pInByteY++, pOutByte += PIXEL_BYTE_RGBA){
				y = (*pInByteY);
				u = (*(pInByteUV + YUV422SP_OFFSET_UV_U));
				v = (*(pInByteUV + YUV422SP_OFFSET_UV_V));
				if (column % 2){	// 奇数桁か？
					pInByteUV += PIXEL_BYTE_YUV422SP_UV;
				}
				*(pOutByte + offsetR) = (UI08)CLIP(CALC_YUV2RGB_R(y, u, v));
				*(pOutByte + offsetG) = (UI08)CLIP(CALC_YUV2RGB_G(y, u, v));
				*(pOutByte + offsetB) = (UI08)CLIP(CALC_YUV2RGB_B(y, u, v));
				*(pOutByte + offsetA) = (UI08)BYTE_FULLSET;
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertYUV422sp_RGB565(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutRGB, brcBool bigEndian)
* @brief YUV422sp->RGB565変換
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInY		入力Y画像領域のポインタ
* @param[in]	pInUV		入力UV画像領域のポインタ
* @param[out]	pOutRGB		出力画像領域のポインタ
* @param[in]	bigEndian	エンディアン指定 true:ビッグエンディアン false:リトルエンディアン
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertYUV422sp_RGB565(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutRGB, brcBool bigEndian)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInY != brcNull) && (pInUV != brcNull) && (pOutRGB != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByteY = (UI08*)pInY;
		UI08	*pInByteUV = (UI08*)pInUV;
		UI08	*pOutByte = (UI08*)pOutRGB;
		UI32	MSB = (bigEndian ? FALSE : TRUE);
		UI32	LSB = (bigEndian ? TRUE : FALSE);
		UI32	row;
		UI32	column;
		UI08	y, u, v;
		UI08	r, g, b;
		UI16	value;
		for (row = 0; row < height; row++){
			for (column = 0; column < width; column++, pInByteY++, pOutByte += PIXEL_BYTE_RGB565){
				y = (*pInByteY);
				u = (*(pInByteUV + YUV422SP_OFFSET_UV_U));
				v = (*(pInByteUV + YUV422SP_OFFSET_UV_V));
				if (column % 2){	// 奇数桁？
					pInByteUV += PIXEL_BYTE_YUV422SP_UV;
				}
				r = (UI08)CLIP(CALC_YUV2RGB_R(y, u, v));
				g = (UI08)CLIP(CALC_YUV2RGB_G(y, u, v));
				b = (UI08)CLIP(CALC_YUV2RGB_B(y, u, v));
				//UI16	value = (((UI16)r) << BITSHIFT_RGB565_R) + (((UI16)g) << BITSHIFT_RGB565_G) + (((UI16)b) << BITSHIFT_RGB565_B);
				value = (((UI16)r >> BITSHIFT_VALUE_3) << BITSHIFT_VALUE_11) | 
					(((UI16)g >> BITSHIFT_VALUE_2) << BITSHIFT_VALUE_5) | ((UI16)b >> BITSHIFT_VALUE_3);
				*(pOutByte + MSB) = value >> BITSHIFT_VALUE_8;
				*(pOutByte + LSB) = value & 0xff;
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertYUV420sp_RGB(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutRGB, brcBool rgbReversal)
* @brief YUV420sp->RGB変換
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInY		入力Y画像領域のポインタ
* @param[in]	pInUV		入力UV画像領域のポインタ
* @param[out]	pOutRGB		出力画像領域のポインタ
* @param[in]	rgbReversal	RGB反転 true:BGR false:RGB
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertYUV420sp_RGB(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutRGB, brcBool rgbReversal)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInY != brcNull) && (pInUV != brcNull) && (pOutRGB != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByteY = (UI08*)pInY;
		UI08	*pInByteUV = (UI08*)pInUV;
		UI08	*pOutByte = (UI08*)pOutRGB;
		UI32	offsetR = (rgbReversal ? BGR_OFFSET_R : RGB_OFFSET_R);
		UI32	offsetG = (rgbReversal ? BGR_OFFSET_G : RGB_OFFSET_G);
		UI32	offsetB = (rgbReversal ? BGR_OFFSET_B : RGB_OFFSET_B);
		UI32	row;
		UI32	offSetYUV;
		UI32	column;
		UI08	y, u, v;
		for (row = 0; row < height; row++){
			offSetYUV = 0;
			for (column = 0; column < width; column++, pInByteY++, pOutByte += PIXEL_BYTE_RGB){
				y = (*pInByteY);
				u = (*(pInByteUV + YUV420SP_OFFSET_UV_U));
				v = (*(pInByteUV + YUV420SP_OFFSET_UV_V));
				//if ((row % 2) && (column % 2)){	// 奇数行＆奇数桁か？
				//	pInByteUV += PIXEL_BYTE_YUV420SP_UV;
				//}
				if (column % 2){
					pInByteUV += PIXEL_BYTE_YUV420SP_UV;
					offSetYUV += PIXEL_BYTE_YUV420SP_UV;
				}
				*(pOutByte + offsetR) = (UI08)CLIP(CALC_YUV2RGB_R(y, u, v));
				*(pOutByte + offsetG) = (UI08)CLIP(CALC_YUV2RGB_G(y, u, v));
				*(pOutByte + offsetB) = (UI08)CLIP(CALC_YUV2RGB_B(y, u, v));
			}
			if ((row % 2) == 0){
				pInByteUV -= offSetYUV;
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertYUV420sp_RGBA(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutRGB, brcBool rgbReversal)
* @brief YUV420sp->RGBA変換
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInY		入力Y画像領域のポインタ
* @param[in]	pInUV		入力UV画像領域のポインタ
* @param[out]	pOutRGB		出力画像領域のポインタ
* @param[in]	rgbReversal	RGB反転 true:BGR false:RGB
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertYUV420sp_RGBA(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutRGB, brcBool rgbReversal)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInY != brcNull) && (pInUV != brcNull) && (pOutRGB != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByteY = (UI08*)pInY;
		UI08	*pInByteUV = (UI08*)pInUV;
		UI08	*pOutByte = (UI08*)pOutRGB;
		UI32	offsetR = (rgbReversal ? ABGR_OFFSET_R : RGBA_OFFSET_R);
		UI32	offsetG = (rgbReversal ? ABGR_OFFSET_G : RGBA_OFFSET_G);
		UI32	offsetB = (rgbReversal ? ABGR_OFFSET_B : RGBA_OFFSET_B);
		UI32	offsetA = (rgbReversal ? ABGR_OFFSET_A : RGBA_OFFSET_A);
		UI32	row;
		UI32	offSetYUV;
		UI32	column;
		UI08	y, u, v;
		for (row = 0; row < height; row++){
			offSetYUV = 0;
			for (column = 0; column < width; column++, pInByteY++, pOutByte += PIXEL_BYTE_RGBA){
				y = (*pInByteY);
				u = (*(pInByteUV + YUV420SP_OFFSET_UV_U));
				v = (*(pInByteUV + YUV420SP_OFFSET_UV_V));
				//if ((row % 2) && (column % 2)){	// 奇数行＆奇数桁か？
				//	pInByteUV += PIXEL_BYTE_YUV420SP_UV;
				//}
				if (column % 2){
					pInByteUV += PIXEL_BYTE_YUV420SP_UV;
					offSetYUV += PIXEL_BYTE_YUV420SP_UV;
				}
				*(pOutByte + offsetR) = (UI08)CLIP(CALC_YUV2RGB_R(y, u, v));
				*(pOutByte + offsetG) = (UI08)CLIP(CALC_YUV2RGB_G(y, u, v));
				*(pOutByte + offsetB) = (UI08)CLIP(CALC_YUV2RGB_B(y, u, v));
				*(pOutByte + offsetA) = (UI08)BYTE_FULLSET;
			}
			if ((row % 2) == 0){
				pInByteUV -= offSetYUV;
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertYUV420sp_RGB565(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutRGB, brcBool bigEndian)
* @brief YUV420sp->RGB565変換
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInY		入力Y画像領域のポインタ
* @param[in]	pInUV		入力UV画像領域のポインタ
* @param[out]	pOutRGB		出力画像領域のポインタ
* @param[in]	bigEndian	エンディアン指定 true:ビッグエンディアン false:リトルエンディアン
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertYUV420sp_RGB565(UI32 width, UI32 height, void *pInY, void *pInUV, void *pOutRGB, brcBool bigEndian)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInY != brcNull) && (pInUV != brcNull) && (pOutRGB != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByteY = (UI08*)pInY;
		UI08	*pInByteUV = (UI08*)pInUV;
		UI08	*pOutByte = (UI08*)pOutRGB;
		UI32	MSB = (bigEndian ? FALSE : TRUE);
		UI32	LSB = (bigEndian ? TRUE : FALSE);
		UI32	row;
		UI32	offSetYUV;
		UI32	column;
		UI08	y, u, v;
		UI08	r, g, b;
		UI16	value;
		for (row = 0; row < height; row++){
			offSetYUV = 0;
			for (column = 0; column < width; column++, pInByteY++, pOutByte += PIXEL_BYTE_RGB565){
				y = (*pInByteY);
				u = (*(pInByteUV + YUV420SP_OFFSET_UV_U));
				v = (*(pInByteUV + YUV420SP_OFFSET_UV_V));
				//if ((row % 2) && (column % 2)){	// 奇数行＆奇数桁か？
				//	pInByteUV += PIXEL_BYTE_YUV420SP_UV;
				//}
				if (column % 2){
					pInByteUV += PIXEL_BYTE_YUV420SP_UV;
					offSetYUV += PIXEL_BYTE_YUV420SP_UV;
				}
				r = (UI08)CLIP(CALC_YUV2RGB_R(y, u, v));
				g = (UI08)CLIP(CALC_YUV2RGB_G(y, u, v));
				b = (UI08)CLIP(CALC_YUV2RGB_B(y, u, v));
				//UI16	value = (((UI16)r) << BITSHIFT_RGB565_R) + (((UI16)g) << BITSHIFT_RGB565_G) + (((UI16)b) << BITSHIFT_RGB565_B);
				value = (((UI16)r >> BITSHIFT_VALUE_3) << BITSHIFT_VALUE_11) | 
					(((UI16)g >> BITSHIFT_VALUE_2) << BITSHIFT_VALUE_5) | ((UI16)b >> BITSHIFT_VALUE_3);
				*(pOutByte + MSB) = value >> BITSHIFT_VALUE_8;
				*(pOutByte + LSB) = value & 0xff;
			}
			if ((row % 2) == 0){
				pInByteUV -= offSetYUV;
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}