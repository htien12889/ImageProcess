﻿/**
 * @file 	BrcImageCropping.c
 * @brief 	画像クロッピングソースファイル
 * @author 	ayesu
 * @date 	2016/07/07
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#include "BrcType.h"
#include "BrcImageProcessingCommon.h"
#include "BrcMemoryUsage.h"

#define ZERO 0


/** CroppingImage(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, UI32 left, UI32 top, UI32 right, UI32 bottom)
* @brief クロッピング
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInRGB		入力画像領域のポインタ
* @param[out]	pOutRGB		出力画像領域のポインタ
* @param[in]	left		左位置
* @param[in]	top			上位置
* @param[in]	right		右位置
* @param[in]	bottom		下位置
* @return		0:成功 0以外:失敗
*/
PUBLIC SI32 CroppingImage(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, UI32 left, UI32 top, UI32 right, UI32 bottom)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height)
		&& (left < width - 1) && (right < width - 1)
		&& (top < height - 1) && (bottom < height - 1)
		&& (left + right < width) && (top + bottom < height)
		&& (pInRGB != brcNull) && (pOutRGB != brcNull) ? SUCCESS : EINVAL);

	if (err == 0){
		SI08	*pInImage = (SI08*)pInRGB;								///	インプット画像
		SI08	*pOutImage = (SI08*)pOutRGB;							/// アウトプット画像
		UI08	*pInWork;
		SI32	newWidth = ZERO;											/// 切り出した画像の幅								
		SI32	newHeight = ZERO;											///	切り出した画像の縦	
		newWidth = (SI32)((width - (left + right)) * RGB_CHANNELS);	    /// 切り出し画像の幅サイズ計算
		newHeight = (SI32)(height - (top + bottom));					/// 切り出し画像の縦サイズ計算
		SI32	j;														/// loop用	
		SI32	i;														/// loop用

		//!画像切り出し処理
		for (j = 0; j < newHeight; j++) {
			pInWork = pInImage + (((width * RGB_CHANNELS) * (j + bottom)) + (left * RGB_CHANNELS));  ///インプット画像の位置の計算
			//UI08			*pOutWork = pOutimage + ((j * newWidth) * + i) * 3;						 ///アウトプット画像の位置の計算
			for (i = 0; i < newWidth; i++) {
				//!切り出されたインプット画像のデータをアウトプット画像に渡す
				*pOutImage = *pInWork;
				pOutImage++;
				pInWork++;
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}
