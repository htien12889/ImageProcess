﻿/**
* @file 	BrcImageConvertRGB2GRAY.c
* @brief 	RGBグレースケール変換シースファイル
* @author 	kyoshitake
* @date 	2016/06/22
* @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
*/
#include "BrcType.h"
#include "BrcImageProcessingCommon.h"
//#include "BrcMemoryUsage.h"

#define ZERO				0
#define ONE					1
#define BITSHIFT_VALUE_1	3
#define BITSHIFT_VALUE_2 	8
#define ARRAY_INDEX_1		256
#define ARRAY_INDEX_2		512
#define ARRAY_INDEX_3		768
#define ARRAY_INDEX_4		8192
#define GRAY_SHIFT			14

/** ConvertRGB_GRAY(UI32 width, UI32 height, void *pInData, void *pOutData, brcBool rgbReversal)
* @brief RGBグレースケール変換
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInData		入力画像領域のポインタ（RGBの3バイト列のデータ）
* @param[out]	pOutData	出力画像領域のポインタ（1バイト列のデータ）
* @param[in]	rgbReversal	RGB反転 true:BGR false:RGB
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertRGB_GRAY(UI32 width, UI32 height, void *pInData, void *pOutData, brcBool rgbReversal)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInData != brcNull) && (pOutData != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInData;
		UI08	*pOutByte = (UI08*)pOutData;
		UI32	offsetR = (rgbReversal ? BGR_OFFSET_R : RGB_OFFSET_R);
		UI32	offsetG = (rgbReversal ? BGR_OFFSET_G : RGB_OFFSET_G);
		UI32	offsetB = (rgbReversal ? BGR_OFFSET_B : RGB_OFFSET_B);
		UI32	max = width * height;
		UI32	index;
		UI08	r, g, b;
		SI32	dr = COEFF_0, dg = COEFF_1, db = COEFF_2;
		SI32	tab[ARRAY_INDEX_3];
		SI32	bTmp = ZERO, gTmp = ZERO, rTmp = ARRAY_INDEX_4;
		UI32	i;
		for (i = 0; i < ARRAY_INDEX_1; i++, bTmp += db, gTmp += dg, rTmp += dr)
		{
			tab[i] = bTmp;
			tab[i + ARRAY_INDEX_1] = gTmp;
			tab[i + ARRAY_INDEX_2] = rTmp;
		}
		for (index = 0; index < max; index++, pInByte += PIXEL_BYTE_RGB, pOutByte++){
			r = (*(pInByte + offsetR));
			g = (*(pInByte + offsetG));
			b = (*(pInByte + offsetB));
			*pOutByte = (UI08)((tab[b] + tab[g + ARRAY_INDEX_1] + tab[r + ARRAY_INDEX_2]) >> GRAY_SHIFT);
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertRGBA_GRAY(UI32 width, UI32 height, void *pInData, void *pOutData, brcBool rgbReversal)
* @brief RGBAグレースケール変換
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInData		入力画像領域のポインタ（RGBAの4バイト列のデータ）
* @param[out]	pOutData	出力画像領域のポインタ（1バイト列のデータ）
* @param[in]	rgbReversal	RGB反転 true:ABGR false:RGBA
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertRGBA_GRAY(UI32 width, UI32 height, void *pInData, void *pOutData, brcBool rgbReversal)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInData != brcNull) && (pOutData != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInData;
		UI08	*pOutByte = (UI08*)pOutData;
		UI32	offsetR = (rgbReversal ? ABGR_OFFSET_R : RGBA_OFFSET_R);
		UI32	offsetG = (rgbReversal ? ABGR_OFFSET_G : RGBA_OFFSET_G);
		UI32	offsetB = (rgbReversal ? ABGR_OFFSET_B : RGBA_OFFSET_B);
		UI32	max = width * height;
		UI32	index;
		UI08	r, g, b;
		SI32	dr = COEFF_0, dg = COEFF_1, db = COEFF_2;
		SI32	tab[ARRAY_INDEX_3];
		SI32	bTmp = ZERO, gTmp = ZERO, rTmp = ARRAY_INDEX_4;
		UI32	i;
		for (i = 0; i < ARRAY_INDEX_1; i++, bTmp += db, gTmp += dg, rTmp += dr)
		{
			tab[i] = bTmp;
			tab[i + ARRAY_INDEX_1] = gTmp;
			tab[i + ARRAY_INDEX_2] = rTmp;
		}
		for (index = 0; index < max; index++, pInByte += PIXEL_BYTE_RGBA, pOutByte++){
			r = (*(pInByte + offsetR));
			g = (*(pInByte + offsetG));
			b = (*(pInByte + offsetB));
			*pOutByte = (UI08)((tab[b] + tab[g + ARRAY_INDEX_1] + tab[r + ARRAY_INDEX_2]) >> GRAY_SHIFT);
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertRGB565_GRAY(UI32 width, UI32 height, void *pInData, void *pOutData, brcBool bigEndian)
* @brief RGB565グレースケール変換
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInData		入力画像領域のポインタ（RGB565の2バイト列のデータ）
* @param[out]	pOutData	出力画像領域のポインタ（1バイト列のデータ）
* @param[in]	bigEndian	エンディアン指定 true:ビッグエンディアン false:リトルエンディアン
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertRGB565_GRAY(UI32 width, UI32 height, void *pInData, void *pOutData, brcBool bigEndian)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInData != brcNull) && (pOutData != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInData;
		UI08	*pOutByte = (UI08*)pOutData;
		UI32	max = width * height;
		UI32	index;
		UI08	r, g, b;
		UI16	value;
		if (bigEndian){
			for (index = 0; index < max; index++, pInByte += PIXEL_BYTE_RGB565, pOutByte++){
				value = ((*pInByte) << BITSHIFT_VALUE_2) + (*(pInByte + ONE));
				r = (UI08)((value >> BITSHIFT_VALUE_2) & 0xf8);
				g = (UI08)((value >> BITSHIFT_VALUE_1) & 0xfc);
				b = (UI08)((value << BITSHIFT_VALUE_1) & 0xf8);
				*pOutByte = (UI08)DESCALE_CONV(b*COEFF_2 + g*COEFF_1 + r*COEFF_0, GRAY_SHIFT);
			}
		}
		else{
			for (index = 0; index < max; index++, pInByte += PIXEL_BYTE_RGB565, pOutByte++){
				value = ((*(pInByte + ONE)) << BITSHIFT_VALUE_2) + (*pInByte);
				r = (UI08)((value >> BITSHIFT_VALUE_2) & 0xf8);
				g = (UI08)((value >> BITSHIFT_VALUE_1) & 0xfc);
				b = (UI08)((value << BITSHIFT_VALUE_1) & 0xf8);
				*pOutByte = (UI08)DESCALE_CONV(b*COEFF_2 + g*COEFF_1 + r*COEFF_0, GRAY_SHIFT);
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}
