﻿/**
* @file 	BrcImageConvertColorSpace.c
* @brief 	色空間変換ソースファイル
* @author 	ykobayashi
* @date 	2016/08/03
* @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
*/
#include <math.h>
#include "BrcType.h"
#include "BrcImageConvertColorSpace.h"
#include "BrcImageProcessingCommon.h"
#include "BrcImageLightingPreference.h"
#include "BrcMemoryUsage.h"

// define for RGB2XYZ function
#define CALC_CORRECTION_SRGB_THRESHOLD_VALUE_OR_LESS(anyRGB) (anyRGB / 12.92f) /// sRGBの明るさを補正する式 r,g,b値が閾値以下のとき
#define CALC_CORRECTION_SRGB_THRESHOLD_VALUE_OVER(anyRGB) (pow((anyRGB + 0.055f) / 1.055f, 2.4f)) /// sRGBの明るさを補正する式 r,g,b値が閾値より上のとき
#define CORRECTION_SRGB_THRESHOLD_VALUE 0.040450f
#define CALC_CORRECTION_ADOBERGB_THRESHOLD_VALUE_OVER(anyRGB) (pow(anyRGB,2.2f)) /// sRGBの明るさを補正する式 r,g,b値が閾値より上のとき

// define for XYZ2Lab function
#define CALC_THRESHOLD_VALUE_OVER(anyXYZ) (pow(anyXYZ,(FP32)1/3)) /// x,y,z値が閾値より上のとき
#define CALC_THRESHOLD_VALUE_OR_LESS(anyXYZ) (anyXYZ*7.787f + 0.13793103448275862f) /// x,y,z値が閾値以下のとき
#define CONVERT_XYZ2LAB_THRESHOLD_VALUE 0.008856f /// 計算式判断用の閾値

#define CALC_CONVERT_LIGHTING_SOURCE_X(x, y, z) (   1.047886f * x + 0.022919f * y + (-0.050216f) * z) /// 標準光源変換式x D65->D50
#define CALC_CONVERT_LIGHTING_SOURCE_Y(x, y, z) (   0.029582f * x + 0.990484f * y + (-0.017079f) * z) /// 標準光源変換式y D65->D50
#define CALC_CONVERT_LIGHTING_SOURCE_Z(x, y, z) ((-0.009252f) * x + 0.015073f * y +    0.751678f * z) /// 標準光源変換式z D65->D50

#define WHITE_POINT_D50_X 1.03713f /// 標準光源の白色点X (1 / 0.9642f)
#define WHITE_POINT_D50_Y 1.0f    /// 標準光源の白色点Y
#define WHITE_POINT_D50_Z 1.21227f /// 標準光源の白色点Z (1 / 0.8249f)

#define WHITE_POINT_D65_X 1.05219f  /// 標準光源の白色点X (1 / 0.9642f)
#define WHITE_POINT_D65_Y 1.0f		/// 標準光源の白色点Y
#define WHITE_POINT_D65_Z 0.9184f	/// 標準光源の白色点Z (1 / 0.9184f)

#define ROW_OR_COLUMN_NUMBER 3    // 行列の行or列の要素数
#define INDEX_SIZE			256		

/// sRGB 標準光源：D65 用変換テーブル
const FP32 g_kConversionTablesRGBD65[ROW_OR_COLUMN_NUMBER][ROW_OR_COLUMN_NUMBER] =
{
	{ 0.4124f, 0.3576f, 0.1805f },
	{ 0.2126f, 0.7152f, 0.0722f },
	{ 0.0193f, 0.1192f, 0.9505f }
};

/// Adobe RGB 標準光源：D65 用変換テーブル
const FP32 g_kConversionTableAdobeRGBD65[ROW_OR_COLUMN_NUMBER][ROW_OR_COLUMN_NUMBER] =
{
	{ 0.5778f, 0.1825f, 0.1902f },
	{ 0.3070f, 0.6170f, 0.0761f },
	{ 0.0181f, 0.0695f, 1.0015f }
};

/** ConvertRGB2XYZ(UI32 width, UI32 height, void *pInRGB, FP32 *pX, FP32 *pY, FP32 *pZ,
*		eCorrectionState emCorrectionState, TT_RGBState *pRGBState)
* @brief RGB->XYZ変換
* @param[in]	width				画像幅
* @param[in]	height				画像高さ
* @param[in]	pInRGB				入力画像領域のポインタ
* @param[out]	pX					X格納領域のポインタ
* @param[out]	pY					Y格納領域のポインタ
* @param[out]	pZ					Z格納領域のポインタ
* @param[in]	emCorrectionState	明るさの補正設定を持つ列挙型
* @param[in]	pRGBState    		RGBの設定を持つ構造体のポインタ
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertRGB2XYZ(UI32 width, UI32 height, void *pInRGB, FP32 *pX, FP32 *pY, FP32 *pZ,
	eCorrectionState emCorrectionState, TT_RGBState *pRGBState)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInRGB != brcNull) && (pX != brcNull)
		&& (pY != brcNull) && (pZ != brcNull) && (pRGBState != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI32 i;
		UI32 numLoops = width * height;
		BrcBGR *pInImage = (BrcBGR*)pInRGB;
		FP32 normalizeRGB[INDEX_SIZE];
		FP32 inverseRGBLessValue[INDEX_SIZE];
		FP32 inverseRGBOverValue[INDEX_SIZE];
		FP32 inverseAdobeRGB[INDEX_SIZE];
		FP32 rValue, gValue, bValue;
		// normalize and inverse for RGB value array
		for (i = 0; i < INDEX_SIZE; i++){
			normalizeRGB[i] = (FP32)i / BYTE_FULLSET;
			inverseRGBOverValue[i] = (FP32)CALC_CORRECTION_SRGB_THRESHOLD_VALUE_OVER(normalizeRGB[i]);
			inverseRGBLessValue[i] = (FP32)CALC_CORRECTION_SRGB_THRESHOLD_VALUE_OR_LESS(normalizeRGB[i]);
			inverseAdobeRGB[i] = (FP32)CALC_CORRECTION_ADOBERGB_THRESHOLD_VALUE_OVER(normalizeRGB[i]);
		}
		for (i = 0; i < numLoops; i++){
			rValue = normalizeRGB[pInImage[i].red];
			gValue = normalizeRGB[pInImage[i].green];
			bValue = normalizeRGB[pInImage[i].blue];

			switch (emCorrectionState){
			case emLinear:
				// 補正なしのため処理なし
				break;
			case emCorrectionsRGB:
				// inverseBrightness for sRGB value
				if (rValue > (FP32)CORRECTION_SRGB_THRESHOLD_VALUE){
					rValue = inverseRGBOverValue[pInImage[i].red];
				}
				else{
					rValue = inverseRGBLessValue[pInImage[i].red];
				}
				if (gValue > (FP32)CORRECTION_SRGB_THRESHOLD_VALUE){
					gValue = inverseRGBOverValue[pInImage[i].green];
				}
				else{
					gValue = inverseRGBLessValue[pInImage[i].green];
				}
				if (bValue > (FP32)CORRECTION_SRGB_THRESHOLD_VALUE){
					bValue = inverseRGBOverValue[pInImage[i].blue];
				}
				else{
					bValue = inverseRGBLessValue[pInImage[i].blue];
				}
				break;
			case emCorrectionAdobeRGB:
				// inverseBrightness for AdobeRGB value
				rValue = inverseAdobeRGB[pInImage[i].red];
				gValue = inverseAdobeRGB[pInImage[i].green];
				bValue = inverseAdobeRGB[pInImage[i].blue];
				break;
			}

			switch (pRGBState->emRGBType){
			case emsRGB:
				switch (pRGBState->emLightginSourceRGB){
				case emD65:
					// sRGB to XYZ conversion
					*(pX + i) = g_kConversionTablesRGBD65[0][0] * rValue + g_kConversionTablesRGBD65[0][1] * gValue
						+ g_kConversionTablesRGBD65[0][2] * bValue;
					*(pY + i) = g_kConversionTablesRGBD65[1][0] * rValue + g_kConversionTablesRGBD65[1][1] * gValue
						+ g_kConversionTablesRGBD65[1][2] * bValue;
					*(pZ + i) = g_kConversionTablesRGBD65[2][0] * rValue + g_kConversionTablesRGBD65[2][1] * gValue
						+ g_kConversionTablesRGBD65[2][2] * bValue;
					break;
				default: // エラー　未実装
					err = ENOSYS;
					break;
				}
				break;
			case emAdobeRGB:
				switch (pRGBState->emLightginSourceRGB){
				case emD65:
					// AdobeRGB to XYZ conversion
					*(pX + i) = g_kConversionTableAdobeRGBD65[0][0] * rValue + g_kConversionTableAdobeRGBD65[0][1] * gValue
						+ g_kConversionTableAdobeRGBD65[0][2] * bValue;
					*(pY + i) = g_kConversionTableAdobeRGBD65[1][0] * rValue + g_kConversionTableAdobeRGBD65[1][1] * gValue
						+ g_kConversionTableAdobeRGBD65[1][2] * bValue;
					*(pZ + i) = g_kConversionTableAdobeRGBD65[2][0] * rValue + g_kConversionTableAdobeRGBD65[2][1] * gValue
						+ g_kConversionTableAdobeRGBD65[2][2] * bValue;
					break;
				default: // エラー　未実装
					err = ENOSYS;
					break;
				}
				break;
			default: // エラー　未実装
				err = ENOSYS;
				break;
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertXYZ2Lab(UI32 width, UI32 height, FP32 *pX, FP32 *pY, FP32 *pZ, FP32 *pL, FP32 *pa, FP32 *pb,
*		TT_LightingSourceState *pLightingSourceState)
* @brief XYZ->Lab変換
* @param[in]	width						画像幅
* @param[in]	height						画像高さ
* @param[in]	pX							pX値
* @param[in]	pY							pY値
* @param[in]	pZ							pZ値
* @param[out]	pL							L格納領域のポインタ
* @param[out]	pa							a格納領域のポインタ
* @param[out]	pb							b格納領域のポインタ
* @param[in]	pLightingSourceState		標準光源の変換設定を持つ構造体のポインタ
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertXYZ2Lab(UI32 width, UI32 height, FP32 *pX, FP32 *pY, FP32 *pZ, FP32 *pL, FP32 *pa, FP32 *pb,
	TT_LightingSourceState *pLightingSourceState)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pX != brcNull) && (pY != brcNull) && (pZ != brcNull)
		&& (pL != brcNull) && (pa != brcNull) && (pb != brcNull) && (pLightingSourceState != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI32 i;
		UI32 numLoops = width * height;
		FP32 varX, varY, varZ;
		for (i = 0; i < numLoops; i++){
			varX = *(pX + i);
			varY = *(pY + i);
			varZ = *(pZ + i);
			if (emD50 == pLightingSourceState->emLightingSourceLab){ // XYZ->Lab(D50)への変換
				switch (pLightingSourceState->emLightingSourceXYZ){
				case emD65: /// 未テスト
					varX = (FP32)CALC_CONVERT_LIGHTING_SOURCE_X(varX, varY, varZ); // xyzの標準光源変換x D65->D50
					varY = (FP32)CALC_CONVERT_LIGHTING_SOURCE_Y(varX, varY, varZ); // xyzの標準光源変換y D65->D50
					varZ = (FP32)CALC_CONVERT_LIGHTING_SOURCE_Z(varX, varY, varZ); // xyzの標準光源変換z D65->D50
					varX *= WHITE_POINT_D50_X;		// varX /= WHITE_POINT_D50_X equal varX = varX * (1 / WHITE_POINT_D50_X)
					// to reduce divide calculation
					varY *= WHITE_POINT_D50_Y;
					varZ *= WHITE_POINT_D50_Z;
					break;
				case emD50:
					// 変更する必要なしなので処理なし D50->D50
					varX *= WHITE_POINT_D50_X;
					varY *= WHITE_POINT_D50_Y;
					varZ *= WHITE_POINT_D50_Z;
					break;
				default: // 上記以外は実装していない機能
					err = ENOSYS;
					break;
				}
			}
			else{ // XYZ->Lab(D65)への変換
				switch (pLightingSourceState->emLightingSourceXYZ){
				case emD65:
					// 変更する必要なしなので処理なし D65->D65
					varX *= WHITE_POINT_D65_X;		// varX /= WHITE_POINT_D65_X equal varX = varX * (1 / WHITE_POINT_D65_X)
					// to reduce divide calculation
					varY *= WHITE_POINT_D65_Y;
					varZ *= WHITE_POINT_D65_Z;
					break;
				default: // 上記以外は実装していない機能
					err = ENOSYS;
					break;
				}
			}

			if (varX > CONVERT_XYZ2LAB_THRESHOLD_VALUE){
				varX = (FP32)CALC_THRESHOLD_VALUE_OVER(varX);
			}
			else{
				varX = (FP32)CALC_THRESHOLD_VALUE_OR_LESS(varX);
			}

			if (varY > CONVERT_XYZ2LAB_THRESHOLD_VALUE){
				varY = (FP32)CALC_THRESHOLD_VALUE_OVER(varY);
			}
			else{
				varY = (FP32)CALC_THRESHOLD_VALUE_OR_LESS(varY);
			}

			if (varZ > CONVERT_XYZ2LAB_THRESHOLD_VALUE){
				varZ = (FP32)CALC_THRESHOLD_VALUE_OVER(varZ);
			}
			else{
				varZ = (FP32)CALC_THRESHOLD_VALUE_OR_LESS(varZ);
			}

			*(pL + i) = (116 * varY) - 16;
			*(pa + i) = 500 * (varX - varY);
			*(pb + i) = 200 * (varY - varZ);
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}