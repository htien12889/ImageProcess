﻿/**
 * @file 	BrcImageHistogram.c
 * @brief 	ヒストグラムソースファイル
 * @author 	EMT-BrycenVN
 * @date 	2016/06/22
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#include <math.h>
#include <string.h>
#include "BrcType.h"
#include <assert.h>
#include "BrcImageProcessingCommon.h"
#include "BrcMemoryUsage.h"

#define H_RANGE						180
#define HSV_SHIFT					12
#define CLAMP(x)					(UI08)(x > 255 ? 255 : (x < 0 ? 0 : x))  
#define Y_luminance(R,G,B)			(UI08)((initRGB[0][R]) + (initRGB[1][G]) + (initRGB[2][B]))
#define MAX(x, y)					(((x) > (y)) ? (x) : (y))
#define MIN(x, y)					(((x) < (y)) ? (x) : (y))
#define FAST_CAST_8U(t)				(assert(-256 <= (t) && (t) <= 512), Saturate8u[(t)+256])
#define CALC_MIN_8U(a,b)			(a) -= FAST_CAST_8U((a) - (b))
#define CALC_MAX_8U(a,b)			(a) += FAST_CAST_8U((b) - (a))
#define SHIFT_RIGHT_2BITS(value)	(UI16)((UI16)(value) << 2)
#define SHIFT_RIGHT_4BITS(value)	(UI16)((UI16)(value) << 4)
#define COMPARE_TWO_VALUES(a,b)		((a) == (b) ? -1 : 0)

PRIVATE void rgbToYCbCr(UI08 r, UI08 g, UI08 b, UI08 *y, UI08 *cb, UI08 *cr);
PRIVATE void ycbcrToRGB(UI08 y, UI08 cb, UI08 cr, UI08 *r, UI08 *g, UI08 *b);
PRIVATE void findMinMaxIntensity(UI08 *max, UI08 *min, UI08 input);
PRIVATE void initConvertRGB2Y(FP32 initRGB[3][256]);
PRIVATE SI32 hsvRound(FP64 value);

const UI08 Saturate8u[] =
{
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
	16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31,
	32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47,
	48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63,
	64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79,
	80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95,
	96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111,
	112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127,
	128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143,
	144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159,
	160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175,
	176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191,
	192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207,
	208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223,
	224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239,
	240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255
};

static FP64 g_rgbToYCbCrmatrix[3][3] = {
	0.299, 0.587, 0.114,
	-0.16874, -0.33126, 0.5,
	0.5, -0.41869, -0.08131 
};

static FP64 g_ycbcrToRGBmatrix[4] = {
	1.402, -0.344136f, -0.714136f, 1.772 
};

typedef enum { 
	FALSE, 
	TRUE 
} BOOL;

/** GetRGBHistogram(UI32 width, UI32 height, void *pInRGB, UI32 max, UI32 *pRed, UI32 *pGreen, UI32 *pBlue, UI32 *pValue)
* @brief RGBヒストグラム取得
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInRGB		入力画像領域のポインタ
* @param[in]	max			最大値
* @param[out]	pRed		赤ヒストグラム領域のポインタ（NULLの場合は出力しない）
* @param[out]	pGreen		緑ヒストグラム領域のポインタ（NULLの場合は出力しない）
* @param[out]	pBlue		青ヒストグラム領域のポインタ（NULLの場合は出力しない）
* @param[out]	pValue		輝度ヒストグラム領域のポインタ（NULLの場合は出力しない）
* @return		0:成功 0以外:失敗
*/
PUBLIC SI32 GetRGBHistogram(UI32 width, UI32 height, void *pInRGB, UI32 max, UI32 *pRed, UI32 *pGreen, UI32 *pBlue, UI32 *pValue)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInRGB != brcNull)
		&& (pRed != brcNull) && (pGreen != brcNull) && (pBlue != brcNull) && (pValue != brcNull)
		&& (max == 8 || max == 10 || max == 12) ? SUCCESS : EINVAL);
	if (err == 0){
		max = (SI32)pow((FP64)2, max);
		// Initialize all members of an array to the zero value
		memset(pRed, 0, sizeof(UI32)* max);
		memset(pGreen, 0, sizeof(UI32)* max);
		memset(pBlue, 0, sizeof(UI32)* max);
		memset(pValue, 0, sizeof(UI32)* max);
		UI32 i;
		BrcBGR *pInimage = (BrcBGR*)pInRGB;
		UI08 y;
		FP32 initRGB[3][256];
		initConvertRGB2Y(initRGB);
		if (max == 256){
			for (i = 0; i < width * height; i++){
				pRed[pInimage[i].red] += 1;
				pGreen[pInimage[i].green] += 1;
				pBlue[pInimage[i].blue] += 1;
				y = (UI08)Y_luminance(pInimage[i].red, pInimage[i].green, pInimage[i].blue);
				pValue[y] += 1;
			}
		}
		else if (max == 1024){
			UI16 r10, g10, b10, y10;
			for (i = 0; i < width * height; i++){
				r10 = SHIFT_RIGHT_2BITS((UI16)pInimage[i].red);
				g10 = SHIFT_RIGHT_2BITS((UI16)pInimage[i].green);
				b10 = SHIFT_RIGHT_2BITS((UI16)pInimage[i].blue);
				pRed[r10] += 1;
				pGreen[g10] += 1;
				pBlue[b10] += 1;
				y = (UI08)Y_luminance(pInimage[i].red, pInimage[i].green, pInimage[i].blue);
				y10 = SHIFT_RIGHT_2BITS((UI16)y);
				pValue[y10] += 1;
			}
		}
		else if (max == 4096){
			UI16 r12, g12, b12, y12;
			for (i = 0; i < width * height; i++){
				r12 = SHIFT_RIGHT_4BITS((UI16)pInimage[i].red);
				g12 = SHIFT_RIGHT_4BITS((UI16)pInimage[i].green);
				b12 = SHIFT_RIGHT_4BITS((UI16)pInimage[i].blue);
				pRed[r12] += 1;
				pGreen[g12] += 1;
				pBlue[b12] += 1;
				y = (UI08)Y_luminance(pInimage[i].red, pInimage[i].green, pInimage[i].blue);
				y12 = SHIFT_RIGHT_4BITS((UI16)y);
				pValue[y12] += 1;
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** GetHSVHistogram(UI32 width, UI32 height, void *pInRGB, UI32 max, UI32 *pHue, UI32 *pSaturation, UI32 *pValue)
* @brief HSVヒストグラム取得
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInRGB		入力画像領域のポインタ
* @param[in]	max			最大値
* @param[out]	pHue		色相ヒストグラム領域のポインタ（NULLの場合は出力しない）
* @param[out]	pSaturation	彩度ヒストグラム領域のポインタ（NULLの場合は出力しない）
* @param[out]	pValue		輝度ヒストグラム領域のポインタ（NULLの場合は出力しない）
* @return		0:成功 0以外:失敗
*/
PUBLIC SI32 GetHSVHistogram(UI32 width, UI32 height, void *pInRGB, UI32 max, UI32 *pHue, UI32 *pSaturation, UI32 *pValue)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInRGB != brcNull)
		&& (pHue != brcNull) && (pSaturation != brcNull) && (pValue != brcNull)
		&& (max == 8 || max == 10 || max == 12) ? SUCCESS : EINVAL);
	if (err == 0){
		max = (SI32)pow((FP64)2, max);
		// Initialize all members of an array to the zero value
		memset(pHue, 0, sizeof(UI32)* max);
		memset(pSaturation, 0, sizeof(UI32)* max);
		memset(pValue, 0, sizeof(UI32)* max);

		BrcBGR *pInimage = (BrcBGR*)pInRGB;

		static SI32 sDivTable[256];
		static SI32 hDivTable180[256];
		static volatile BOOL initialized = FALSE;
		const SI32 *HDIV_TABLE = hDivTable180;

		UI32 i;
		if (!initialized){
			sDivTable[0] = hDivTable180[0] = 0;
			for (i = 1; i < 256; i++){
				sDivTable[i] = hsvRound((255 << HSV_SHIFT) / (1.*i));
				hDivTable180[i] = hsvRound((180 << HSV_SHIFT) / (6.*i));
			}
			initialized = TRUE;
		}

		UI08 b, g, r;
		SI32 h, s, v;
		SI32 vMin, diff;
		SI32 vR, vG;
		if (max == 256){
			for (i = 0; i < width * height; i++){
				b = pInimage[i].blue, g = pInimage[i].green, r = pInimage[i].red;
				v = b;
				vMin = b;
				CALC_MAX_8U(v, g);
				CALC_MAX_8U(v, r);
				CALC_MIN_8U(vMin, g);
				CALC_MIN_8U(vMin, r);

				diff = v - vMin;
				vR = COMPARE_TWO_VALUES(v,r);
				vG = COMPARE_TWO_VALUES(v,g);

				s = (diff * sDivTable[v] + (1 << (HSV_SHIFT - 1))) >> HSV_SHIFT;
				h = (vR & (g - b)) +
					(~vR & ((vG & (b - r + 2 * diff)) + ((~vG) & (r - g + 4 * diff))));
				h = (h * HDIV_TABLE[diff] + (1 << (HSV_SHIFT - 1))) >> HSV_SHIFT;
				h += h < 0 ? H_RANGE : 0;

				pHue[h] += 1;
				pSaturation[s] += 1;
				pValue[v] += 1;
			}
		}
		else if (max == 1024){
			SI32 h10, s10, v10;
			for (i = 0; i < width * height; i++){
				b = pInimage[i].blue, g = pInimage[i].green, r = pInimage[i].red;
				v = b;
				vMin = b;
				CALC_MAX_8U(v, g);
				CALC_MAX_8U(v, r);
				CALC_MIN_8U(vMin, g);
				CALC_MIN_8U(vMin, r);

				diff = v - vMin;
				vR = COMPARE_TWO_VALUES(v, r);
				vG = COMPARE_TWO_VALUES(v, g);

				s = (diff * sDivTable[v] + (1 << (HSV_SHIFT - 1))) >> HSV_SHIFT;
				h = (vR & (g - b)) +
					(~vR & ((vG & (b - r + 2 * diff)) + ((~vG) & (r - g + 4 * diff))));
				h = (h * HDIV_TABLE[diff] + (1 << (HSV_SHIFT - 1))) >> HSV_SHIFT;
				h += h < 0 ? H_RANGE : 0;

				h10 = SHIFT_RIGHT_2BITS(h);
				s10 = SHIFT_RIGHT_2BITS(s);
				v10 = SHIFT_RIGHT_2BITS(v);

				pHue[h10] += 1;
				pSaturation[s10] += 1;
				pValue[v10] += 1;
			}
		}
		else if (max == 4096){
			SI32 h12, s12, v12;
			for (i = 0; i < width * height; i++){
				b = pInimage[i].blue, g = pInimage[i].green, r = pInimage[i].red;
				v = b;
				vMin = b;

				CALC_MAX_8U(v, g);
				CALC_MAX_8U(v, r);
				CALC_MIN_8U(vMin, g);
				CALC_MIN_8U(vMin, r);

				diff = v - vMin;
				vR = COMPARE_TWO_VALUES(v, r);
				vG = COMPARE_TWO_VALUES(v, g);

				s = (diff * sDivTable[v] + (1 << (HSV_SHIFT - 1))) >> HSV_SHIFT;
				h = (vR & (g - b)) +
					(~vR & ((vG & (b - r + 2 * diff)) + ((~vG) & (r - g + 4 * diff))));
				h = (h * HDIV_TABLE[diff] + (1 << (HSV_SHIFT - 1))) >> HSV_SHIFT;
				h += h < 0 ? H_RANGE : 0;

				h12 = SHIFT_RIGHT_4BITS(h);
				s12 = SHIFT_RIGHT_4BITS(s);
				v12 = SHIFT_RIGHT_4BITS(v);

				pHue[h12] += 1;
				pSaturation[s12] += 1;
				pValue[v12] += 1;
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** GetDensityHistogram(UI32 width, UI32 height, void *pInRGB, UI32 max, UI32 *pDensity)
* @brief 濃度ヒストグラム取得
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInRGB		入力画像領域のポインタ
* @param[in]	max			最大値
* @param[out]	pDensity	濃度ヒストグラム領域のポインタ
* @return		0:成功 0以外:失敗
*/
PUBLIC SI32 GetDensityHistogram(UI32 width, UI32 height, void *pInRGB, UI32 max, UI32 *pDensity)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInRGB != brcNull)
		&& (pDensity != (UI32*)brcNull) 
		&& (max == 8 || max == 10 || max == 12) ? SUCCESS : EINVAL);
	if (err == 0){
		max = (SI32)pow((FP64)2, max);
		// Initialize all members of an array to the zero value
		memset(pDensity, 0, sizeof(UI32)* max);

		BrcBGR *pInimage = (BrcBGR*)pInRGB;
		UI32 i;
		UI08 y;
		FP32 initRGB[3][256];
		initConvertRGB2Y(initRGB);
		if (max == 256){
			for (i = 0; i < width * height; i++){
				y = (UI08)Y_luminance(pInimage[i].red, pInimage[i].green, pInimage[i].blue);
				pDensity[y] += 1;
			}
		}
		else if (max == 1024){
			UI16 y10;
			for (i = 0; i < width * height; i++){
				y = (UI08)Y_luminance(pInimage[i].red, pInimage[i].green, pInimage[i].blue);
				y10 = SHIFT_RIGHT_2BITS((UI16)y);
				pDensity[y10] += 1;
			}
		}
		else if (max == 4096){
			UI16 y12;
			for (i = 0; i < width * height; i++){
				y = (UI08)Y_luminance(pInimage[i].red, pInimage[i].green, pInimage[i].blue);
				y12 = SHIFT_RIGHT_4BITS((UI16)y);
				pDensity[y12] += 1;
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** StretchHistogram(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, UI32 min, UI32 max)
* @brief ヒストグラム伸張化
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInRGB		入力画像領域のポインタ
* @param[out]	pOutRGB		出力画像領域のポインタ
* @param[in]	min			最小値
* @param[in]	max			最大値
* @return		0:成功 0以外:失敗
*/
PUBLIC SI32 StretchHistogram(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, UI32 min, UI32 max)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height)
		&& (pInRGB != brcNull) && (pOutRGB != brcNull) && (min < max) 
		&& ((SI32)min >= 0 && (SI32)min < 255) && ((SI32)max > 0 && (SI32)max <= 255) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08 minR = 255; UI08 maxR = 0;
		UI08 minG = 255; UI08 maxG = 0;
		UI08 minB = 255; UI08 maxB = 0;

		BrcBGR *pInimage = (BrcBGR*)pInRGB;
		BrcBGR *pOutimage = (BrcBGR*)pOutRGB;
		UI32 i;
		// Fin min, max of intensity histogram
		for (i = 0; i < width * height; i++){
			findMinMaxIntensity(&maxR, &minR, pInimage[i].red);
			findMinMaxIntensity(&maxG, &minG, pInimage[i].green);
			findMinMaxIntensity(&maxB, &minB, pInimage[i].blue);
		}
		/*
		* Normalized pixel values
		*/
		for (i = 0; i < width * height; i++){
			pOutimage[i].red = CLAMP((UI08)(((UI32)pInimage[i].red - minR)*(max - min) / (maxR - minR) + min));
			pOutimage[i].green = CLAMP((UI08)(((UI32)pInimage[i].green - minG)*(max - min) / (maxG - minG) + min));
			pOutimage[i].blue = CLAMP((UI08)(((UI32)pInimage[i].blue - minB)*(max - min) / (maxB - minB) + min));
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** FlattenHistogram(UI32 width, UI32 height, void *pInRGB, void *pOutRGB)
* @brief ヒストグラム平坦化
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInRGB		入力画像領域のポインタ
* @param[out]	pOutRGB		出力画像領域のポインタ
* @return		0:成功 0以外:失敗
*/
PUBLIC SI32 FlattenHistogram(UI32 width, UI32 height, void *pInRGB, void *pOutRGB)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height)
		&& (pInRGB != brcNull) && (pOutRGB != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI32 density[256] = { 0 };
		UI32 cdf[256] = { 0 };
		UI32 equalized[256] = { 0 };
		UI08 y;
		UI32 i;
		BrcBGR *pInimage = (BrcBGR*)pInRGB;
		BrcBGR *pOutimage = (BrcBGR*)pOutRGB;
		FP32 initRGB[3][256];
		initConvertRGB2Y(initRGB);

		for (i = 0; i < width * height; i++){
			y = (UI08)Y_luminance(pInimage[i].red, pInimage[i].green, pInimage[i].blue);
			density[y] += 1;
		}

		cdf[0] = density[0];
		for (i = 1; i < 256; i++){
			cdf[i] = density[i] + cdf[i - 1];
		}
		/*
		* The CDF must be normalized to [0, 255]
		* The general histogram equalization formula is :
		* Find CDFmin
		* h(v) = Round (((CDF(v) - CDFmin) / (M*N - CDFmin)) * (L - 1))
		* CLAMP(x)
		* CDFmin is the minimum non-zero value of the CDF
		* M ~ N gives the image's number of pixels, where M is width and N the height
		* L is the number of grey levels used (in most cases, like this one, 256).
		*/
		UI32 cdfMin = 0;
		for (i = 0; i < 256; i++){
			if (cdf[i] > 0){
				cdfMin = cdf[i];
				break;
			}
		}
		SI32 n1; 
		UI32 n2, t;
		FP32 n3;
		for (i = 0; i < 256; i++){
			n1 = cdf[i] - cdfMin;
			n2 = (width*height) - cdfMin;
			n3 = (FP32)n1 / n2;
			t = (UI32)(n3 * 255); //round
			equalized[i] = CLAMP(t);
		}

		UI08 r, g, b;
		UI08 cb, cr;
		for (i = 0; i < width * height; i++){
			r = pInimage[i].red;
			g = pInimage[i].green;
			b = pInimage[i].blue;
			rgbToYCbCr(r, g, b, &y, &cb, &cr);
			y = equalized[y];
			ycbcrToRGB(y, cb, cr, &r, &g, &b);
			pOutimage[i].red = r;
			pOutimage[i].green = g;
			pOutimage[i].blue = b;
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** findMinMaxIntensity(UI08 *max, UI08 *min, UI08 input)
* @brief Find min and max of intensity histogram
* @param[out]	max		Pointer of maximum value
* @param[out]	min		Pointer of minimum value
* @param[in]	input	Data input
* @return		none
*/
PRIVATE void findMinMaxIntensity(UI08 *max, UI08 *min, UI08 input)
{
	if (*min > input){
		*min = input;
	}
	if (*max < input){
		*max = input;
	}
}

/** rgbToYCbCr(UI08 r, UI08 g, UI08 b, UI08 *y, UI08 *cb, UI08 *cr)
* @brief RGB to YCbCr
* @param[in]	r	 Red color
* @param[in]	g	 Green color
* @param[in]	b	 Blue color
* @param[out]	y	 y color
* @param[out]	cb	 cb color
* @param[out]	cr	 cr color
* @return		none
*
*/
PRIVATE void rgbToYCbCr(UI08 r, UI08 g, UI08 b, UI08 *y, UI08 *cb, UI08 *cr)
{
	*y = CLAMP(0 + (g_rgbToYCbCrmatrix[0][0] * r) + (g_rgbToYCbCrmatrix[0][1] * g) + (g_rgbToYCbCrmatrix[0][2] * b));
	*cb = CLAMP(128 + (g_rgbToYCbCrmatrix[1][0] * r) + (g_rgbToYCbCrmatrix[1][1] * g) + (g_rgbToYCbCrmatrix[1][2] * b));
	*cr = CLAMP(128 + (g_rgbToYCbCrmatrix[2][0] * r) + (g_rgbToYCbCrmatrix[2][1] * g) + (g_rgbToYCbCrmatrix[2][2] * b));
}

/** ycbcrToRGB(UI08 y, UI08 cb, UI08 cr, UI08 *r, UI08 *g, UI08 *b)
* @brief RGB to YCbCr
* @param[in]	y	 y color
* @param[in]	cb	 Cb color
* @param[in]	cr	 Cr color
* @param[out]	r	 Red color
* @param[out]	g	 Green color
* @param[out]	b	 Blue color
* @return		none
*
*/
PRIVATE void ycbcrToRGB(UI08 y, UI08 cb, UI08 cr, UI08 *r, UI08 *g, UI08 *b)
{
	*r = CLAMP(y + g_ycbcrToRGBmatrix[0] * (cr - 128));
	*g = CLAMP(y + g_ycbcrToRGBmatrix[1] * (cb - 128) + g_ycbcrToRGBmatrix[2] * (cr - 128));
	*b = CLAMP(y + g_ycbcrToRGBmatrix[3] * (cb - 128));
}

/** initConvertRGB2Y(FP32 initRGB[3][256])
* @brief init parameter to convert RGB to Y
* @param[out]	initRGB	 output parameter
* @return		none
*
*/
PRIVATE void initConvertRGB2Y(FP32 initRGB[3][256]){
	for (SI32 i = 0; i < 256; i++)
	{
		initRGB[0][i] = 0.2989f * i;
		initRGB[1][i] = 0.5870f * i;
		initRGB[2][i] = 0.1140f * i;
	}
}

/** hsvRound(FP64 value)
* @brief Rounding the values
* @param[int]	value	 Value to round
* @return		Value after rounding
*
*/
PRIVATE SI32 hsvRound(FP64 value) {
	FP64 intpart, fractpart;
	fractpart = modf(value, &intpart);
	if ((fabs(fractpart) != 0.5) || ((((SI32)intpart) % 2) != 0))
		return (SI32)(value + (value >= 0 ? 0.5 : -0.5));
	else
		return (SI32)intpart;
}