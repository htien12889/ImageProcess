﻿/**
* @file	BrcImageScaling.c
* @brief	画像拡大縮小ソースファイル
* @author	tfujii
* @date	2016/07/21
* @par		Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
*/

#include <limits.h>
#include <math.h>
#include <xmmintrin.h>  
#include <emmintrin.h> 
#include "BrcImageProcessingCommon.h"
#include "BrcType.h"
#include "BrcMemoryUsage.h"
#include "BrcHardwareFeatures.h"

#define CLIP(x, min, max)					((x) < (min) ? (min) : (max) < (x) ? (max) : (x)) 
#define BI_CUBIC_INTERPOLATION_KERNEL_SIZE	(4)
#define SHARPNESS							(-0.75f)
#define INTER_RESIZE_COEF_BITS				(11)
#define INTER_RESIZE_COEF_SCALE				(1 << INTER_RESIZE_COEF_BITS)
#define SHIFT								(INTER_RESIZE_COEF_BITS*2)
#define DELTA								(1 << (SHIFT - 1))
#define CASTOP(val)							CLIP((((val) + DELTA) >> SHIFT), 0, 255)
#define BLOCK_SCALE_SIZE					16
#define BICUBIC_COEFFS						-0.75f
#define INTER_TAB_SIZE						32
#define AB_SCALES							1024        // 1 << 10
#define INTER_BITS							5
#define SCALE(value)						(1.0f / (value))
#define BICUBIC_INDEX(tab, alpha)			((tab) + (alpha) * 16)
PRIVATE __inline void interpolateCubic(FP32 x, FP32 *coeffs)
{
	coeffs[0] = ((SHARPNESS*(x + 1) - 5 * SHARPNESS)*(x + 1) + 8 * SHARPNESS)*(x + 1) - 4 * SHARPNESS;
	coeffs[1] = ((SHARPNESS + 2)*x - (SHARPNESS + 3))*x*x + 1;
	coeffs[2] = ((SHARPNESS + 2)*(1 - x) - (SHARPNESS + 3))*(1 - x)*(1 - x) + 1;
	coeffs[3] = 1.f - coeffs[0] - coeffs[1] - coeffs[2];
}

PRIVATE void hResize(UI08 **src, FP32 **dst, SI32 count, const SI32 *xofs, const SI16 *alpha,
	SI32 swidth, SI32 dwidth, SI32 cn, SI32 xmin, SI32 xmax);
PRIVATE void vResize(SI32 **src, UI08 *dst, const SI16 *beta, SI32 width);
PRIVATE SI32 sseOp(SI32 **src, UI08 *dst, const SI16 *beta, SI32 width);
PRIVATE void initInterTab1D(FP32 *tab, SI32 tabsz);
PRIVATE void interpolateCubic(FP32 x, FP32 *coeffs);
PRIVATE void initBicubic(FP32 *tab);
PRIVATE void normalScalingImage(UI32 outWidth, UI32 outHeight, UI32 inWidth, UI32  inHeight, UI08 *pOImg, void *pInRGB, SI32 dY, FP32 rW, FP32 rH, FP32* tab);

/** normalScalingImage(UI32 outWidth, UI32 outHeight, UI32 inWidth, UI32  inHeight, UI08 *pOImg, void *pInRGB, SI32 dY, FP32 rW, FP32 rH, FP32* tab)
* @brief		Scalling image by normal way
* @param[in]	outWidth		The width of output image
* @param[in]	outHeight		The height of output image
* @param[in]	inWidth			The width of input image
* @param[in]	inHeight		The heifht of input image
* @param[out]	pOImg			Output image pointer
* @param[in]	pInRGB			Input image pointer
* @param[in]	dY				Coordinate of image follow y-asis
* @param[in]	rW				Width ratio
* @param[in]	rH				Height ratio
* @param[in]	tab				the table of interpolation coefficient
* @return 		void
*/
PRIVATE void normalScalingImage(UI32 outWidth, UI32 outHeight, UI32 inWidth, UI32  inHeight, UI08 *pOImg, void *pInRGB, SI32 dY, FP32 rW, FP32 rH, FP32* tab)
{
	SI32 i = 0, k;
	SI32 positionXScale, positionYScale, x, y, xx, yy, alpha, sstep, sx, sy, m;
	FP32    *tabIndex;
	UI08    *pPixelImg;
	FP32    sum;
	SI32	interpolationVal[RGB_CHANNELS];			
	pOImg = pOImg + outWidth * RGB_CHANNELS * dY;
	UI08*	pIn = (UI08 *)pInRGB;
	FP32 fX, fY;
	for (; dY < (SI32)outHeight; dY++){
		for (i = 0; i < (SI32)outWidth; i++){
			fX = (FP32)((i + 0.5)*(1.0 / rW) - 0.5);
			fY = (FP32)((dY + 0.5)*(1.0 / rH) - 0.5);
			positionXScale = (SI32)(fX * AB_SCALES);
			positionYScale = (SI32)(fY * AB_SCALES);
			x = positionXScale >> INTER_BITS;
			y = positionYScale >> INTER_BITS;
			xx = x >> INTER_BITS;
			yy = y >> INTER_BITS;
			alpha = ((y & (INTER_TAB_SIZE - 1))*INTER_TAB_SIZE + (x & (INTER_TAB_SIZE - 1)));
			sstep = inWidth*RGB_CHANNELS;
			tabIndex = BICUBIC_INDEX(tab, alpha);
			sx = xx - 1, sy = yy - 1;
			pPixelImg = pIn + sy*sstep + sx*RGB_CHANNELS;
			sum = BYTE_RESET;
			if ((0 <= (xx - 1)) && ((xx + 3) < (SI32)inWidth) && (0 <= (yy - 1)) && ((yy + 3) < (SI32)inHeight)){
				for (k = 0; k < RGB_CHANNELS; k++){
					sum = (pPixelImg[0] * tabIndex[0]) + (pPixelImg[RGB_CHANNELS] * tabIndex[1])
						+ (pPixelImg[RGB_CHANNELS * 2] * tabIndex[2]) + (pPixelImg[RGB_CHANNELS * 3] * tabIndex[3]);
					pPixelImg += sstep;
					sum += (pPixelImg[0] * tabIndex[4]) + (pPixelImg[RGB_CHANNELS] * tabIndex[5])
						+ (pPixelImg[RGB_CHANNELS * 2] * tabIndex[6]) + (pPixelImg[RGB_CHANNELS * 3] * tabIndex[7]);
					pPixelImg += sstep;
					sum += (pPixelImg[0] * tabIndex[8]) + (pPixelImg[RGB_CHANNELS] * tabIndex[9])
						+ (pPixelImg[RGB_CHANNELS * 2] * tabIndex[10]) + (pPixelImg[RGB_CHANNELS * 3] * tabIndex[11]);
					pPixelImg += sstep;
					sum += (pPixelImg[0] * tabIndex[12]) + (pPixelImg[RGB_CHANNELS] * tabIndex[13])
						+ (pPixelImg[RGB_CHANNELS * 2] * tabIndex[14]) + (pPixelImg[RGB_CHANNELS * 3] * tabIndex[15]);
					pPixelImg += 1 - sstep * RGB_CHANNELS;
					interpolationVal[k] = (SI32)sum;
				}
				*(pOImg++) = (UI08)CLIP(interpolationVal[0], BYTE_RESET, BYTE_FULLSET);
				*(pOImg++) = (UI08)CLIP(interpolationVal[1], BYTE_RESET, BYTE_FULLSET);
				*(pOImg++) = (UI08)CLIP(interpolationVal[2], BYTE_RESET, BYTE_FULLSET);
			}
			else {
				SI32 x[4], y[4];
				UI08 k;
				if ((sx >= (SI32)inWidth) || (sx + 4 < 0) || (sy >= (SI32)inHeight) || (sy + 4 < 0)){
					pOImg += RGB_CHANNELS;
					continue;
				}
				for (k = 0; k < 4; k++){
					//Get values x outside image
					if ((sx + k) < (SI32)inWidth && (sx + k) >= 0){
						x[k] = (sx + k) * RGB_CHANNELS;
					}
					else {
						if (sx + k >= (SI32)inWidth){
							x[k] = (inWidth - 1) * RGB_CHANNELS;
						}
						else {
							x[k] = BYTE_RESET;
						}
					}
					//Get values y outside image
					if ((sy + k) < (SI32)inHeight && (sy + k) >= 0){
						y[k] = (sy + k);
					}
					else {
						if (sy + k >= (SI32)inHeight){
							y[k] = (inHeight - 1);
						}
						else {
							y[k] = BYTE_RESET;
						}
					}
				}
				SI32 yi;
				UI08 *src;
				for (k = 0; k < RGB_CHANNELS; k++, pIn++, tabIndex -= 16){
					sum = BYTE_RESET;
					for (m = 0; m < 4; m++, tabIndex += 4){
						yi = y[m];
						src = pIn + yi * sstep;
						if (yi < BYTE_RESET){
							continue;
						}
						if (x[0] >= BYTE_RESET){
							sum += (src[x[0]]) * tabIndex[0];
						}
						if (x[1] >= BYTE_RESET){
							sum += (src[x[1]]) * tabIndex[1];
						}
						if (x[2] >= BYTE_RESET){
							sum += (src[x[2]]) * tabIndex[2];
						}
						if (x[3] >= BYTE_RESET){
							sum += (src[x[3]]) * tabIndex[3];
						}
					}
					*(pOImg++) = (UI08)CLIP(sum, BYTE_RESET, BYTE_FULLSET);
				}
				pIn -= RGB_CHANNELS;
			}
		}
	}
}
/** ScalingImage(void *pInRGB, UI32 inWidth, UI32 inHeight, void *pOutRGB, UI32 outWidth, UI32 outHeight)
* @brief		画像の拡大縮小処理
* @param[in]	pInRGB		入力画像
* @param[in]	inWidth		入力画像の幅
* @param[in]	inHeight	入力画像の高さ
* @param[out]	pOutRGB		出力画像
* @param[in]	outWidth	出力画像の幅
* @param[in]	outHeight	出力画像の高さ
* @return		0:成功 0以外:失敗
*/
PUBLIC SI32 ScalingImage(void *pInRGB, UI32 inWidth, UI32 inHeight, void *pOutRGB, UI32 outWidth, UI32 outHeight)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < inWidth) && (0 < inHeight) && (0 < (SI32)outWidth) && (0 < (SI32)outHeight)
		&& (pInRGB != brcNull) && (pOutRGB != brcNull) ? SUCCESS : EINVAL);

	if (err == 0){
		FP32	rW = (FP32)outWidth / (FP32)inWidth;
		FP32	rH = (FP32)outHeight / (FP32)inHeight;

		UI08	*const	pIImg = pInRGB;
		UI08	*pOImg = (UI08*)pOutRGB;

		SI32	dX, dY, k;
		SI32	sX, sY;

		SI32	kSize = BI_CUBIC_INTERPOLATION_KERNEL_SIZE;
		SI32	kSize2 = kSize / 2;

		FP32	fX, fY;

		UI32	sizeOutputImage = outWidth * outHeight * RGB_CHANNELS;
		UI32	sizeBuff = (outWidth * 3 + outHeight)*(sizeof(SI32) + sizeof(SI16) * 4) + sizeof(FP32)*(outWidth * 3) * 4;
		UI32	heightOver;
		FP32	tab[16384];
		initBicubic(tab);
		if (sizeBuff % (outWidth * RGB_CHANNELS)){
			heightOver = (sizeBuff / (outWidth * RGB_CHANNELS)) + 1;
		}
		else {
			heightOver = sizeBuff / (outWidth * RGB_CHANNELS);
		}

		if (heightOver > outHeight){
			dY = 0;
			normalScalingImage(outWidth, outHeight, inWidth, inHeight, pOImg, pInRGB, dY, rW, rH, tab);
		}
		else {
			UI32	buffPos = sizeOutputImage - (outWidth * heightOver * RGB_CHANNELS);

			// Pointer to buffer memory zone
			UI08	*buffer1 = (UI08*)pOutRGB + buffPos;
			UI32	sizeOfBuffer1 = (outWidth * RGB_CHANNELS + outHeight)*(sizeof(SI32) + sizeof(SI16)*kSize);

			SI32	*xOfs = (SI32*)(UI08*)buffer1;
			SI32	*yOfs = xOfs + (outWidth * RGB_CHANNELS);

			SI16	*iAlpha = (SI16*)(yOfs + outHeight);
			SI16	*iBeta = iAlpha + outWidth * RGB_CHANNELS * kSize;

			SI32	PREV_SY[BLOCK_SCALE_SIZE];
			FP32	*rows[BLOCK_SCALE_SIZE] = { 0 };
			const UI08 *sRows[BLOCK_SCALE_SIZE] = { 0 };
			UI32	bufStep = outWidth * RGB_CHANNELS;
			// Pointer to buffer memory zone
			FP32	*buffer2 = (FP32*)(buffer1 + sizeOfBuffer1);
			// sizeOfBuffer2 = sizeof(FP32)*bufstep*ksize;

			SI32	xMin = 0, xMax = outWidth;
			FP32	CBUF[BLOCK_SCALE_SIZE];
			SI32	numLoops = RGB_CHANNELS*kSize;

			/// Calculate cubic function for all pixels of output image

			for (dX = 0; dX < (SI32)outWidth; dX++){
				fX = (FP32)((dX + 0.5)*(1.0 / rW) - 0.5);
				sX = (SI32)floor(fX);
				fX -= sX;

				if (sX < kSize2 - 1){
					xMin = dX + 1;
				}
				if (sX + kSize2 >= (SI32)inWidth){
					xMax = min(xMax, dX);
				}

				for (k = 0, sX *= RGB_CHANNELS; k < RGB_CHANNELS; k++){
					xOfs[dX * RGB_CHANNELS + k] = sX + k;
				}

				interpolateCubic(fX, CBUF);

				for (k = 0; k < kSize; k++){
					iAlpha[dX*RGB_CHANNELS*kSize + k] = (SI16)(CBUF[k] * INTER_RESIZE_COEF_SCALE);
				}
				for (; k < numLoops; k++){
					iAlpha[dX*RGB_CHANNELS*kSize + k] = iAlpha[dX*RGB_CHANNELS*kSize + k - kSize];
				}
			}

			for (dY = 0; dY < (SI32)outHeight; dY++){
				fY = (FP32)((dY + 0.5)*(1.0 / rH) - 0.5);
				sY = (SI32)floor(fY);
				fY -= sY;

				yOfs[dY] = sY;

				interpolateCubic(fY, CBUF);

				for (k = 0; k < kSize; k++){
					iBeta[dY*kSize + k] = (SI16)(CBUF[k] * INTER_RESIZE_COEF_SCALE);
				}
			}

			/// Coding to reuse convolutions, at first by X coordinate then by Y coordinate.

			for (k = 0; k < kSize; k++){
				PREV_SY[k] = -1;
				rows[k] = buffer2 + bufStep*k;
			}

			const SI16 *beta = iBeta;
			SI32 sY0, k0, k1;
			for (dY = 0; dY < (SI32)(outHeight - heightOver); dY++, beta += kSize){
				sY0 = yOfs[dY], k0 = kSize, k1 = 0;

				for (k = 0; k < kSize; k++){
					sY = CLIP(sY0 - kSize2 + 1 + k, 0, (SI32)inHeight - 1);
					for (k1 = max(k1, k); k1 < kSize; k1++){
						if (sY == PREV_SY[k1]){ // if the sy-th row has been computed already, reuse it.
							if (k1 > k){
								memcpy((void*)rows[k], (void*)rows[k1], bufStep*kSize);
							}
							break;
						}
					}
					if (k1 == kSize){
						k0 = min(k0, k); // remember the first row that needs to be computed
					}
					sRows[k] = pIImg + (inWidth * RGB_CHANNELS * sY);
					PREV_SY[k] = sY;
				}

				if (k0 < kSize){
					hResize((UI08**)(sRows + k0), (FP32**)(rows + k0), kSize - k0, xOfs, iAlpha,
						(inWidth * RGB_CHANNELS), (outWidth * RGB_CHANNELS), RGB_CHANNELS, xMin*RGB_CHANNELS, xMax*RGB_CHANNELS);
				}
				vResize((SI32**)rows, (pOImg + outWidth * RGB_CHANNELS * dY), beta, (outWidth * RGB_CHANNELS));
			}
			normalScalingImage(outWidth, outHeight, inWidth, inHeight, pOImg, pInRGB, dY, rW, rH, tab);
		}


	}

#if __tracking
	Memory_Report();
#endif
	return err;
}

/** hResize(UI08 **src, FP32 **dst, SI32 count, const SI32 *xofs, const SI16 *alpha,
*	SI32 swidth, SI32 dwidth, SI32 cn, SI32 xmin, SI32 xmax)
* @brief		horizontal resize
* @param[in]	src		source image data
* @param[out]	dst		destination image data
* @param[in]	count	number of line
* @param[in]	xofs	x-offset
* @param[in]	alpha	list of bicubic by dx
* @param[in]	swidth	width of source image
* @param[in]	dwidth	width of destination image
* @param[in]	cn		RGB channel
* @param[in]	xmin	minimum by dx
* @param[in]	xmax	maximum by dx
* @return 		void
*/
PRIVATE void hResize(UI08 **src, FP32 **dst, SI32 count, const SI32 *xofs, const SI16 *alpha,
	SI32 swidth, SI32 dwidth, SI32 cn, SI32 xmin, SI32 xmax)
{
	UI08 *S;
	SI32 *D;
	SI32 v, j, sx, sxj, k, dX, limit;
	for (k = 0; k < count; k++){
		S = src[k];
		D = (SI32*)dst[k];
		dX = 0, limit = xmin;
		for (;;){
			for (; dX < limit; dX++, alpha += 4){
				sx = xofs[dX] - cn;
				v = 0;
				for (j = 0; j < 4; j++){
					sxj = sx + j*cn;
					if ((UI08)sxj >= (UI08)swidth){
						while (sxj < 0){
							sxj += cn;
						}
						while (sxj >= swidth){
							sxj -= cn;
						}
					}
					v += S[sxj] * alpha[j];
				}
				D[dX] = v;
			}
			if (limit == dwidth){
				break;
			}
			for (; dX < xmax; dX++, alpha += 4){
				sx = xofs[dX];
				D[dX] = S[sx - cn] * alpha[0] + S[sx] * alpha[1] +
					S[sx + cn] * alpha[2] + S[sx + cn * 2] * alpha[3];
			}
			limit = dwidth;
		}
		alpha -= dwidth * 4;
	}
}

/** vResize(const SI32 **src, UI08 *dst, const SI16 *beta, SI32 width)
* @brief		vertical resize
* @param[in]	src		source image data
* @param[out]	dst		destination image data
* @param[in]	beta	list of bicubic by dy
* @param[in]	width	width of destination image
* @return 		void
*/
PRIVATE void vResize(SI32 **src, UI08 *dst, const SI16 *beta, SI32 width)
{
	SI32 b0 = beta[0], b1 = beta[1], b2 = beta[2], b3 = beta[3];
	const SI32 *S0 = src[0], *S1 = src[1], *S2 = src[2], *S3 = src[3];

	SI32 x = sseOp(src, dst, beta, width);
	for (; x < width; x++){
		dst[x] = CASTOP(S0[x] * b0 + S1[x] * b1 + S2[x] * b2 + S3[x] * b3);
	}
}

/** sseOp(const SI32** src, UI08 *dst, const SI16 *beta, SI32 width)
* @brief		vertical resize
* @param[in]	src		source image data
* @param[out]	dst		destination image data
* @param[in]	beta	list of bicubic by dy
* @param[in]	width	width of destination image;
* @return		0:Un-support SSE 0以外:成功
*/
PRIVATE SI32 sseOp(SI32 **src, UI08 *dst, const SI16 *beta, SI32 width)
{
	// Check hardware support SSE2
	if (!CheckHardwareSupport(CPU_SSE2)){
		return 0;
	}

	SI32	numLoops = width - 8;
	const	SI32 *S0 = src[0], *S1 = src[1], *S2 = src[2], *S3 = src[3];
	SI32	x = 0;
	FP32	scale = 1.f / (INTER_RESIZE_COEF_SCALE*INTER_RESIZE_COEF_SCALE);
	__m128	b0 = _mm_set1_ps(beta[0] * scale), b1 = _mm_set1_ps(beta[1] * scale),
		b2 = _mm_set1_ps(beta[2] * scale), b3 = _mm_set1_ps(beta[3] * scale);

	if ((((size_t)S0 | (size_t)S1 | (size_t)S2 | (size_t)S3) & 15) == 0){	// 16-byte aligned
		__m128i	x0, x1, y0, y1;
		__m128	s0, s1, f0, f1;
		for (; x <= numLoops; x += 8) {
			x0 = _mm_load_si128((const __m128i*)(S0 + x));
			x1 = _mm_load_si128((const __m128i*)(S0 + x + 4));
			y0 = _mm_load_si128((const __m128i*)(S1 + x));
			y1 = _mm_load_si128((const __m128i*)(S1 + x + 4));

			s0 = _mm_mul_ps(_mm_cvtepi32_ps(x0), b0);
			s1 = _mm_mul_ps(_mm_cvtepi32_ps(x1), b0);
			f0 = _mm_mul_ps(_mm_cvtepi32_ps(y0), b1);
			f1 = _mm_mul_ps(_mm_cvtepi32_ps(y1), b1);
			s0 = _mm_add_ps(s0, f0);
			s1 = _mm_add_ps(s1, f1);

			x0 = _mm_load_si128((const __m128i*)(S2 + x));
			x1 = _mm_load_si128((const __m128i*)(S2 + x + 4));
			y0 = _mm_load_si128((const __m128i*)(S3 + x));
			y1 = _mm_load_si128((const __m128i*)(S3 + x + 4));

			f0 = _mm_mul_ps(_mm_cvtepi32_ps(x0), b2);
			f1 = _mm_mul_ps(_mm_cvtepi32_ps(x1), b2);
			s0 = _mm_add_ps(s0, f0);
			s1 = _mm_add_ps(s1, f1);
			f0 = _mm_mul_ps(_mm_cvtepi32_ps(y0), b3);
			f1 = _mm_mul_ps(_mm_cvtepi32_ps(y1), b3);
			s0 = _mm_add_ps(s0, f0);
			s1 = _mm_add_ps(s1, f1);

			x0 = _mm_cvtps_epi32(s0);
			x1 = _mm_cvtps_epi32(s1);

			x0 = _mm_packs_epi32(x0, x1);
			_mm_storel_epi64((__m128i*)(dst + x), _mm_packus_epi16(x0, x0));
		}
	}
	else{	// 16-byte unaligned, (inWidth % 4) != 0
		__m128i	x0, x1, y0, y1;
		__m128	s0, s1, f0, f1;
		for (; x <= numLoops; x += 8) {
			x0 = _mm_loadu_si128((const __m128i*)(S0 + x));
			x1 = _mm_loadu_si128((const __m128i*)(S0 + x + 4));
			y0 = _mm_loadu_si128((const __m128i*)(S1 + x));
			y1 = _mm_loadu_si128((const __m128i*)(S1 + x + 4));

			s0 = _mm_mul_ps(_mm_cvtepi32_ps(x0), b0);
			s1 = _mm_mul_ps(_mm_cvtepi32_ps(x1), b0);
			f0 = _mm_mul_ps(_mm_cvtepi32_ps(y0), b1);
			f1 = _mm_mul_ps(_mm_cvtepi32_ps(y1), b1);
			s0 = _mm_add_ps(s0, f0);
			s1 = _mm_add_ps(s1, f1);

			x0 = _mm_loadu_si128((const __m128i*)(S2 + x));
			x1 = _mm_loadu_si128((const __m128i*)(S2 + x + 4));
			y0 = _mm_loadu_si128((const __m128i*)(S3 + x));
			y1 = _mm_loadu_si128((const __m128i*)(S3 + x + 4));

			f0 = _mm_mul_ps(_mm_cvtepi32_ps(x0), b2);
			f1 = _mm_mul_ps(_mm_cvtepi32_ps(x1), b2);
			s0 = _mm_add_ps(s0, f0);
			s1 = _mm_add_ps(s1, f1);
			f0 = _mm_mul_ps(_mm_cvtepi32_ps(y0), b3);
			f1 = _mm_mul_ps(_mm_cvtepi32_ps(y1), b3);
			s0 = _mm_add_ps(s0, f0);
			s1 = _mm_add_ps(s1, f1);

			x0 = _mm_cvtps_epi32(s0);
			x1 = _mm_cvtps_epi32(s1);

			x0 = _mm_packs_epi32(x0, x1);
			_mm_storel_epi64((__m128i*)(dst + x), _mm_packus_epi16(x0, x0));
		}
	}
	return x;
}

/** initInterTab1D(FP32* tab, SI32 tabsz)
* @brief		initialize inter tab
* @param[in]	tab		inter tab
* @param[in]	tabsz	inter tab size
* @return 		none
*/
PRIVATE void initInterTab1D(FP32 *tab, SI32 tabsz)
{
	FP32 scale = SCALE(tabsz);
	SI32 i;
	for (i = 0; i < tabsz; i++, tab += 4){
		interpolateCubic(i * scale, tab);
	}
}

/** initBicubic(FP32* tab, SI32 tabsz)
* @brief		initialize bicubic
* @param[in]	tab		inter tab
* @return 		none
*/
PRIVATE void initBicubic(FP32 *tab)
{
	FP32 tabs[128];
	initInterTab1D(tabs, INTER_TAB_SIZE);
	SI32 i, j, k1, k2;
	SI32 ksize = 4;
	FP32 vy, v;
	for (i = 0; i < INTER_TAB_SIZE; i++){
		for (j = 0; j < INTER_TAB_SIZE; j++, tab += ksize * ksize){
			for (k1 = 0; k1 < ksize; k1++){
				vy = tabs[(i * ksize) + k1];
				for (k2 = 0; k2 < ksize; k2++){
					v = vy * tabs[(j * ksize) + k2];
					tab[(k1 * ksize) + k2] = v;
				}
			}
		}
	}
}
