﻿/** 
 * @file 	BrcImageCorrectGamma.c
 * @brief 	ガンマ補正ソースファイル
 * @author 	tfujii
 * @date 	2016/08/05
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */

#include <math.h>
#include "BrcType.h"
#include "BrcImageProcessingCommon.h"
#include "BrcMemoryUsage.h"


#define LUT_NUM			256
#define EXPONENT_VALUE(value)  (FP64)(1.0 / (FP64)value)
#define MAX_VALUE(value) (FP64)((value) - 1)


PRIVATE void makeGammaLUT(UI32 *lut, UI32 num, FP64 gammaValue);

/** CorrectGamma(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, UI32 gammaValue)
 * @brief		ガンマ補正
 * @param[in]	width		画像幅
 * @param[in]	height		画像高さ
 * @param[in]	pInRGB		入力画像領域のポインタ
 * @param[out]	pOutRGB		出力画像領域のポインタ
 * @param[in]	gammaValue	ガンマ値
 * @return		0:成功 0以外:失敗
 */
PUBLIC SI32 CorrectGamma(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, FP64 gammaValue)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height)
		&& (pInRGB != brcNull) && (pOutRGB != brcNull) && (gammaValue != 0) ? SUCCESS : EINVAL);
	if (err == 0){
		UI32	lut[LUT_NUM];								/// ルックアップテーブル
		UI32	num = height * width * RGB_CHANNELS;		/// 画像のサイズ(要素数)
		UI08	*pIn = (UI08*)pInRGB;						/// 入力画像の走査用ポインタ
		UI08	*pOut = (UI08*)pOutRGB;						/// 出力画像の走査用ポインタ
		UI08	*pInEnd = (UI08*)pInRGB + num;				/// 画像の終了を表すアドレスを記憶

		makeGammaLUT(lut, LUT_NUM, gammaValue);

		while (pIn != pInEnd){
			*(pOut++) = lut[*(pIn++)];
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** makeGammaLUT(UI32 *lut, UI32 num, FP64 gammaValue, UI32 maxValue)
* @brief		ガンマ補正用ルックアップテーブルを生成
* @param[out]	lut			ルックアップテーブル
* @param[in]	num			ピクセルビット値の上限(そのままルックアップテーブルの長さになる)
* @param[in]	gammaValue	ガンマ値
*/
PRIVATE void makeGammaLUT(UI32 *lut, UI32 num, FP64 gammaValue)
{
	UI32	i;
	FP64	expValue = EXPONENT_VALUE(gammaValue);
	FP64	maxValue = MAX_VALUE(num);

	for (i = 0; i < num; ++i){
		lut[i] = (UI32)(pow((FP64)i / maxValue, expValue) * maxValue);
	}
}
