﻿/**
 * @file 	BrcImageSepiaTone.c
 * @brief 	セピア調化ソースファイル
 * @author 	etsuchida
 * @date 	2016/08/01
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#include "BrcType.h"
#include "BrcImageProcessingCommon.h"
#include "BrcMemoryUsage.h"

PRIVATE void rgbToY(FP32 r, FP32 g, FP32 b, FP32 *y);
PRIVATE void yToSepiaRGB(FP32 *r, FP32 *g, FP32 *b, FP32 y);
PRIVATE void store(UI08 r, UI08 g, UI08 b, UI08 *pOut);

#define RGB_TO_GRAYSCALE(r, g, b) (FP32)(0.299*(r) + 0.587*(g) + 0.114*(b))
#define SEPIA_RGB_R 250
#define SEPIA_RGB_G 180
#define SEPIA_RGB_B 110

/** ConvertSepiaTone(UI32 width, UI32 height, void *pInRGB, void *pOutRGB)
* @brief セピア調化
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInRGB		入力画像領域のポインタ
* @param[out]	pOutRGB		出力画像領域のポインタ
* @return		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertSepiaTone(UI32 width, UI32 height, void *pInRGB, void *pOutRGB)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height)
		&& (pInRGB != brcNull) && (pOutRGB != brcNull) ? SUCCESS : EINVAL);

	if (err == 0){

		//! 画素走査用
		UI64 i;
		//! RGB、輝度値
		FP32 r, g, b, y;

		UI08 *pIn = (UI08*)pInRGB;
		UI08 *pOut = (UI08*)pOutRGB;

		UI64 imgDataSize = width * height;

		/// 画像全体を走査
		for (i = 0; i < imgDataSize; i++){
			b = *(pIn);
			g = *(pIn + 1);
			r = *(pIn + 2);

			/// RGBを輝度に変換
			rgbToY(r, g, b, &y);

			/// 輝度をセピア調化
			yToSepiaRGB(&r, &g, &b, y);

			/// 出力用データ書き込み
			store((UI08)r, (UI08)g, (UI08)b, pOut);

			//次の画素を指す
			pIn += RGB_CHANNELS;
			pOut += RGB_CHANNELS;
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}


/** rgbToY(FP32 r, FP32 g, FP32 b, FP32 *y)
* @brief RGBを輝度に変換
* @param[in]	r				R成分
* @param[in]	g				G成分
* @param[in]	b				B成分
* @param[out]	y				輝度
*/
PRIVATE void rgbToY(FP32 r, FP32 g, FP32 b, FP32 *y)
{
	/// 変換式参考http://www.sm.rim.or.jp/~shishido/yuv.html
	*y = RGB_TO_GRAYSCALE(r, g, b);

	/// 輝度値が上限を超えていたら上限値にしておく
	if (*y > BYTE_FULLSET) *y = BYTE_FULLSET;
}

/** yToSepiaRGB(FP32 *r, FP32 *g, FP32 *b, FP32 y)
* @brief	輝度データを元にセピア調化したRGBに変換
* @param[out]	r				R成分
* @param[out]	g				G成分
* @param[out]	b				B成分
* @param[in]	y				輝度
*/
PRIVATE void yToSepiaRGB(FP32 *r, FP32 *g, FP32 *b, FP32 y)
{
	/// 参考http://homepage2.nifty.com/tsugu/sotuken/ronbun/sec3-2.html
	*r = (FP32)((y / BYTE_FULLSET) * SEPIA_RGB_R);
	*g = (FP32)((y / BYTE_FULLSET) * SEPIA_RGB_G);
	*b = (FP32)((y / BYTE_FULLSET) * SEPIA_RGB_B);
}

/**  store(UI08 r, UI08 g, UI08 b, UI08 *pOut)
* @brief 出力用データ書き込み
* @param[in]	r				R成分
* @param[in]	g				G成分
* @param[in]	b				B成分
* @param[out]	pOut			出力画像領域のポインタ
*/
PRIVATE void store(UI08 r, UI08 g, UI08 b, UI08 *pOut)
{
	/// 3チャンネル分書き込み
	*pOut = b;
	*(pOut + 1) = g;
	*(pOut + 2) = r;
}