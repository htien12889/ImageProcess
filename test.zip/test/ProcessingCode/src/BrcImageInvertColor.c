﻿/**
 * @file 	BrcImageInvertColor.c
 * @brief 	ネガポジ変換ソースファイル
 * @author 	rfukukita
 * @date 	2016/06/22
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#include "BrcType.h"
#include "BrcImageProcessingCommon.h"
#include "BrcMemoryUsage.h"

#define PROCESS_UNIT_4_BYTES(width, height) (SI32)((width) * (height) * 3 / 4)

/** InvertColor(UI32 width, UI32 height, void *pInRGB, void *pOutRGB)
 * @brief ネガポジ反転
 * @param[in]	width		画像幅
 * @param[in]	height		画像高さ
 * @param[in]	pInRGB		入力画像領域のポインタ
 * @param[out]	pOutRGB		出力画像領域のポインタ
 * @return		0:成功 0以外:失敗
 */
PUBLIC SI32 InvertColor(UI32 width, UI32 height, void *pInRGB, void *pOutRGB)
{
#if __tracking
	Memory_Start();
#endif
	UI64 index;

	SI32	err = ((0 < width) && (0 < height)
				&& (pInRGB != brcNull) && (pOutRGB != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		// 4Byte単位での処理（高速化版）
		UI64 roopNum = PROCESS_UNIT_4_BYTES(width, height);
		UI32 *pInRGB32;
		UI32 *pOutRGB32;
		pInRGB32 = pInRGB;
		pOutRGB32 = pOutRGB;

		for (index = 0; index < roopNum; index++){
			*pOutRGB32 = ~(*pInRGB32);
			pInRGB32++;
			pOutRGB32++;
		}

		if (width % 4){				/// 4Byte処理の端数が出た場合
			UI08	*pInRGB08	= (UI08*)pInRGB32;
			UI08	*pOutRGB08	= (UI08*)pOutRGB32;
			for (index = 0; index < (width % 4); index++){
				*pOutRGB08 = ~(*pInRGB08);
				pInRGB08++;
				pOutRGB08++;
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}
