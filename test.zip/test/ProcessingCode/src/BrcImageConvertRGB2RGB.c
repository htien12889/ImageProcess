﻿/**
* @file 	BrcImageConvertRGB2RGB.c
* @brief 	RGB変換シースファイル
* @author 	kyoshitake
* @date 	2016/06/22
* @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
*/
#include "BrcType.h"
#include "BrcImageProcessingCommon.h"
//#include "BrcMemoryUsage.h"

#define TRUE	1
#define FALSE	0
#define BITSHIFT_VALUE_2 	2
#define BITSHIFT_VALUE_3 	3
#define BITSHIFT_VALUE_5 	5
#define BITSHIFT_VALUE_8 	8
#define BITSHIFT_VALUE_11 	11


/** ConvertRGB_RGBA(UI32 width, UI32 height, void *pInData, void *pOutData, brcBool rgbReversal)
* @brief RGB->RGBA変換
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInData		入力画像領域のポインタ
* @param[out]	pOutData	出力画像領域のポインタ
* @param[in]	rgbReversal	RGB反転 true:BGR/ABGR false:RGB/RGBA
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertRGB_RGBA(UI32 width, UI32 height, void *pInData, void *pOutData, brcBool rgbReversal)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInData != brcNull) && (pOutData != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInData;
		UI08	*pOutByte = (UI08*)pOutData;
		/*UI32	offsetRGB_R = (rgbReversal ? BGR_OFFSET_R : RGB_OFFSET_R);
		UI32	offsetRGB_G = (rgbReversal ? BGR_OFFSET_G : RGB_OFFSET_G);
		UI32	offsetRGB_B = (rgbReversal ? BGR_OFFSET_B : RGB_OFFSET_B);*/
		UI32	offsetRGBA_R = (rgbReversal ? ABGR_OFFSET_R : RGBA_OFFSET_R);
		UI32	offsetRGBA_G = (rgbReversal ? ABGR_OFFSET_G : RGBA_OFFSET_G);
		UI32	offsetRGBA_B = (rgbReversal ? ABGR_OFFSET_B : RGBA_OFFSET_B);
		UI32	offsetRGBA_A = (rgbReversal ? ABGR_OFFSET_A : RGBA_OFFSET_A);
		UI32	max = width * height;
		UI32	index;
		UI08	r, g, b;
		for (index = 0; index < max; index++, pInByte += PIXEL_BYTE_RGB, pOutByte += PIXEL_BYTE_RGBA){
			r = (*(pInByte + BGR_OFFSET_R));
			g = (*(pInByte + BGR_OFFSET_G));
			b = (*(pInByte + BGR_OFFSET_B));
			*(pOutByte + offsetRGBA_R) = r;
			*(pOutByte + offsetRGBA_G) = g;
			*(pOutByte + offsetRGBA_B) = b;
			*(pOutByte + offsetRGBA_A) = (UI08)BYTE_FULLSET;
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertRGB_RGB565(UI32 width, UI32 height, void *pInData, void *pOutData, brcBool rgbReversal, brcBool bigEndian)
* @brief RGB->RGB565変換
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInData		入力画像領域のポインタ
* @param[out]	pOutData	出力画像領域のポインタ
* @param[in]	rgbReversal	RGB反転 true:BGR false:RGB
* @param[in]	bigEndian	エンディアン指定 true:ビッグエンディアン false:リトルエンディアン
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertRGB_RGB565(UI32 width, UI32 height, void *pInData, void *pOutData, brcBool rgbReversal, brcBool bigEndian)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInData != brcNull) && (pOutData != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInData;
		UI08	*pOutByte = (UI08*)pOutData;
		UI32	offsetRGB_R = (rgbReversal ? BGR_OFFSET_R : RGB_OFFSET_R);
		UI32	offsetRGB_G = (rgbReversal ? BGR_OFFSET_G : RGB_OFFSET_G);
		UI32	offsetRGB_B = (rgbReversal ? BGR_OFFSET_B : RGB_OFFSET_B);
		UI32	msb = (bigEndian ? FALSE : TRUE);
		UI32	lsb = (bigEndian ? TRUE : FALSE);
		UI32	max = width * height;
		UI32	index;
		UI08	r, g, b;
		UI16	value;
		for (index = 0; index < max; index++, pInByte += PIXEL_BYTE_RGB, pOutByte += PIXEL_BYTE_RGB565){
			r = (*(pInByte + offsetRGB_R));
			g = (*(pInByte + offsetRGB_G));
			b = (*(pInByte + offsetRGB_B));
			// UI16	value = (((UI16)r) << BITSHIFT_RGB565_R) + (((UI16)g) << BITSHIFT_RGB565_G) + (((UI16)b) << BITSHIFT_RGB565_B);
			value = (((UI16)r >> BITSHIFT_VALUE_3) << BITSHIFT_VALUE_11) |
				(((UI16)g >> BITSHIFT_VALUE_2) << BITSHIFT_VALUE_5) | ((UI16)b >> BITSHIFT_VALUE_3);
			*(pOutByte + msb) = value >> BITSHIFT_VALUE_8;
			*(pOutByte + lsb) = value & 0xff;
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertRGBA_RGB(UI32 width, UI32 height, void *pInData, void *pOutData, brcBool rgbReversal)
* @brief RGBA->RGB変換
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInData		入力画像領域のポインタ
* @param[out]	pOutData	出力画像領域のポインタ
* @param[in]	rgbReversal	RGB反転 true:BGR/ABGR false:RGB/RGBA
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertRGBA_RGB(UI32 width, UI32 height, void *pInData, void *pOutData, brcBool rgbReversal)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInData != brcNull) && (pOutData != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInData;
		UI08	*pOutByte = (UI08*)pOutData;
		UI32	offsetRGB_R = (rgbReversal ? BGR_OFFSET_R : RGB_OFFSET_R);
		UI32	offsetRGB_G = (rgbReversal ? BGR_OFFSET_G : RGB_OFFSET_G);
		UI32	offsetRGB_B = (rgbReversal ? BGR_OFFSET_B : RGB_OFFSET_B);
		/*UI32	offsetRGBA_R = (rgbReversal ? ABGR_OFFSET_R : RGBA_OFFSET_R);
		UI32	offsetRGBA_G = (rgbReversal ? ABGR_OFFSET_G : RGBA_OFFSET_G);
		UI32	offsetRGBA_B = (rgbReversal ? ABGR_OFFSET_B : RGBA_OFFSET_B);
		UI32	offsetRGBA_A = (rgbReversal ? ABGR_OFFSET_A : RGBA_OFFSET_A);*/
		UI32	max = width * height;
		UI32	index;
		UI08	r, g, b;
		for (index = 0; index < max; index++, pInByte += PIXEL_BYTE_RGBA, pOutByte += PIXEL_BYTE_RGB){
			r = (*(pInByte + ABGR_OFFSET_R));
			g = (*(pInByte + ABGR_OFFSET_G));
			b = (*(pInByte + ABGR_OFFSET_B));
			*(pOutByte + offsetRGB_R) = r;
			*(pOutByte + offsetRGB_G) = g;
			*(pOutByte + offsetRGB_B) = b;
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertRGBA_RGB565(UI32 width, UI32 height, void *pInData, void *pOutData, brcBool rgbReversal, brcBool bigEndian)
* @brief RGBA->RGB565変換
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInData		入力画像領域のポインタ
* @param[out]	pOutData	出力画像領域のポインタ
* @param[in]	rgbReversal	RGB反転 true:BGR/ABGR false:RGB/RGBA
* @param[in]	bigEndian	エンディアン指定 true:ビッグエンディアン false:リトルエンディアン
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertRGBA_RGB565(UI32 width, UI32 height, void *pInData, void *pOutData, brcBool rgbReversal, brcBool bigEndian)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInData != brcNull) && (pOutData != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInData;
		UI08	*pOutByte = (UI08*)pOutData;
		UI32	offsetRGBA_R = (rgbReversal ? ABGR_OFFSET_R : RGBA_OFFSET_R);
		UI32	offsetRGBA_G = (rgbReversal ? ABGR_OFFSET_G : RGBA_OFFSET_G);
		UI32	offsetRGBA_B = (rgbReversal ? ABGR_OFFSET_B : RGBA_OFFSET_B);
		UI32	msb = (bigEndian ? FALSE : TRUE);
		UI32	lsb = (bigEndian ? TRUE : FALSE);
		UI32	max = width * height;
		UI32	index;
		UI08	r, g, b;
		UI16	value;
		for (index = 0; index < max; index++, pInByte += PIXEL_BYTE_RGBA, pOutByte += PIXEL_BYTE_RGB565){
			r = (*(pInByte + offsetRGBA_R));
			g = (*(pInByte + offsetRGBA_G));
			b = (*(pInByte + offsetRGBA_B));
			// UI16	value = (((UI16)r) << BITSHIFT_RGB565_R) + (((UI16)g) << BITSHIFT_RGB565_G) + (((UI16)b) << BITSHIFT_RGB565_B);
			value = (((UI16)r >> BITSHIFT_VALUE_3) << BITSHIFT_VALUE_11) |
				(((UI16)g >> BITSHIFT_VALUE_2) << BITSHIFT_VALUE_5) | ((UI16)b >> BITSHIFT_VALUE_3);
			*(pOutByte + msb) = value >> BITSHIFT_VALUE_8;
			*(pOutByte + lsb) = value & 0xff;
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertRGB565_RGB(UI32 width, UI32 height, void *pInData, void *pOutData, brcBool rgbReversal, brcBool bigEndian)
* @brief RGB565->RGB変換
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInData		入力画像領域のポインタ
* @param[out]	pOutData	出力画像領域のポインタ
* @param[in]	rgbReversal	RGB反転 true:BGR false:RGB
* @param[in]	bigEndian	エンディアン指定 true:ビッグエンディアン false:リトルエンディアン
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertRGB565_RGB(UI32 width, UI32 height, void *pInData, void *pOutData, brcBool rgbReversal, brcBool bigEndian)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInData != brcNull) && (pOutData != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInData;
		UI08	*pOutByte = (UI08*)pOutData;
		UI32	offsetRGB_R = (rgbReversal ? BGR_OFFSET_R : RGB_OFFSET_R);
		UI32	offsetRGB_G = (rgbReversal ? BGR_OFFSET_G : RGB_OFFSET_G);
		UI32	offsetRGB_B = (rgbReversal ? BGR_OFFSET_B : RGB_OFFSET_B);
		UI32	MSB = (bigEndian ? FALSE : TRUE);
		UI32	LSB = (bigEndian ? TRUE : FALSE);
		UI32	max = width * height;
		UI32	index;
		UI08	r, g, b;
		UI16	value;
		for (index = 0; index < max; index++, pInByte += PIXEL_BYTE_RGB565, pOutByte += PIXEL_BYTE_RGB){
			/*UI16	value = ((*(pInByte + MSB)) << 8) + (*(pInByte + LSB));
			UI08	r = (UI08)((value >> BITSHIFT_RGB565_R)&BITMASK_RGB565_R);
			UI08	g = (UI08)((value >> BITSHIFT_RGB565_G)&BITMASK_RGB565_G);
			UI08	b = (UI08)((value >> BITSHIFT_RGB565_B)&BITMASK_RGB565_B);*/
			value = ((*(pInByte + MSB)) << BITSHIFT_VALUE_8) + (*(pInByte + LSB));
			r = (UI08)((value & 0xF800) >> BITSHIFT_VALUE_8);
			g = (UI08)((value & 0x07E0) >> BITSHIFT_VALUE_3);
			b = (UI08)((value & 0x001F) << BITSHIFT_VALUE_3);

			*(pOutByte + offsetRGB_R) = r;
			*(pOutByte + offsetRGB_G) = g;
			*(pOutByte + offsetRGB_B) = b;
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** ConvertRGB565_RGBA(UI32 width, UI32 height, void *pInData, void *pOutData, brcBool rgbReversal, brcBool bigEndian)
* @brief RGB565->RGBA変換
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInData		入力画像領域のポインタ
* @param[out]	pOutData	出力画像領域のポインタ
* @param[in]	rgbReversal	RGB反転 true:BGR/ABGR false:RGB/RGBA
* @param[in]	bigEndian	エンディアン指定 true:ビッグエンディアン false:リトルエンディアン
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 ConvertRGB565_RGBA(UI32 width, UI32 height, void *pInData, void *pOutData, brcBool rgbReversal, brcBool bigEndian)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height) && (pInData != brcNull) && (pOutData != brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08	*pInByte = (UI08*)pInData;
		UI08	*pOutByte = (UI08*)pOutData;
		UI32	offsetRGBA_R = (rgbReversal ? ABGR_OFFSET_R : RGBA_OFFSET_R);
		UI32	offsetRGBA_G = (rgbReversal ? ABGR_OFFSET_G : RGBA_OFFSET_G);
		UI32	offsetRGBA_B = (rgbReversal ? ABGR_OFFSET_B : RGBA_OFFSET_B);
		UI32	offsetRGBA_A = (rgbReversal ? ABGR_OFFSET_A : RGBA_OFFSET_A);
		UI32	msb = (bigEndian ? FALSE : TRUE);
		UI32	lsb = (bigEndian ? TRUE : FALSE);
		UI32	max = width * height;
		UI32	index;
		UI08	r, g, b;
		UI16	value;
		for (index = 0; index < max; index++, pInByte += PIXEL_BYTE_RGB565, pOutByte += PIXEL_BYTE_RGBA){
			/*UI16	value = ((*(pInByte + MSB)) << 8) + (*((pInByte + LSB)));
			UI08	r = (UI08)((value >> BITSHIFT_RGB565_R)&BITMASK_RGB565_R);
			UI08	g = (UI08)((value >> BITSHIFT_RGB565_G)&BITMASK_RGB565_G);
			UI08	b = (UI08)((value >> BITSHIFT_RGB565_B)&BITMASK_RGB565_B);*/
			value = ((*(pInByte + msb)) << BITSHIFT_VALUE_8) + (*(pInByte + lsb));
			r = (UI08)((value & 0xF800) >> BITSHIFT_VALUE_8);
			g = (UI08)((value & 0x07E0) >> BITSHIFT_VALUE_3);
			b = (UI08)((value & 0x001F) << BITSHIFT_VALUE_3);

			*(pOutByte + offsetRGBA_R) = r;
			*(pOutByte + offsetRGBA_G) = g;
			*(pOutByte + offsetRGBA_B) = b;
			*(pOutByte + offsetRGBA_A) = (UI08)BYTE_FULLSET;
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}
