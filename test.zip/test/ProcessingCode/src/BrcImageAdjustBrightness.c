﻿/**
* @file 	BrcImageAdjustBrightness.c
* @brief 	明るさ調整(HSV版,YUV版)ソースファイル
* @author 	etsuchida
* @date 	2016/07/26
* @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
*/
#include "BrcType.h"
#include "BrcImageProcessingCommon.h"
#include "BrcMemoryUsage.h"

PRIVATE void addBrightnessIncrement(FP32 *brigthness, SI32 brightnessIncrement, UI08 upperLimit);
PRIVATE void addBrightnessIncrementHSV(SI32 *brigthness, SI32 brightnessIncrement, UI08 upperLimit);
PRIVATE UI08 adjustLimit(FP32 num, UI08 upperLimit);
PRIVATE void store(UI08 r, UI08 g, UI08 b, UI08 *pOut);
PRIVATE void rgbToYUV(FP32 *yR, FP32 *uG, FP32 *vB, UI08 *pIn, FP32 initRGB[9][256]);
PRIVATE void yuvToRGB(FP32 *yR, FP32 *uG, FP32 *vB, FP32 initYUV[4][256]);
PRIVATE void initConvertRGBYUV(FP32 initRGB[9][256], FP32 initYUV[4][256]);
PRIVATE void HSV2RGB(FP32* src, FP32* dst, UI32 n);

/** @def UpperLimitOfYUV
* YUVの上限値
*/
#define UpperLimitOfYUV				255

/** @def UpperLimitOfV
* V(HSV)の上限値
*/
#define UpperLimitOfV				100
#define H_RANGE						180
#define HSV_SHIFT					 12
#define BLOCK_SIZE					256
#define	VALUE_1						1.f
#define	VALUE_2						255.f
#define SCALE_VALUE					6.f / 180
#define MAX_VALUE					255
#define CONVERT_RGB_TO_Y(R, G, B)	(FP32)(initRGB[0][(R)]  + initRGB[1][(G)] + initRGB[2][(B)])
#define CONVERT_RGB_TO_U(R, G, B)	(FP32)(-initRGB[3][(R)] - initRGB[4][(G)] + initRGB[5][(B)] + 128)
#define CONVERT_RGB_TO_V(R, G, B)	(FP32)(initRGB[5][(R)]  - initRGB[7][(G)] - initRGB[8][(B)] + 128)
#define CONVERT_YUV_TO_R(Y, U, V)	(FP32)((Y) + initYUV[0][(V)])
#define CONVERT_YUV_TO_G(Y, U, V)	(FP32)((Y) - initYUV[1][(U)] - initYUV[2][(V)])
#define CONVERT_YUV_TO_B(Y, U, V)	(FP32)((Y) + initYUV[3][(U)])
#define FAST_CAST_8U(t)				((-256 <= (t) && (t) <= 512) ? Saturate8u[(t) + 256] : 0)
#define CALC_MIN_8U(a,b)			(a) -= FAST_CAST_8U((a) - (b))
#define CALC_MAX_8U(a,b)			(a) += FAST_CAST_8U((b) - (a))
#define COMPARE_TWO_VALUES(a,b)		((a) == (b) ? -1 : 0)
#define MIN(a,b)					(((a) < (b)) ? (a) : (b))
#define SECTOR_DATA_VALUE			{ { 1, 3, 0 }, { 1, 0, 2 }, { 3, 0, 1 }, { 0, 2, 1 }, { 0, 1, 3 }, { 2, 1, 0 } }

const UI08 Saturate8u[] =
{
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
	16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31,
	32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47,
	48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63,
	64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79,
	80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95,
	96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111,
	112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127,
	128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143,
	144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159,
	160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175,
	176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191,
	192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207,
	208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223,
	224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239,
	240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
	255
};

//各計算式は下記参考
//YUV変換式　http://www.sm.rim.or.jp/~shishido/yuv.html
//HSV変換式　http://www.peko-step.com/tool/hslrgb.html#ppick1

/** AdjustBrightnessHSV(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, SI32 brightnessIncrement)
* @brief 明るさ調整1
* @param[in]	width				画像幅
* @param[in]	height				画像高さ
* @param[in]	pInRGB				入力画像領域のポインタ
* @param[out]	pOutRGB				出力画像領域のポインタ
* @param[in]	brightnessIncrement	明るさ調整値
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 AdjustBrightnessHSV(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, SI32 brightnessIncrement)
{
#if __tracking
	Memory_Start();
#endif
	/// エラー：入力画像のサイズが正の値でない、入力・出力画像がNULL
	SI32	err = ((0 < width) && (0 < height)
		&& (pInRGB != brcNull) && (pOutRGB != brcNull) && (brightnessIncrement >= -UpperLimitOfV)
		&& (brightnessIncrement <= UpperLimitOfV) ? SUCCESS : EINVAL);
	if (err == 0){
		//! 画素走査用
		UI08 *pIn = (UI08*)pInRGB;
		UI08 *pOut = (UI08*)pOutRGB;
		UI32 imgDataSize = width * height;
		SI32 hR, sG, vB;
		/// 画像全体を走査ｃ
		SI32 sDivTable[256];
		SI32 hDivTable180[256];
		SI32 *HDIV_TABLE = hDivTable180;
		UI32 i, j, k, l, m;
		sDivTable[0] = hDivTable180[0] = 0;
		for (k = 1; k < 256; k++){
			sDivTable[k] = (SI32)((MAX_VALUE << HSV_SHIFT) / (1.*k));
			hDivTable180[k] = (SI32)((H_RANGE << HSV_SHIFT) / (6.*k));
		}
		UI08 b, g, r;
		SI32 vMin, diff;
		SI32 vR, vG;
		UI32 HSVBuf[BLOCK_SIZE * RGB_CHANNELS];
		UI32 bufIndex;
		FP32 buf[BLOCK_SIZE * RGB_CHANNELS];
		UI32 dn = 0;
		// RGBtoHSV convertion
		for (i = 0; i < height; i++)
		{
			// process for block size = 256
			for (l = 0; l < width; l += BLOCK_SIZE, pIn += dn * RGB_CHANNELS)
			{
				dn = MIN(width - l, BLOCK_SIZE);
				for (j = 0; j < dn * RGB_CHANNELS; j += RGB_CHANNELS)
				{
					b = *(pIn + j), g = *(pIn + j + 1), r = *(pIn + j + 2);
					vB = b;
					vMin = b;
					CALC_MAX_8U(vB, g);
					CALC_MAX_8U(vB, r);
					CALC_MIN_8U(vMin, g);
					CALC_MIN_8U(vMin, r);

					diff = vB - vMin;
					vR = COMPARE_TWO_VALUES(vB, r);
					vG = COMPARE_TWO_VALUES(vB, g);

					sG = (diff * sDivTable[vB] + (1 << (HSV_SHIFT - 1))) >> HSV_SHIFT;
					hR = (vR & (g - b)) +
						(~vR & ((vG & (b - r + 2 * diff)) + ((~vG) & (r - g + 4 * diff))));
					hR = (hR * HDIV_TABLE[diff] + (1 << (HSV_SHIFT - 1))) >> HSV_SHIFT;
					hR += hR < 0 ? H_RANGE : 0;

					// AdjustBrightnessHSV
					addBrightnessIncrementHSV(&vB, brightnessIncrement, UpperLimitOfV);

					HSVBuf[j] = (UI08)hR;
					HSVBuf[j + 1] = (UI08)sG;
					HSVBuf[j + 2] = (UI08)vB;

				}
				for (bufIndex = 0; bufIndex < dn * RGB_CHANNELS; bufIndex += RGB_CHANNELS)
				{
					buf[bufIndex] = (FP32)HSVBuf[bufIndex];
					buf[bufIndex + 1] = HSVBuf[bufIndex + 1] * (VALUE_1 / VALUE_2);
					buf[bufIndex + 2] = HSVBuf[bufIndex + 2] * (VALUE_1 / VALUE_2);
				}
				// HSV to RGB conversion
				HSV2RGB(buf, buf, dn);
				for (m = 0; m < dn * RGB_CHANNELS; m += RGB_CHANNELS, pOut += RGB_CHANNELS)
				{
					pOut[0] = (UI08)(buf[m] * VALUE_2);
					pOut[1] = (UI08)(buf[m + 1] * VALUE_2);
					pOut[2] = (UI08)(buf[m + 2] * VALUE_2);
				}
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** AdjustBrightnessYUV(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, SI32 brightnessIncrement)
* @brief 明るさ調整1
* @param[in]	width				画像幅
* @param[in]	height				画像高さ
* @param[in]	pInRGB				入力画像領域のポインタ
* @param[out]	pOutRGB				出力画像領域のポインタ
* @param[in]	brightnessIncrement	明るさ調整値
* @return 		0:成功 0以外:失敗
*/
PUBLIC SI32 AdjustBrightnessYUV(UI32 width, UI32 height, void *pInRGB, void *pOutRGB, SI32 brightnessIncrement)
{
#if __tracking
	Memory_Start();
#endif
	/// エラー：入力画像のサイズが正の値でない、入力・出力画像がNULL
	SI32	err = ((0 < width) && (0 < height)
		&& (pInRGB != brcNull) && (pOutRGB != brcNull) && (brightnessIncrement >= -UpperLimitOfYUV)
		&& (brightnessIncrement <= UpperLimitOfYUV) ? SUCCESS : EINVAL);
	if (err == 0){
		//! 画素走査用
		UI64 i;
		UI08* pIn = (UI08*)pInRGB;
		UI08* pOut = (UI08*)pOutRGB;
		UI64 imgDataSize = width * height;
		//YUV成分(RGB兼用)
		FP32 yR, uG, vB;
		FP32 initRGB[9][256];
		FP32 initYUV[4][256];
		initConvertRGBYUV(initRGB, initYUV);
		/// 画像全体を走査
		for (i = 0; i < imgDataSize; i++){
			// RGBをYUVに変換
			rgbToYUV(&yR, &uG, &vB, pIn, initRGB);
			// 明るさ調整値に応じて輝度を変更
			addBrightnessIncrement(&yR, brightnessIncrement, UpperLimitOfYUV);
			// YUVをRGBに変換
			yuvToRGB(&yR, &uG, &vB, initYUV);
			// 出力用データ書き込み
			store((UI08)yR, (UI08)uG, (UI08)vB, pOut);
			// 次の画素を指す
			pIn += RGB_CHANNELS;
			pOut += RGB_CHANNELS;
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** HSV2RGB(FP32* src, FP32* dst, UI32 n)
* @brief Convert HSV to RGB
* @param[out]	dst				Pointer of RGB value
* @param[in]	src				Pointer of HSV value
* @param[in]	n				size of block value
* @return 		なし
*/
PRIVATE void HSV2RGB(FP32* src, FP32* dst, UI32 n)
{
	UI32 i;
	FP32 h, s, v;
	FP32 b, g, r;
	FP32 tab[4];
	SI32 sector;
	n *= RGB_CHANNELS;
	const SI32 sector_data[][3] = SECTOR_DATA_VALUE;
	for (i = 0; i < n; i += RGB_CHANNELS, dst += RGB_CHANNELS)
	{
		h = src[i], s = src[i + 1], v = src[i + 2];
		if (s == 0){
			b = g = r = v;
		}
		else{
			h *= SCALE_VALUE;
			if (h < 0){
				do (h += 6); while (h < 0);
			}
			else if (h >= 6){
				do (h -= 6); while (h >= 6);
			}
			sector = (SI32)h;
			h -= sector;
			if ((unsigned)sector >= 6u){
				sector = 0;
				h = 0.f;
			}

			tab[0] = v;
			tab[1] = v * (VALUE_1 - s);
			tab[2] = v * (VALUE_1 - s * h);
			tab[3] = v * (VALUE_1 - s * (VALUE_1 - h));

			b = tab[sector_data[sector][0]];
			g = tab[sector_data[sector][1]];
			r = tab[sector_data[sector][2]];
		}
		dst[0] = b;
		dst[1] = g;
		dst[2] = r;
	}
}

/** addBrightnessIncrement(FP32 *brigthness, SI32 brightnessIncrement, UI08 upperLimit)
* @brief 明るさ調整値に応じて輝度を変更する
* @param[out]	brigthness				輝度成分
* @param[in]	brightnessIncrement		明るさ調整値
* @param[in]	upperLimit				上限
* @return 		なし
*/
PRIVATE void addBrightnessIncrement(FP32 *brigthness, SI32 brightnessIncrement, UI08 upperLimit)
{
	if (upperLimit < *brigthness + (FP32)brightnessIncrement){ /// 輝度+調整値がオーバーしたとき
		*brigthness = upperLimit;
	}
	else if (0 > *brigthness + (FP32)brightnessIncrement){ ///　輝度+調整値が0を下回ったとき
		*brigthness = 0;
	}
	else {
		*brigthness += (FP32)brightnessIncrement;
	}
}

/** addBrightnessIncrementHSV(SI32 *brigthness, SI32 brightnessIncrement, UI08 upperLimit)
* @brief 明るさ調整値に応じて輝度を変更する
* @param[out]	brigthness				輝度成分
* @param[in]	brightnessIncrement		明るさ調整値
* @param[in]	upperLimit				上限
* @return 		なし
*/
PRIVATE void addBrightnessIncrementHSV(SI32 *brigthness, SI32 brightnessIncrement, UI08 upperLimit)
{
	if (upperLimit < *brigthness + (SI32)brightnessIncrement){ /// 輝度+調整値がオーバーしたとき
		*brigthness = upperLimit;
	}
	else if (0 > *brigthness + (SI32)brightnessIncrement){ ///　輝度+調整値が0を下回ったとき
		*brigthness = 0;
	}
	else {
		*brigthness += (SI32)brightnessIncrement;
	}
}

/** void initConvertRGBYUV(FP32 initRGB[9][256], FP32 initYUV[4][256])
* @brief Initialize the values to convert RGB and YUV
* @param[out]	initRGB		Parameter for convert RGB to YUV
* @param[out]	initYUV		Parameter for convert YUV to RGB
* @return 		None
*/
PRIVATE void initConvertRGBYUV(FP32 initRGB[9][256], FP32 initYUV[4][256]){
	for (SI32 i = 0; i < 256; i++)
	{
		initRGB[0][i] = 0.299f * i;
		initRGB[1][i] = 0.587f * i;
		initRGB[2][i] = 0.114f * i;
		initRGB[3][i] = 0.169f * i;
		initRGB[4][i] = 0.331f * i;
		initRGB[5][i] = 0.5f * i;
		//initRGB[6][i] = initRGB[5][i];
		initRGB[7][i] = 0.419f * i;
		initRGB[8][i] = 0.081f * i;
		initYUV[0][i] = 1.402f * (i - 128);
		initYUV[1][i] = 0.344f * (i - 128);
		initYUV[2][i] = 0.714f * (i - 128);
		initYUV[3][i] = 1.772f * (i - 128);
	}
}

/** UI08 adjustLimit(FP32 num, UI08 upperLimit)
* @brief 上限、下限(0)を越えないように調整をする。
* @param[in]	num				調整対象
* @param[in]	upperLimit		上限
* @return 		調整後の値
*/
PRIVATE UI08 adjustLimit(FP32 num, UI08 upperLimit)
{
	if (num > upperLimit){ 	//上限値よりも大きければ返戻値を上限値にする
		num = upperLimit;
	}
	else if (num < 0){ //下限値(0)よりも小さければ返戻値を下限値にする
		num = 0;
	}
	return (UI08)num;
}

/** store(UI08 r, UI08 g, UI08 b, UI08 *pOut)
* @brief 出力用データ書き込み
* @param[in]	r				R成分
* @param[in]	g				G成分
* @param[in]	b				B成分
* @param[out]	pOut			出力画像領域のポインタ
* @return 		なし
*/
PRIVATE void store(UI08 r, UI08 g, UI08 b, UI08 *pOut)
{
	/// 3チャンネル分書き込み
	*pOut = b;
	*(pOut + 1) = g;
	*(pOut + 2) = r;
}

/** rgbToYUV(FP32 *yR, FP32 *uG, FP32 *vB, UI08 *pIn)
* @brief RGBをYUVに変換
* @param[out]	yR				R成分、Y成分（兼用）
* @param[out]	uG				G成分、U成分（兼用）
* @param[out]	vB				B成分、V成分（兼用）
* @param[in]	pIn				入力画像領域のポインタ
* @return 		なし
*/
PRIVATE void rgbToYUV(FP32 *yR, FP32 *uG, FP32 *vB, UI08 *pIn, FP32 initRGB[9][256])
{
	/// 3チャンネル分の色成分を一時的に格納
	UI08 tmpVB = *pIn;
	UI08 tmpUG = *(pIn + 1);
	UI08 tmpYR = *(pIn + 2);
	/// 変換式参考http://www.sm.rim.or.jp/~shishido/yuv.html
	*yR = CONVERT_RGB_TO_Y(tmpYR, tmpUG, tmpVB);
	*uG = CONVERT_RGB_TO_U(tmpYR, tmpUG, tmpVB);
	*vB = CONVERT_RGB_TO_V(tmpYR, tmpUG, tmpVB);
}

/** yuvToRGB(FP32 *yR, FP32 *uG, FP32 *vB)
* @brief YUVをRGBに変換
* @param[out]	yR				R成分、Y成分（兼用）
* @param[out]	uG				G成分、U成分（兼用）
* @param[out]	vB				B成分、V成分（兼用）
* @return 		なし
*/
PRIVATE void yuvToRGB(FP32 *yR, FP32 *uG, FP32 *vB, FP32 initYUV[4][256])
{
	/// 変換式参考http://www.sm.rim.or.jp/~shishido/yuv.html
	SI32 tmpYR = (SI32)*yR;
	SI32 tmpUG = (SI32)*uG;
	SI32 tmpVB = (SI32)*vB;

	*yR = (FP32)adjustLimit(CONVERT_YUV_TO_R(tmpYR, tmpUG, tmpVB), UpperLimitOfYUV);
	*uG = (FP32)adjustLimit(CONVERT_YUV_TO_G(tmpYR, tmpUG, tmpVB), UpperLimitOfYUV);
	*vB = (FP32)adjustLimit(CONVERT_YUV_TO_B(tmpYR, tmpUG, tmpVB), UpperLimitOfYUV);
}
