﻿/**
 * @file 	BrcJpegConvert.c
 * @brief 	JPEG変換ソースファイル
 * @author 	kyoshitake
 * @date 	2016/06/22
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
#include "BrcType.h"
#include "BrcImageProcessingCommon.h"
#include "BrcJpegConvertInterface.h"
#include "BrcMemoryUsage.h"

#define Clamp(x) 						(UI08)((x) > 255 ? 255 : ((x) < 0 ? 0 : (x)))  
#define DEQUANTIZE(dct, quantyValule) 	(SI32)((dct) * (quantyValule))
#define MULTIPLY(a, b) 					(SI32)((a) * (b))
#define RIGHT_SHIFT(x,shft)				(SI32)((x) >> (shft))
#define DESCALE(x,n)  					(SI32)RIGHT_SHIFT((x) + (1 << ((n)-1)), (n))
#define FIX(x)							((SI32) ((x) * (1L<<SCALEBITS) + 0.5))
#define MAXJSAMPLE 						255
#define CENTERJSAMPLE 					128
#define MEMZERO(target,size)			memset((void *)(target), 0, (size_t)(size))
#define MEMCOPY(dest,src,size)			memcpy((void *)(dest), (const void *)(src), (size_t)(size))
#define SCALEBITS 						16
#define ONE_HALF						((SI32) 1 << (SCALEBITS-1))
#define FIX_0_298631336  				2446    
#define FIX_0_390180644  				3196	    
#define FIX_0_541196100  				4433    
#define FIX_0_765366865  				6270    
#define FIX_0_899976223  				7373   
#define FIX_1_175875602  				9633
#define FIX_1_501321110  				12299
#define FIX_1_847759065  				15137	
#define FIX_1_961570560  				16069	
#define FIX_2_053119869  				16819	
#define FIX_2_562915447  				20995	
#define FIX_3_072711026  				25172	
#define RANGE_MASK						1023
#define DCTSIZE							8
#define CONST_BITS  					13
#define PASS1_BITS  					2
#define BLOCK_4		 					4
#define BLOCK_8		 					8
#define BLOCK_12						12
#define BLOCK_17						17
#define BLOCK_16		 				16
#define BLOCK_64		 				64
#define BLOCK_80						80
#define BLOCK_128	 					128
#define BLOCK_162						162
#define BLOCK_256	 					256
#define MAX_BITS_DCHAFFMAN				16
#define MAX_BITS_ACHAFFMAN				162
/*!< Define for Encode */
#define VALUE_RANGE_INT 				32767
#define VALUE_RANGE_UNSIGNED_SHORT 		65535
#define valueEOB 						0x00
#define valueM16zeroes 					0xF0
#define FDCT_QUANTIZATION1 				0.707106781
#define FDCT_QUANTIZATION2 				0.382683433
#define FDCT_QUANTIZATION3 				0.541196100
#define FDCT_QUANTIZATION4 				1.306562965
#define FDCT_QUANTIZATION5 				16384.5
#define FDCT_QUANTIZATION6 				16384

/*!< RGB to YUV formula for Encode */
static FP64 RGBtoYCbCrmatrix[3][3] = {
	0.299, 0.587, 0.114,
	-0.16874, -0.33126, 0.5,
	0.5, -0.41869, -0.08131 };
#define Y(R,G,B) (UI08)(((SI32)((65536 * RGBtoYCbCrmatrix[0][0] + 0.5)*R + (65536 * RGBtoYCbCrmatrix[0][1] + 0.5)*G \
	+ (65536 * RGBtoYCbCrmatrix[0][2] + 0.5)*B) >> 16) - 128);
#define Cb(R,G,B) (UI08)((SI32)((65536 * RGBtoYCbCrmatrix[1][0] + 0.5)*R + (65536 * RGBtoYCbCrmatrix[1][1] + 0.5)*G + (32768)*B) >> 16);
#define Cr(R,G,B) (UI08)((SI32)((32768)*R + (65536 * RGBtoYCbCrmatrix[2][1] + 0.5)*G + (65536 * RGBtoYCbCrmatrix[2][2] + 0.5)*B) >> 16);

/*!< Define structs for Encode */
typedef struct { 
	UI08 length; 
	SI16 value;
} BitString;

static UI08 g_jpegNaturalOrder[BLOCK_80] = {
	0, 1, 8, 16, 9, 2, 3, 10,
	17, 24, 32, 25, 18, 11, 4, 5,
	12, 19, 26, 33, 40, 48, 41, 34,
	27, 20, 13, 6, 7, 14, 21, 28,
	35, 42, 49, 56, 57, 50, 43, 36,
	29, 22, 15, 23, 30, 37, 44, 51,
	58, 59, 52, 45, 38, 31, 39, 46,
	53, 60, 61, 54, 47, 55, 62, 63,
	63, 63, 63, 63, 63, 63, 63, 63, /* extra entries for safety in decoder */
	63, 63, 63, 63, 63, 63, 63, 63
};

static UI08 g_zigZag[BLOCK_64] = {
	0, 1, 5, 6, 14, 15, 27, 28,
	2, 4, 7, 13, 16, 26, 29, 42,
	3, 8, 12, 17, 25, 30, 41, 43,
	9, 11, 18, 24, 31, 40, 44, 53,
	10, 19, 23, 32, 39, 45, 52, 54,
	20, 22, 33, 38, 46, 51, 55, 60,
	21, 34, 37, 47, 50, 56, 59, 61,
	35, 36, 48, 49, 57, 58, 62, 63
};

typedef struct
{
	SI32 value;
	SI32 length;
	UI16 code;
} StBlock;


typedef struct
{
	StBlock yDcHt[BLOCK_12];
	StBlock cbDcHt[BLOCK_12];
	StBlock yAcHt[BLOCK_256];
	StBlock cbAcHt[BLOCK_256];
	UI08 yDcHtLength[BLOCK_12];
	UI08 yDcHtAdd[BLOCK_12];

	UI08 cbDcHtLength[BLOCK_12];
	UI08 cbDcHtAdd[BLOCK_12];

	UI08 yAcHtLength[BLOCK_17];
	UI08 yAcHtAdd[BLOCK_17];

	UI08 cbAcHtLength[BLOCK_17];
	UI08 cbAcHtAdd[BLOCK_17];
} HuffmanTable;

// Not used
//typedef struct
//{
//	UI08 yDecoded[BLOCK_256];
//	UI08 uDecoded[BLOCK_64];
//	UI08 vDecoded[BLOCK_64];
//} UYVDecode;

typedef struct
{
	UI08 *dataInput;
	BrcBGR *dataOutput;
	SI32	vSize;
	SI32	hSize;
	TSegmentInfo *segDQT;
	TSegmentInfo *segDHT;
	UI32 width;
	UI32 height;
	HuffmanTable *huffmanTb;
	UI08 yDecoded[BLOCK_256];
	UI08 uDecoded[BLOCK_64];
	UI08 vDecoded[BLOCK_64];
	SI16 yPreviousDC;
	SI16 uPreviousDC;
	SI16 vPreviousDC;
	UI08 *jSample;
	SI16 mRestartInterval;
	SI16 interval;
	SI16 intervalLocal;
	SI32 *cbBTab;
	SI32 *cbGTab;
	SI32 *crRTab;
	SI32 *crGTab;
} DecodeStructInfo;
UI32 g_reservoir;
UI32 g_nbitsInReservoir;
/*!< Protypes for Encode */
PRIVATE void setDQTInfo(JpegPropertyT *jpegProperty, UI08 *dqtYTable, UI08 *dqtCbTable);
PRIVATE void setDHTInfo(JpegPropertyT *jpegProperty, UI08 *stdDcLuminanceNrCodes, UI08 *stdDcLuminanceValues,
	UI08 *stdDcChrominanceNrCodes, UI08 *stdDcChrominanceValues, UI08 *stdAcLuminanceNrCodes,
	UI08 *stdAcLuminanceValues, UI08 *stdAcChrominanceNrCodes, UI08 *stdAcChrominanceValues);
PRIVATE void computeHuffmanTable(UI08 *nrCodes, UI08 *stdTable, BitString *ht);
PRIVATE void setNumbersCategoryAndBitcode(UI08 *categoryAlloc, SI08 **category, BitString *bitcodeAlloc, BitString **bitCode);
PRIVATE void prepareQuantTables(FP32 *fdtblY, FP32 *fdtblCb, UI08 *dqtYTable, UI08 *dqtCbTable);
PRIVATE void writeByte(UI08 b, UI08 *outputData, SI32 *writeIndex);
PRIVATE SI32 encode(BrcBGR *rgbBuffer, UI08 *outputData, SI32 widthImage, SI32 heightImage, enum JpegSampling encodeMode,
	FP32 *fdtblY, FP32 *fdtblCb, BitString *yDcHt, BitString *cbDcHt, BitString *yAcHt, BitString *cbAcHt,
	SI08 *category, BitString *bitCode, SI32 *writeIndex, SI08 *bytePos, UI08 *byteNew);
PRIVATE void processDU(SI08 *componentDU, FP32 *fdtbl, SI16 *dc, BitString *htDC, BitString *htAC, UI08 *outputData,
	SI08 *category, BitString *bitCode, SI32 *writeIndex, SI08 *bytePos, UI08 *byteNew);
PRIVATE void fdctAndQuantization(SI08 *data, FP32 *fdtbl, SI16 *outData);
PRIVATE void writeBits(BitString bs, UI08 *outputData, SI32 *writeIndex, SI08 *bytePos, UI08 *byteNew);
PRIVATE SI32 checkLocation(SI32 location, SI32 widthImage, SI32 heightImage);
PRIVATE SI32 get8x8Matrix(SI32 row, SI32 col, BrcBGR *rgbBuffer, UI08 *arrY, UI08 *arrU, UI08 *arrV, SI32 widthImage, SI32 heightImage);
PRIVATE void get8x8_2(SI32 row, SI32 col, SI08 *input, SI08 *output, SI32 w);
PRIVATE SI32 get8x16Matrix(SI32 row, SI32 col, BrcBGR *rgbBuffer, UI08 *arrYOrder, UI08 *arrU, UI08 *arrV,
	SI32 widthImage, SI32 heightImage);
PRIVATE SI32 get16x16Matrix(SI32 row, SI32 col, BrcBGR *rgbBuffer, UI08 *arrYOrder, UI08 *arrU, UI08 *arrV,
	SI32 widthImage, SI32 heightImage);

/*!< Protypes for Decode */
PRIVATE void initJsample(UI08 *table, DecodeStructInfo *decodeStructInfo);
PRIVATE void decodeComputeHuffmanTable(UI08 *nrCodes, UI08 *stdTable, StBlock *ht, UI08 *tableLength, UI08 *tableAdd);
PRIVATE void decodeInitHuffmanTables(JpegPropertyT *pProperty, HuffmanTable *huffman);
PRIVATE SI32 determineSign(SI16 val, SI32 nBits);
PRIVATE SI16 getNBits(DecodeStructInfo *stream, SI32 nBitsWanted);
PRIVATE SI32 lookNBits(DecodeStructInfo *stream, SI32 nBitsWanted);
PRIVATE SI32 isInHuffmanCodes(SI32 code, UI08 numBlocks, StBlock *blocks, SI32 *outValue);
PRIVATE SI32 processHuffmanDataUnit(DecodeStructInfo *jdata, StBlock *dcBlocks, StBlock *acBlocks, UI08 *dcLength, UI08 *acLength, UI08 *dcAdd, UI08 *acAdd,
	SI32 *outPut, SI16 *mPreviousDC);
PRIVATE void jpegIdctIfast(UI08 *output, SI32 *input, SI08 *quantyTable, SI08 *jSample);
PRIVATE void decodeSingleBlock(SI32 *comp, UI08 *outputBuf, SI08 *quantyTable, SI32 stride, UI08 *jSample);
//PRIVATE void decodeSingleBlockForCrCb(SI32 *comp, UI08 *outputBuf, SI08* quantyTable, UI08* jSample);
PRIVATE SI32 decodeMCU(DecodeStructInfo *data);
PRIVATE void yccRGBTable(SI32 *crRTab, SI32 *cbBTab, SI32 *crGTab, SI32 *cbGTab);
PRIVATE void yuvToRGB24Block8x8(UI32 row, UI32 col, DecodeStructInfo *dataOut);
PRIVATE SI32 decode(DecodeStructInfo *buff);
PRIVATE void fillNBits(DecodeStructInfo *stream, SI32 nBitsWanted);
PRIVATE void skipNBits(DecodeStructInfo *stream, SI32 nBitsWanted);
/** SI32 EncodeJPEGFile(UI32 width, UI32 height, void *pInImage, void *pOutJpeg, UI32 *sizeOfOutJpeg, JpegPropertyT *pProperty, enum JpegSampling jSampling)
* @brief JPEGエンコード
* @param[in]	width			画像幅
* @param[in]	height			画像高さ
* @param[in]	pInImage		入力画像領域のポインタ
* @param[out]	pOutJpeg		出力画像領域のポインタ
* @param[in]	sizeOfOutJpeg	size of output jpeg
* @param[in]	pProperty		プロパティ格納領域のポインタ
* @param[in]	jSampling		EncodeMode
* @return		0:成功 0以外:失敗
*/
PUBLIC SI32 EncodeJPEGFile(UI32 width, UI32 height, void *pInImage, void *pOutJpeg, UI32 *sizeOfOutJpeg, JpegPropertyT *pProperty, enum JpegSampling jSampling)
{
#if __tracking
	Memory_Start();
#endif
	SI32 encodeMode = jSampling;
	SI32	err = ((0 < width) && (0 < height)
		&& (pInImage != brcNull) && (pOutJpeg != brcNull)
		&& (pProperty != (JpegPropertyT*)brcNull) && (encodeMode == 0 || encodeMode == 1 || encodeMode == 2) ? SUCCESS : EINVAL);
	if (err == 0){
		UI08 *pInData = (UI08*)pInImage;
		// Setup encode mode
		if (err == 0){
			// Init data to encode
			UI08 dqtYtable[BLOCK_64];
			UI08 dqtCbtable[BLOCK_64];
			UI08 stdDcLuminanceNrcodes[BLOCK_17];
			UI08 stdDcLuminanceValues[BLOCK_12];
			UI08 stdDcChrominanceNrcodes[BLOCK_17];
			UI08 stdDcChrominanceValues[BLOCK_12];
			UI08 stdAcLuminanceNrcodes[BLOCK_17];
			UI08 stdAcLuminanceValues[BLOCK_162];
			UI08 stdAcChrominanceNrcodes[BLOCK_17];
			UI08 stdAcChrominanceValues[BLOCK_162];
			BitString yDcHt[BLOCK_12] = { 0 };
			BitString cbDcHt[BLOCK_12] = { 0 };
			BitString yAcHt[BLOCK_256] = { 0 };
			BitString cbAcHt[BLOCK_256] = { 0 };
			UI08 categoryAlloc[VALUE_RANGE_UNSIGNED_SHORT] = { 0 };
			SI08 *category = 0;
			BitString bitcodeAlloc[VALUE_RANGE_UNSIGNED_SHORT] = { 0 };
			BitString *bitCode = { 0 };
			FP32 fdtblY[BLOCK_64];
			FP32 fdtblCb[BLOCK_64];
			SI32 writeIndex = 0;
			*sizeOfOutJpeg = 0;
			SI08 bytePos = 7;
			UI08 byteNew = 0;

			setDQTInfo(pProperty, dqtYtable, dqtCbtable);
			setDHTInfo(pProperty, stdDcLuminanceNrcodes, stdDcLuminanceValues,
				stdDcChrominanceNrcodes, stdDcChrominanceValues, stdAcLuminanceNrcodes,
				stdAcLuminanceValues, stdAcChrominanceNrcodes, stdAcChrominanceValues);
			computeHuffmanTable(stdDcLuminanceNrcodes, stdDcLuminanceValues, yDcHt);
			computeHuffmanTable(stdDcChrominanceNrcodes, stdDcChrominanceValues, cbDcHt);
			computeHuffmanTable(stdAcLuminanceNrcodes, stdAcLuminanceValues, yAcHt);
			computeHuffmanTable(stdAcChrominanceNrcodes, stdAcChrominanceValues, cbAcHt);
			setNumbersCategoryAndBitcode(categoryAlloc, &category, bitcodeAlloc, &bitCode);
			prepareQuantTables(fdtblY, fdtblCb, dqtYtable, dqtCbtable);
			err = encode((BrcBGR*)pInData, pOutJpeg, width, height, jSampling,
				fdtblY, fdtblCb, yDcHt, cbDcHt, yAcHt, cbAcHt, category, bitCode, sizeOfOutJpeg, &bytePos, &byteNew);
			if (err == 0){
				BitString fillBits;
				if (bytePos >= 0) {
					fillBits.length = bytePos + 1;
					fillBits.value = (1 << (bytePos + 1)) - 1;
					writeBits(fillBits, pOutJpeg, sizeOfOutJpeg, &bytePos, &byteNew);
				}
				//return writeIndex;
			}
			else{
				return EINPROGRESS;
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** DecodeJPEGFile(UI32 width, UI32 height, void *pInJpeg, void *pOutImage, JpegPropertyT *pProperty)
* @brief JPEGデコード
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInJpeg		入力画像領域のポインタ
* @param[out]	pOutImage	出力画像領域のポインタ
* @param[out]	pProperty	プロパティ格納領域のポインタ
* @return		0:成功 0以外:失敗
*/
PUBLIC SI32 DecodeJPEGFile(UI32 width, UI32 height, void *pInJpeg, void *pOutImage, JpegPropertyT *pProperty)
{
#if __tracking
	Memory_Start();
#endif
	SI32	err = ((0 < width) && (0 < height)
		&& (pInJpeg != brcNull) && (pOutImage != brcNull)
		&& (pProperty != (JpegPropertyT*)brcNull) ? SUCCESS : EINVAL);
	if (err == 0){
		SI32 crRTab[BLOCK_256];
		SI32 cbBTab[BLOCK_256];
		SI32 crGTab[BLOCK_256];
		SI32 cbGTab[BLOCK_256];
		HuffmanTable huffmanTb = { 0 };
		// Not used
		//UYVDecode uyvDecode = { 0 }; 
		DecodeStructInfo decodeStructInfo = { 0 };
		yccRGBTable(crRTab, cbBTab, crGTab, cbGTab);
		UI08 jSample[1408];
		SI16 interval = 0;
		//SI16 interval_local = 0;
		initJsample(jSample, &decodeStructInfo);
		decodeInitHuffmanTables(pProperty, &huffmanTb);

		UI08 *pInJpegTemp = (UI08 *)pInJpeg;
		decodeStructInfo.dataInput = pInJpegTemp;
		decodeStructInfo.dataOutput = (BrcBGR *)pOutImage;
		decodeStructInfo.width = width;
		decodeStructInfo.height = height;
		decodeStructInfo.huffmanTb = &huffmanTb;
		decodeStructInfo.uPreviousDC = 0;
		decodeStructInfo.yPreviousDC = 0;
		decodeStructInfo.vPreviousDC = 0;
		decodeStructInfo.jSample = jSample + 256;
		decodeStructInfo.vSize = pProperty->vSize;
		decodeStructInfo.hSize = pProperty->hSize;
		decodeStructInfo.segDHT = pProperty->segDHT;
		decodeStructInfo.segDQT = pProperty->segDQT;
		decodeStructInfo.interval = pProperty->mRestartInterval;
		decodeStructInfo.intervalLocal = decodeStructInfo.interval;
		decodeStructInfo.cbBTab = cbBTab;
		decodeStructInfo.cbGTab = cbGTab;
		decodeStructInfo.crRTab = crRTab;
		decodeStructInfo.crGTab = crGTab;

		if (pProperty->mRestartInterval != 0){
			decodeStructInfo.mRestartInterval = 1;
		}
		if (decode(&decodeStructInfo) != 0){
			return EINPROGRESS;
		}
	}
#if __tracking
	Memory_Report();
#endif

	return err;
}

/*!< Functions for Encode */
/** setDQTInfo(JpegPropertyT *jpegProperty, UI08 *dqtYTable, UI08 *dqtCbTable)
* @brief Set up values of DQT marker
* Do the setup values of DQT marker
* @param[in]	jpegProperty	The values of DQT marker
* @param[out]	dqtYTable		The values of dqtYTable
* @param[out]	dqtCbTable		The values of dqtCbTable
* @return		0  Success !0 Failure
*/
PRIVATE void setDQTInfo(JpegPropertyT *jpegProperty, UI08 *dqtYTable, UI08 *dqtCbTable)
{
	// The DQT header
	// 0 is the luminance index and 1 is the chrominance index
	// Only accept 65 or 130 bytes
	UI08 *dqtData;
	SI32 i;
	if (jpegProperty->segDQT[0].size == 130){
		dqtData = (UI08*)jpegProperty->segDQT[0].pData;
		if (dqtData != brcNull){
			for (i = 0; i < BLOCK_64; i++){
				dqtYTable[i] = dqtData[i + 1];
			}
			for (i = 0; i < BLOCK_64; i++){
				dqtCbTable[i] = dqtData[i + 66];
			}
		}
	}
	else if (jpegProperty->segDQT[0].size == 65 && jpegProperty->segDQT[1].size == 65) {
		dqtData = (UI08*)jpegProperty->segDQT[0].pData;
		if (dqtData != brcNull){
			for (i = 0; i < BLOCK_64; i++){
				dqtYTable[i] = dqtData[i + 1];
			}
		}
		dqtData = (UI08*)jpegProperty->segDQT[1].pData;
		if (dqtData != brcNull){
			for (i = 0; i < BLOCK_64; i++){
				dqtCbTable[i] = dqtData[i + 1];
			}
		}
	}
}

/** setDHTInfo(JpegPropertyT *jpegProperty, UI08 *stdDcLuminanceNrCodes, UI08 *stdDcLuminanceValues,
UI08 *stdDcChrominanceNrCodes, UI08 *stdDcChrominanceValues, UI08 *stdAcLuminanceNrCodes,
UI08 *stdAcLuminanceValues, UI08 *stdAcChrominanceNrCodes, UI08 *stdAcChrominanceValues)
* @brief Set up infor of Huffman table
* Do the setting of Huffman table
* @param[in]	jpegProperty				Infor of Huffman table
* @param[out]	stdDcLuminanceNrCodes		The data of dc_luminance_nrcodes
* @param[out]	stdDcLuminanceValues		The data of dc_luminance_values
* @param[out]	stdDcChrominanceNrCodes		The data of dc_chrominance_nrcodes
* @param[out]	stdDcChrominanceValues		The data of dc_chrominance_values
* @param[out]	stdAcLuminanceNrCodes		The data of ac_luminance_nrcodes
* @param[out]	stdAcLuminanceValues		The data of ac_luminance_values
* @param[out]	stdAcChrominanceNrCodes		The data of ac_chrominance_nrcodes
* @param[out]	stdAcChrominanceValues		The data of ac_chrominance_values
* @return		0	Success !0 Failure
*/
PRIVATE void setDHTInfo(JpegPropertyT *jpegProperty, UI08 *stdDcLuminanceNrCodes, UI08 *stdDcLuminanceValues,
	UI08 *stdDcChrominanceNrCodes, UI08 *stdDcChrominanceValues, UI08 *stdAcLuminanceNrCodes,
	UI08 *stdAcLuminanceValues, UI08 *stdAcChrominanceNrCodes, UI08 *stdAcChrominanceValues)
{
	UI08 *dhtData;
	UI32 i, j;
	if (jpegProperty->segDHT[0].size == 416){ // Only one segDHT
		j = 0;
		dhtData = (UI08*)jpegProperty->segDHT[0].pData;
		if (dhtData != brcNull){
			j++;	// Skip byte "Th"
			for (i = 0; i < BLOCK_16; i++, j++) {
				stdDcLuminanceNrCodes[i + 1] = *(dhtData + j);
			}
			for (i = 0; i < BLOCK_12; i++, j++) {
				stdDcLuminanceValues[i] = *(dhtData + j);
			}
			j++;	// Skip byte "Th"
			for (i = 0; i < BLOCK_16; i++, j++) {
				stdAcLuminanceNrCodes[i + 1] = *(dhtData + j);
			}
			for (i = 0; i < BLOCK_162; i++, j++) {
				stdAcLuminanceValues[i] = *(dhtData + j);
			}
			j++;	// Skip byte "Th"
			for (i = 0; i < BLOCK_16; i++, j++) {
				stdDcChrominanceNrCodes[i + 1] = *(dhtData + j);
			}
			for (i = 0; i < BLOCK_12; i++, j++) {
				stdDcChrominanceValues[i] = *(dhtData + j);
			}
			j++;	// Skip byte "Th"
			for (i = 0; i < BLOCK_16; i++, j++) {
				stdAcChrominanceNrCodes[i + 1] = *(dhtData + j);
			}
			for (i = 0; i < BLOCK_162; i++, j++) {
				stdAcChrominanceValues[i] = *(dhtData + j);
			}
		}
	}
	else if (jpegProperty->segDHT[0].size == 29 && jpegProperty->segDHT[1].size == 179 &&
		jpegProperty->segDHT[2].size == 29 && jpegProperty->segDHT[0].size == 179) {	// four segDHT - JPEG_format_1_02.pdf
		j = 0;
		dhtData = (UI08*)jpegProperty->segDHT[0].pData;
		if (dhtData != brcNull){
			j++;	// Skip byte "Th"
			for (i = 0; i < BLOCK_16; i++, j++) {
				stdDcLuminanceNrCodes[i + 1] = *(dhtData + j);
			}
			for (i = 0; i < BLOCK_12; i++, j++) {
				stdDcLuminanceValues[i] = *(dhtData + j);
			}
		}
		j = 0;
		dhtData = (UI08*)jpegProperty->segDHT[1].pData;
		if (dhtData != brcNull){
			j++;	// Skip byte "Th"
			for (i = 0; i < BLOCK_16; i++, j++) {
				stdAcLuminanceNrCodes[i + 1] = *(dhtData + j);
			}
			for (i = 0; i < BLOCK_162; i++, j++) {
				stdAcLuminanceValues[i] = *(dhtData + j);
			}
		}
		j = 0;
		dhtData = (UI08*)jpegProperty->segDHT[2].pData;
		if (dhtData != brcNull){
			j++;	// Skip byte "Th"
			for (i = 0; i < BLOCK_16; i++, j++) {
				stdDcChrominanceNrCodes[i + 1] = *(dhtData + j);
			}
			for (i = 0; i < BLOCK_12; i++, j++) {
				stdDcChrominanceValues[i] = *(dhtData + j);
			}
		}
		j = 0;
		dhtData = (UI08*)jpegProperty->segDHT[3].pData;
		if (dhtData != brcNull){
			j++;	// Skip byte "Th"
			for (i = 0; i < BLOCK_16; i++, j++) {
				stdAcChrominanceNrCodes[i + 1] = *(dhtData + j);
			}
			for (i = 0; i < BLOCK_162; i++, j++) {
				stdAcChrominanceValues[i] = *(dhtData + j);
			}
		}
	}
}

/** computeHuffmanTable(UI08 *nrCodes, UI08 *stdTable, BitString *ht)
* @brief Compute the Huffman table
* Do the computing of Huffman table from the data already set up.
* @param[in]	nrCodes		The codes of ac/dc luminance or chrominance
* @param[in]	stdTable	The values of ac/dc luminance or chrominance
* @param[out]	HT			Store infos of Huffman table after computing
* @return		none
*/
PRIVATE void computeHuffmanTable(UI08 *nrCodes, UI08 *stdTable, BitString *ht)
{
	UI08 k, j;
	UI08 posInTable;
	SI16 codeValue;
	codeValue = 0; posInTable = 0;
	for (k = 1; k <= BLOCK_16; k++){
		for (j = 1; j <= nrCodes[k]; j++){
			ht[stdTable[posInTable]].value = codeValue;
			ht[stdTable[posInTable]].length = k;
			posInTable++;
			codeValue++;
		}
		codeValue *= 2;
	}
}

/** setNumbersCategoryAndBitcode(UI08 *categoryAlloc, SI08 **category, BitString *bitcodeAlloc, BitString **bitCode)
* @brief Set up number of category and bitCode
* Do the setting of category and bitCode
* @param[in]	categoryAlloc		The values of category
* @param[out]	category			The category after computed
* @param[in]	bitcodeAlloc		The values of bitCode
* @param[out]	bitCode				The number bitCode after computed
* @return		none
*/
PRIVATE void setNumbersCategoryAndBitcode(UI08 *categoryAlloc, SI08 **category, BitString *bitcodeAlloc, BitString **bitCode)
{
	SI16 nr;
	SI16 nrLower, nrUpper;
	UI08 cat;
	nrLower = 1; nrUpper = 2;
	*category = categoryAlloc + VALUE_RANGE_INT; //allow negative subscripts
	*bitCode = bitcodeAlloc + VALUE_RANGE_INT;
	BitString *bitTemp = bitcodeAlloc + VALUE_RANGE_INT;
	for (cat = 1; cat <= 15; cat++){
		//Positive numbers
		for (nr = nrLower; nr < nrUpper; nr++){
			*(*category + nr) = cat;
			bitTemp[nr].length = cat;
			bitTemp[nr].value = (SI16)nr;
		}
		//Negative numbers
		for (nr = -(nrUpper - 1); nr <= -nrLower; nr++){
			*(*category + nr) = cat;
			bitTemp[nr].length = cat;
			bitTemp[nr].value = (SI16)(nrUpper - 1 + nr);
		}
		nrLower <<= 1;
		nrUpper <<= 1;
	}
}

/** prepareQuantTables(FP32 *fdtblY, FP32 *fdtblCb, UI08 *dqtYTable, UI08 *dqtCbTable)
* @brief Prepare for quantization tables
* Do the preparing of quantization tables
* @param[out]	fdtblY		The data of fdtblY after Quantization and zigzag
* @param[out]	fdtblCb		The data of fdtblCb after Quantization and zigzag
* @param[in]	DQT_Ytable  Quantization tables of Y table
* @param[in]	DQT_Cbtable Quantization tables  of Cb table
* @return		none
*/
PRIVATE void prepareQuantTables(FP32 *fdtblY, FP32 *fdtblCb, UI08 *dqtYTable, UI08 *dqtCbTable)
{
	FP64 aAnScaleFactor[8] = { 1.0, 1.387039845, 1.306562965, 1.175875602,
		1.0, 0.785694958, 0.541196100, 0.275899379 };
	UI08 row, col;
	UI08 i = 0;
	for (row = 0; row < BLOCK_8; row++){
		for (col = 0; col < BLOCK_8; col++){
			fdtblY[i] = (FP32)(1.0 / ((FP64)dqtYTable[g_zigZag[i]] * aAnScaleFactor[row] * aAnScaleFactor[col] * 8.0));
			fdtblCb[i] = (FP32)(1.0 / ((FP64)dqtCbTable[g_zigZag[i]] * aAnScaleFactor[row] * aAnScaleFactor[col] * 8.0));
			i++;
		}
	}
}

/** writeByte(UI08 b, UI08 *outputData, SI32 *writeIndex)
* @brief Write byte
* Do the wrtiting one byte into jpeg data stream
* @param[in]	b			The data in byte
* @param[out]	outputData  The pointer of jpeg data
* @param[in,out] writeIndex	The pointer of index data
* @return		none
*/
PRIVATE void writeByte(UI08 b, UI08 *outputData, SI32 *writeIndex)
{
	outputData[*writeIndex] = b;
	*writeIndex = *writeIndex + 1;
}

/** encode(BrcData *rgbBuffer, UI08 *outputData, SI32 widthImage, SI32 heightImage, enum JpegSampling encodeMode,
FP32 *fdtblY, FP32 *fdtblCb, BitString *yDcHt, BitString *cbDcHt, BitString *yAcHt, BitString *cbAcHt,
SI08 *category, BitString *bitCode, SI32 *writeIndex, SI08 *bytePos, UI08 *byteNew)
* @brief Encoding the JPEG data
* Do the encoding of JPEG data from the image data.
* @param[in]  rgbBuffer		The pointer of rgb data
* @param[out] outputData	The pointer of jpeg data
* @param[in] widthImage		Width image
* @param[in] heightImage	Height image
* @param[in] encodeMode		Encode mode
* @param[in] fdtblY			The data of fdtblY after Quantization and zigzag
* @param[in] fdtblCb		The data of fdtblCb after Quantization and zigzag
* @param[in] yDcHt			The data of yDcHt after computed Huffman table
* @param[in] cbDcHt			The data of cbDcHt after computed Huffman table
* @param[in] yAcHt			The data of yAcHt after computed Huffman table
* @param[in] cbAcHt			The data of cbAcHt after computed Huffman table
* @param[in] category		The pointer of category
* @param[in] bitCode		The pointer of bitCode
* @param[in] writeIndex		The pointer of index data
* @param[in] bytePos		The pointer of byte position
* @param[in] byteNew		The pointer of new data
* @return	 0	 Success !0 Failure
*/
PRIVATE SI32 encode(BrcBGR *rgbBuffer, UI08 *outputData, SI32 widthImage, SI32 heightImage, enum JpegSampling encodeMode,
	FP32 *fdtblY, FP32 *fdtblCb, BitString *yDcHt, BitString *cbDcHt, BitString *yAcHt, BitString *cbAcHt,
	SI08 *category, BitString *bitCode, SI32 *writeIndex, SI08 *bytePos, UI08 *byteNew)
{
	SI16 dcY = 0, dcU = 0, dcV = 0; //DC coefficients used for differential encoding
	SI32 xPos, yPos;
	if (encodeMode == YCbCr444){
		UI08 arrY[BLOCK_64], arrU[BLOCK_64], arrV[BLOCK_64];
		for (yPos = 0; yPos < heightImage; yPos += BLOCK_8){
			for (xPos = 0; xPos < widthImage; xPos += BLOCK_8){
				if (get8x8Matrix(xPos, yPos, rgbBuffer, arrY, arrU, arrV, widthImage, heightImage) != 0){
					return EINPROGRESS;
				}
				processDU(arrY, fdtblY, &dcY, yDcHt, yAcHt, outputData, category, bitCode, writeIndex, bytePos, byteNew);
				processDU(arrU, fdtblCb, &dcU, cbDcHt, cbAcHt, outputData, category, bitCode, writeIndex, bytePos, byteNew);
				processDU(arrV, fdtblCb, &dcV, cbDcHt, cbAcHt, outputData, category, bitCode, writeIndex, bytePos, byteNew);
			}
		}
	}
	else if (encodeMode == YCbCr422){
		SI32 yPoss, xPoss;
		UI08 arrYOrder[BLOCK_128], arrU[BLOCK_64], arrV[BLOCK_64];
		UI08 arrYOutput[BLOCK_64] = { 0 };
		for (yPos = 0; yPos < heightImage; yPos += BLOCK_8){
			for (xPos = 0; xPos < widthImage; xPos += BLOCK_16){
				if (get8x16Matrix(xPos, yPos, rgbBuffer, arrYOrder, arrU, arrV, widthImage, heightImage) != 0){
					return EINPROGRESS;
				}
				for (yPoss = 0; yPoss < BLOCK_8; yPoss += BLOCK_8){
					for (xPoss = 0; xPoss < BLOCK_16; xPoss += BLOCK_8){
						get8x8_2(xPoss, yPoss, arrYOrder, arrYOutput, BLOCK_16);
						processDU(arrYOutput, fdtblY, &dcY, yDcHt, yAcHt, outputData, category, bitCode, writeIndex, bytePos, byteNew);
					}
				}
				processDU(arrU, fdtblCb, &dcU, cbDcHt, cbAcHt, outputData, category, bitCode, writeIndex, bytePos, byteNew);
				processDU(arrV, fdtblCb, &dcV, cbDcHt, cbAcHt, outputData, category, bitCode, writeIndex, bytePos, byteNew);
			}
		}
	}
	else if (encodeMode == YCbCr420){
		SI32 yPoss, xPoss;
		UI08 arrYOrder[BLOCK_256], arrU[BLOCK_64], arrV[BLOCK_64];
		UI08 arrYOutput[BLOCK_64] = { 0 };
		for (yPos = 0; yPos < heightImage; yPos += BLOCK_16){
			for (xPos = 0; xPos < widthImage; xPos += BLOCK_16){
				if (get16x16Matrix(xPos, yPos, rgbBuffer, arrYOrder, arrU, arrV, widthImage, heightImage) != 0){
					return EINPROGRESS;
				}
				for (yPoss = 0; yPoss < BLOCK_16; yPoss += BLOCK_8){
					for (xPoss = 0; xPoss < BLOCK_16; xPoss += BLOCK_8){
						get8x8_2(xPoss, yPoss, arrYOrder, arrYOutput, BLOCK_16);
						processDU(arrYOutput, fdtblY, &dcY, yDcHt, yAcHt, outputData, category, bitCode, writeIndex, bytePos, byteNew);
					}
				}
				processDU(arrU, fdtblCb, &dcU, cbDcHt, cbAcHt, outputData, category, bitCode, writeIndex, bytePos, byteNew);
				processDU(arrV, fdtblCb, &dcV, cbDcHt, cbAcHt, outputData, category, bitCode, writeIndex, bytePos, byteNew);
			}
		}
	}
	return SUCCESS;
}

/** processDU(SI08 *componentDU, FP32 *fdtbl, SI16 *dc, BitString *htDC, BitString *htAC, UI08 * outputData,
SI08 *category, BitString *bitCode, SI32 *writeIndex, SI08 *bytePos, UI08 *byteNew)
* @brief Process encode component units
* Do the encoding component units
* @param[in]	componentDU		The YUV data block
* @param[in]	fdtbl			The data of fdtbl after computed with scale factor
* @param[in]	dc				dc coefficients used for differential encoding
* @param[out]	htDC			Huffman table DC
* @param[out]	htAC			Huffman table AC
* @param[out]	outputData		The pointer of jpeg data
* @param[in]	category		The pointer of category
* @param[in]	bitCode			The pointer of bitCode
* @param[in,out] writeIndex		The pointer of Index data
* @param[in,out] bytePos		The pointer of byte position
* @param[in,out] byteNew		The pointer of new data
* @return		none
*/
PRIVATE void processDU(SI08 *componentDU, FP32 *fdtbl, SI16 *dc, BitString *htDC, BitString *htAC, UI08 * outputData,
	SI08 *category, BitString *bitCode, SI32 *writeIndex, SI08 *bytePos, UI08 *byteNew)
{
	BitString eOB = htAC[valueEOB];
	BitString m16Zeroes = htAC[valueM16zeroes];
	UI08 i;
	UI08 startPos;
	UI08 end0Pos;
	UI08 nrZeroes;
	UI08 nrMarker;
	SI16 diff;
	SI16 duDCT[BLOCK_64];
	SI16 du[BLOCK_64];
	fdctAndQuantization(componentDU, fdtbl, duDCT);
	//zigzag reorder
	for (i = 0; i <= 63; i++){
		du[g_zigZag[i]] = duDCT[i];
	}
	diff = du[0] - *dc;
	*dc = du[0];
	//Encode DC
	if (diff == 0){
		writeBits(htDC[0], outputData, writeIndex, bytePos, byteNew); //Diff might be 0
	}
	else{
		writeBits(htDC[category[diff]], outputData, writeIndex, bytePos, byteNew);
		writeBits(bitCode[diff], outputData, writeIndex, bytePos, byteNew);
	}
	//Encode ACs
	for (end0Pos = 63; (end0Pos > 0) && (du[end0Pos] == 0); end0Pos--){}
	if (end0Pos == 0){
		writeBits(eOB, outputData, writeIndex, bytePos, byteNew);
		return;
	}

	i = 1;
	while (i <= end0Pos){
		startPos = i;
		for (; (du[i] == 0) && (i <= end0Pos); i++){};
		nrZeroes = i - startPos;
		if (nrZeroes >= BLOCK_16){
			for (nrMarker = 1; nrMarker <= nrZeroes / BLOCK_16; nrMarker++){
				writeBits(m16Zeroes, outputData, writeIndex, bytePos, byteNew);
			}
			nrZeroes = nrZeroes % 16;
		}
		writeBits(htAC[nrZeroes * BLOCK_16 + category[du[i]]], outputData, writeIndex, bytePos, byteNew);
		writeBits(bitCode[du[i]], outputData, writeIndex, bytePos, byteNew);
		i++;
	}
	if (end0Pos != 63) writeBits(eOB, outputData, writeIndex, bytePos, byteNew);
}

/** fdctAndQuantization(SI08 *data, FP32 *fdtbl, SI16 *outData)
* @brief DCT and quatization
* Do the DCT and quatization
* @param[in]	data	 The data of color space
* @param[in]	fdtbl	 The data of fdtbl after computed with scale factor
* @param[out]	outData  Store values after DCT and quatization
* @return		none
*/
PRIVATE void fdctAndQuantization(SI08 *data, FP32 *fdtbl, SI16 *outData)
{
	FP32 tmp0, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7;
	FP32 tmp10, tmp11, tmp12, tmp13;
	FP32 z1, z2, z3, z4, z5, z11, z13;
	FP32 *dataPtr;
	FP32 dataFloat[BLOCK_64];
	FP32 temp;
	SI08 ctr;
	SI08 i;
	for (i = 0; i < BLOCK_64; i++){
		dataFloat[i] = data[i];
	}
	// Pass 1: process rows.
	dataPtr = dataFloat;
	for (ctr = 7; ctr >= 0; ctr--){
		tmp0 = dataPtr[0] + dataPtr[7];
		tmp7 = dataPtr[0] - dataPtr[7];
		tmp1 = dataPtr[1] + dataPtr[6];
		tmp6 = dataPtr[1] - dataPtr[6];
		tmp2 = dataPtr[2] + dataPtr[5];
		tmp5 = dataPtr[2] - dataPtr[5];
		tmp3 = dataPtr[3] + dataPtr[4];
		tmp4 = dataPtr[3] - dataPtr[4];
		// Even part
		tmp10 = tmp0 + tmp3;	// phase 2
		tmp13 = tmp0 - tmp3;
		tmp11 = tmp1 + tmp2;
		tmp12 = tmp1 - tmp2;
		dataPtr[0] = tmp10 + tmp11; // phase 3
		dataPtr[4] = tmp10 - tmp11;
		z1 = (tmp12 + tmp13) * ((FP32)FDCT_QUANTIZATION1); // c4
		dataPtr[2] = tmp13 + z1;	// phase 5
		dataPtr[6] = tmp13 - z1;
		// Odd part
		tmp10 = tmp4 + tmp5;	// phase 2
		tmp11 = tmp5 + tmp6;
		tmp12 = tmp6 + tmp7;
		// The rotator is modified from fig 4-8 to avoid extra negations
		z5 = (tmp10 - tmp12) * ((FP32)FDCT_QUANTIZATION2); // c6
		z2 = ((FP32)FDCT_QUANTIZATION3) * tmp10 + z5; // c2-c6
		z4 = ((FP32)FDCT_QUANTIZATION4) * tmp12 + z5; // c2+c6
		z3 = tmp11 * ((FP32)FDCT_QUANTIZATION1); // c4
		z11 = tmp7 + z3;		// phase 5
		z13 = tmp7 - z3;
		dataPtr[5] = z13 + z2;	// phase 6
		dataPtr[3] = z13 - z2;
		dataPtr[1] = z11 + z4;
		dataPtr[7] = z11 - z4;
		dataPtr += 8;			//advance pointer to next row
	}
	// Pass 2: process columns
	dataPtr = dataFloat;
	for (ctr = 7; ctr >= 0; ctr--){
		tmp0 = dataPtr[0] + dataPtr[56];
		tmp7 = dataPtr[0] - dataPtr[56];
		tmp1 = dataPtr[8] + dataPtr[48];
		tmp6 = dataPtr[8] - dataPtr[48];
		tmp2 = dataPtr[16] + dataPtr[40];
		tmp5 = dataPtr[16] - dataPtr[40];
		tmp3 = dataPtr[24] + dataPtr[32];
		tmp4 = dataPtr[24] - dataPtr[32];
		//Even part/
		tmp10 = tmp0 + tmp3;		//phase 2
		tmp13 = tmp0 - tmp3;
		tmp11 = tmp1 + tmp2;
		tmp12 = tmp1 - tmp2;
		dataPtr[0] = tmp10 + tmp11; // phase 3
		dataPtr[32] = tmp10 - tmp11;
		z1 = (tmp12 + tmp13) * ((FP32)FDCT_QUANTIZATION1); // c4
		dataPtr[16] = tmp13 + z1;	// phase 5
		dataPtr[48] = tmp13 - z1;
		// Odd part
		tmp10 = tmp4 + tmp5;		// phase 2
		tmp11 = tmp5 + tmp6;
		tmp12 = tmp6 + tmp7;
		// The rotator is modified from fig 4-8 to avoid extra negations.
		z5 = (tmp10 - tmp12) * ((FP32)FDCT_QUANTIZATION2);	// c6
		z2 = ((FP32)FDCT_QUANTIZATION3) * tmp10 + z5;		// c2-c6
		z4 = ((FP32)FDCT_QUANTIZATION4) * tmp12 + z5;		// c2+c6
		z3 = tmp11 * ((FP32)FDCT_QUANTIZATION1);			// c4
		z11 = tmp7 + z3;		// phase 5
		z13 = tmp7 - z3;
		dataPtr[40] = z13 + z2; // phase 6
		dataPtr[24] = z13 - z2;
		dataPtr[8] = z11 + z4;
		dataPtr[56] = z11 - z4;
		dataPtr++;				// advance pointer to next column
	}
	for (i = 0; i < BLOCK_64; i++){
		temp = dataFloat[i] * fdtbl[i];
		outData[i] = (SI16)((SI16)(temp + FDCT_QUANTIZATION5) - FDCT_QUANTIZATION6);
	}
}

/** writeBits(BitString bs, UI08 *outputData, SI32 *writeIndex, SI08 *bytePos, UI08 *byteNew)
* @brief Write bits
* Do the writing bits
* @param[in]	bs			BitString(length, value)
* @param[out]	outputData  The pointer of jpeg data
* @param[in,out] writeIndex The pointer of Index data
* @param[in,out] bytePos	The pointer of byte position
* @param[in,out] byteNew	The pointer of new data
* @return		none
*/
PRIVATE void writeBits(BitString bs, UI08 *outputData, SI32 *writeIndex, SI08 *bytePos, UI08 *byteNew)
{
	// A portable version; it should be done in assembler
	UI16 mask[16] = { 1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768 };
	//UI08 byteNew = 0;
	SI16 value;
	SI08 posVal;//bit position in the BitString we read, should be<=15 and >=0
	value = bs.value;
	posVal = bs.length - 1;
	while (posVal >= 0){
		if (value & mask[posVal]){
			*byteNew = *byteNew | mask[*bytePos];
		}
		posVal--;
		*bytePos = *bytePos - 1;
		if (*bytePos < 0){
			if (*byteNew == 0xFF){
				writeByte(0xFF, outputData, writeIndex);
				writeByte(0, outputData, writeIndex);
			}
			else{
				writeByte(*byteNew, outputData, writeIndex);
			}
			*bytePos = 7;
			*byteNew = 0;
		}
	}
}

/** checkLocation(SI32 location, SI32 widthImage, SI32 heightImage)
* @brief Check Location
* Do the checking pixel location of image
* @param[in]	location of pixel
* @param[in]	widthImage  Width image
* @param[in]	heightImage Height image
* @return		0	Success !0 Failure
*/
PRIVATE SI32 checkLocation(SI32 location, SI32 widthImage, SI32 heightImage)
{
	SI32 err = ((0 <= location) ? SUCCESS : EINVAL);
	if ((RGB_CHANNELS * location) > (widthImage * heightImage * RGB_CHANNELS)){
		return EOVERFLOW;
	}
	else{
		return err;
	}
}

/** get8x8Matrix(SI32 row, SI32 col, BrcBGR *rgbBuffer, UI08 *arrY, UI08 *arrU, UI08 *arrV, SI32 widthImage, SI32 heightImage)
* @brief Get data blocks
* Do the getting data blocks from YUV444 data
* @param[in]	row			The number of row of block
* @param[in]	col			The number of col of block
* @param[in]	rgbBuffer  The pointer of RGB Data
* @param[out]	arrY		The array of Y
* @param[out]	arrU		The array of U
* @param[out]	arrV		The array of V
* @param[in]	widthImage  Width image
* @param[in]	heightImage Height image
* @return		0	Success !0 Failure
*/
PRIVATE SI32 get8x8Matrix(SI32 row, SI32 col, BrcBGR *rgbBuffer, UI08 *arrY, UI08 *arrU, UI08 *arrV, SI32 widthImage, SI32 heightImage)
{
	SI32 x, y;
	SI32 pos = 0;
	SI32 location;
	SI32 err;
	location = col * widthImage + row;
	UI08 r, g, b;
	for (y = 0; y < BLOCK_8; y++){
		for (x = 0; x < BLOCK_8; x++){
			if (err = checkLocation(location, widthImage, heightImage) != 0){
				return err;
			}
			r = rgbBuffer[location].red;
			g = rgbBuffer[location].green;
			b = rgbBuffer[location].blue;
			arrY[pos] = Y(r, g, b);
			arrU[pos] = Cb(r, g, b);
			arrV[pos] = Cr(r, g, b);
			location++;
			pos++;
		}
		location += widthImage - BLOCK_8;
	}
	return err;
}

/** get8x8_2(SI32 row, SI32 col, SI08 *input, SI08 *output, SI32 w)
* @brief Get data blocks
* Do the getting data blocks from YUV data
* @param[in]	row		The number of row of block
* @param[in]	col		The number of col of block
* @param[in]	input	The pointer of input data
* @param[out]	output  The pointer of output data
* @param[in]	w		The width
* @return		none
*/
PRIVATE void get8x8_2(SI32 row, SI32 col, SI08 *input, SI08 *output, SI32 w)
{
	SI32 x, y;
	SI32 pos = 0;
	SI32 location;
	location = col * w + row;
	for (y = 0; y < BLOCK_8; y++){
		for (x = 0; x < BLOCK_8; x++){
			output[pos] = input[location];
			location++; pos++;
		}
		location += w - BLOCK_8;
	}
}

/** get8x16Matrix(SI32 row, SI32 col, BrcBGR *rgbBuffer, UI08 *arrYOrder, UI08 *arrU, UI08 *arrV,
SI32 widthImage, SI32 heightImage)
* @brief Get data blocks
* Do the getting data blocks from YUV422 data
* @param[in]	row			The number of row of block
* @param[in]	col			The number of col of block
* @param[in]	rgbBuffer	The pointer of RGB Data
* @param[out]	arrYOrder   The array of Y
* @param[out]	arrU		The array of U
* @param[out]	arrV		The array of V
* @param[in]	widthImage  Width image
* @param[in]	heightImage Height image
* @return		none
*/
PRIVATE SI32 get8x16Matrix(SI32 row, SI32 col, BrcBGR *rgbBuffer, UI08 *arrYOrder, UI08 *arrU, UI08 *arrV,
	SI32 widthImage, SI32 heightImage)
{
	SI32 x, y;
	SI32 pos = 0, possy = 0;

	SI32 location;
	location = col * widthImage + row;
	SI32 err;
	UI08 r, g, b;
	SI08 tu[2], tv[2];
	SI32 index = 0;
	for (y = 0; y < BLOCK_8; y++){
		for (x = 0; x < BLOCK_16; x++){
			if (err = checkLocation(location, widthImage, heightImage) != 0){
				if (col + BLOCK_16 > heightImage){
					err = 0;
					break;
				}
				return err;
			}
			r = rgbBuffer[location].red;
			g = rgbBuffer[location].green;
			b = rgbBuffer[location].blue;
			arrYOrder[possy] = Y(r, g, b);
			tu[index] = Cb(r, g, b);
			tv[index] = Cr(r, g, b);
			location++;
			possy++;
			if (index == 1){
				arrU[pos] = (tu[0] + tu[1]) / 2;
				arrV[pos] = (tv[0] + tv[1]) / 2;
				pos++;
				index = 0;
			}
			else{
				index++;
			}
		}
		location += widthImage - BLOCK_16;
	}
	return err;
}

/** get16x16Matrix(SI32 row, SI32 col, BrcBGR *rgbBuffer, UI08 *arrYOrder, UI08 *arrU, UI08 *arrV,
SI32 widthImage, SI32 heightImage)
* @brief Get data blocks
* Do the getting data blocks from YUV420 data
* @param[in]	row			The number of row of block
* @param[in]	col			The number of col of block
* @param[in]	rgbBuffer  The pointer of RGB Data
* @param[out]	arrYOrder   The array of Y
* @param[out]	arrU		The array of U
* @param[out]	arrV		The array of V
* @param[in]	widthImage  Width image
* @param[in]	heightImage Height image
* @return		none
*/
PRIVATE SI32 get16x16Matrix(SI32 row, SI32 col, BrcBGR *rgbBuffer, UI08 *arrYOrder, UI08 *arrU, UI08 *arrV,
	SI32 widthImage, SI32 heightImage)
{
	SI32 x, y;
	SI32 pos = 0, possy = 0;
	SI32 location;
	SI32 err;
	location = col * widthImage + row;
	SI32 index = 0;
	UI08 r[BLOCK_4], g[BLOCK_4], b[BLOCK_4];
	SI08 tu[BLOCK_4], tv[BLOCK_4];
	for (y = 0; y < BLOCK_16; y++){
		for (x = 0; x < BLOCK_16; x++){
			if (err = checkLocation(location, widthImage, heightImage) != 0){
				if ((col + BLOCK_16 > heightImage) || (row + BLOCK_16 > widthImage)){
					err = 0;
					break;
				}
				return err;
			}
			r[index] = rgbBuffer[location].red;
			g[index] = rgbBuffer[location].green;
			b[index] = rgbBuffer[location].blue;
			arrYOrder[possy] = Y(r[index], g[index], b[index]);
			tu[index] = Cb(r[index], g[index], b[index]);
			tv[index] = Cr(r[index], g[index], b[index]);
			location++;
			possy++;
			if (index == 3){
				arrU[pos] = (tu[0] + tu[1] + tu[2] + tu[3]) / BLOCK_4;
				arrV[pos] = (tv[0] + tv[1] + tv[2] + tv[3]) / BLOCK_4;
				pos++;
				index = 0;
			}
			else{
				index++;
			}
		}
		location += widthImage - BLOCK_16;
	}
	return err;
}

/*!< Functions for Decode */
/** initJsample(UI08 *table, DecodeStructInfo *decodeStructInfo)
* @brief Init jpeg sample
* Do the initial jpeg sample
* @param[in]	table				Table
* @param[out]	decodeStructInfo	Info structure to decode
* @return		none
*/

PRIVATE void initJsample(UI08 *table, DecodeStructInfo *decodeStructInfo)
{
	SI32 i;
	table += (MAXJSAMPLE + 1);
	decodeStructInfo->jSample = table;
	MEMZERO(table - (MAXJSAMPLE + 1), (MAXJSAMPLE + 1) * sizeof(UI08));
	for (i = 0; i <= MAXJSAMPLE; i++)
		table[i] = (UI08)i;
	table += CENTERJSAMPLE;
	for (i = CENTERJSAMPLE; i < 2 * (MAXJSAMPLE + 1); i++)
		table[i] = MAXJSAMPLE;
	MEMZERO(table + (2 * (MAXJSAMPLE + 1)), (2 * (MAXJSAMPLE + 1) - CENTERJSAMPLE) * sizeof(UI08));
	MEMCOPY(table + (4 * (MAXJSAMPLE + 1) - CENTERJSAMPLE),
		decodeStructInfo->jSample, CENTERJSAMPLE * sizeof(UI08));
}

PRIVATE void yccRGBTable(SI32 *crRTab, SI32 *cbBTab, SI32 *crGTab, SI32 *cbGTab)
{
	SI32 i;
	SI32 x;
	for (i = 0, x = -128; i <= MAXJSAMPLE; i++, x++) {
		crRTab[i] = (SI32)RIGHT_SHIFT(FIX(1.40200) * x + ONE_HALF, SCALEBITS);
		cbBTab[i] = (SI32)RIGHT_SHIFT(FIX(1.77200) * x + ONE_HALF, SCALEBITS);
		crGTab[i] = (SI32)(-FIX(0.71414)) * x;
		cbGTab[i] = (SI32)(-FIX(0.34414)) * x + ONE_HALF;
	}
}

/** decodeComputeHuffmanTable(UI08 *nrCodes, UI08 *stdTable, StBlock *ht, UI08 *tableLength, UI08 *tableAdd)
* @brief Compute the AC Huffman table
* Do the computing AC values Huffman table
* @param[in]	nrCodes			The AC nrCodes in DHTinfo
* @param[in]	stdTable		The AC values in DHTinfo
* @param[out]	HT				Store the AC values after decode
* @param[in]	tableLength	Length of table
* @param[in]	tableAdd		Table add
* @return		none
*/
PRIVATE void decodeComputeHuffmanTable(UI08 *nrCodes, UI08 *stdTable, StBlock *ht, UI08 *tableLength, UI08 *tableAdd)
{
	UI08 k, j, i = 0;
	UI08 posInTable;
	UI16 codeValue; 
	codeValue = 0; posInTable = 0;
	for (k = 1; k <= BLOCK_16; k++){
		for (j = 1; j <= nrCodes[k - 1]; j++) {
			ht[i].code = codeValue;
			ht[i].length = k;
			ht[i].value = stdTable[posInTable];
			if (j == 1){
				tableAdd[k] = i;
			}
			tableLength[k]++;
			posInTable++;
			codeValue++;
			i++;
		}
		codeValue *= 2;
	}
}

/** decodeInitHuffmanTables(JpegPropertyT *pProperty, HuffmanTable *huffman)
* @brief Init Huffman table
* Do the initializing Huffman table, prepare values to decoding image
* @param[in]	pProperty	The AC,DC nrCodes and AC,DC values in DHTinfo
* @param[out]	huffman		Store the AC and DC values after decode
* @return		none
*/
PRIVATE void decodeInitHuffmanTables(JpegPropertyT *pProperty, HuffmanTable *huffman)
{
	decodeComputeHuffmanTable((UI08 *)((UI32)pProperty->segDHT[0].pData), (UI08 *)((UI32)pProperty->segDHT[0].pData + 16), huffman->yDcHt, huffman->yDcHtLength, huffman->yDcHtAdd);
	decodeComputeHuffmanTable((UI08 *)((UI32)pProperty->segDHT[1].pData), (UI08 *)((UI32)pProperty->segDHT[1].pData + 16), huffman->cbDcHt, huffman->cbDcHtLength, huffman->cbDcHtAdd);
	decodeComputeHuffmanTable((UI08 *)((UI32)pProperty->segDHT[2].pData), (UI08 *)((UI32)pProperty->segDHT[2].pData + 16), huffman->yAcHt, huffman->yAcHtLength, huffman->yAcHtAdd);
	decodeComputeHuffmanTable((UI08 *)((UI32)pProperty->segDHT[3].pData), (UI08 *)((UI32)pProperty->segDHT[3].pData + 16), huffman->cbAcHt, huffman->cbAcHtLength, huffman->cbAcHtAdd);
}

/** fillNBits(stream, nBitsWanted)
* @brief Fill bits
* Do the fill bits with variable number of ones
* @param[in,out] stream			The data to fill bits
* @param[in]	 nBitsWanted	The number of bits wanted
* @return		none
*
*/
/*#define fillNBits(stream, nBitsWanted)						\
{															\
	while ((SI32)(g_nbitsInReservoir) < nBitsWanted){   \
	register UI08 c = *stream->dataInput++;				\
	g_reservoir <<= 8;									\
if (c == 0xff && (*stream->dataInput) == 0x00){ \
	stream->dataInput++;							\
}													\
	g_reservoir |= c;									\
	g_nbitsInReservoir += BLOCK8;						\
	}														\
}*/

PRIVATE void fillNBits(DecodeStructInfo *stream, SI32 nBitsWanted)
{
	UI08 c;
	while ((SI32)(g_nbitsInReservoir) < nBitsWanted){
		c = *stream->dataInput++;				
		g_reservoir <<= 8;	
		if (c == 0xff && (*stream->dataInput) == 0x00){
			stream->dataInput++;						
		}
		g_reservoir |= c;									
		g_nbitsInReservoir += BLOCK_8;
	}														
}

/** skipNBits(stream, nBitsWanted)
* @brief Skip bits
* Do the skipping bits with variable number of ones
* @param[in,out] stream		The data to skip bits
* @param[in]	nBitsWanted	The number of bits wanted
* @return		none
*/
/*#define skipNBits(stream, nBitsWanted)					\
{														\
	fillNBits(stream, nBitsWanted);					\
	g_nbitsInReservoir -= (nBitsWanted);				\
	g_reservoir &= ((1U << g_nbitsInReservoir) - 1);	\
}*/
PRIVATE void skipNBits(DecodeStructInfo *stream, SI32 nBitsWanted)
{														
	fillNBits(stream, nBitsWanted);
	g_nbitsInReservoir -= (nBitsWanted);
	g_reservoir &= ((1U << g_nbitsInReservoir) - 1);
}

/** determineSign(SI32 val, SI32 nBits)
* @brief Determine sign
* Do the determine sign of values is negative or positive
* @param[in, out]	val		The values to determine
* @param[in]		nBits	The n bits
* @return			0		Success !0 Failure
*/
PRIVATE SI32 determineSign(SI16 val, SI32 nBits)
{
	SI32 negative = val < (1 << (nBits - 1));
	if (negative){
		val = val + (-1 << (nBits)) + 1;
	}
	return val;
}

/** getNBits(DecodeStructInfo *stream, SI32 nBitsWanted)
* @brief Get bits
* Do the get bits with variable number of ones
* @param[in]	stream			The data to get bits
* @param[in]	nBitsWanted		The number of bits wanted
* @return		result			The result after get n bits
*/
PRIVATE SI16 getNBits(DecodeStructInfo *stream, SI32 nBitsWanted)
{
	fillNBits(stream, nBitsWanted);
	SI16 result = ((g_reservoir) >> (g_nbitsInReservoir - (nBitsWanted)));
	g_nbitsInReservoir -= (nBitsWanted);
	g_reservoir &= ((1U << g_nbitsInReservoir) - 1);
	return result;
}

/** lookNBits(DecodeStructInfo *stream, SI32 nBitsWanted)
* @brief Look bits
* Do the looking bits with variable number of ones
* @param[in]	stream			The data to looking bits
* @param[in]	nBitsWanted		The number of bits wanted
* @return		result			The result after looking bits
*/
PRIVATE SI32 lookNBits(DecodeStructInfo *stream, SI32 nBitsWanted)
{
	fillNBits(stream, nBitsWanted);
	return (SI32)((g_reservoir) >> (g_nbitsInReservoir - (nBitsWanted)));
}

/** isInHuffmanCodes(SI32 code, UI08 numBlocks, StBlock *blocks, SI32 *outValue)
* @brief Check data is exist in Huffman table
* Do the checking data exist or not in Huffman table
* @param[in]	code			The code to check
* @param[in]	numBlocks		The number blocks to check
* @param[in]	blocks			The number blocks is ac or dc blocks
* @param[out]	outValue		The output values after checked
* @return		1				Map to Huffman table
* @return		0				Un map to Huffman table
*/
PRIVATE SI32 isInHuffmanCodes(SI32 code, UI08 numBlocks, StBlock * blocks, SI32 *outValue)
{
	UI08 j;
	for (j = 0; j < numBlocks; j++){
		if ((blocks + j)->code == code){
			*outValue = (blocks + j)->value;
			return 1;
		}
	}
	return 0;
}
/** processHuffmanDataUnit(DecodeStructInfo *jdata, StBlock *dcBlocks, StBlock *acBlocks, UI08 *dcLength, UI08 *acLength, UI08 *dcAdd, UI08 *acAdd,
SI32 *outPut, SI16 *mPreviousDC)
* @brief Process to Huffman for each data unit
* Do the processing huffman data
* @param[in]		jdata			The jpeg data
* @param[in]		dcBlocks		The dc block values
* @param[in]		acBlocks		The ac block values
* @param[in]		dcLength		The dc length
* @param[in]		acLength		The ac length
* @param[in]		dcAdd			The dc add
* @param[in]		acAdd			The ac add
* @param[out]		outPut			The output data
* @param[in,out]	mPreviousDC		The previous DC
* @return			SI32
*/
PRIVATE SI32 processHuffmanDataUnit(DecodeStructInfo *jdata, StBlock *dcBlocks, StBlock *acBlocks, UI08 *dcLength, UI08 *acLength, UI08 *dcAdd, UI08 *acAdd,
	SI32 *outPut, SI16 *mPreviousDC)
{
	SI32 found = 0;
	SI32 decodedValue = 0;
	SI32 k;
	SI32 code;
	SI16 data;
	SI32 valCode;
	UI08 sizeVal;
	UI08 count0;
	for (k = 1; k < MAX_BITS_DCHAFFMAN; k++){
		// Keep grabbing one bit at a time till we find one thats a huffman code
		code = lookNBits(jdata, k);
		// Check if its one of our huffman codes
		if (dcLength[k] != 0 && isInHuffmanCodes(code, dcLength[k], dcBlocks + dcAdd[k], &decodedValue)){
			// Skip over the rest of the bits now.
			skipNBits(jdata, k);
			found = 1;
			// We know the next k bits are for the actual data
			if (decodedValue == 0){
				outPut[0] = *mPreviousDC;
			}
			else{
				data = getNBits(jdata, decodedValue);
				data = determineSign(data, decodedValue);
				outPut[0] = *mPreviousDC + data;
				*mPreviousDC = outPut[0];
			}
			// Found so we can exit out
			break;
		}
	}
	if (!found){
		/*printf("-|- ##ERROR## We have a *serious* error, unable to find huffman code\n");
		return;*/
		return ENODATA; /* No data available */
	}
	
	// Second, the 63 AC coefficient
	SI32 nr = 1;
	SI32 eobFound = 0;
	while ((nr <= 63) && (!eobFound)){
		k = 0;
		found = 0;
		for (k = 1; k <= 16; k++){
			// Keep grabbing one bit at a time till we find one thats a huffman code
			code = lookNBits(jdata, k);
			// Check if its one of our huffman codes
			if (acLength[k] != 0 && isInHuffmanCodes(code, acLength[k], acBlocks + acAdd[k], &decodedValue)){
				// Skip over k bits, since we found the huffman value
				skipNBits(jdata, k);
				found = 1;
				// Our decoded value is broken down into 2 parts, repeating RLE, and then
				// the number of bits that make up the actual value next
				valCode = decodedValue;
				sizeVal = valCode & 0xF;	// Number of bits for our data
				count0 = valCode >> 4;	// Number RunLengthZeros
				if (sizeVal == 0){// RLE 
					if (count0 != 15)eobFound = 1;	// EOB found, go out
					else nr += BLOCK_16;  // skip 16 zeros
				}
				else{
					nr += count0; //skip count_0 zeroes
					data = getNBits(jdata, sizeVal);
					data = determineSign(data, sizeVal);
					outPut[g_jpegNaturalOrder[nr++]] = data;
				}
				break;
			}
		}
		if (!found){
			/*printf("-|- ##ERROR## We have a *serious* error, unable to find huffman code\n");
			return;*/
			return ENODATA; /* No data available */
		}
	}
	// We've decoded a block of data, so copy it across to our buffer
	
	return SUCCESS;
}

/** jpegIdctIfast(UI08 *output, SI32 *input, SI08 *quantyTable, SI08 *jSample)
* @brief Fast IDCT
* Perform fast inverse discrete cosine transform
* @param[out]	output		The output data block
* @param[in]	input		The input data block
* @param[in]	quantyTable	The quantization table
* @param[in]	jSample		Jpeg sample
* @return		none
*/
PRIVATE void jpegIdctIfast(UI08 *output, SI32 *input, SI08 *quantyTable, SI08 *jSample)
{
	SI32 tmp0, tmp1, tmp2, tmp3;
	SI32 tmp10, tmp11, tmp12, tmp13;
	SI32 z1, z2, z3;
	SI32 *inPtr;
	SI08 *quantPtr;
	SI32 *wsPtr;
	UI08 *outPtr;
	SI32 ctr;
	SI32 workSpace[BLOCK_64];	/* buffers data between passes */
	SI32 dcVal;

	inPtr = input;
	quantPtr = quantyTable;
	wsPtr = workSpace;

	for (ctr = DCTSIZE; ctr > 0; ctr--) {
		if (inPtr[DCTSIZE * 1] == 0 && inPtr[DCTSIZE * 2] == 0 &&
			inPtr[DCTSIZE * 3] == 0 && inPtr[DCTSIZE * 4] == 0 &&
			inPtr[DCTSIZE * 5] == 0 && inPtr[DCTSIZE * 6] == 0 &&
			inPtr[DCTSIZE * 7] == 0) {
			/* Terms of same column all zero */
			dcVal = DEQUANTIZE(inPtr[DCTSIZE * 0], quantPtr[DCTSIZE * 0]) << PASS1_BITS;

			wsPtr[DCTSIZE * 0] = dcVal;
			wsPtr[DCTSIZE * 1] = dcVal;
			wsPtr[DCTSIZE * 2] = dcVal;
			wsPtr[DCTSIZE * 3] = dcVal;
			wsPtr[DCTSIZE * 4] = dcVal;
			wsPtr[DCTSIZE * 5] = dcVal;
			wsPtr[DCTSIZE * 6] = dcVal;
			wsPtr[DCTSIZE * 7] = dcVal;

			inPtr++;
			quantPtr++;
			wsPtr++;
			continue;
		}
		z2 = DEQUANTIZE(inPtr[DCTSIZE * 2], quantPtr[DCTSIZE * 2]);
		z3 = DEQUANTIZE(inPtr[DCTSIZE * 6], quantPtr[DCTSIZE * 6]);
		z1 = MULTIPLY(z2 + z3, FIX_0_541196100);
		tmp2 = z1 + MULTIPLY(z2, FIX_0_765366865);
		tmp3 = z1 - MULTIPLY(z3, FIX_1_847759065);

		z2 = DEQUANTIZE(inPtr[DCTSIZE * 0], quantPtr[DCTSIZE * 0]);
		z3 = DEQUANTIZE(inPtr[DCTSIZE * 4], quantPtr[DCTSIZE * 4]);
		z2 <<= CONST_BITS;
		z3 <<= CONST_BITS;
		z2 += 1 << (CONST_BITS - PASS1_BITS - 1);
		tmp0 = z2 + z3;
		tmp1 = z2 - z3;
		tmp10 = tmp0 + tmp2;
		tmp13 = tmp0 - tmp2;
		tmp11 = tmp1 + tmp3;
		tmp12 = tmp1 - tmp3;

		tmp0 = DEQUANTIZE(inPtr[DCTSIZE * 7], quantPtr[DCTSIZE * 7]);
		tmp1 = DEQUANTIZE(inPtr[DCTSIZE * 5], quantPtr[DCTSIZE * 5]);
		tmp2 = DEQUANTIZE(inPtr[DCTSIZE * 3], quantPtr[DCTSIZE * 3]);
		tmp3 = DEQUANTIZE(inPtr[DCTSIZE * 1], quantPtr[DCTSIZE * 1]);
		z2 = tmp0 + tmp2;
		z3 = tmp1 + tmp3;

		z1 = MULTIPLY(z2 + z3, FIX_1_175875602); /* sqrt(2) * c3 */
		z2 = MULTIPLY(z2, -FIX_1_961570560); /* sqrt(2) * (-c3-c5) */
		z3 = MULTIPLY(z3, -FIX_0_390180644); /* sqrt(2) * (c5-c3) */
		z2 += z1;
		z3 += z1;

		z1 = MULTIPLY(tmp0 + tmp3, -FIX_0_899976223); /* sqrt(2) * (c7-c3) */
		tmp0 = MULTIPLY(tmp0, FIX_0_298631336); /* sqrt(2) * (-c1+c3+c5-c7) */
		tmp3 = MULTIPLY(tmp3, FIX_1_501321110); /* sqrt(2) * ( c1+c3-c5-c7) */
		tmp0 += z1 + z2;
		tmp3 += z1 + z3;

		z1 = MULTIPLY(tmp1 + tmp2, -FIX_2_562915447); /* sqrt(2) * (-c1-c3) */
		tmp1 = MULTIPLY(tmp1, FIX_2_053119869); /* sqrt(2) * ( c1+c3-c5+c7) */
		tmp2 = MULTIPLY(tmp2, FIX_3_072711026); /* sqrt(2) * ( c1+c3+c5-c7) */
		tmp1 += z1 + z3;
		tmp2 += z1 + z2;

		wsPtr[DCTSIZE * 0] = (SI32)RIGHT_SHIFT(tmp10 + tmp3, CONST_BITS - PASS1_BITS);
		wsPtr[DCTSIZE * 7] = (SI32)RIGHT_SHIFT(tmp10 - tmp3, CONST_BITS - PASS1_BITS);
		wsPtr[DCTSIZE * 1] = (SI32)RIGHT_SHIFT(tmp11 + tmp2, CONST_BITS - PASS1_BITS);
		wsPtr[DCTSIZE * 6] = (SI32)RIGHT_SHIFT(tmp11 - tmp2, CONST_BITS - PASS1_BITS);
		wsPtr[DCTSIZE * 2] = (SI32)RIGHT_SHIFT(tmp12 + tmp1, CONST_BITS - PASS1_BITS);
		wsPtr[DCTSIZE * 5] = (SI32)RIGHT_SHIFT(tmp12 - tmp1, CONST_BITS - PASS1_BITS);
		wsPtr[DCTSIZE * 3] = (SI32)RIGHT_SHIFT(tmp13 + tmp0, CONST_BITS - PASS1_BITS);
		wsPtr[DCTSIZE * 4] = (SI32)RIGHT_SHIFT(tmp13 - tmp0, CONST_BITS - PASS1_BITS);

		inPtr++;
		quantPtr++;
		wsPtr++;
	}

	wsPtr = workSpace;
	outPtr = output;
	for (ctr = 0; ctr < DCTSIZE; ctr++) {
		if (wsPtr[1] == 0 && wsPtr[2] == 0 && wsPtr[3] == 0 && wsPtr[4] == 0 &&
			wsPtr[5] == 0 && wsPtr[6] == 0 && wsPtr[7] == 0) {
			dcVal = jSample[((SI32)DESCALE((SI32)wsPtr[0], PASS1_BITS + 3) & RANGE_MASK) + 128];
			outPtr[0] = dcVal;
			outPtr[1] = dcVal;
			outPtr[2] = dcVal;
			outPtr[3] = dcVal;
			outPtr[4] = dcVal;
			outPtr[5] = dcVal;
			outPtr[6] = dcVal;
			outPtr[7] = dcVal;
			wsPtr += DCTSIZE;
			outPtr += DCTSIZE;
			continue;
		}
		z2 = (SI32)wsPtr[2];
		z3 = (SI32)wsPtr[6];
		z1 = MULTIPLY(z2 + z3, FIX_0_541196100);
		tmp2 = z1 + MULTIPLY(z2, FIX_0_765366865);
		tmp3 = z1 - MULTIPLY(z3, FIX_1_847759065);

		/* Add fudge factor here for final descale. */
		z2 = (SI32)wsPtr[0] + (1 << (PASS1_BITS + 2));
		z3 = (SI32)wsPtr[4];
		tmp0 = (z2 + z3) << CONST_BITS;
		tmp1 = (z2 - z3) << CONST_BITS;
		tmp10 = tmp0 + tmp2;
		tmp13 = tmp0 - tmp2;
		tmp11 = tmp1 + tmp3;
		tmp12 = tmp1 - tmp3;
		tmp0 = (SI32)wsPtr[7];
		tmp1 = (SI32)wsPtr[5];
		tmp2 = (SI32)wsPtr[3];
		tmp3 = (SI32)wsPtr[1];

		z2 = tmp0 + tmp2;
		z3 = tmp1 + tmp3;
		z1 = MULTIPLY(z2 + z3, FIX_1_175875602); /* sqrt(2) * c3 */
		z2 = MULTIPLY(z2, -FIX_1_961570560); /* sqrt(2) * (-c3-c5) */
		z3 = MULTIPLY(z3, -FIX_0_390180644); /* sqrt(2) * (c5-c3) */

		z2 += z1;
		z3 += z1;
		z1 = MULTIPLY(tmp0 + tmp3, -FIX_0_899976223); /* sqrt(2) * (c7-c3) */
		tmp0 = MULTIPLY(tmp0, FIX_0_298631336); /* sqrt(2) * (-c1+c3+c5-c7) */
		tmp3 = MULTIPLY(tmp3, FIX_1_501321110); /* sqrt(2) * ( c1+c3-c5-c7) */
		tmp0 += z1 + z2;
		tmp3 += z1 + z3;

		z1 = MULTIPLY(tmp1 + tmp2, -FIX_2_562915447); /* sqrt(2) * (-c1-c3) */
		tmp1 = MULTIPLY(tmp1, FIX_2_053119869); /* sqrt(2) * ( c1+c3-c5+c7) */
		tmp2 = MULTIPLY(tmp2, FIX_3_072711026); /* sqrt(2) * ( c1+c3+c5-c7) */
		tmp1 += z1 + z3;
		tmp2 += z1 + z2;
		outPtr[0] = jSample[((SI32)RIGHT_SHIFT(tmp10 + tmp3, CONST_BITS + PASS1_BITS + 3) & RANGE_MASK) + 128];
		outPtr[7] = jSample[((SI32)RIGHT_SHIFT(tmp10 - tmp3, CONST_BITS + PASS1_BITS + 3) & RANGE_MASK) + 128];
		outPtr[1] = jSample[((SI32)RIGHT_SHIFT(tmp11 + tmp2, CONST_BITS + PASS1_BITS + 3) & RANGE_MASK) + 128];
		outPtr[6] = jSample[((SI32)RIGHT_SHIFT(tmp11 - tmp2, CONST_BITS + PASS1_BITS + 3) & RANGE_MASK) + 128];
		outPtr[2] = jSample[((SI32)RIGHT_SHIFT(tmp12 + tmp1, CONST_BITS + PASS1_BITS + 3) & RANGE_MASK) + 128];
		outPtr[5] = jSample[((SI32)RIGHT_SHIFT(tmp12 - tmp1, CONST_BITS + PASS1_BITS + 3) & RANGE_MASK) + 128];
		outPtr[3] = jSample[((SI32)RIGHT_SHIFT(tmp13 + tmp0, CONST_BITS + PASS1_BITS + 3) & RANGE_MASK) + 128];
		outPtr[4] = jSample[((SI32)RIGHT_SHIFT(tmp13 - tmp0, CONST_BITS + PASS1_BITS + 3) & RANGE_MASK) + 128];
		wsPtr += DCTSIZE;		/* advance pointer to next row */
		outPtr += DCTSIZE;
	}
}

/** decodeSingleBlock(SI32 *comp, UI08 *outputBuf, SI08 *quantyTable, SI32 stride, UI08 *jSample)
* @brief Decode single block
* Do the decoding single block data
* @param[in]  comp			The DCT values
* @param[in]  quantyTable	The DQT values
* @param[in]  stride		The offset values
* @param[out] outputBuf		The output data
* @param[in]  jSample		Jpeg sample
* @return	  none
*/
PRIVATE void decodeSingleBlock(SI32 *comp, UI08 *outputBuf, SI08 *quantyTable, SI32 stride, UI08 *jSample)
{
	UI08 tempArr[BLOCK_64];
	UI08 *outPtr;
	SI32 x, y;
	jpegIdctIfast(tempArr, comp, quantyTable, jSample);
	outPtr = outputBuf;
	for (x = 0; x < BLOCK_8; x++){
		for (y = 0; y < BLOCK_8; y++){
			outPtr[y] = tempArr[y + (x * BLOCK_8)];
		}
		outPtr += stride;
	}
}


/** SI32 decodeMCU(DecodeStructInfo *data)
* @brief Decode data
* Do the decoding data (minimum coded unit)
* @param[in]	data		The data to decoding
* @return		SI32
*/
PRIVATE SI32 decodeMCU(DecodeStructInfo *data)
{
	SI32 dctU[BLOCK_64] = { 0 };
	SI32 dctV[BLOCK_64] = { 0 };
	SI32 vSize = data->vSize;
	SI32 hSize = data->hSize;
	SI32 stride = hSize << 3;
	SI32 offset;
	SI32 x, y;
	
	for (y = 0; y < vSize; y++){
		for (x = 0; x < hSize; x++){
			SI32 DCT_Y[BLOCK_64] = { 0 };
			offset = (x << 3) + ((y << 6) * hSize);
			if (processHuffmanDataUnit(data, data->huffmanTb->yDcHt, data->huffmanTb->yAcHt, data->huffmanTb->yDcHtLength,
				data->huffmanTb->yAcHtLength, data->huffmanTb->yDcHtAdd, data->huffmanTb->yAcHtAdd, DCT_Y, &data->yPreviousDC) != 0){
				return ENOSYS; /* Function not implemented */
			}
			decodeSingleBlock(DCT_Y, (data->yDecoded + offset), (SI08 *)((UI32)data->segDQT[0].pData), stride, data->jSample);
		}
	}
	if (processHuffmanDataUnit(data, data->huffmanTb->cbDcHt, data->huffmanTb->cbAcHt,
		data->huffmanTb->cbDcHtLength, data->huffmanTb->cbAcHtLength, data->huffmanTb->cbDcHtAdd, data->huffmanTb->cbAcHtAdd,
		dctU, &data->uPreviousDC) != 0){
		return ENOSYS; /* Function not implemented */
	}
	jpegIdctIfast(data->uDecoded, dctU, (SI08 *)((UI32)data->segDQT[1].pData), data->jSample);
	if (processHuffmanDataUnit(data, data->huffmanTb->cbDcHt, data->huffmanTb->cbAcHt,
		data->huffmanTb->cbDcHtLength, data->huffmanTb->cbAcHtLength, data->huffmanTb->cbDcHtAdd, data->huffmanTb->cbAcHtAdd,
		dctV, &data->vPreviousDC) != 0){
		return ENOSYS; /* Function not implemented */
	}
	jpegIdctIfast(data->vDecoded, dctV, (SI08 *)((UI32)data->segDQT[1].pData), data->jSample);
	
	return SUCCESS;
}

/** ConvertYCrCbtoRGB(y, cb, cr, dataOut, location)
* @brief Convert YCrCb to RGB
* Do the converting YCrCb to RGB
* @param[in]  y			The y data
* @param[in]  cb		The cb data
* @param[in]  cr		The cr data
* @param[out] dataOut	The output data
* @param[in]  location	The location of data
*/
#define ConvertYCrCbtoRGB(y, cb, cr, dataOut, location)																						\
{																																			\
	dataOut->dataOutput[location].red = dataOut->jSample[y + dataOut->crRTab[cr]];															\
	dataOut->dataOutput[location].green = dataOut->jSample[y + ((SI32)RIGHT_SHIFT(dataOut->cbGTab[cb] + dataOut->crGTab[cr], SCALEBITS))];	\
	dataOut->dataOutput[location].blue = dataOut->jSample[y + dataOut->cbBTab[cb]];															\
}

/** yuvToRGB24Block8x8(UI32 row, UI32 col, DecodeStructInfo* dataOut)
* @brief Convert YUV to RGB by blocks
* Do the convert YUV to RGB by blocks8x8
* @param[in]	row			The number of row
* @param[in]	col			The number of column
* @param[out]	dataOut		The rgb data
* @return		none
*/
PRIVATE void yuvToRGB24Block8x8(UI32 row, UI32 col, DecodeStructInfo *dataOut)
{
	UI32 width = dataOut->width;
	UI32 height = dataOut->height;
	SI32 xLoop, yLoop;
	SI32 pos = 0, yPoss = 0;
	SI32 locationBase = col * width + row;
	SI32 location, pOff = 0;
	SI32 vSize = dataOut->vSize;
	SI32 hSize = dataOut->hSize;
	SI32 numYLoop = vSize << 3;
	SI32 numXLoop = hSize << 3;
	
	for (yLoop = 0; yLoop < numYLoop; yLoop++){
		for (xLoop = 0; xLoop < numXLoop; xLoop++){
			if (row + xLoop >= width) {
				continue;
			}
			if (col + yLoop >= height) {
				continue;
			}
			pOff = xLoop + (width * yLoop);
			location = locationBase + pOff;
			yPoss = xLoop + yLoop*(hSize * BLOCK_8);
			pos = (SI32)(xLoop*(1.0f / hSize)) + (SI32)(yLoop*(1.0f / vSize)) * BLOCK_8;
			ConvertYCrCbtoRGB((SI32)dataOut->yDecoded[yPoss], (SI32)dataOut->uDecoded[pos],
				(SI32)dataOut->vDecoded[pos], dataOut, location);
		}
	}
}

/** decode(DecodeStructInfo *buff)
* @brief Decode jpeg data
* Do the decoding jpeg data
* @param[in]	buff		The structure of jpeg data
* @return		SI32
*/
PRIVATE SI32 decode(DecodeStructInfo *buff)
{
	SI32 mhFactorLoop = BLOCK_8 * buff->hSize;
	SI32 mvFactorLoop = BLOCK_8 * buff->vSize;
	UI32 y, x;
	UI32 width = buff->width;
	UI32 height = buff->height;
	for (y = 0; y < height; y += mvFactorLoop){
		for (x = 0; x < width; x += mhFactorLoop){
			if (buff->mRestartInterval != 0) {
				if (buff->interval == 0) {
					if (*(buff->dataInput) == 0xFF && *(buff->dataInput + 1) != 0x00){
						buff->dataInput += 2;
					}
					buff->yPreviousDC = 0;
					buff->uPreviousDC = 0;
					buff->vPreviousDC = 0;
					buff->interval = buff->intervalLocal;
					g_reservoir = 0;
					g_nbitsInReservoir = 0;
				}
			}
			if (decodeMCU(buff) != 0){
				return ENOSYS; /* Function not implemented */
			}
			buff->interval -= 1;
			yuvToRGB24Block8x8(x, y, buff);
		}
	}
	return SUCCESS;
}