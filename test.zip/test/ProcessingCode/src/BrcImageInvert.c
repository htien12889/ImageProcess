﻿/**
 * @file 	BrcImageInvert.c
 * @brief 	画像反転ソースファイル
 * @author 	etsuchida
 * @date 	2016/07/20
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */

#include "BrcType.h"
#include "BrcImageProcessingCommon.h"
#include "BrcMemoryUsage.h"

#define HALF_WIDTH(width) (((FP64)(width)) / 2)
#define HALF_HEIGHT(height) (((FP64)(height)) / 2)
/** @def ATTENTION_PIXEL
* 画素アクセス用
*/
#define ATTENTION_PIXEL(img, i, j, w, ch) img[ ( ( i + (j * w) ) * 3 ) + ch ]



/** @def channelNum
* チャンネル数
*/
//#define channelNum 3

/** InvertHorizontally(UI32 width, UI32 height, void *pInRGB, void *pOutRGB)
* @brief 水平反転
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInRGB		入力画像領域のポインタ
* @param[out]	pOutRGB		出力画像領域のポインタ
* @return		0:成功 0以外:失敗
*/
PUBLIC SI32 InvertHorizontally(UI32 width, UI32 height, void *pInRGB, void *pOutRGB)
{
#if __tracking
	Memory_Start();
#endif
	/// サイズが存在しない画像のときはエラー
	/// 入力ポインタ、出力ポインタの実体が空のときはエラー
	SI32	err = ((0 < width) && (0 < height)
		&& (pInRGB != brcNull) && (pOutRGB != brcNull) ? SUCCESS : EINVAL);

	if (err == 0){
		//! チャンネル走査用
		UI08 i;
		UI08 *pIn = (UI08*)pInRGB;
		UI08 *pOut = (UI08*)pOutRGB;
		//! 画素走査用
		UI64 y;
		//! 画素走査用
		UI64 x;
		//! 横幅の処理範囲(逆ソートなので対象方向の半分)
		FP64 halfWidth;
		/// < 横幅×高さ(半分)×チャンネル数 >を走査する
		for (i = 0; i < RGB_CHANNELS; i++){
			for (y = 0; y < height; y++){
				halfWidth = HALF_WIDTH(width);
				for (x = 0; x < halfWidth; x++){
					/// 水平方向に逆順に並べ替える
					ATTENTION_PIXEL(pOut, width - x - 1, y, width, i) = ATTENTION_PIXEL(pIn, x, y, width, i);
					ATTENTION_PIXEL(pOut, x, y, width, i) = ATTENTION_PIXEL(pIn, width - x - 1, y, width, i);
				}
			}
		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}

/** InvertVertically(UI32 width, UI32 height, void *pInRGB, void *pOutRGB)
* @brief 垂直反転
* @param[in]	width		画像幅
* @param[in]	height		画像高さ
* @param[in]	pInRGB		入力画像領域のポインタ
* @param[out]	pOutRGB		出力画像領域のポインタ
* @return		0:成功 0以外:失敗
*/
PUBLIC SI32 InvertVertically(UI32 width, UI32 height, void *pInRGB, void *pOutRGB)
{
#if __tracking
	Memory_Start();
#endif
	/// サイズが存在しない画像のときはエラー
	/// 入力ポインタ、出力ポインタの実体が空のときはエラー
	SI32	err = ((0 < width) && (0 < height)
		&& (pInRGB != brcNull) && (pOutRGB != brcNull) ? SUCCESS : EINVAL);

	if (err == 0){
		//! チャンネル走査用
		UI08 i;
		UI08 *pIn = (UI08*)pInRGB;
		UI08 *pOut = (UI08*)pOutRGB;
		//! 画素走査用
		UI64 y;
		//! 画素走査用
		UI64 x;
		//! 縦幅の処理範囲(逆ソートなので対象方向の半分)
		FP64 halfHeight;
		/// < 横幅(半分)×高さ×チャンネル数 >を走査する
		for (i = 0; i < RGB_CHANNELS; i++){
			halfHeight = HALF_HEIGHT(height);
			for (y = 0; y < halfHeight; y++){
				for (x = 0; x < width; x++){
					/// 垂直方向に逆順に並べる
					ATTENTION_PIXEL(pOut, x, y, width, i) = ATTENTION_PIXEL(pIn, x, (height - y - 1), width, i);
					ATTENTION_PIXEL(pOut, x, (height - y - 1), width, i) = ATTENTION_PIXEL(pIn, x, y, width, i);
				}
			}

		}
	}
#if __tracking
	Memory_Report();
#endif
	return err;
}