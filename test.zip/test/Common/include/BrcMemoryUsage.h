/**
* @file BrcMemoryUsage.h
* @brief Measure memory usage of C/C++ program
* @author EMT-BRYCEN VN
* @date 2016/11/17
* @par Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
*/

/**
*	USAGE:
*
*		#include "BrcMemoryUsage.h"	// include this header file
*
*		#if __tracking
*			Memory_Start();			// put this at the begin of program
*		#endif
*
*		#if __tracking
*			Memory_Report();		// put this at the end of program
*		#endif
*
*/

#ifndef MEMORYUSAGE_H
#define MEMORYUSAGE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if defined ( WIN32 )
#define __func__ __FUNCTION__
#endif

#define __tracking	(1)			// 1 = enable tracking memory; 0 = disable tracking memory

#define TRACK_TABLE_SIZE	(0xfff)

/* _TRACK_ENTRY structures */
typedef struct _TRACK_ENTRY {
	unsigned long int address;   /* address of memory allocated           */
	unsigned int size_mem;       /* size of memory allocated (bytes)      */
	unsigned int size_free;      /* size of memory was freed (bytes)      */
	unsigned int source_line;    /* actual line in the code               */
	char*        function_name;  /* function name containing the alloc    */
	char*        file_name;      /* name of file containing the alloc     */
} _TRACK_ENTRY;

/* Global variables */
static unsigned int Total_Size;
static unsigned int Memory_Leak;
static unsigned int Count_Alloc;
static _TRACK_ENTRY *track_table;
static _TRACK_ENTRY *track_ptr;

/* Prototypes */
extern void Memory_Start();
extern void Memory_Report();
static void safe_free(void** ptr);
static _TRACK_ENTRY* track_table_find_entry(unsigned long int address);
static void track_table_add_entry(unsigned long int address, unsigned int size,
	unsigned int source_line, const char* func_name, const char* file_name);
static void track_table_delete_entry(unsigned long int address);
static void *my_malloc(size_t size, unsigned int line, const char* func_name, const char* file_name);
static void *my_calloc(size_t n, size_t size, unsigned int line, const char* func_name, const char* file_name);
static void my_free(void *ptr);
static void *my_realloc(void *p_ptr, size_t size, unsigned int line, const char* func_name, const char* file_name);

/**
* @brief	Start traking memory usage
*			Put this at the begin of program
* @return void
*/
extern void Memory_Start() {
	/* Init tracking table */
	track_table = (_TRACK_ENTRY*)calloc(TRACK_TABLE_SIZE, sizeof(_TRACK_ENTRY));
	track_ptr = track_table;
	Total_Size = 0;
	Memory_Leak = 0;
	Count_Alloc = 0;
}

/**
* @brief	Check memory usage and memory leak of C/C++ program
*			Put this at the end of program
*
* @return void
*/
extern void Memory_Report() {
	unsigned int i;
	if (track_table != NULL && Count_Alloc < TRACK_TABLE_SIZE) {
		printf("Memory allocated: %u [bytes]\n", Total_Size);
		if (Memory_Leak != 0){
			printf("Source code contains memory leaks!\n");
			printf("Memory leak: %u [bytes]\n", Memory_Leak);
			printf("==========      START LIST OF LEAKS      ==========\n");
			for (i = 0; i < TRACK_TABLE_SIZE; i++)
			{
				if (track_table[i].size_mem != track_table[i].size_free){
					printf("Leak at %#lx: %u bytes \nFunction %s(): line %u \nFilename: %s\n", track_table[i].address,
						track_table[i].size_mem, track_table[i].function_name, track_table[i].source_line, track_table[i].file_name);
				}
			}
			printf("==========       END LIST OF LEAKS       ==========\n");
		}
		else {
			printf("Congratulations! Source code has no memory leaks.\n");
		}
		// Reset tracking table
		safe_free((void**)&track_table);
	}
}

static void safe_free(void** ptr)
{
	free(*ptr);
	*ptr = NULL;
}

static _TRACK_ENTRY* track_table_find_entry(unsigned long int address)
{
	int i;
	if (track_table != NULL){
		_TRACK_ENTRY* entry = track_table;
		for (i = 0; i < TRACK_TABLE_SIZE; i++)
		{
			if (address == track_table[i].address && address != 0){
				return entry = &track_table[i];
			}
		}
	}
	return NULL;  /* Not found */
}

static void track_table_add_entry(unsigned long int address, unsigned int size,
	unsigned int source_line, const char* func_name, const char* file_name)
{
	if (track_table != NULL){
		if (track_table_find_entry(address) == NULL && Count_Alloc < TRACK_TABLE_SIZE) {
			// Set entry infomation
			track_ptr->address = address;
			track_ptr->size_mem = size;
			track_ptr->size_free = 0;
			track_ptr->source_line = source_line;
			track_ptr->function_name = (char*)malloc(strlen(func_name) + 1);
			if (track_ptr->function_name != NULL) {
#ifdef _WIN32
				strcpy_s(track_ptr->function_name, strlen(func_name) + 1, func_name);
#elif __linux__
				strcpy(track_ptr->function_name, func_name);
#endif
			}
			track_ptr->file_name = (char*)malloc(strlen(file_name) + 1);
			if (track_ptr->file_name != NULL) {
#ifdef _WIN32
				strcpy_s(track_ptr->file_name, strlen(file_name) + 1, file_name);
#elif __linux__
				strcpy(track_ptr->file_name, file_name);
#endif			
			}
			// End of set entry infomation

			track_ptr++;			// pointer to next entry
			Count_Alloc++;			// count to check out of tracking table
			Total_Size += size;		// tracking total size
			Memory_Leak += size;	// tracking memory leak size
		}
	}
}

static void track_table_delete_entry(unsigned long int address)
{
	if (track_table != NULL){
		_TRACK_ENTRY *p;
		p = track_table_find_entry(address);
		if (p != NULL) {
			// subtrack
			Memory_Leak -= p->size_mem;
			p->size_free = p->size_mem;
			// reset
			p->address = 0;
			p->source_line = 0;
			p->function_name = 0;
			p->file_name = 0;
		}
	}
}

static void *my_malloc(size_t size, unsigned int line, const char* func_name, const char* file_name) {
	void *ptr;
	ptr = (void *)malloc(size);
	if (track_table != NULL && ptr != NULL){
		track_table_add_entry((unsigned long int)ptr, size, line, func_name, file_name);
	}
	return ptr;
}

static void *my_calloc(size_t n, size_t size, unsigned int line, const char* func_name, const char* file_name) {
	void *ptr;
	ptr = (void *)calloc(n, size);
	if (track_table != NULL && ptr != NULL){
		track_table_add_entry((unsigned long int)ptr, n*size, line, func_name, file_name);
	}
	return ptr;
}

static void my_free(void *ptr) {
	if (track_table != NULL && ptr != NULL) {
		track_table_delete_entry((unsigned long int)ptr);
	}
	free(ptr);
}

static void *my_realloc(void *p_ptr, size_t size, unsigned int line, const char* func_name, const char* file_name) {
	void *ptr;
	ptr = (void *)realloc(p_ptr, size);
	if (track_table != NULL && ptr != NULL){
		_TRACK_ENTRY *p;
		p = track_table_find_entry((unsigned long int)p_ptr);
		if (p != NULL){
			// subtract
			p->size_free = p->size_mem;
			Total_Size -= p->size_mem;
			Memory_Leak -= p->size_mem;
			// reset
			p->address = 0;
			p->source_line = 0;
			p->function_name = 0;
			p->file_name = 0;
		}
		// add new
		track_table_add_entry((unsigned long int)ptr, size, line, func_name, file_name);
	}
	return ptr;
}

#define malloc(size) my_malloc(size, __LINE__, __func__, __FILE__)
#define calloc(n, size) my_calloc(n,size, __LINE__, __func__, __FILE__)
#define free(adr) my_free(adr)
#define realloc(ptr, size) my_realloc(ptr, size, __LINE__, __func__, __FILE__)

#endif // MEMORYUSAGE_H