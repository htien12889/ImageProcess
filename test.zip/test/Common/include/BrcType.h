 /**
 * @file 	BrcType.h
 * @brief 	Define data type
 * @author 	Masatoshi Kawsashima
 * @date 	2016/05/26
 * @par 	Copyright (C) 2016 BRYCEN Co., Ltd. All Rights Reserved.
 */
  
#ifndef BRCTYPE_H_
#define BRCTYPE_H_

//### typedef ###
typedef unsigned long long	UI64;	// unsigned 64 bit integer
typedef unsigned int		UI32;	// unsigned 32 bit integer
typedef unsigned short		UI16;	// unsigned 16 bit integer
typedef unsigned char		UI08;	// unsigned  8 bit integer
typedef signed long	long	SI64;	// unsigned 64 bit integer
typedef signed int			SI32;	// unsigned 32 bit integer
typedef signed short		SI16;	// unsigned 16 bit integer
typedef signed char			SI08;	// unsigned  8 bit integer
typedef float				FP32;	// 32 bit floating point
typedef double				FP64;	// 64 bit floating point

//### enum ###
typedef enum {
	brcFalse = 0,
	brcTrue = 1
} brcBool;

#define brcNull	(0)

//### macro ###
#define MinimumRGB(r,g,b) ((r > g)? ((g > b)? b: g): ((r > b)? b: r))
#define IsRange(val,min, max) ((val < min)? brcFalse: (max <= val)? brcFalse: brcTrue)
#define ClipUnder(val, min) ((val < min)? min: val)
#define ClipOver(val, max) ((max < val)? max: val)
#define ClipRange(val, min, max) ((val < min)? min: (max < val)? max: val)
#define ConvertStats(coord, min, step)	(coord * step + min) 
#define ConvertCoordinate(stats, min, step)	((stats - min) / step) 
#define COPY_ARRAY(src, dst, cnt)	(for (UI32 i = 0; i < 9; i++, src++, dst++) *dst = *src;)

#endif /* BRCTYPE_H_ */
