import React, {Component} from 'react';
import {
	View, Text, StyleSheet, TouchableOpacity, ListView,
	TextInput, WebView, NetInfo, Alert, Image, Animated, Dimensions, StatusBar
} from 'react-native';
import DanhMuc from './danhMuc/DanhMuc.js';
var SQLite = require('react-native-sqlite-storage')
var db = SQLite.openDatabase({name : "jlptDB_v2_new", createFromLocation : "~jlpt_v2_new.db"}, this.openCB,this.errorCB);
var db1 = SQLite.openDatabase({name : "jlptDB_folder", createFromLocation : "~folder.db"}, this.openCB,this.errorCB);
var {height, width} = Dimensions.get('window');
var heightOfView = height - 150 - StatusBar.currentHeight;
var heightOfAddDanhMuc = heightOfView;
export default class Grammar extends Component<{}>{
	constructor(props) {
		super(props);
		this.isSearch = false;
		this.grammarId = 0;
		this.danhMucId = 0;
		this.grammarIds = 0;
		this.state = {
			dataLenght: 1,
			dataGrammarLength: 1,
			dataSource: new ListView.DataSource({rowHasChanged: (r1, r2)=>r1!==r2}),
			isContent: 0,
			htmlContent: "",
			topAnimate: new Animated.Value(-heightOfView),
			renderOverlay: 0,
		}
	}
	openCB(){
		console.log("Open Database");
	}
	sucessCB() {
		ToastAndroid.show("Sucessful", ToastAndroid.SHORT);
	}
	errorCB(err) {
		ToastAndroid.show("SQL Error" + err, ToastAndroid.SHORT);
	}
  render() {
    return (
			this.renderContentGrammar()
    );
  }
	renderContentGrammar(){
		if(this.state.isContent == 0) {
			if(this.state.dataLenght == 0) {
				return(
					<View style={style.grammarContainer}>
						<View style={{flex: 1, justifyContent: 'center', paddingLeft: 5, paddingRight: 5}}>
							<Text style={{textAlign: 'center', fontWeight: 'bold', fontSize: 25}}>Không có danh mục ngữ pháp nào</Text>
						</View>
					</View>
				);

			} else {
				if(this.props.level == 0) {
					return(
						<View style={style.grammarContainer}>
							<View style={{flex: 1}}>
								<ListView
									dataSource={this.state.dataSource}
									renderRow={(rowData) =>
										<TouchableOpacity style={style.listView}
											onPress={this.getListViewGrammarDM.bind(this, rowData)}>
											<View style={{justifyContent: 'center'}}>
												<Text style={{fontSize: 17, marginLeft: 15, color: 'white'}}>{rowData.stt}</Text>
											</View>
											<View style={{justifyContent: 'center'}}>
												<Text style={{fontSize: 17, marginLeft: 15, color: 'white'}}>{rowData.title}</Text>
											</View>
										</TouchableOpacity>
									}
								/>
							</View>
						</View>
					);
				} else {
					if(this.props.lanThu > 0 && !this.isSearch) {
						this.getRowData();
					}
					return(
						<View style={style.grammarContainer}>
							<View style={{backgroundColor: '#4fc1e9'}}>
								<TextInput
									 style={style.TextInputStyleClass}
									 onChangeText={(text) => this.SearchFilterFunction(text)}
									 placeholderTextColor={'#FFF'}
									 //value={this.state.text}
									 underlineColorAndroid='transparent'
									 placeholder="Search Here"
								/>
							</View>
							<View style={{flex: 1}}>
								<ListView
									dataSource={this.state.dataSource}
									renderRow={(rowData) =>
										<TouchableOpacity style={style.listView}
											onPress={this.GetListViewItem.bind(this, rowData.id)}>
											<View style={{justifyContent: 'center'}}>
												<Text style={{fontSize: 17, marginLeft: 15, color: 'white'}}>{rowData.stt}</Text>
											</View>
											<View style={{justifyContent: 'center'}}>
												<Text style={{fontSize: 17, marginLeft: 15, color: 'white'}}>{rowData.title}</Text>
											</View>
										</TouchableOpacity>
									}
								/>
							</View>
						</View>
					);
				}

			}
		} else if(this.state.isContent == 1) {
			if(this.props.level == 0) {
				return(
					<View style={{flex: 1, paddingTop: 5, backgroundColor: 'white'}}>
						{this.renderOverlay()}
						<Animated.View style={{position: 'absolute', bottom: this.state.topAnimate, left: 7, height: heightOfAddDanhMuc, width: width - 14, zIndex: 999}}>
	            <DanhMuc
								title="Danh Mục ngữ pháp"
	              type="grammar"
	              ref="danhMuc"
	              addDanhMucAction={(value) => {this.addDanhMucAction(value)}}
	              closeList={() => {this.closeList()}}/>
	          </Animated.View>
						<TouchableOpacity style={style.AddIconImage} onPress={() => {this.removeGrammarType()}}>
							<Image style={{width: 25, height: 25}} source={require('./../../assets/remove.png')}></Image>
						</TouchableOpacity>
						<WebView
			        source={{ html: this.state.htmlContent, baseUrl: 'file:///android_asset/' }}
			      />
					</View>
				);
			} else {
				return(
					<View style={{flex: 1, paddingTop: 5, backgroundColor: 'white'}}>
						{this.renderOverlay()}
						<Animated.View style={{position: 'absolute', bottom: this.state.topAnimate, left: 7, height: heightOfAddDanhMuc, width: width - 14, zIndex: 999}}>
	            <DanhMuc
								title="Danh Mục ngữ pháp"
	              type="grammar"
	              ref="danhMuc"
	              addDanhMucAction={(value) => {this.addDanhMucAction(value)}}
	              closeList={() => {this.closeList()}}/>
	          </Animated.View>
						<TouchableOpacity style={style.AddIconImage} onPress={() => {this.addGrammarType()}}>
							<Image style={{width: 25, height: 25}} source={require('./../../assets/addContent.png')}></Image>
						</TouchableOpacity>
						<WebView
			        source={{ html: this.state.htmlContent, baseUrl: 'file:///android_asset/' }}
			      />
					</View>
				);
			}
		} else if(this.state.isContent == 2) {
			if(this.state.dataGrammarLength == 0) {
				return(
					<View style={style.grammarContainer}>
						<View style={{flex: 1, justifyContent: 'center', paddingLeft: 5, paddingRight: 5}}>
							<Text style={{textAlign: 'center', fontWeight: 'bold', fontSize: 25}}>Không có ngữ pháp nào trong danh mục này</Text>
						</View>
					</View>
				);
			} else {
				return(
					<View style={style.grammarContainer}>
						<View style={{flex: 1}}>
							<ListView
								dataSource={this.state.dataSource}
								renderRow={(rowData) =>
									<TouchableOpacity style={style.listView}
										onPress={this.GetListViewItem.bind(this, rowData.id)}>
										<View style={{justifyContent: 'center'}}>
											<Text style={{fontSize: 17, marginLeft: 15, color: 'white'}}>{rowData.stt}</Text>
										</View>
										<View style={{justifyContent: 'center'}}>
											<Text style={{fontSize: 17, marginLeft: 15, color: 'white'}}>{rowData.title}</Text>
										</View>
									</TouchableOpacity>
								}
							/>
						</View>
					</View>
				);
			}

		}
	}
	removeGrammarType() {
		var grammarId = this.grammarId;
		var dmId = this.danhMucId;
		var sql = "SELECT * FROM folder WHERE `id`='"+ dmId +"'";
		db1.transaction((tx) => {
      tx.executeSql(sql, [], (tx, results) => {
        let ids = results.rows.item(0).ids;
        let idsWrite = "";
        let arrayIds = ids.split(',');
        let j = 0;
        for(let i = 0; i < arrayIds.length; i++) {
          if(arrayIds[i] == grammarId) {
            continue;
          }
          if(j == 0) {
            idsWrite = idsWrite + arrayIds[i];
          } else {
            idsWrite = idsWrite + "," + arrayIds[i];
          }
          j++;
        }
        db1.transaction((tx) => {
          //console.log("INSERT INTO folder (`type`,`name`) VALUES ('vocabulary','"+value+"')");
          //console.log("UPDATE folder SET ids='"+idsWrite+"' WHERE id='"+dmId+"'");
          tx.executeSql("UPDATE folder SET ids='"+idsWrite+"' WHERE id='"+dmId+"'", [], (tx, results) => {
            this.getListViewDM(idsWrite);
          });
        });
       });
    });
	}
	getListViewDM(value) {
		var sql = "SELECT * FROM lesson WHERE `id` in ("+ value +")";
		db.transaction((tx) => {
			tx.executeSql(sql, [], (tx, results) => {
					var array = [];
					var len = results.rows.length;
					for (let i = 0; i < len; i++) {
          	array[i] = {id: results.rows.item(i).id, stt: i + 1, title: results.rows.item(i).title, ids: ""};
					}
					this.setState({
            dataSource: this.state.dataSource.cloneWithRows(array),
						isContent: 2,
						dataGrammarLength: array.length,
					});
			 });
		});
	}
	getListViewGrammarDM(value) {
		this.props.updateIsContent();
		var sql = "SELECT * FROM lesson WHERE `id` in ("+ value.ids +")";
		this.danhMucId = value.id;
		this.grammarIds = value.ids;
		db.transaction((tx) => {
			tx.executeSql(sql, [], (tx, results) => {
					var array = [];
					var len = results.rows.length;
					for (let i = 0; i < len; i++) {
          	array[i] = {id: results.rows.item(i).id, stt: i + 1, title: results.rows.item(i).title, ids: ""};
					}
					this.setState({
            dataSource: this.state.dataSource.cloneWithRows(array),
						isContent: 2,
						dataGrammarLength: array.length,
					});
			 });
		});
	}
	renderOverlay(){
    if(this.state.renderOverlay == 1) {
      return(
        <View style={{backgroundColor: 'black', opacity: 0.5, width: width, height: height, position: 'absolute', top: 0, left: 0, zIndex: 99}}></View>
      );
    }
  }
	addDanhMucAction(value) {
		db1.transaction((tx) => {
      tx.executeSql("SELECT * FROM folder where type='grammar' and id='"+value.id+"'", [], (tx, results) => {
        let ids = results.rows.item(0).ids;
        if(ids) {
          let arrayIds = ids.split(',');
          let lengthIds = arrayIds.length;
          if(lengthIds == 0) {
            ids = ids + "," + this.grammarId;
          } else {
            let check = false;
            for(let i = 0; i < lengthIds; i++) {
              if(this.grammarId == arrayIds[i]) {
                check = true;
                break;
              }
            }
            if(check) {
              Alert.alert(
                'Thông Báo',
                '"'+value.name+'" đã tồn tại ngữ pháp này',
                [
                  {text: 'OK', onPress: () => {console.log("ok")}},
                ]
              );
              return;
            } else {
              ids = ids + "," + this.grammarId;
            }
          }
        } else {
          ids = this.grammarId;
        }
        //console.log(ids);
        db1.transaction((tx) => {
          //console.log("INSERT INTO folder (`type`,`name`) VALUES ('vocabulary','"+value+"')");
          tx.executeSql("UPDATE folder SET ids='"+ids+"' WHERE id='"+value.id+"' ", [], (tx, results) => {
            //this.getDatas();
            this.closeList();
          });
        });

      });
    });
	}
	addGrammarType() {
		value = this.grammarId;
    this.refs.danhMuc.resetDanhMuc(value);
    //console.log(value);
    this.setState({
      renderOverlay: 1,
    });
    Animated.timing(
      this.state.topAnimate,
      {
        toValue: 0,
        duration: 200,
      }
    ).start();
	}
	closeList() {
    //console.log(value);
    this.setState({
      renderOverlay: 0,
    });
    Animated.timing(
      this.state.topAnimate,
      {
        toValue: -heightOfView,
        duration: 200,
      }
    ).start();
  }
	backProcess(){
		this.getRowData();
		this.setState({
			isContent: 0,
		});
	}
	GetListViewItem(id) {
		this.grammarId = id;
		NetInfo.isConnected.fetch().then(isConnected => {
      if(isConnected)
      {
				this.props.lessonUpdateClick(1.5);
				this.props.updateIsContent();
				var sql = "SELECT * FROM lesson WHERE `id`= '" + id + "'";
				db.transaction((tx) => {
					tx.executeSql(sql, [], (tx, results) => {
							var html = "";
							var len = results.rows.length;
							for (let i = 0; i < len; i++) {
								html = results.rows.item(i).content;
							}
							this.setState({
								isContent: 1,
								htmlContent: html,
							});
					 });
				});
      } else {
        Alert.alert(
    			'Thông Báo',
    			'Hãy kết nối internet để sử dụng chức năng này',
    			[
    				{text: 'OK', onPress: () => {console.log("ok")}},
    			]
    		);
      }
    });
	}
	SearchFilterFunction(text) {
		var cat_id = this.props.level;
		if(this.props.level == 1) {
			cat_id = 6;
		}
		else if(this.props.level == 4) {
			cat_id = 2;
		}
		else if(this.props.level == 5) {
			cat_id = 3;
		}
		else if(this.props.level == 3) {
			cat_id = 4;
		}
		else {
			cat_id = 5;
		}
		var sql = "SELECT * FROM lesson WHERE cat_id="+cat_id+" and `title` like '%" + text + "%'";
		db.transaction((tx) => {
      tx.executeSql(sql, [], (tx, results) => {
					var array = [];
          var len = results.rows.length;
          for (let i = 0; i < len; i++) {
            array[i] = results.rows.item(i);
						array[i]["stt"] = i + 1;
          }
					this.isSearch = true;
					this.setState({
						dataSource: this.state.dataSource.cloneWithRows(array),
					});
        });
    });
		this.isSearch = false;
	}
	getRowData(){

		if(this.props.level == 0) {
			db1.transaction((tx) => {
	      tx.executeSql("SELECT * FROM folder where type='grammar'", [], (tx, results) => {
						var array = [];
	          var len = results.rows.length;
	          for (let i = 0; i < len; i++) {
							array[i] = {id: results.rows.item(i).id, stt: i + 1, title: results.rows.item(i).name, ids: results.rows.item(i).ids}
	            /*array[i] = results.rows.item(i);
							array[i]["stt"] = i + 1;*/
	          }
						this.setState({
							dataLenght: array.length,
							dataSource: this.state.dataSource.cloneWithRows(array),
						});
	        });
	    });
		} else {
			var cat_id = this.props.level;
			if(this.props.level == 1) {
				cat_id = 6;
			}
			else if(this.props.level == 4) {
				cat_id = 2;
			}
			else if(this.props.level == 5) {
				cat_id = 3;
			}
			else if(this.props.level == 3) {
				cat_id = 4;
			}
			else {
				cat_id = 5;
			}
			db.transaction((tx) => {
	      tx.executeSql('SELECT * FROM lesson where cat_id='+cat_id, [], (tx, results) => {
						var array = [];
	          var len = results.rows.length;
	          for (let i = 0; i < len; i++) {
	            /*array[i] = results.rows.item(i);
							array[i]["stt"] = i + 1;*/
							array[i] = {id: results.rows.item(i).id, stt: i + 1, title: results.rows.item(i).title, ids: ""}
	          }
						this.setState({
							dataLenght: array.length,
							dataSource: this.state.dataSource.cloneWithRows(array),
						});
	        });
	    });
		}

	}
	componentDidMount() {
		this.getRowData();
	}
}

const style = StyleSheet.create({
	AddIconImage: {
    width: 25,
    height: 25,
    position: 'absolute',
    bottom: 10,
    right: 10,
    zIndex: 999,
  },
	listView: {
		/*flexDirection: 'row',
		height: 40,
		marginLeft: 10,
		marginRight: 10,
		marginTop: 3,
		borderRadius: 7,
		backgroundColor: '#ffffff',*/
		flexDirection: 'row',
    padding: 10,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderBottomColor: '#2ea5dd',
    borderTopColor: '#75d2f0',
    backgroundColor: '#4fc1e9',
		//justifyContent: 'center',
	},
	TextInputStyleClass: {
		textAlign: 'center',
		color: '#989fa9',
		height: 40,
		borderWidth: 1,
		borderColor: '#2d9ed0',
		borderRadius: 7 ,
		backgroundColor : "#3bafda",
		margin: 10
	},
  grammarContainer: {
		flex: 1,
		backgroundColor: '#e3e4e8',
	},
});
