import React, {Component} from 'react';
import {View, Text, TouchableOpacity, StyleSheet, ListView} from 'react-native';
import TopMenu from '../common/TopMenu.js';
import KanjiList from './Kanji/KanjiList.js';
import KanjiFlashCard from './Kanji/KanjiFlashCard.js';
import KanjiKiemTraList from './Kanji/KanjiKiemTraList.js';
var SQLite = require('react-native-sqlite-storage')
var db = SQLite.openDatabase({name : "jlptDB_v2_new", createFromLocation : "~jlpt_v2_new.db"}, this.openCB,this.errorCB);
var db1 = SQLite.openDatabase({name : "jlptDB_folder", createFromLocation : "~folder.db"}, this.openCB,this.errorCB);
export default class Kanji extends Component<{}> {
  constructor(props) {
		super(props);
    this.pages = 0;
    this.kanjiIds = 0;
    this.danhMucId = 0;
		this.state = {
      lenghtData: 1,
			dataSource: new ListView.DataSource({rowHasChanged: (r1, r2)=>r1!==r2}),
			isContent: 0,
      kanjiType: 'kanji',
      kanjiDatas: [],
		}
	}
	openCB(){
		console.log("Open Database");
	}
	sucessCB() {
		ToastAndroid.show("Sucessful", ToastAndroid.SHORT);
	}
	errorCB(err) {
		ToastAndroid.show("SQL Error" + err, ToastAndroid.SHORT);
	}
  render(){
    return(
      this.renderContentKanji()
    );
  }
  renderContentKanji(){
    if(this.state.isContent == 0) {
      if(this.state.lenghtData == 0) {
        return(
          <View style={style.kanjiContainer}>
            <View style={{flex: 1, justifyContent: 'center', paddingLeft: 5, paddingRight: 5}}>
              <Text style={{textAlign: 'center', fontWeight: 'bold', fontSize: 25}}>Không có danh mục kanji nào</Text>
            </View>
          </View>
        );
      } else {
        return(
          <View style={style.kanjiContainer}>
            <View style={{flex: 1}}>
              <ListView
                dataSource={this.state.dataSource}
                renderRow={(rowData) =>
                  <TouchableOpacity style={style.listView}
                    onPress={this.GetListViewItem.bind(this, rowData)}>
                    <View style={{justifyContent: 'center'}}>
                      <Text style={{fontSize: 17, marginLeft: 15, color: 'white'}}>{rowData.stt}</Text>
                    </View>
                    <View style={{justifyContent: 'center'}}>
                      <Text style={{fontSize: 17, marginLeft: 15, color: 'white'}}>{rowData.title}</Text>
                    </View>
                  </TouchableOpacity>
                }
              />
            </View>
          </View>
        );
      }

    } else {
      if(this.state.kanjiType == "kanji") {
        return(
          <View style={style.kanjiContainer}>
            <TopMenu
              contentClick={() => {this.contentClick()}}
              flashCardClick={() => {this.flashCardClick()}}
              quizClick={() => {this.quizClick()}}
              nameButton={"Kanji"}/>
              <KanjiList
                reloadDatas={(value) => {this.GetListViewItem(value)}}
                getDatas={(value) => {this.getDatas(value)}}
                danhMucId={this.danhMucId}
                kanjiDatas={this.state.kanjiDatas}
                level={this.props.level}
                lessonUpdateClick={(value) => {this.props.lessonUpdateClick(value)}}/>
          </View>
        );
      } else if (this.state.kanjiType == "flashcard") {
        return(
          <View style={style.kanjiContainer}>
            <TopMenu
              contentClick={() => {this.contentClick()}}
              flashCardClick={() => {this.flashCardClick()}}
              quizClick={() => {this.quizClick()}}
              nameButton={"Kanji"}/>
            <KanjiFlashCard
              page={this.page}
              level={this.props.level}
              kanjiIds={this.kanjiIds}/>
          </View>
        );
      } else if (this.state.kanjiType == "kiemtra") {
        return(
          <View style={style.kanjiContainer}>
            <TopMenu
              contentClick={() => {this.contentClick()}}
              flashCardClick={() => {this.flashCardClick()}}
              quizClick={() => {this.quizClick()}}
              nameButton={"Kanji"}/>
              <KanjiKiemTraList
                kanjiDatas={this.state.kanjiDatas}
                level={this.props.level}
                lessonUpdateClick={(value) => {this.props.lessonUpdateClick(value)}}/>
          </View>
        );
      }
    }
  }
  // vocabulary, flashcard, kiemtra
  contentClick(){
    this.props.lessonUpdateClick(0.5);
    this.setState({
      kanjiType: "kanji"
    });

  }
  flashCardClick(){
    this.props.lessonUpdateClick(0.5);
    this.setState({
      kanjiType: "flashcard"
    });

  }
  quizClick(){
    this.props.lessonUpdateClick(0.5);
    this.setState({
      kanjiType: "kiemtra"
    });

  }
  backProcess(){
		this.setState({
			isContent: 0,
		});
	}

  GetListViewItem(value) {
    this.props.lessonUpdateClick(3);
    this.page = value.index;
		this.props.updateIsContent();
    var sql = "";
    console.log(value.ids);
    if(this.props.level != 0) {
  		sql = "SELECT * FROM kanji WHERE `parent_id`="+ this.props.level +" and page='" + value.index + "'";
    } else {
      if(typeof value.ids !== 'undefined') {
        sql = "SELECT * FROM kanji WHERE `id` in ("+ value.ids +")";
        this.kanjiIds = value.ids;
        this.danhMucId = value.index;
      } else {
        sql = "SELECT * FROM kanji WHERE `id` in ("+ value +")";
        this.kanjiIds = value;
      }
    }

		db.transaction((tx) => {
			tx.executeSql(sql, [], (tx, results) => {
					var array = [];
					var len = results.rows.length;
					for (let i = 0; i < len; i++) {
            var id = results.rows.item(i)["id"];
            var kanjiName = results.rows.item(i)["kanji_name"];
            var kun = results.rows.item(i)["kun"];
            var on = results.rows.item(i)["om"];
            var example = results.rows.item(i)["w"];
            var rows = {"id": id, "kanjiName": kanjiName, kun: kun, on: on, "example": "no_data", indexBtn: i};
            if(example != "") {
              rows = {"id": id, "kanjiName": kanjiName, kun: kun, on: on, "example": "have_data", indexBtn: i};
            } else {
              rows = {"id": id, "kanjiName": kanjiName, kun: kun, on: on, "example": "no_data", indexBtn: i};
            }
						array[i] = rows;
					}
					this.setState({
            kanjiType: "kanji",
						isContent: 1,
						kanjiDatas: array,
					});
			 });
		});
	}

  getDatas(){
    if(this.props.level != 0) {
      db.transaction((tx) => {
        tx.executeSql('SELECT * FROM category WHERE id='+ this.props.level, [], (tx, results) => {
  					var array = [];
            var numberPage = results.rows.item(0)["number_page_kanji"];
            for (let i = 0; i < numberPage; i++) {
              var row = {"stt": i + 1, "index": i, "title": "Bài Số " + (i + 1), "ids": ""};
              array[i] = row;
            }
  					this.setState({
              lenghtData: array.length,
  						dataSource: this.state.dataSource.cloneWithRows(array),
  					});
          });
      });
    } else {
      db1.transaction((tx) => {
        tx.executeSql("SELECT * FROM folder where type='kanji'", [], (tx, results) => {
  					var array = [];
            let numberPage = results.rows.length;
            for (let i = 0; i < numberPage; i++) {
              var row = {"stt": i + 1, "index": results.rows.item(i).id, "title": results.rows.item(i).name, "ids": results.rows.item(i).ids};
              array[i] = row;
            }
  					this.setState({
              lenghtData: array.length,
  						dataSource: this.state.dataSource.cloneWithRows(array),
  					});
          });
      });
    }
  }
  componentDidMount() {
    this.getDatas();
	}
}

const style = StyleSheet.create({
	listView: {
		/*flexDirection: 'row',
		height: 40,
		marginLeft: 10,
		marginRight: 10,
		marginTop: 3,
		borderRadius: 7,
		backgroundColor: '#ffffff',*/
    flexDirection: 'row',
    padding: 10,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderBottomColor: '#2ea5dd',
    borderTopColor: '#75d2f0',
    backgroundColor: '#4fc1e9',
		//justifyContent: 'center',
	},
  kanjiContainer: {
		flex: 1,
		backgroundColor: '#e3e4e8',
	},
});
