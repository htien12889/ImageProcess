import React, {Component} from 'react';
import {View, Text, StyleSheet, ListView} from 'react-native';
import KanjiCard from './KanjiCard.js';
var SQLite = require('react-native-sqlite-storage');
var db = SQLite.openDatabase({name : "jlptDB_v2_new", createFromLocation : "~jlpt_v2_new.db"}, this.openCB,this.errorCB);
export default class KanjiFlashCard extends Component<{}>{
  constructor(props){
    super(props);
    this.state = {
			dataSource: new ListView.DataSource({rowHasChanged: (r1, r2)=>r1!==r2}),
      dataLenght: 1,
		}
  }
  render() {
    if(this.state.dataLenght == 0) {
      return(
        <View style={style.vocabularyContainer}>
          <View style={{flex: 1, justifyContent: 'center', paddingLeft: 5, paddingRight: 5}}>
            <Text style={{textAlign: 'center', fontWeight: 'bold', fontSize: 25}}>Không có từ kanji nào trong danh mục này</Text>
          </View>
        </View>
      );
    } else {
      return(
        <View style={style.vocabularyContainer}>
          <View style={style.vocabularyContent}>
            <ListView
              dataSource={this.state.dataSource}
              renderRow={(rowData) =>
                <KanjiCard
                  frontArray={rowData.front}
                  backArray={rowData.back} />
              }
            />
          </View>
        </View>
      );
    }

  }
  componentDidMount(){
    var page = this.props.page;
    var sql = "";
    if(this.props.level == 0) {
      sql = "SELECT * FROM kanji WHERE `id` in ("+this.props.kanjiIds+")";
    } else {
      sql = "SELECT * FROM kanji WHERE `parent_id`="+this.props.level+" and page='" + page + "'";
    }
		db.transaction((tx) => {
			tx.executeSql(sql, [], (tx, results) => {
					var array = [];
					var len = results.rows.length;

					for (let i = 0; i < len; i++) {
            var id = results.rows.item(i)["id"];
            var kanjiName = results.rows.item(i)["kanji_name"];
            var w = results.rows.item(i)["w"];
            w = w.split("$$##$$");
            var p = results.rows.item(i)["p"];
            p = p.split("$$##$$");
            var m = results.rows.item(i)["m"];
            m = m.split("$$##$$");
            var h = results.rows.item(i)["h"];
            h = h.split("$$##$$");
            var on = results.rows.item(i)["on"];
            var kun = results.rows.item(i)["kun"];
            var frontArray = [];
            var backArray = [];
            var rows_front = {"name": kanjiName, "w": w};
            var rows_back = {"name": kanjiName, "p": p, "m": m, "h": h, "on": on, "kun": kun};
            var rows = {"front": rows_front, "back": rows_back};
						array[i] = rows;
					}
          this.setState({
            dataSource: this.state.dataSource.cloneWithRows(array),
            dataLenght: array.length,
          });

			 });
		});

  }
}

const style = StyleSheet.create({
  vocabularyContainer: {
    flex: 1,
    backgroundColor: '#e3e4e8',
  },
  vocabularyContent: {
    flex: 1,
    marginTop: 7,
    marginLeft: 7,
    marginRight: 7,
  }
});
