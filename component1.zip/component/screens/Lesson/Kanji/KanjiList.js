import React, {Component} from 'react';
import {View, Text, StyleSheet, TouchableOpacity, Animated, Dimensions, NetInfo, Alert, StatusBar, ListView} from 'react-native';
import KanjiContent from './KanjiContent.js';
import DanhMuc from '../danhMuc/DanhMuc.js';
var {height, width} = Dimensions.get('window');
var heightOfView = height - 150 - StatusBar.currentHeight;
var heightOfAddDanhMuc = heightOfView;
var SQLite = require('react-native-sqlite-storage')
var db = SQLite.openDatabase({name : "jlptDB_v2_new", createFromLocation : "~jlpt_v2_new.db"}, this.openCB,this.errorCB);
var db1 = SQLite.openDatabase({name : "jlptDB_folder", createFromLocation : "~folder.db"}, this.openCB,this.errorCB);
export default class KanjiList extends Component {
  constructor(props) {
    super(props);
    this.kanjiId = 0;
    this.rows = 0;
    this.state = {
      dataSource: new ListView.DataSource({rowHasChanged: (r1, r2)=>r1!==r2}),
      lenghtData: 1,
      id: 0,
      renderOverlay: 0,
      topAnimate: new Animated.Value(-heightOfView),
		}
  }
  render() {
    //console.log(this.props.kanjiDatas);
    this.rows = 0;
    if(this.state.id == 0) {
      if(this.props.kanjiDatas.length == 0) {
        return(
          <View style={style.kanjiListContainer}>
            <View style={{flex: 1, justifyContent: 'center', paddingLeft: 5, paddingRight: 5}}>
              <Text style={{textAlign: 'center', fontWeight: 'bold', fontSize: 25}}>Không có từ kanji nào trong danh mục này</Text>
            </View>
          </View>
        );
      } else {
        if(this.props.level != 0) {
          return(
            <View style={style.kanjiListContainer}>
              {this.renderContentList()}
              {this.renderContentList()}
              {this.renderContentList()}
              {this.renderContentList()}
              {this.renderContentList()}
            </View>
          );
        } else {
          return(
            <View style={style.kanjiListContainer}>
              <View style={{flex: 1}}>
                <ListView
                  dataSource={this.state.dataSource}
                  renderRow={(rowData) =>
                    <TouchableOpacity style={style.listView}
                      onPress={this.showContent.bind(this, rowData.id)}>
                      <View style={{justifyContent: 'center'}}>
                        <Text style={{fontSize: 20, fontWeight: 'bold', marginLeft: 15, color: 'white'}}>{rowData.indexBtn + 1}.  {rowData.kanjiName}</Text>
                      </View>
                    </TouchableOpacity>
                  }
                />
              </View>
            </View>
          );
        }

      }

    } else {
      return(
        <View style={style.kanjiListContainer}>
          {this.renderOverlay()}
          <Animated.View style={{position: 'absolute', bottom: this.state.topAnimate, left: 7, height: heightOfAddDanhMuc, width: width - 14, zIndex: 999}}>
            <DanhMuc
              title="Danh mục kanji"
              type="kanji"
              ref="danhMuc"
              addDanhMucAction={(value) => {this.addDanhMucAction(value)}}
              closeList={() => {this.closeList()}}/>
          </Animated.View>
          <KanjiContent
            danhMucId={this.props.danhMucId}
            removeKanjiType={(kanjiId, dmId) => {this.removeKanjiType(kanjiId, dmId)}}
            level={this.props.level}
            addKanjiType={(value) => {this.addKanjiType(value)}}
            id={this.state.id}/>
        </View>
      );
    }
  }
  removeKanjiType(kanjiId, dmId) {
    var sql = "SELECT * FROM folder WHERE `id`='"+ dmId +"'";
    //console.log(sql);
    db1.transaction((tx) => {
      tx.executeSql(sql, [], (tx, results) => {
        let ids = results.rows.item(0).ids;
        let idsWrite = "";
        let arrayIds = ids.split(',');
        let j = 0;
        for(let i = 0; i < arrayIds.length; i++) {
          if(arrayIds[i] == kanjiId) {
            continue;
          }
          if(j == 0) {
            idsWrite = idsWrite + arrayIds[i];
          } else {
            idsWrite = idsWrite + "," + arrayIds[i];
          }
          j++;
        }
        db1.transaction((tx) => {
          //console.log("INSERT INTO folder (`type`,`name`) VALUES ('vocabulary','"+value+"')");
          //console.log("UPDATE folder SET ids='"+idsWrite+"' WHERE id='"+dmId+"'");
          tx.executeSql("UPDATE folder SET ids='"+idsWrite+"' WHERE id='"+dmId+"'", [], (tx, results) => {
            this.getListViewDM(idsWrite);
            this.props.reloadDatas(idsWrite);
          });
        });
       });
    });
  }
  getListViewDM(value) {
    var sql = "SELECT * FROM kanji WHERE `id` in ("+ value +")";
    db.transaction((tx) => {
      tx.executeSql(sql, [], (tx, results) => {
          var array = [];
          var len = results.rows.length;
          for (let i = 0; i < len; i++) {
            var id = results.rows.item(i)["id"];
            var kanjiName = results.rows.item(i)["kanji_name"];
            var kun = results.rows.item(i)["kun"];
            var on = results.rows.item(i)["om"];
            var example = results.rows.item(i)["w"];
            var rows = {"id": id, "kanjiName": kanjiName, kun: kun, on: on, "example": "no_data", indexBtn: i};
            if(example != "") {
              rows = {"id": id, "kanjiName": kanjiName, kun: kun, on: on, "example": "have_data", indexBtn: i};
            } else {
              rows = {"id": id, "kanjiName": kanjiName, kun: kun, on: on, "example": "no_data", indexBtn: i};
            }
						array[i] = rows;
          }
          this.setState({
            id: 0,
          });
          this.props.kanjiDatas = array;
          this.props.getDatas();
          this.setState({
            dataSource: this.state.dataSource.cloneWithRows(array),
          });
          /*this.getDatas();
          this.refs.vocaContent.resetDatas(array);*/
       });
    });
  }
  addDanhMucAction(value) {
    db1.transaction((tx) => {
      tx.executeSql("SELECT * FROM folder where type='kanji' and id='"+value.id+"'", [], (tx, results) => {
        let ids = results.rows.item(0).ids;
        if(ids) {
          let arrayIds = ids.split(',');
          let lengthIds = arrayIds.length;
          if(lengthIds == 0) {
            ids = ids + "," + this.kanjiId;
          } else {
            let check = false;
            for(let i = 0; i < lengthIds; i++) {
              if(this.kanjiId == arrayIds[i]) {
                check = true;
                break;
              }
            }
            if(check) {
              Alert.alert(
                'Thông Báo',
                '"'+value.name+'" đã tồn tại từ này',
                [
                  {text: 'OK', onPress: () => {console.log("ok")}},
                ]
              );
              return;
            } else {
              ids = ids + "," + this.kanjiId;
            }
          }
        } else {
          ids = this.kanjiId;
        }
        //console.log(ids);
        db1.transaction((tx) => {
          //console.log("INSERT INTO folder (`type`,`name`) VALUES ('vocabulary','"+value+"')");
          tx.executeSql("UPDATE folder SET ids='"+ids+"' WHERE id='"+value.id+"' ", [], (tx, results) => {
            //this.getDatas();
            this.closeList();
          });
        });

      });
    });
  }
  addKanjiType(value) {
    this.kanjiId = value;
    this.refs.danhMuc.resetDanhMuc(value);
    //console.log(value);
    this.setState({
      renderOverlay: 1,
    });
    Animated.timing(
      this.state.topAnimate,
      {
        toValue: 0,
        duration: 200,
      }
    ).start();
  }
  renderOverlay(){
    if(this.state.renderOverlay == 1) {
      return(
        <View style={{backgroundColor: 'black', opacity: 0.5, width: width, height: height, position: 'absolute', top: 0, left: 0, zIndex: 99}}></View>
      );
    }
  }
  closeList() {
    //console.log(value);
    this.setState({
      renderOverlay: 0,
    });
    Animated.timing(
      this.state.topAnimate,
      {
        toValue: -heightOfView,
        duration: 200,
      }
    ).start();
  }

  showContent(id) {
    NetInfo.isConnected.fetch().then(isConnected => {
      if(isConnected)
      {
        this.props.lessonUpdateClick(1);
        this.setState({
          id: id,
        });
      } else {
        Alert.alert(
    			'Thông Báo',
    			'Hãy kết nối internet để sử dụng chức năng này',
    			[
    				{text: 'OK', onPress: () => {console.log("ok")}},
    			]
    		);
      }
    });
    /*this.props.lessonUpdateClick(1);
    this.setState({
      id: id,
    });*/
  }
  renderContentList(){
    var len = this.props.kanjiDatas.length;
    var row = this.rows;
    if((row * 2) + 1 <= (len - 1)) {
      this.rows += 1;
      return(
        <View style={style.kanjiListRow}>
          <TouchableOpacity style={style.kanjiListCol} onPress={this.showContent.bind(this, this.props.kanjiDatas[row * 2]["id"])}>
            <Text style={{fontSize: 45, fontWeight: 'bold', color: '#006335', textAlign: 'center'}}>{this.props.kanjiDatas[row * 2]["kanjiName"]}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={style.kanjiListCol2} onPress={this.showContent.bind(this, this.props.kanjiDatas[row * 2 + 1]["id"])}>
            <Text style={{fontSize: 45, fontWeight: 'bold', color: '#006335', textAlign: 'center'}}>{this.props.kanjiDatas[row * 2 + 1]["kanjiName"]}</Text>
          </TouchableOpacity>
        </View>
      );
    } else {
      this.rows += 1;
      if(row * 2 <= (len - 1)) {
        return(
          <View style={style.kanjiListRow}>
            <TouchableOpacity style={style.kanjiListCol} onPress={this.showContent.bind(this, this.props.kanjiDatas[row * 2]["id"])}>
              <Text style={{fontSize: 45, fontWeight: 'bold', color: '#006335', textAlign: 'center'}}>{this.props.kanjiDatas[row * 2]["kanjiName"]}</Text>
            </TouchableOpacity>
            <View style={style.kanjiListCol2Emp}>

            </View>
          </View>
        );
      } else {
        return(
          <View style={style.kanjiListRow}>
            <View style={style.kanjiListColEmp}>

            </View>
            <View style={style.kanjiListCol2Emp}>

            </View>
          </View>
        );
      }
    }
  }
  componentDidMount() {
    if(this.props.level == 0) {
      this.setState({
        dataSource: this.state.dataSource.cloneWithRows(this.props.kanjiDatas),
      });

    }
	}
}
const style = StyleSheet.create({
  listView: {
		/*flexDirection: 'row',
		height: 40,
		marginLeft: 10,
		marginRight: 10,
		marginTop: 3,
		borderRadius: 7,
		backgroundColor: '#ffffff',*/
    padding: 10,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderBottomColor: '#2ea5dd',
    borderTopColor: '#75d2f0',
    backgroundColor: '#4fc1e9',
		//justifyContent: 'center',
	},
  kanjiListContainer: {
    backgroundColor: 'white',
    paddingTop: 5,
    flex: 1,
  },
  kanjiListRow: {
    flexDirection: 'row',
    flex: 1,
  },
  kanjiListCol: {
    backgroundColor: 'white',
    justifyContent: 'center',
    flex: 1,
    borderWidth: 1,
    borderColor: '#006335',
    borderRadius: 5,
    marginLeft: 10,
    marginRight: 3,
    marginTop: 3,
    marginBottom: 3,
  },
  kanjiListCol2: {
    backgroundColor: 'white',
    justifyContent: 'center',
    flex: 1,
    borderWidth: 1,
    borderColor: '#006335',
    borderRadius: 5,
    marginLeft: 3,
    marginRight: 10,
    marginTop: 3,
    marginBottom: 3,
  },

  kanjiListColEmp: {
    justifyContent: 'center',
    flex: 1,
    borderRadius: 5,
    marginLeft: 10,
    marginRight: 3,
    marginTop: 3,
    marginBottom: 3,
  },
  kanjiListCol2Emp: {
    justifyContent: 'center',
    flex: 1,
    marginLeft: 3,
    marginRight: 10,
    marginTop: 3,
    marginBottom: 3,
  }
});
