import React, {Component} from 'react';
import {Button, View, Text, StyleSheet, TouchableOpacity, Animated, Dimensions, Alert, ListView} from 'react-native';
import KanjiContent from './KanjiContent.js';
import KanjiKiemTra from './KanjiKiemTra.js';
var SQLite = require('react-native-sqlite-storage');
var db = SQLite.openDatabase({name : "jlptDB_v2_new", createFromLocation : "~jlpt_v2_new.db"}, this.openCB,this.errorCB);
export default class KanjiKiemTraList extends Component {
  constructor(props) {
    super(props);
    this.rows = 0;
    this.chooseIdsStyle = [];
    this.chooseIds = [];
    this.dataForKiemTra = [];
    if(this.props.level == 0) {
      for(let i = 0; i < this.props.kanjiDatas.length; i++) {
        var rowStyle = {'color': '#4fc1e9', 'backgroundColor': '#4fc1e9'};
        this.chooseIdsStyle[i] = rowStyle;
        this.chooseIds[i] = 0;
      }
    }
    this.state = {
      dataSource: new ListView.DataSource({rowHasChanged: (r1, r2)=>r1!==r2}),
      id: 0,
      goDisable: true,
      isFirstRender: true,
      elementStyle: [],
      kiemTraDatas: [],
      isKiemTra: false,
      dataRight: false,
      goClick: 0,
		}
  }
  render() {
    this.rows = 0;
    if(this.state.isKiemTra == false) {
      if(this.props.kanjiDatas.length == 0) {
        return(
          <View style={style.kanjiListContainer}>
            <View style={{flex: 1, justifyContent: 'center', paddingLeft: 5, paddingRight: 5}}>
              <Text style={{textAlign: 'center', fontWeight: 'bold', fontSize: 25}}>Không có từ kanji nào trong danh mục này</Text>
            </View>
          </View>
        );
      } else {
        if(this.props.level == 0) {
          return(
            <View style={style.kanjiListContainer}>
              <View style={{flex: 1, justifyContent: 'center'}}>
                <View>
                  <Text style={{textAlign: 'center', color: 'black', fontSize: 18, fontWeight: 'bold', fontStyle: 'italic',}}>Hãy Chọn Kanji Sau Đó Nhấn Go</Text>
                </View>
                <View style={{flex: 1, justifyContent: 'center', marginLeft: 10, marginRight: 10, marginTop: 5, borderRadius: 5, marginBottom: 10}}>
                  <Button
                    onPress={() => this.goButtonPress()}
                    title="Go"
                    color="#a0d468"
                    accessibilityLabel="Go"
                    disabled={this.state.goDisable} />
                </View>
              </View>
              <View style={{flex: 5}}>
                <View style={{flex: 1}}>
                  <ListView
                    dataSource={this.state.dataSource}
                    renderRow={(rowData) =>
                      <TouchableOpacity style={[style.listView, {backgroundColor: this.chooseIdsStyle[rowData.indexBtn].backgroundColor}]}
                        onPress={this.chooseKanji.bind(this, rowData.id, rowData.indexBtn)}>
                        <Text style={{fontSize: 20, fontWeight: 'bold', marginLeft: 15, color: 'white', textAlign: 'center'}}>{rowData.kanjiName}</Text>
                      </TouchableOpacity>
                    }
                  />
                </View>
              </View>

            </View>
          );
        } else {
          return(
            <View style={style.kanjiListContainer}>
              <View style={{flex: 1, justifyContent: 'center'}}>
                <View>
                  <Text style={{textAlign: 'center', color: 'black', fontSize: 18, fontWeight: 'bold', fontStyle: 'italic',}}>Hãy Chọn Kanji Sau Đó Nhấn Go</Text>
                </View>
                <View style={{flex: 1, justifyContent: 'center', marginLeft: 10, marginRight: 10, marginTop: 5, borderRadius: 5}}>
                  <Button
                    onPress={() => this.goButtonPress()}
                    title="Go"
                    color="#3bafda"
                    accessibilityLabel="Go"
                    disabled={this.state.goDisable} />
                </View>
              </View>
              <View style={{flex: 5}}>
                {this.renderContentList()}
                {this.renderContentList()}
                {this.renderContentList()}
                {this.renderContentList()}
                {this.renderContentList()}
              </View>

            </View>
          );
        }
      }

    } else {

      if(this.state.dataRight) {
        return(
          <KanjiKiemTra
            kiemTraDatas={this.state.kiemTraDatas}
            lessonUpdateClick={(value) => {this.props.lessonUpdateClick(value)}}/>
        );
      } else {
        Alert.alert(
    			'Thông Báo',
    			'Từ Kanji đã chọn không đủ dữ liệu để làm kiểm tra, hãy chọn thêm một chữ kanji nữa',
    			[
    				{text: 'OK', onPress: () => {console.log("ok")}},
    			]
    		);
        if(this.props.level == 0) {
          return (
            <View style={style.kanjiListContainer}>
              <View style={{flex: 1, justifyContent: 'center'}}>
                <View>
                  <Text style={{textAlign: 'center', color: 'black', fontSize: 18, fontWeight: 'bold', fontStyle: 'italic',}}>Hãy Chọn Kanji Sau Đó Nhấn Go</Text>
                </View>
                <View style={{flex: 1, justifyContent: 'center', marginLeft: 10, marginRight: 10, marginTop: 5, borderRadius: 5}}>
                  <Button
                    onPress={() => this.goButtonPress()}
                    title="Go"
                    color="#3bafda"
                    accessibilityLabel="Go"
                    disabled={this.state.goDisable} />
                </View>
              </View>
              <View style={{flex: 5}}>
                <View style={{flex: 1}}>
                  <ListView
                    dataSource={this.state.dataSource}
                    renderRow={(rowData) =>
                      <TouchableOpacity style={[style.listView, {backgroundColor: this.chooseIdsStyle[rowData.indexBtn].backgroundColor}]}
                        onPress={this.chooseKanji.bind(this, rowData.id, rowData.indexBtn)}>
                        <Text style={{fontSize: 20, fontWeight: 'bold', marginLeft: 15, color: 'white', textAlign: 'center'}}>{rowData.kanjiName}</Text>
                      </TouchableOpacity>
                    }
                  />
                </View>
              </View>

            </View>
          );
        } else {
          return (
            <View style={style.kanjiListContainer}>
              <View style={{flex: 1, justifyContent: 'center'}}>
                <View>
                  <Text style={{textAlign: 'center', color: 'black', fontSize: 18, fontWeight: 'bold', fontStyle: 'italic',}}>Hãy Chọn Kanji Sau Đó Nhấn Go</Text>
                </View>
                <View style={{flex: 1, justifyContent: 'center', marginLeft: 10, marginRight: 10, marginTop: 5, borderRadius: 5}}>
                  <Button
                    onPress={() => this.goButtonPress()}
                    title="Go"
                    color="#3bafda"
                    accessibilityLabel="Go"
                    disabled={this.state.goDisable} />
                </View>
              </View>
              <View style={{flex: 5}}>
                {this.renderContentList()}
                {this.renderContentList()}
                {this.renderContentList()}
                {this.renderContentList()}
                {this.renderContentList()}
              </View>

            </View>
          );
        }

      }
    }
  }
  goButtonPress(){
    var len = this.chooseIds.length;
    var idString = "";
    for(let i = 0; i < len; i++){
      if(this.chooseIds[i] == 0) {
        continue;
      }
      idString += this.chooseIds[i] + ",";
    }
    idString = idString.substring(0, idString.length - 1);

    var sql = "SELECT * FROM kanji WHERE `id` in ("+ idString +")";
    var indexRows = 0;
    db.transaction((tx) => {
      tx.executeSql(sql, [], (tx, results) => {
          var array = [];
          var len = results.rows.length;

          for (let i = 0; i < len; i++) {
            var id = results.rows.item(i)["id"];
            var kanjiName = results.rows.item(i)["kanji_name"];
            var w = results.rows.item(i)["w"];
            w = w.split("$$##$$");
            var p = results.rows.item(i)["p"];
            p = p.split("$$##$$");
            var m = results.rows.item(i)["m"];
            m = m.split("$$##$$");
            var lenExam = w.length;
            for(let j = 0; j < lenExam; j++) {
              var datas = {"w": w[j], "p": p[j]};
              array[indexRows] = datas;
              indexRows += 1;
            }
          }
          if(this.createDataForKiemTra(array)) {
            this.setState({
              kiemTraDatas: this.dataForKiemTra,
              isKiemTra: true,
              dataRight: true,
              goClick: this.state.goClick + 1,
            });
          } else {
            this.setState({
              kiemTraDatas: this.dataForKiemTra,
              isKiemTra: true,
              dataRight: false,
              goClick: this.state.goClick + 1,
            });
          }
          //console.log(array);
          /*this.setState({
            kiemTraDatas: array,
            isKiemTra: true,
          });*/

       });
    });
  }
  getRandomInt(min, max) {
    var number = Math.floor(Math.random() * (max - min + 1)) + min;
    return parseInt(number);
  }
  createDataForKiemTra(KTKanjidatas) {
    var len = KTKanjidatas.length;
    for(let i = 0; i < len; i++){
      //rowData.word + "(" + rowData.phonetic + ")"
      this.tongSo += 1;
      var answers = [];
      var oldIndex = [];
      var question = KTKanjidatas[i].w;
      var questionText = KTKanjidatas[i].w;
      var correctNumber = this.getRandomInt(0, 3);
      for(let j = 0; j < 4; j++) {
        if(j != correctNumber) {
          var aswIndex = this.getRandomInt(0, len - 1);
          oldIndex[j] = aswIndex;
        } else {
          //answers[j] = this.props.vocabularyDatas[i].mean;
          oldIndex[j] = i;
        }
      }
      var lenAnswerIndex = oldIndex.length;
      for(let j = 0; j < lenAnswerIndex; j++) {
        if(j == correctNumber) {
          answers[j] = KTKanjidatas[oldIndex[j]].p;
          continue;
        }
        let answ1 = oldIndex[0];
        let answ2 = oldIndex[1];
        let answ3 = oldIndex[2];
        let answ4 = oldIndex[3];
        let answer1 = KTKanjidatas[answ1].w;
        let answer2 = KTKanjidatas[answ2].w;
        let answer3 = KTKanjidatas[answ3].w;
        let answer4 = KTKanjidatas[answ4].w;
        let ansOldIndex = KTKanjidatas[oldIndex[j]].w;
        let count = 0;
        while (oldIndex[j] == answ1 || oldIndex[j] == answ2 || oldIndex[j] == answ3 || oldIndex[j] == answ4 ||
              ansOldIndex == answer1 || ansOldIndex == answer2 || ansOldIndex == answer3 || ansOldIndex == answer4) {
          count++;
          oldIndex[j] = this.getRandomInt(0, len - 1);
          ansOldIndex = KTKanjidatas[oldIndex[j]].w;
          if(count == 100) {
            return false;
          }
        }
        answers[j] = KTKanjidatas[oldIndex[j]].p;
      }
      var row = {"answers": answers, "correctNumber": correctNumber, "question": questionText};
      this.dataForKiemTra[i] = row;
    }

    for(let i = 0; i < len; i++){
      //rowData.word + "(" + rowData.phonetic + ")"
      this.tongSo += 1;
      var answers = [];
      var oldIndex = [];
      var question = KTKanjidatas[i].p;
      var questionText = KTKanjidatas[i].p;
      var correctNumber = this.getRandomInt(0, 3);
      for(let j = 0; j < 4; j++) {
        if(j != correctNumber) {
          var aswIndex = this.getRandomInt(0, len - 1);
          oldIndex[j] = aswIndex;
        } else {
          //answers[j] = this.props.vocabularyDatas[i].mean;
          oldIndex[j] = i;
        }
      }
      var lenAnswerIndex = oldIndex.length;
      for(let j = 0; j < lenAnswerIndex; j++) {
        if(j == correctNumber) {
          answers[j] = KTKanjidatas[oldIndex[j]].w;
          continue;
        }
        let answ1 = oldIndex[0];
        let answ2 = oldIndex[1];
        let answ3 = oldIndex[2];
        let answ4 = oldIndex[3];

        let answer1 = KTKanjidatas[answ1].w;
        let answer2 = KTKanjidatas[answ2].w;
        let answer3 = KTKanjidatas[answ3].w;
        let answer4 = KTKanjidatas[answ4].w;
        let ansOldIndex = KTKanjidatas[oldIndex[j]].w;
        let count = 0;
        while (oldIndex[j] == answ1 || oldIndex[j] == answ2 || oldIndex[j] == answ3 || oldIndex[j] == answ4 ||
              ansOldIndex == answer1 || ansOldIndex == answer2 || ansOldIndex == answer3 || ansOldIndex == answer4) {
          count++;
          oldIndex[j] = this.getRandomInt(0, len - 1);
          ansOldIndex = KTKanjidatas[oldIndex[j]].w;
          if(count == 100) {
            return false;
          }
        }
        answers[j] = KTKanjidatas[oldIndex[j]].w;
      }
      var row = {"answers": answers, "correctNumber": correctNumber, "question": questionText};
      this.dataForKiemTra[i + len] = row;
    }
    for(let i = 0; i < 2 * len; i++) {
      var ranNum = this.getRandomInt(0, (2 * len) - 1);
      var temp = this.dataForKiemTra[ranNum];
      this.dataForKiemTra[ranNum] = this.dataForKiemTra[i];
      this.dataForKiemTra[i] = temp;
    }
    return true;
  }
  chooseKanji(id, indexChoose) {
    if(this.props.level == 0) {
      if(this.chooseIds[indexChoose] == 0) {
        this.chooseIdsStyle[indexChoose] = {'color': 'white', 'backgroundColor': '#3bafda'};
        this.chooseIds[indexChoose] = id;
      } else {
        this.chooseIdsStyle[indexChoose] = {'color': 'white', 'backgroundColor': '#4fc1e9'};
        this.chooseIds[indexChoose] = 0;
      }
    } else {
      if(this.chooseIds[indexChoose] == 0) {
        this.chooseIdsStyle[indexChoose] = {'color': 'white', 'backgroundColor': '#006335'};
        this.chooseIds[indexChoose] = id;
      } else {
        this.chooseIdsStyle[indexChoose] = {'color': '#006335', 'backgroundColor': 'white'};
        this.chooseIds[indexChoose] = 0;
      }
    }


    this.updateStyle();
  }
  updateStyle(){
    var len = this.chooseIds.length;
    var check = false;
    for(let i = 0; i < len; i++){
      if(this.chooseIds[i] != 0) {
        check = true;
        break;
      }
    }
    if(check) {
      this.setState({
        isKiemTra: false,
        goDisable: false,
        isFirstRender: false,
        elementStyle: this.chooseIdsStyle,
      })
    } else {
      this.setState({
        isKiemTra: false,
        goDisable: true,
        isFirstRender: false,
        elementStyle: this.chooseIdsStyle,
      })
    }

  }
  renderKanjiButton1(indexBtn){
    //console.log(this.props.kanjiDatas[indexBtn]["example"]);
    if(this.props.kanjiDatas[indexBtn]["example"] != "no_data") {
      return(
        <TouchableOpacity style={[style.kanjiListCol, {backgroundColor: this.chooseIdsStyle[indexBtn].backgroundColor}]} onPress={this.chooseKanji.bind(this, this.props.kanjiDatas[indexBtn]["id"], indexBtn)}>
          <Text style={{fontSize: 45, fontWeight: 'bold', color: this.chooseIdsStyle[indexBtn].color, textAlign: 'center'}}>{this.props.kanjiDatas[indexBtn]["kanjiName"]}</Text>
        </TouchableOpacity>
      );
    }
  }

  renderKanjiButton2(indexBtn){
    //console.log(this.props.kanjiDatas[indexBtn]["example"]);
    if(this.props.kanjiDatas[indexBtn]["example"] != "no_data") {
      return(
        <TouchableOpacity style={[style.kanjiListCol2, {backgroundColor: this.chooseIdsStyle[indexBtn].backgroundColor}]} onPress={this.chooseKanji.bind(this, this.props.kanjiDatas[indexBtn]["id"], indexBtn)}>
          <Text style={{fontSize: 45, fontWeight: 'bold', color: this.chooseIdsStyle[indexBtn].color, textAlign: 'center'}}>{this.props.kanjiDatas[indexBtn]["kanjiName"]}</Text>
        </TouchableOpacity>
      );
    }
  }
  renderContentList(){
    var len = this.props.kanjiDatas.length;
    var row = this.rows;
    if((row * 2) + 1 <= (len - 1)) {
      this.rows += 1;
      if(this.state.isFirstRender) {
        var rowStyle = {'color': '#006335', 'backgroundColor': 'white'};
        this.chooseIdsStyle[row * 2] = rowStyle;
        this.chooseIdsStyle[row * 2 + 1] = rowStyle;
        this.chooseIds[row * 2] = 0;
        this.chooseIds[row * 2 + 1] = 0;
      }
      return(
        <View style={style.kanjiListRow}>
          {this.renderKanjiButton1(row * 2)}
          {this.renderKanjiButton2(row * 2 + 1)}
        </View>
      );
    } else {
      this.rows += 1;
      if(row * 2 <= (len - 1)) {
        if(this.state.isFirstRender) {
          rowStyle = {'color': '#006335', 'backgroundColor': 'white'};
          this.chooseIdsStyle[row * 2] = rowStyle;
          this.chooseIds[row * 2] = 0;
        }
        return(
          <View style={style.kanjiListRow}>
            {this.renderKanjiButton1(row * 2)}
            <View style={style.kanjiListCol2Emp}>

            </View>
          </View>
        );
      } else {
        return(
          <View style={style.kanjiListRow}>
            <View style={style.kanjiListColEmp}>

            </View>
            <View style={style.kanjiListCol2Emp}>

            </View>
          </View>
        );
      }
    }
  }
  componentDidMount() {
    if(this.props.level == 0) {
      this.setState({
        dataSource: this.state.dataSource.cloneWithRows(this.props.kanjiDatas),
      });

    }
	}
}
const style = StyleSheet.create({
  listView: {
		/*flexDirection: 'row',
		height: 40,
		marginLeft: 10,
		marginRight: 10,
		marginTop: 3,
		borderRadius: 7,
		backgroundColor: '#ffffff',*/
    padding: 10,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderBottomColor: '#2ea5dd',
    borderTopColor: '#75d2f0',
    backgroundColor: '#4fc1e9',
		//justifyContent: 'center',
	},
  kanjiListContainer: {
    marginTop: 5,
    flex: 1,
  },
  kanjiListRow: {
    flexDirection: 'row',
    flex: 1,
  },
  kanjiListCol: {
    backgroundColor: 'white',
    justifyContent: 'center',
    flex: 1,
    borderWidth: 1,
    borderColor: '#006335',
    borderRadius: 5,
    marginLeft: 10,
    marginRight: 3,
    marginTop: 3,
    marginBottom: 3,
  },
  kanjiListCol2: {
    backgroundColor: 'white',
    justifyContent: 'center',
    flex: 1,
    borderWidth: 1,
    borderColor: '#006335',
    borderRadius: 5,
    marginLeft: 3,
    marginRight: 10,
    marginTop: 3,
    marginBottom: 3,
  },

  kanjiListColEmp: {
    justifyContent: 'center',
    flex: 1,
    borderRadius: 5,
    marginLeft: 10,
    marginRight: 3,
    marginTop: 3,
    marginBottom: 3,
  },
  kanjiListCol2Emp: {
    justifyContent: 'center',
    flex: 1,
    marginLeft: 3,
    marginRight: 10,
    marginTop: 3,
    marginBottom: 3,
  }
});
