import React, {Component} from 'react';
import {View, TouchableOpacity, Text, StyleSheet, Linking} from 'react-native';
import PercentageCircle from 'react-native-percentage-circle';
export default class KanjiResult extends Component<{}>{
  render() {
    return(
      <View style={style.resultContainer}>
        <View style={style.resultPercent}>
          <PercentageCircle radius={70} percent={this.props.percent} color={"#e64c65"}
            innerColor={"#4fc1e9"}
            bgcolor={"#3bafda"}
            borderWidth={"20"}
            textStyle={{fontSize: "50", color: 'white'}}>
            <Text style={{fontSize: 20, color: 'white', fontWeight: 'bold'}}>{this.props.percent}%</Text>
          </PercentageCircle>
        </View>
        <View style={style.resultText}>
          {this.renderKetQua()}
          <Text style={{textAlign: 'center', fontSize: 15, fontWeight: 'bold', padding: 5, color: 'white'}}>Kết quả của bạn là {this.props.tongCauDung} câu đúng và {this.props.tongCauSai} câu sai</Text>
          <TouchableOpacity style={style.resultButton}
            onPress={() => {this.tryAgain()}}>
            <Text style={{textAlign: 'center', padding: 5, fontSize: 18, color: 'white', fontWeight: 'bold', paddingTop: 5, paddingBottom: 10}}>Làm Lại Bài Kiểm Tra</Text>
          </TouchableOpacity>
          <TouchableOpacity style={style.resultButton}
            onPress={() => {this.reviewApp()}}>
            <Text style={{textAlign: 'center', padding: 5, fontSize: 18, color: 'white', fontWeight: 'bold', paddingTop: 5, paddingBottom: 10}}>Đánh Giá Ứng Dụng</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }
  reviewApp(){
    Linking.openURL('https://play.google.com/store/apps/details?id=tienjoneey.com.jlpt');
  }
  tryAgain(){
    this.props.lessonUpdateClick(1);
    this.props.tryAgain();
  }
  renderKetQua() {
    if(this.props.percent < 50) {
      return(
        <Text style={{textAlign: 'center', fontSize: 20, fontWeight: 'bold', padding: 5, color: 'white'}}>Chưa Đạt!!!</Text>
      );
    } else if (this.props.percent >= 50 && this.props.percent < 70) {
      return(
        <Text style={{textAlign: 'center', fontSize: 20, fontWeight: 'bold', padding: 5, color: 'white'}}>Khá Tốt!!!</Text>
      );
    } else if (this.props.percent >= 70 && this.props.percent <= 100) {
      return(
        <Text style={{textAlign: 'center', fontSize: 20, fontWeight: 'bold', padding: 5, color: 'white'}}>Rất Tốt!!!</Text>
      );
    }
  }
}

const style = StyleSheet.create({
  resultButton: {
    marginTop: 10,
    marginLeft: 40,
    marginRight: 40,
    backgroundColor: '#a0d468',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'white',
    borderRadius: 5
  },
  resultPercent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  resultContainer: {
		flex: 1,
    justifyContent: 'center',
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: 'white',
    backgroundColor: '#4fc1e9',
	},
  resultText: {
    flex: 1,
  }
});
