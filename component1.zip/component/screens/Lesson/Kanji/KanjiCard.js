import React, {Component} from 'react';
import {View, Text, StyleSheet, TouchableOpacity, Animated, Dimensions} from 'react-native';
var {height, width} = Dimensions.get('window');
var heightOfCard = 0;
export default class KanjiCard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isRending: 0,
      heightBack: 0,
      heightFront: 0,
    }
  }
  componentWillMount() {
    this.animatedValue = new Animated.Value(0);
    this.value = 0;
    this.animatedValue.addListener(({ value }) => {
      this.value = value;
    })
    this.frontOpacity = this.animatedValue.interpolate({
      inputRange: [89, 90],
      outputRange: [1, 0]
    })
    this.frontInterpolate = this.animatedValue.interpolate({
      inputRange: [0, 180],
      outputRange: ['0deg', '180deg'],
    })
    this.backInterpolate = this.animatedValue.interpolate({
      inputRange: [0, 180],
      outputRange: ['180deg', '360deg']
    })
    this.backOpacity = this.animatedValue.interpolate({
      inputRange: [89, 90],
      outputRange: [0, 1]
    })
  }
  flipCard() {
    if (this.value >= 90) {
      Animated.spring(this.animatedValue,{
        toValue: 0,
        friction: 8,
        tension: 30
      }).start();
    } else {
      Animated.spring(this.animatedValue,{
        toValue: 180,
        friction: 8,
        tension: 30
      }).start();
    }

  }

  render() {

    if(this.state.heightFront < this.state.heightBack) {
      heightOfCard = this.state.heightBack;
    } else {
      heightOfCard = this.state.heightFront;
    }
    const frontAnimatedStyle = {
      opacity: this.frontOpacity,
      transform: [
        { rotateY: this.frontInterpolate}
      ]
    }
    // /console.log(heightOfCard);
    const backAnimatedStyle = {
      opacity: this.backOpacity,
      transform: [
        { rotateY: this.backInterpolate }
      ]
    }
    if(this.state.isRending == 1 ){
      return (
        <View style={styles.container}>
          <TouchableOpacity onPress={() => this.flipCard()}>
            <Animated.View onLayout={this.onLayoutHeightFront} style={[backAnimatedStyle, styles.flipCard, {width: width - 20, height: heightOfCard}, styles.flipCardBack]}>
              <View style={{width: width - 30, borderBottomWidth: 1, borderColor: "#00703c", marginBottom: 10}}>
                {this.renderOn()}
                {this.renderKun()}
              </View>
              {this.renderBackExam()}
            </Animated.View>
            <Animated.View onLayout={this.onLayoutHeightBack} style={[styles.flipCard, frontAnimatedStyle, {flexDirection: 'row', alignItems: 'center', justifyContent: 'center', height: heightOfCard}]}>
              <View style={styles.col1}>
                <Text style={styles.flipTextName}>
                  {this.props.frontArray.name}
                </Text>
              </View>
              {this.renderExample()}
            </Animated.View>
          </TouchableOpacity>
        </View>
      );
    } else {
      return (
        <View style={styles.container}>
          <TouchableOpacity onPress={() => this.flipCard()}>
            <Animated.View onLayout={this.onLayoutHeightFront} style={[backAnimatedStyle, styles.flipCard, {width: width - 20}, styles.flipCardBack]}>
              <View style={{width: width - 30, borderBottomWidth: 1, borderColor: "#00703c", marginBottom: 10}}>
                {this.renderOn()}
                {this.renderKun()}
              </View>
              {this.renderBackExam()}
            </Animated.View>
            <Animated.View onLayout={this.onLayoutHeightBack} style={[styles.flipCard, frontAnimatedStyle, {flexDirection: 'row', alignItems: 'center', justifyContent: 'center'}]}>
              <View style={styles.col1}>
                <Text style={styles.flipTextName}>
                  {this.props.frontArray.name}
                </Text>
              </View>
              {this.renderExample()}
            </Animated.View>
          </TouchableOpacity>
        </View>
      );
    }

  }
  onLayoutHeightFront = (event) => {
    var heightItem = event.nativeEvent.layout.height;
    if(this.state.heightFront < heightItem) {
      this.setState({
        isRending: 1,
        heightFront: heightItem,
      });
    }
  }
  onLayoutHeightBack = (event) => {
    var heightItem = event.nativeEvent.layout.height;
    if(this.state.heightBack < heightItem) {
      this.setState({
        isRending: 1,
        heightBack: heightItem,
      });
    }
  }
  renderBackExam(){
    return(
      <View style={{width: width - 30}}>
        {this.props.backArray.p.map((prop, key) => {
           if(prop != "") {
             return (
               <Text style={[styles.flipTextEx, {fontSize: 14}]} key={key}>
                 {(key + 1) + ". " + prop + ": " + this.props.backArray.m[key]}
               </Text>
             );
           }
        })}
      </View>
    );
  }
  renderOn(){
    if (this.props.backArray.on != ""){
      return(
        <Text style={[styles.flipTextEx, {fontSize: 15}]}>{"Âm On: " + this.props.backArray.on}</Text>
      );
    }
  }
  renderKun(){
    if (this.props.backArray.kun != ""){
      return(
        <Text style={[styles.flipTextEx, {fontSize: 15}]}>{"Âm Kun: " + this.props.backArray.kun}</Text>
      );
    }
  }
  renderExample() {
    return(
      <View style={styles.col2}>
        {this.props.frontArray.w.map((prop, key) => {
           return (
             <Text style={styles.flipTextEx} key={key}>
               {prop}
             </Text>
           );
        })}
      </View>
    );
  }

}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  flipCard: {
    padding: 5,

    backgroundColor: 'white',
    backfaceVisibility: 'hidden',
    marginBottom: 7,
    borderRadius: 15
  },
  flipCardBack: {
    flex: 1,
    backgroundColor: "white",
    position: "absolute",
    top: 0,
  },
  flipTextName: {
    color: '#00703c',
    fontSize: 110,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  flipTextEx: {
    color: '#107948',
    fontSize: 18,
    fontWeight: '300',
  },
  flipText: {
    fontSize: 15,
    color: 'black',
    fontWeight: '300',
  },
  col1: {
    alignItems: 'center',
    flex: 1,
  },
  col2: {
    flex: 1,
  }
});
