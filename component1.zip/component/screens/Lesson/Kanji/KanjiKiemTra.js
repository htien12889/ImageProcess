import React, {Component} from 'react';
import {View, Text, StyleSheet, ListView, TouchableOpacity, Dimensions, Animated} from 'react-native';
import KanjiResult from './KanjiResult.js';
var {height, width} = Dimensions.get('window');
var heightItem;
export default class KanjiKiemTra extends Component<{}>{
  constructor(props){
    super(props);
    this.tongSo = this.props.kiemTraDatas.length;
    //this.createDataForKiemTra();
    this.state = {
      stt: 1,
      index: 0,
      answerStatus: 0,
      clicked: 0,
      showResult: 0,
      opac: new Animated.Value(0),
      tongCauDung: 0,
      tongCauSai: 0,
    }
  }



  render() {
    const opacity = this.state.opac;
    if(this.state.showResult === 1) {
      var percent = (this.state.tongCauDung / this.tongSo) * 100;
      percent = parseFloat(percent).toFixed(2);
      return(
        <KanjiResult
          tongCauDung={this.state.tongCauDung}
          tongCauSai={this.state.tongCauSai}
          percent={percent}
          tryAgain={() => this.tryAgain()}
          lessonUpdateClick={(value) => this.props.lessonUpdateClick(value)}/>
      );
    } else {
      return(
        <Animated.View style={{flex: 1, backgroundColor: '#e3e4e8', opacity}}>
          <View style={style.vocabularyContent}>
            <Text style={{fontSize: 15, fontWeight: '300', color: '#989fa9', textAlign: 'center'}}>{this.state.stt + "/" + this.tongSo}</Text>
            <View style={style.kiemTraText}>
              <Text style={style.KiemTraString}>{this.props.kiemTraDatas[this.state.index]["question"]}</Text>
            </View>

            <View style={style.buttonView}>
              <TouchableOpacity style={style.kiemTraButton} onPress={this.answerClick.bind(this, 0)}>
                <Text style={style.kiemTraButtonText}>{this.props.kiemTraDatas[this.state.index]["answers"][0]}</Text>
              </TouchableOpacity>

              <TouchableOpacity style={style.kiemTraButton} onPress={this.answerClick.bind(this, 1)}>
                <Text style={style.kiemTraButtonText}>{this.props.kiemTraDatas[this.state.index]["answers"][1]}</Text>
              </TouchableOpacity>

              <TouchableOpacity style={style.kiemTraButton} onPress={this.answerClick.bind(this, 2)}>
                <Text style={style.kiemTraButtonText}>{this.props.kiemTraDatas[this.state.index]["answers"][2]}</Text>
              </TouchableOpacity>

              <TouchableOpacity style={style.kiemTraButton} onPress={this.answerClick.bind(this, 3)}>
                <Text style={style.kiemTraButtonText}>{this.props.kiemTraDatas[this.state.index]["answers"][3]}</Text>
              </TouchableOpacity>
            </View>
          </View>
          {this.renderOverlay()}
        </Animated.View>
      );
    }
  }
  renderOverlay(){
    if(this.state.clicked === 1) {
      if(this.state.answerStatus === 1) {
        return(
          <View style={{position: 'absolute', width: width, height: height, justifyContent: 'center', alignItems: 'center',}}>
            <View style={style.kiemTraOverlay}></View>
            <View style={style.kiemtraKetQua} onLayout={this.getWidthAndHeight}>
              <View style={style.cautraLoi}>
                <Text style={{textAlign: 'center', fontSize: 18, fontWeight: 'bold', color: '#a0d468'}}>Đúng</Text>
              </View>
              <View style={style.cauDung}>
                <Text style={style.textSai}>{this.props.kiemTraDatas[this.state.index]["question"]}: {this.props.kiemTraDatas[this.state.index]["answers"][this.props.kiemTraDatas[this.state.index]["correctNumber"]]}</Text>
              </View>
              <TouchableOpacity style={style.tiepTuc} onPress={() => {this.tiepTucProcess()}}>
                <Text style={{textAlign: 'center', fontSize: 18, fontWeight: 'bold', color: 'white'}}>Tiếp Tục</Text>
              </TouchableOpacity>
            </View>
          </View>
        );
      } else {
        return(
          <View style={{position: 'absolute', width: width, height: height, justifyContent: 'center', alignItems: 'center',}}>
            <View style={style.kiemTraOverlay}></View>
            <View style={style.kiemtraKetQua} onLayout={this.getWidthAndHeight}>
              <View style={style.cautraLoi}>
                <Text style={{textAlign: 'center', fontSize: 18, fontWeight: 'bold', color: '#ed5565'}}>Sai</Text>
              </View>
              <View style={style.cauDung}>
                <Text style={style.textSai}>{this.props.kiemTraDatas[this.state.index]["question"]}: {this.props.kiemTraDatas[this.state.index]["answers"][this.props.kiemTraDatas[this.state.index]["correctNumber"]]}</Text>
              </View>
              <TouchableOpacity style={style.tiepTuc} onPress={() => {this.tiepTucProcess()}}>
                <Text style={{textAlign: 'center', fontSize: 18, fontWeight: 'bold', color: 'white'}}>Tiếp Tục</Text>
              </TouchableOpacity>
            </View>
          </View>
        );
      }
    }
    Animated.timing(
      this.state.opac,{
        toValue: 1,
        duration: 200,
    }).start();
  }
  /*this.state = {
    stt: 1,
    index: 0,
    answerStatus: 0,
    clicked: 0,
  }*/
  getRandomInt(min, max) {
    var number = Math.floor(Math.random() * (max - min + 1)) + min;
    return parseInt(number);
  }
  randomKiemTra() {
    for(let i = 0; i < this.tongSo; i++) {
      var ranNum = this.getRandomInt(0, this.tongSo - 1);
      var temp = this.props.kiemTraDatas[ranNum];
      this.props.kiemTraDatas[ranNum] = this.props.kiemTraDatas[i];
      this.props.kiemTraDatas[i] = temp;
    }
  }
  tryAgain(){
    this.randomKiemTra();
    this.setState({
      stt: 1,
      index: 0,
      answerStatus: 0,
      clicked: 0,
      showResult: 0,
      opac: new Animated.Value(0),
      tongCauDung: 0,
      tongCauSai: 0,
    });
  }
  answerClick(answerIndex) {
    if(answerIndex === this.props.kiemTraDatas[this.state.index]["correctNumber"]) {
      this.setState({
        answerStatus: 1,
        clicked: 1,
        tongCauDung: this.state.tongCauDung + 1,
      });
    } else {
      this.setState({
        answerStatus: 0,
        clicked: 1,
        tongCauSai: this.state.tongCauSai + 1,
      });
    }
  }
  tiepTucProcess() {
    this.props.lessonUpdateClick(1);
    Animated.timing(
      this.state.opac,{
        toValue: 0,
        duration: 200,
    }).start(() => {
      if(this.state.stt === this.tongSo) {
        this.setState({
          stt: 1,
          index: 0,
          answerStatus: 0,
          clicked: 0,
          showResult: 1,
        });
      } else {
        this.setState({
          stt: this.state.stt + 1,
          index: this.state.index + 1,
          answerStatus: 0,
          clicked: 0,
          showResult: 0,
        });
      }
    });


    /*Animated.timing(
      this.state.opac,{
        toValue: 1,
        duration: 1000,
    }).start();*/
  }
  getWidthAndHeight = (e) => {
    heightItem = e.nativeEvent.layout.height;
  }
}

var centerWidth = (width / 2) - 150;
var centerHeight = (height / 5);
//var {height, width} = Dimensions.get('window');
const style = StyleSheet.create({
  textDung: {
    textAlign: 'center',
    fontSize: 18,
    fontWeight: '300',
    color: '#989fa9'
  },
  textSai: {
    textAlign: 'center',
    fontSize: 18,
    fontWeight: '300',
    color: '#989fa9'
  },
  tiepTuc: {
    left: 100,
    width: 100,
    padding: 5,
    backgroundColor: '#4fc1e9',
    marginBottom: 20,
    marginTop: 30,
    borderRadius: 5,
  },
  cauDung: {
    padding: 10,
  },
  kiemtraKetQua: {
    position: 'absolute',
    top: centerHeight,
    left: centerWidth,
    backgroundColor: 'white',
    width: 300,
    borderRadius: 10,
  },
  cautraLoi: {
    borderBottomWidth: 1,
    borderColor: '#e3e4e8',
    padding: 10,
  },
  kiemTraOverlay: {
    backgroundColor: 'black',
    position: 'absolute',
    width: width,
    height: height,
    top: 0,
    opacity: 0.7
  },
  kiemTraButtonText: {
    color: 'white',
    textAlign: 'center',
    fontSize: 18,
    fontWeight: '300',
  },
  buttonView: {
    flex: 1,
    justifyContent: 'center',
  },
  kiemTraButton: {
    padding: 7,
    backgroundColor: '#3bafda',
    justifyContent: 'center',
    marginBottom: 5,
    borderRadius: 3,
  },

  KiemTraString: {
    fontSize: 18,
    color: 'black',
    fontWeight: '300',
    textAlign: 'center'
  },
  kiemTraText: {
    flex: 1,
    backgroundColor: 'white',
    justifyContent: 'center',
  },

  vocabularyContent: {
    flex: 1,
    marginTop: 7,
    marginLeft: 7,
    marginRight: 7,
  }
});
