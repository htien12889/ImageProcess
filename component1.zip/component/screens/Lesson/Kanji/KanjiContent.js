import React, {Component} from 'react';
import {WebView, View, StyleSheet, TouchableOpacity, Image} from 'react-native';
export default class KanjiContent extends Component {
  constructor(props) {
    super(props);
  }
  render() {
    if(this.props.level == 0) {
      return(
        <View style={{flex: 1, paddingTop: 5, backgroundColor: 'white'}}>
          <TouchableOpacity style={style.AddIconImage} onPress={() => {this.props.removeKanjiType(this.props.id, this.props.danhMucId)}}>
            <Image style={{width: 25, height: 25}} source={require('../../../assets/remove.png')}></Image>
          </TouchableOpacity>
          <WebView
          source={{ uri: "http://www.vnsupa.com/hoangtien/mazzi/writer_kanji/showkanji.php?&id=" + this.props.id }} />
        </View>
      );
    } else {
      return(
        <View style={{flex: 1, paddingTop: 5, backgroundColor: 'white'}}>
          <TouchableOpacity style={style.AddIconImage} onPress={() => {this.props.addKanjiType(this.props.id)}}>
            <Image style={{width: 25, height: 25}} source={require('../../../assets/addContent.png')}></Image>
          </TouchableOpacity>
          <WebView
          source={{ uri: "http://www.vnsupa.com/hoangtien/mazzi/writer_kanji/showkanji.php?&id=" + this.props.id }} />
        </View>
      );
    }

  }

}

const style = StyleSheet.create({
  AddIconImage: {
    width: 25,
    height: 25,
    position: 'absolute',
    top: 0,
    right: 10,
    zIndex: 999,
  }
});
