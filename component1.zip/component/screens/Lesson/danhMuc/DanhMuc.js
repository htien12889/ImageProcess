import React, {Component} from 'react';
import {View, Text, TouchableOpacity, StyleSheet, ListView, Image, StatusBar, Dimensions, Animated, Alert} from 'react-native';
import AddDanhMuc from './AddDanhMuc.js';
var SQLite = require('react-native-sqlite-storage')
var db = SQLite.openDatabase({name : "jlptDB_folder", createFromLocation : "~folder.db"}, this.openCB,this.errorCB);
var {height, width} = Dimensions.get('window');

export default class DanhMuc extends Component<{}> {
  constructor(props) {
		super(props);
    this.vocabularyId = 0;
    this.arrayDatas = [],
		this.state = {
			dataSource: new ListView.DataSource({rowHasChanged: (r1, r2)=>r1!==r2}),
      topPos: new Animated.Value(height),
      renderOverlay: 0,
      resetDM: true,
		}
	}
  render() {
    return(
      <View style={style.danhMucContainer}>
        {this.renderOverlay()}
        <Animated.View style={{position: 'absolute', top: this.state.topPos, left: 0.25*width, height: 300, width: 0.5*width, zIndex: 999}}>
          <AddDanhMuc
            ref="child"
            closeForm={() => {this.closeForm()}}
            saveForm={(value) => {this.saveForm(value)}}/>
        </Animated.View>
        <View style={style.danhMucHeader}>
          <View style={{justifyContent: 'center'}}>
            <Text style={{fontSize: 17, color: 'white', fontWeight: 'bold'}}>{this.props.title}</Text>
          </View>
          <View style={{flexDirection: 'row', height: 30}}>
            <TouchableOpacity style={style.danhMucAddButton} onPress={() => {this.themDanhMuc()}}>
              <Image style={{width: 25, height: 25}} source={require('../../../assets/addds.png')}></Image>
            </TouchableOpacity>
            <TouchableOpacity style={style.danhMucAddButton} onPress={() => {this.props.closeList()}}>
              <Image style={{width: 25, height: 25}} source={require('../../../assets/close.png')}></Image>
            </TouchableOpacity>
          </View>
        </View>
        {this.renderListView()}
      </View>
    );
  }
  renderOverlay(){
    if(this.state.renderOverlay == 1) {
      return(
        <View style={{backgroundColor: 'black', opacity: 0.5, width: width, height: height, position: 'absolute', top: 0, left: 0, zIndex: 99}}></View>
      );
    }
  }
  renderListView(){
    if(this.arrayDatas.length > 0) {
      return(
        <View style={{flex: 1}}>
          <ListView
            dataSource={this.state.dataSource}
            renderRow={(rowData) =>
              <TouchableOpacity style={[style.listView, {backgroundColor: rowData.background}]} onPress={() => {this.props.addDanhMucAction(rowData.datas)}}>
                <View style={{justifyContent: 'center'}}>
                  <Text style={{fontSize: 17, marginLeft: 15, color: 'white', fontWeight: 'bold'}}>{rowData.datas.name}</Text>
                </View>
              </TouchableOpacity>
            }
          />
        </View>
      );
    } else {
      return(
        <View style={{flex: 1, justifyContent: 'center', paddingLeft: 5, paddingRight: 5}}>
          <Text style={{textAlign: 'center', fontWeight: 'bold', fontSize: 25}}>Bạn không có danh mục nào, hãy chạm vào dấu "+" ở phía trên góc phải để tạo danh mục trước khi thêm nội dung vào danh mục</Text>
        </View>
      );
    }
  }
  saveForm(value){
    if(value == "") {
      Alert.alert(
        'Thông Báo',
        'Hãy nhập tên danh mục',
        [
          {text: 'OK', onPress: () => {console.log("ok")}},
        ]
      );
    } else {
      db.transaction((tx) => {
        tx.executeSql("SELECT * FROM folder where type='"+this.props.type+"' and name='"+value+"'", [], (tx, results) => {
          if(results.rows.length > 0) {
            Alert.alert(
              'Thông Báo',
              'Danh mục "'+value+'" đã tồn tại',
              [
                {text: 'OK', onPress: () => {console.log("ok")}},
              ]
            );
          } else {
            db.transaction((tx) => {
              //console.log("INSERT INTO folder (`type`,`name`) VALUES ('vocabulary','"+value+"')");
              tx.executeSql("INSERT INTO folder (`type`,`name`) VALUES ('"+this.props.type+"','"+value+"')", [], (tx, results) => {
                this.getDatas();
              });
            });
          }
        });
      });
    }
  }
  resetDanhMuc(vocaID) {
    console.log(vocaID);
    this.vocabularyId = vocaID;
    this.getDatas();
  }
  closeForm(){
    this.refs.child.resetForm();
    this.setState({
      renderOverlay: 0,
    });
    Animated.timing(
      this.state.topPos,
      {
        toValue: height,
        duration: 300,
      }
    ).start();

  }
  themDanhMuc(){
    this.setState({
      renderOverlay: 1,
    });
    Animated.timing(
      this.state.topPos,
      {
        toValue: 0,
        duration: 200,
      }
    ).start();
  }
  GetListViewItem(id){

  }
  getDatas() {
    db.transaction((tx) => {
      tx.executeSql("SELECT * FROM folder where type='"+this.props.type+"'", [], (tx, results) => {
          console.log(results.rows.length);
          var array = [];
          var len = results.rows.length;
          console.log(results.rows);
          for (let i = 0; i < len; i++) {
            if(this.checkExits(results.rows.item(i))) {
              array[i] = {datas: results.rows.item(i), background: '#4fb7de'};
            } else {
              array[i] = {datas: results.rows.item(i), background: '#4fc1e9'};
            }
            console.log(array);
          }
          this.arrayDatas = array;
          this.setState({
            dataSource: this.state.dataSource.cloneWithRows(array),
          });
          this.closeForm();
        });
    });
  }
  checkExits(value) {
    let ids = value.ids;
    //console.log(ids);
    if(ids) {
      let arrayIds = ids.split(',');
      let lengthIds = arrayIds.length;
      let check = false;
      if(lengthIds == 0) {
        if(ids == this.vocabularyId) {
          check = true;
        }
      } else {
        for(let i = 0; i < lengthIds; i++) {
          console.log(arrayIds[i]);
          console.log(this.vocabularyId);
          if(this.vocabularyId == arrayIds[i]) {
            check = true;
            break;
          }
        }
      }
      return check;
    } else {
      return false;
    }
  }
  componentDidMount() {
    this.getDatas();
  }
}

const style = StyleSheet.create({
  danhMucContainer: {
    flex: 1,
    backgroundColor: 'white',
  },
  danhMucAddButton: {
    width: 24,
    height: 24,
    justifyContent: 'center',
    marginLeft: 10
  },
  danhMucHeader: {
    backgroundColor: '#3bafda',
    flexDirection: 'row',
    padding: 5,
    justifyContent: 'space-between',
  },
  listView: {
    padding: 10,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderBottomColor: '#2ea5dd',
    borderTopColor: '#75d2f0',
    backgroundColor: '#4fc1e9',
  }
});
