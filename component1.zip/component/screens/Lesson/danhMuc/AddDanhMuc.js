import React, {Component} from 'react';
import {View, Text, TouchableOpacity, StyleSheet, ListView, Image, StatusBar, Dimensions, TextInput, KeyboardAvoidingView} from 'react-native';
var SQLite = require('react-native-sqlite-storage')
var db = SQLite.openDatabase({name : "jlptDB_v2_new", createFromLocation : "~jlpt_v2_new.db"}, this.openCB,this.errorCB);
var {height, width} = Dimensions.get('window');

export default class AddDanhMuc extends Component<{}> {
  constructor(props) {
		super(props);
    this.state = {
      text: "",
    };
	}
  render() {
    return(
      <View style={style.addDanhMucContainer}>
        <View style={style.header}>
          <Text style={{textAlign: 'center', fontSize: 17, fontWeight: 'bold', color: '#d6dae0'}}>Tạo Danh Mục</Text>
        </View>
        <View style={style.textBox}>
          <KeyboardAvoidingView behavior="position" enabled>
            <TextInput
               style={style.TextInputStyleClass}
               onChangeText={(text) => this.SearchFilterFunction(text)}
               value={this.state.text}
               underlineColorAndroid='transparent'
               placeholder="Nhập Tên Danh Mục"
            />
          </KeyboardAvoidingView>

        </View>
        <View style={style.buttons}>
          <TouchableOpacity onPress={() => {this.props.closeForm()}} style={{flex: 1, justifyContent: 'center', backgroundColor: '#ff3c30', paddingTop: 10, paddingBottom: 10, borderRadius: 5, marginRight: 5}}>
            <Text style={{textAlign: 'center', fontWeight: 'bold', color: 'white'}}>Đóng</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => {this.props.saveForm(this.state.text)}} style={{flex: 1, justifyContent: 'center', backgroundColor: '#a0d468', paddingTop: 10, paddingBottom: 10, borderRadius: 5, marginLeft: 5}}>
            <Text style={{textAlign: 'center', fontWeight: 'bold', color: 'white'}}>Tạo</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }
  resetForm(){
    this.setState({
      text: "",
    });
  }
  SearchFilterFunction(text) {
    this.setState({
      text: text,
    });
  }
}

const style = StyleSheet.create({
  header: {
    padding: 5,
    justifyContent: 'center',
  },
  buttons: {
    flexDirection: 'row',
    padding: 5,
    justifyContent: 'center',
  },
  textBox: {
    padding: 5,
    justifyContent: 'center',
  },
  danhMucAddButton: {
    width: 25,
    height: 25,
    justifyContent: 'center',
  },
  addDanhMucContainer: {
    width: 0.5*width,
    padding: 5,
    backgroundColor: 'white',
    borderRadius: 5,
  },
  TextInputStyleClass: {
    marginTop: 5,
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: '#b7babf',
    borderRadius: 5,
    textAlign: 'center',
    padding: 0,
    color: '#c5c9ce'
  }
});
