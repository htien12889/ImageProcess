import React, {Component} from 'react';
import {View, Text, TouchableOpacity, StyleSheet, ListView, Animated, StatusBar, Dimensions, Alert} from 'react-native';
import VocabularyContent from './Vocabulary/VocabularyContent.js';
import FlashCardChoose from './Vocabulary/FlashCardChoose.js';
import VocabularyKiemTra from './Vocabulary/VocabularyKiemTra.js';
import DanhMuc from './danhMuc/DanhMuc.js';
import TopMenu from '../common/TopMenu.js';
var SQLite = require('react-native-sqlite-storage')
var db = SQLite.openDatabase({name : "jlptDB_v2_new", createFromLocation : "~jlpt_v2_new.db"}, this.openCB,this.errorCB);
var db1 = SQLite.openDatabase({name : "jlptDB_folder", createFromLocation : "~folder.db"}, this.openCB,this.errorCB);
var {height, width} = Dimensions.get('window');
var heightOfView = height - 150 - StatusBar.currentHeight;
var heightOfAddDanhMuc = heightOfView;
export default class Vocabulary extends Component<{}> {
  constructor(props) {
		super(props);
    this.dataTemp = [];
    this.vocabularyId = 0;
    this.danhMucId = 0;
		this.state = {
      numberDatas: 0,
      lenghtData: 1,
			dataSource: new ListView.DataSource({rowHasChanged: (r1, r2)=>r1!==r2}),
			isContent: 0,
			vocabularyDatas: [],
      vocabularyKiemTra: [],
      vocabularyType: "vocabulary", // vocabulary, flashcard, kiemtra
      topAnimate: new Animated.Value(-heightOfView),
      renderOverlay: 0,
		}
	}
	openCB(){
		//console.log("Open Database");
	}
	sucessCB() {
		//ToastAndroid.show("Sucessful", ToastAndroid.SHORT);
	}
	errorCB(err) {
		//ToastAndroid.show("SQL Error" + err, ToastAndroid.SHORT);
	}
  render(){
    this.dataTemp = [];
    return(
      this.renderContentVocabulary()
    );
  }
  renderContentVocabulary(){
    if(this.state.isContent == 0) {
      if(this.state.lenghtData > 0) {
        return(
          <View style={style.vocabularyContainer}>
            <View style={{flex: 1}}>
              <ListView
                dataSource={this.state.dataSource}
                renderRow={(rowData) =>
                  <TouchableOpacity style={style.listView}
                    onPress={this.GetListViewItem.bind(this, rowData)}>
                    <View style={{justifyContent: 'center'}}>
                      <Text style={{fontSize: 17, marginLeft: 15, color: 'white'}}>{rowData.stt}</Text>
                    </View>
                    <View style={{justifyContent: 'center'}}>
                      <Text style={{fontSize: 17, marginLeft: 15, color: 'white'}}>{rowData.title}</Text>
                    </View>
                  </TouchableOpacity>
                }
              />
            </View>
          </View>
        );
      } else {
          return(
            <View style={style.vocabularyContainer}>
              <View style={{flex: 1, justifyContent: 'center', paddingLeft: 5, paddingRight: 5}}>
                <Text style={{textAlign: 'center', fontWeight: 'bold', fontSize: 25}}>Không có danh mục từ vựng nào</Text>
              </View>
            </View>
          );
      }
    } else {
      if(this.state.vocabularyType == "vocabulary") {
        return(
          <View style={style.vocabularyContainer}>
            {this.renderOverlay()}
            <Animated.View style={{position: 'absolute', bottom: this.state.topAnimate, left: 7, height: heightOfAddDanhMuc, width: width - 14, zIndex: 999}}>
              <DanhMuc
                title="Danh mục từ vựng"
                type="vocabulary"
                ref="danhMuc"
                addDanhMucAction={(value) => {this.addDanhMucAction(value)}}
                closeList={() => {this.closeList()}}/>
            </Animated.View>
            <TopMenu
              contentClick={() => {this.contentClick()}}
              flashCardClick={() => {this.flashCardClick()}}
              quizClick={() => {this.quizClick()}}
              nameButton={"Từ Vựng"}/>
            <VocabularyContent
              ref="vocaContent"
              danhMucId={this.danhMucId}
              level={this.props.level}
              vocabularyDatas={this.state.vocabularyDatas}
              contentClick={() => {this.contentClick()}}
              flashCardClick={() => {this.flashCardClick()}}
              addVocaType={(value) => {this.addVocaType(value)}}
              removeVocaType={(vocaId, dmId) => {this.removeVocaType(vocaId, dmId)}}
              quizClick={() => {this.quizClick()}}/>
          </View>
        );
      } else if (this.state.vocabularyType == "flashcard") {
        return(
          <View style={style.vocabularyContainer}>
            <TopMenu
              contentClick={() => {this.contentClick()}}
              flashCardClick={() => {this.flashCardClick()}}
              quizClick={() => {this.quizClick()}}
              nameButton={"Từ Vựng"}/>
            <FlashCardChoose
              vocabularyDatas={this.state.vocabularyDatas}
              contentClick={() => {this.contentClick()}}
              flashCardClick={() => {this.flashCardClick()}}
              quizClick={() => {this.quizClick()}}
              lessonUpdateClick={(value) => {this.props.lessonUpdateClick(value)}}/>
          </View>
        );
      } else if (this.state.vocabularyType == "kiemtra") {
        console.log(this.state.vocabularyKiemTra);
        return(

          <View style={style.vocabularyContainer}>
            <TopMenu
              contentClick={() => {this.contentClick()}}
              flashCardClick={() => {this.flashCardClick()}}
              quizClick={() => {this.quizClick()}}
              nameButton={"Từ Vựng"}/>
            <VocabularyKiemTra
              vocabularyDatas={this.state.vocabularyKiemTra}
              numberDatas = {this.state.numberDatas}
              contentClick={() => {this.contentClick()}}
              flashCardClick={() => {this.flashCardClick()}}
              quizClick={() => {this.quizClick()}}
              lessonUpdateClick={(value) => {this.props.lessonUpdateClick(value)}}/>
          </View>
        );
      }
    }
  }
  renderOverlay(){
    if(this.state.renderOverlay == 1) {
      return(
        <View style={{backgroundColor: 'black', opacity: 0.5, width: width, height: height, position: 'absolute', top: 0, left: 0, zIndex: 99}}></View>
      );
    }
  }
  closeList() {
    //console.log(value);
    this.setState({
      renderOverlay: 0,
    });
    Animated.timing(
      this.state.topAnimate,
      {
        toValue: -heightOfView,
        duration: 200,
      }
    ).start();
  }
  addVocaType(value) {
    this.vocabularyId = value;
    this.refs.danhMuc.resetDanhMuc(value);
    //console.log(value);
    this.setState({
      renderOverlay: 1,
    });
    Animated.timing(
      this.state.topAnimate,
      {
        toValue: 0,
        duration: 200,
      }
    ).start();
  }

  // vocabulary, flashcard, kiemtra
  contentClick(){
    this.props.lessonUpdateClick(0.5);
    this.setState({
      vocabularyType: "vocabulary"
    });
  }
  flashCardClick(){
    this.props.lessonUpdateClick(0.5);
    this.setState({
      vocabularyType: "flashcard"
    });
  }
  quizClick(){
    this.props.lessonUpdateClick(0.5);
    this.setState({
      vocabularyType: "kiemtra"
    });
  }
  backProcess(){
		this.setState({
			isContent: 0,
		});
	}
  addDanhMucAction(value) {
    db1.transaction((tx) => {
      tx.executeSql("SELECT * FROM folder where type='vocabulary' and id='"+value.id+"'", [], (tx, results) => {
        let ids = results.rows.item(0).ids;
        if(ids) {
          let arrayIds = ids.split(',');
          let lengthIds = arrayIds.length;
          if(lengthIds == 0) {
            ids = ids + "," + this.vocabularyId;
          } else {
            let check = false;
            for(let i = 0; i < lengthIds; i++) {
              if(this.vocabularyId == arrayIds[i]) {
                check = true;
                break;
              }
            }
            if(check) {
              Alert.alert(
                'Thông Báo',
                '"'+value.name+'" đã tồn tại từ này',
                [
                  {text: 'OK', onPress: () => {console.log("ok")}},
                ]
              );
              return;
            } else {
              ids = ids + "," + this.vocabularyId;
            }
          }
        } else {
          ids = this.vocabularyId;
        }
        //console.log(ids);
        db1.transaction((tx) => {
          //console.log("INSERT INTO folder (`type`,`name`) VALUES ('vocabulary','"+value+"')");
          tx.executeSql("UPDATE folder SET ids='"+ids+"' WHERE id='"+value.id+"' ", [], (tx, results) => {
            //this.getDatas();
            this.closeList();
          });
        });

      });
    });
  }
  removeVocaType(vocaId, dmId) {
    var sql = "SELECT * FROM folder WHERE `id`='"+ dmId +"'";
    //console.log(sql);
    db1.transaction((tx) => {
      tx.executeSql(sql, [], (tx, results) => {
        let ids = results.rows.item(0).ids;
        let idsWrite = "";
        let arrayIds = ids.split(',');
        let j = 0;
        for(let i = 0; i < arrayIds.length; i++) {
          if(arrayIds[i] == vocaId) {
            continue;
          }
          if(j == 0) {
            idsWrite = idsWrite + arrayIds[i];
          } else {
            idsWrite = idsWrite + "," + arrayIds[i];
          }
          j++;
        }
        db1.transaction((tx) => {
          //console.log("INSERT INTO folder (`type`,`name`) VALUES ('vocabulary','"+value+"')");
          //console.log("UPDATE folder SET ids='"+idsWrite+"' WHERE id='"+dmId+"'");
          tx.executeSql("UPDATE folder SET ids='"+idsWrite+"' WHERE id='"+dmId+"'", [], (tx, results) => {
            var valuePara = {ids: idsWrite, index: 0};
            this.GetListViewItem(valuePara);
            this.getDatas();
          });
        });
       });
    });
  }
  getListViewDM(value) {
    /*var sql = "SELECT * FROM vocabulary WHERE `id` in ("+ value +")";
    db.transaction((tx) => {
      tx.executeSql(sql, [], (tx, results) => {
          var array = [];
          var len = results.rows.length;
          for (let i = 0; i < len; i++) {
            array[i] = results.rows.item(i);
          }
          this.setState({
            vocabularyType: "vocabulary",
            isContent: 1,
            vocabularyDatas: array,
          });
          this.getDatas();
          this.refs.vocaContent.resetDatas(array);
       });
    });*/
  }
  GetListViewItem(value) {
    this.props.lessonUpdateClick(3);
    this.props.updateIsContent();
    if(this.props.level != 0) {
  		var sql = "SELECT * FROM vocabulary WHERE `parent_id`="+ this.props.level +" and page='" + value.index + "'";
    } else {
      var sql = "SELECT * FROM vocabulary WHERE `id` in ("+ value.ids +")";
      if(value.index != 0) {
        this.danhMucId = value.index;
      }
    }
    db.transaction((tx) => {
      tx.executeSql(sql, [], (tx, results) => {
          var numberDatas = 0;
          var array = [];
          var len = results.rows.length;
          var tempIds = [];
          var arrayIndex = 0;
          var vocabularyDatas = [];
          for (let i = 0; i < len; i++) {
            vocabularyDatas[i] = results.rows.item(i);
            array[i] = results.rows.item(i);
            tempIds[i] = results.rows.item(i).id;
            arrayIndex += 1;
          }
          numberDatas = array.length;
          if(array.length < 10) {
            var sql1 = "";
            if(this.props.level != 0) {
              var sql1 = "SELECT * FROM vocabulary WHERE `parent_id`="+ this.props.level;
            } else {
              var sql1 = "SELECT * FROM vocabulary WHERE `parent_id`='3'";
            }
            //console.log(sql1);
            db.transaction((tx) => {
              tx.executeSql(sql1, [], (tx, results) => {
                for (let i = 0; i < results.rows.length; i++) {
                  let idItem = results.rows.item(i).id;
                  let checkExits = false;
                  for(let j = 0; j < tempIds.length; j++) {
                    if(idItem == tempIds[j]) {
                      checkExits = true;
                      break;
                    }
                  }
                  if(!checkExits){
                    array[arrayIndex] = results.rows.item(i);
                    tempIds[arrayIndex] = results.rows.item(i).id;
                    if(array.length >= 10) {
                      break;
                    }
                    arrayIndex += 1;
                  } else {
                    continue;
                  }
                }
                this.setState({
                  numberDatas: numberDatas,
                  vocabularyType: "vocabulary",
                  isContent: 1,
                  vocabularyDatas: vocabularyDatas,
                  vocabularyKiemTra: array,
                });
               });
            });
          } else {
            this.setState({
              numberDatas: numberDatas,
              vocabularyType: "vocabulary",
              isContent: 1,
              vocabularyDatas: vocabularyDatas,
              vocabularyKiemTra: array,
            });
          }
          this.refs.vocaContent.resetDatas(vocabularyDatas);
       });
    });
	}
  getDatas(){
    if(this.props.level != 0) {
      db.transaction((tx) => {
        tx.executeSql('SELECT * FROM category WHERE id='+ this.props.level, [], (tx, results) => {
  					var array = [];
            var numberPage = results.rows.item(0)["number_page_voca"];
            for (let i = 0; i < numberPage; i++) {
              var row = {"stt": i + 1, "index": i, "title": "Bài Số " + (i + 1), "ids": ""};
              array[i] = row;
            }
  					this.setState({
              lenghtData: array.length,
  						dataSource: this.state.dataSource.cloneWithRows(array),
  					});
          });
      });
    } else {
      db1.transaction((tx) => {
        tx.executeSql("SELECT * FROM folder where type='vocabulary'", [], (tx, results) => {
  					var array = [];
            let numberPage = results.rows.length;
            for (let i = 0; i < numberPage; i++) {
              var row = {"stt": i + 1, "index": results.rows.item(i).id, "title": results.rows.item(i).name, "ids": results.rows.item(i).ids};
              array[i] = row;
            }
  					this.setState({
              lenghtData: array.length,
  						dataSource: this.state.dataSource.cloneWithRows(array),
  					});
          });
      });
    }
  }
  componentDidMount() {
    this.getDatas();
	}
}

const style = StyleSheet.create({
	listView: {
		/*flexDirection: 'row',
		height: 40,
		marginLeft: 10,
		marginRight: 10,
		marginTop: 3,
		borderRadius: 7,
		backgroundColor: '#ffffff',*/
    flexDirection: 'row',
    padding: 10,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderBottomColor: '#2ea5dd',
    borderTopColor: '#75d2f0',
    backgroundColor: '#4fc1e9',
		//justifyContent: 'center',
	},
  vocabularyContainer: {
		flex: 1,
		backgroundColor: '#e3e4e8',
	},
});
