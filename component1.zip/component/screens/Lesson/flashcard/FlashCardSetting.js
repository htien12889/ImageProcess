import React, {Component} from 'react';
import {View, Text, StyleSheet, Switch, TouchableOpacity} from 'react-native';
import SegmentedControlTab from 'react-native-segmented-control-tab';
import Slider from "react-native-slider";
export default class FlashCardSetting extends Component<{}>{
  constructor(props) {
		super(props);
		this.state = {
      selectedIndexLang: this.props.engORJP,
      selectedIndexAuPlay: this.props.renderSlider,
      selectedIndexAuFlip: this.props.autoflipCard,
      selectedIndexRandom: this.props.randomCard,
      timerValue: 10,
		}
	}
  render(){
    return(
      <View style={{flex: 1, padding: 5, paddingLeft: 0, paddingRight: 0, paddingTop: 0, backgroundColor: '#e3e4e8'}}>
        <View style={style.itemSetting}>
          <View style={style.segmentView}>
            <Text style={style.textStyle}>Hiển thị ngôn ngữ trước card:</Text>
          </View>
          <View style={style.segmentView}>
              <SegmentedControlTab
                values={['Nhật', 'Việt']}
                selectedIndex={this.state.selectedIndexLang}
                onTabPress={this.handleIndexChange}
              />
          </View>
        </View>
        <View style={{borderTopWidth: 2,borderColor: '#75d2f0'}}>
          <View style={style.itemSettingSlider}>
            <View style={style.segmentView2}>
              <Text style={style.textStyle}>Tự động chuyển đổi card:</Text>
            </View>
            <View style={style.segmentView}>
              <Switch
                onValueChange = {() => {this.toggleAutoPlay()}}
                value = {this.state.selectedIndexAuPlay}/>
            </View>

          </View>
        </View>
        {this.renderAutoFlipCard()}

        <View style={style.itemSetting}>
          <View style={style.segmentView2}>
            <Text style={style.textStyle}>Xáo trộn card:</Text>
          </View>
          <View style={style.segmentView}>
            <Switch
              onValueChange = {() => {this.toggleRandom()}}
              value = {this.state.selectedIndexRandom}/>
          </View>
        </View>
        <View style={{backgroundColor: '#4fc1e9', paddingBottom: 10, paddingTop: 20}}>
          <TouchableOpacity onPress={() => {this.props.okPress()}} style={{marginLeft: 5, marginRight: 5, padding: 10, borderWidth: 1, borderColor: 'white', backgroundColor: '#a0d468', borderRadius: 3,}}>
            <Text style={{textAlign: 'center', fontSize: 17, fontWeight: 'bold', color: 'white'}}>Đồng Ý</Text>
          </TouchableOpacity>
        </View>

      </View>
    );
  }
  renderAutoFlipCard() {
    if(this.state.selectedIndexAuPlay) {
      return(
        <View style={{borderTopWidth: 2,borderColor: '#75d2f0'}}>
          <View style={style.itemSettingSlider}>
            <View style={style.segmentView2}>
              <Text style={style.textStyle}>Tự động xoay card:</Text>
            </View>
            <View style={style.segmentView}>
              <Switch
                onValueChange = {() => {this.toggleAutoFlipCard()}}
                value = {this.state.selectedIndexAuFlip}/>
            </View>
          </View>
        </View>
      );
    }
  }
  handleIndexChange = (index) => {
    this.props.changeLanguage(index);
    this.setState({
      selectedIndexLang: index,
    });
  }
  toggleAutoPlay(){
    this.props.changeAutoPlay(!this.state.selectedIndexAuPlay);
    this.setState({
      selectedIndexAuPlay: !this.state.selectedIndexAuPlay,
    });
  }
  toggleRandom(){
    this.props.changeRandom(!this.state.selectedIndexRandom);
    this.setState({
      selectedIndexRandom: !this.state.selectedIndexRandom,
    });
  }
  toggleAutoFlipCard(){
    this.props.changeFlip(!this.state.selectedIndexAuFlip);
    this.setState({
      selectedIndexAuFlip: !this.state.selectedIndexAuFlip,
    });
  }
}

const style = StyleSheet.create({
  itemSetting: {
    flexDirection: 'row',
    borderTopWidth: 2,
    borderColor: '#75d2f0',
    paddingTop: 10,
    paddingBottom: 10,
    backgroundColor: '#4fc1e9',
    paddingLeft: 5,
    paddingRight: 5,
  },
  itemSettingSlider: {
    flexDirection: 'row',
    paddingTop: 10,
    paddingBottom: 10,
    backgroundColor: '#4fc1e9',
    paddingLeft: 5,
    paddingRight: 5,
  },
  itemSettingSlider1: {
    flexDirection: 'row',
    paddingTop: 0,
    paddingBottom: 10,
    backgroundColor: '#4fc1e9',
    paddingLeft: 5,
    paddingRight: 5,
  },
  segmentView: {
    flex: 1,
  },
  segmentView2: {
    flex: 2,
  },
  textStyle: {
    color: 'white',
    fontSize: 15,
    fontWeight: 'bold',
  }
});
