import React, {Component} from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import VocabularyFlashCard from './VocabularyFlashCard.js';
import FlashCardQuiz from '../flashcard/FlashCardQuiz.js';
export default class FlashCardChoose extends Component<{}>{
  constructor(props){
    super(props);
    this.state = {
      chooseFlashCard: 0,
    }
  }
  render() {
    if(this.props.vocabularyDatas.length > 0) {
      if(this.state.chooseFlashCard == 0) {
        return(
          <View style={style.vocabularyContainer}>
            <TouchableOpacity style={style.chooseButton}
              onPress={() => {this.flashcardQuiz()}}>
              <Text style={{textAlign: 'center', padding: 5, fontSize: 18, color: 'white', fontWeight: 'bold', paddingTop: 5, paddingBottom: 10}}>Học Từ Vựng (Bước 1)</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[style.chooseButton, {marginTop: 5}]}
              onPress={() => {this.overview()}}>
              <Text style={{textAlign: 'center', padding: 5, fontSize: 18, color: 'white', fontWeight: 'bold', paddingTop: 5, paddingBottom: 10}}>Ôn Tập (Bước 2)</Text>
            </TouchableOpacity>
          </View>
        );
      } else if(this.state.chooseFlashCard == 1) {
        return(
          <FlashCardQuiz
            vocabularyDatas={this.props.vocabularyDatas} />
        );
      } else {
        return(
          <VocabularyFlashCard
            vocabularyDatas={this.props.vocabularyDatas} />
        );
      }
    } else {
      return(
        <View style={{flex: 1, justifyContent: 'center', paddingLeft: 5, paddingRight: 5}}>
          <Text style={{textAlign: 'center', fontWeight: 'bold', fontSize: 25}}>Không có từ vựng nào tồn tại trong danh mục này</Text>
        </View>
      );

    }
  }
  flashcardQuiz(){
    this.props.lessonUpdateClick(10);
    this.setState({
      chooseFlashCard: 1,
    });
  }
  overview(){
    this.props.lessonUpdateClick(3);
    this.setState({
      chooseFlashCard: 2,
    });
  }
}

const style = StyleSheet.create({
  vocabularyContainer: {
    flex: 1,
    backgroundColor: '#4fc1e9',
    justifyContent: 'center',
  },
  chooseButton: {
    borderColor: 'white',
    borderRadius: 3,
    padding: 2,
    borderWidth: 1,
    backgroundColor: '#a0d468',
    marginLeft: 10,
    marginRight: 10,
  }
});
