import React, {Component} from 'react';
import {View, Text, StyleSheet, ListView, TouchableOpacity, Dimensions, Animated} from 'react-native';
import VocabularyResult from './VocabularyResult.js';
var {height, width} = Dimensions.get('window');
var heightItem;
export default class VocabularyKiemTra extends Component<{}>{
  constructor(props){
    super(props);
    this.dataForKiemTra = [];
    this.tongSo = 0;
    this.createDataForKiemTra();
    this.numberDatas = this.props.numberDatas;
    this.state = {
      stt: 1,
      index: 0,
      answerStatus: 0,
      clicked: 0,
      showResult: 0,
      opac: new Animated.Value(0),
      tongCauDung: 0,
      tongCauSai: 0,
    }
  }

  getRandomInt(min, max) {
    var number = Math.floor(Math.random() * (max - min + 1)) + min;
    return parseInt(number);
  }
  createDataForKiemTra() {
    this.numberDatas = this.props.numberDatas;
    var len = this.props.numberDatas;
    var allDatasLen = this.props.vocabularyDatas.length;
    for(let i = 0; i < len; i++){
      //rowData.word + "(" + rowData.phonetic + ")"
      this.tongSo += 1;
      var answers = [];
      var oldIndex = [];
      var question = this.props.vocabularyDatas[i].word;
      var questionText = this.props.vocabularyDatas[i].word + "(" + this.props.vocabularyDatas[i].phonetic + ")";
      var correctNumber = this.getRandomInt(0, 3);
      for(let j = 0; j < 4; j++) {
        if(j != correctNumber) {
          var aswIndex = this.getRandomInt(0, allDatasLen - 1);
          oldIndex[j] = aswIndex;
        } else {
          //answers[j] = this.props.vocabularyDatas[i].mean;
          oldIndex[j] = i;
        }
      }
      var lenAnswerIndex = oldIndex.length;
      for(let j = 0; j < lenAnswerIndex; j++) {
        if(j == correctNumber) {
          answers[j] = this.props.vocabularyDatas[oldIndex[j]].mean.substring(0, this.props.vocabularyDatas[oldIndex[j]].mean.length - 2);
          continue;
        }
        let answ1 = oldIndex[0];
        let answ2 = oldIndex[1];
        let answ3 = oldIndex[2];
        let answ4 = oldIndex[3];
        while (oldIndex[j] == answ1 || oldIndex[j] == answ2 || oldIndex[j] == answ3 || oldIndex[j] == answ4) {
          oldIndex[j] = this.getRandomInt(0, allDatasLen - 1);
        }
        answers[j] = this.props.vocabularyDatas[oldIndex[j]].mean.substring(0, this.props.vocabularyDatas[oldIndex[j]].mean.length - 2);
      }
      var row = {"answers": answers, "correctNumber": correctNumber, "question": questionText};
      this.dataForKiemTra[i] = row;
    }

    for(let i = 0; i < len; i++){
      this.tongSo += 1;
      var answers = [];
      var oldIndex = [];
      var question = this.props.vocabularyDatas[i].word;
      var questionText = this.props.vocabularyDatas[i].mean.substring(0, this.props.vocabularyDatas[i].mean.length - 2);
      var correctNumber = this.getRandomInt(0, 3);
      for(let j = 0; j < 4; j++) {
        if(j != correctNumber) {
          var aswIndex = this.getRandomInt(0, allDatasLen - 1);
          oldIndex[j] = aswIndex;
        } else {
          //answers[j] = this.props.vocabularyDatas[i].mean;
          oldIndex[j] = i;
        }
      }
      var lenAnswerIndex = oldIndex.length;
      for(let j = 0; j < lenAnswerIndex; j++) {
        if(j == correctNumber) {
          answers[j] = this.props.vocabularyDatas[oldIndex[j]].word + "(" + this.props.vocabularyDatas[oldIndex[j]].phonetic + ")";
          continue;
        }
        let answ1 = oldIndex[0];
        let answ2 = oldIndex[1];
        let answ3 = oldIndex[2];
        let answ4 = oldIndex[3];
        while (oldIndex[j] == answ1 || oldIndex[j] == answ2 || oldIndex[j] == answ3 || oldIndex[j] == answ4) {
          oldIndex[j] = this.getRandomInt(0, allDatasLen - 1);
        }

        answers[j] = this.props.vocabularyDatas[oldIndex[j]].word + "(" + this.props.vocabularyDatas[oldIndex[j]].phonetic + ")";
      }
      var row = {"answers": answers, "correctNumber": correctNumber, "question": questionText};
      this.dataForKiemTra[i + len] = row;
    }
    for(let i = 0; i < 2 * len; i++) {
      var ranNum = this.getRandomInt(0, (2 * len) - 1);
      var temp = this.dataForKiemTra[ranNum];
      this.dataForKiemTra[ranNum] = this.dataForKiemTra[i];
      this.dataForKiemTra[i] = temp;
    }
  }
  render() {
    if(this.props.numberDatas == 0) {
      return(
        <View style={style.vocabularyContent}>
          <View style={{flex: 1, justifyContent: 'center', paddingLeft: 5, paddingRight: 5}}>
            <Text style={{textAlign: 'center', fontWeight: 'bold', fontSize: 25}}>Không có từ vựng nào tồn tại trong danh mục này</Text>
          </View>
        </View>
      );

    }
    if(this.numberDatas != this.props.numberDatas) {
      this.dataForKiemTra = [];
      this.tongSo = 0;
      this.createDataForKiemTra();
    }
    const opacity = this.state.opac;
    if(this.state.showResult === 1) {
      var percent = (this.state.tongCauDung / this.tongSo) * 100;
      percent = parseFloat(percent).toFixed(2);
      return(
        <VocabularyResult
          tongCauDung={this.state.tongCauDung}
          tongCauSai={this.state.tongCauSai}
          percent={percent}
          tryAgain={() => this.tryAgain()}
          lessonUpdateClick={(value) => {this.props.lessonUpdateClick(1)}}/>
      );
    } else {
      return(
        <Animated.View style={{flex: 1, backgroundColor: '#e3e4e8', opacity}}>
          <View style={style.vocabularyContent}>
            <Text style={{fontSize: 15, fontWeight: '300', color: '#989fa9', textAlign: 'center'}}>{this.state.stt + "/" + this.tongSo}</Text>
            <View style={style.kiemTraText}>
              <Text style={style.KiemTraString}>{this.dataForKiemTra[this.state.index]["question"]}</Text>
            </View>

            <View style={style.buttonView}>
              <TouchableOpacity style={style.kiemTraButton} onPress={this.answerClick.bind(this, 0)}>
                <Text style={style.kiemTraButtonText}>{this.dataForKiemTra[this.state.index]["answers"][0]}</Text>
              </TouchableOpacity>

              <TouchableOpacity style={style.kiemTraButton} onPress={this.answerClick.bind(this, 1)}>
                <Text style={style.kiemTraButtonText}>{this.dataForKiemTra[this.state.index]["answers"][1]}</Text>
              </TouchableOpacity>

              <TouchableOpacity style={style.kiemTraButton} onPress={this.answerClick.bind(this, 2)}>
                <Text style={style.kiemTraButtonText}>{this.dataForKiemTra[this.state.index]["answers"][2]}</Text>
              </TouchableOpacity>

              <TouchableOpacity style={style.kiemTraButton} onPress={this.answerClick.bind(this, 3)}>
                <Text style={style.kiemTraButtonText}>{this.dataForKiemTra[this.state.index]["answers"][3]}</Text>
              </TouchableOpacity>
            </View>
          </View>
          {this.renderOverlay()}
        </Animated.View>
      );
    }
  }
  renderOverlay(){
    if(this.state.clicked === 1) {
      if(this.state.answerStatus === 1) {
        return(
          <View style={{position: 'absolute', width: width, height: height, justifyContent: 'center', alignItems: 'center',}}>
            <View style={style.kiemTraOverlay}></View>
            <View style={style.kiemtraKetQua} onLayout={this.getWidthAndHeight}>
              <View style={style.cautraLoi}>
                <Text style={{textAlign: 'center', fontSize: 18, fontWeight: 'bold', color: '#a0d468'}}>Đúng</Text>
              </View>
              <View style={style.cauDung}>
                <Text style={style.textSai}>{this.dataForKiemTra[this.state.index]["question"]}: {this.dataForKiemTra[this.state.index]["answers"][this.dataForKiemTra[this.state.index]["correctNumber"]]}</Text>
              </View>
              <TouchableOpacity style={style.tiepTuc} onPress={() => {this.tiepTucProcess()}}>
                <Text style={{textAlign: 'center', fontSize: 18, fontWeight: 'bold', color: 'white'}}>Tiếp Tục</Text>
              </TouchableOpacity>
            </View>
          </View>
        );
      } else {
        return(
          <View style={{position: 'absolute', width: width, height: height, justifyContent: 'center', alignItems: 'center',}}>
            <View style={style.kiemTraOverlay}></View>
            <View style={style.kiemtraKetQua} onLayout={this.getWidthAndHeight}>
              <View style={style.cautraLoi}>
                <Text style={{textAlign: 'center', fontSize: 18, fontWeight: 'bold', color: '#ed5565'}}>Sai</Text>
              </View>
              <View style={style.cauDung}>
                <Text style={style.textSai}>{this.dataForKiemTra[this.state.index]["question"]}: {this.dataForKiemTra[this.state.index]["answers"][this.dataForKiemTra[this.state.index]["correctNumber"]]}</Text>
              </View>
              <TouchableOpacity style={style.tiepTuc} onPress={() => {this.tiepTucProcess()}}>
                <Text style={{textAlign: 'center', fontSize: 18, fontWeight: 'bold', color: 'white'}}>Tiếp Tục</Text>
              </TouchableOpacity>
            </View>
          </View>
        );
      }
    }
    Animated.timing(
      this.state.opac,{
        toValue: 1,
        duration: 200,
    }).start();
  }
  /*this.state = {
    stt: 1,
    index: 0,
    answerStatus: 0,
    clicked: 0,
  }*/
  tryAgain(){
    this.dataForKiemTra = [];
    this.tongSo = 0;
    this.createDataForKiemTra();
    this.setState({
      stt: 1,
      index: 0,
      answerStatus: 0,
      clicked: 0,
      showResult: 0,
      opac: new Animated.Value(0),
      tongCauDung: 0,
      tongCauSai: 0,
    });
  }
  answerClick(answerIndex) {
    if(answerIndex === this.dataForKiemTra[this.state.index]["correctNumber"]) {
      this.setState({
        answerStatus: 1,
        clicked: 1,
        tongCauDung: this.state.tongCauDung + 1,
      });
    } else {
      this.setState({
        answerStatus: 0,
        clicked: 1,
        tongCauSai: this.state.tongCauSai + 1,
      });
    }
  }
  tiepTucProcess() {
    this.props.lessonUpdateClick(1);
    Animated.timing(
      this.state.opac,{
        toValue: 0,
        duration: 200,
    }).start(() => {
      if(this.state.stt === this.tongSo) {
        this.setState({
          stt: 1,
          index: 0,
          answerStatus: 0,
          clicked: 0,
          showResult: 1,
        });
      } else {
        this.setState({
          stt: this.state.stt + 1,
          index: this.state.index + 1,
          answerStatus: 0,
          clicked: 0,
          showResult: 0,
        });
      }
    });


    /*Animated.timing(
      this.state.opac,{
        toValue: 1,
        duration: 1000,
    }).start();*/
  }
  getWidthAndHeight = (e) => {
    heightItem = e.nativeEvent.layout.height;
  }
}

var centerWidth = (width / 2) - 150;
var centerHeight = (height / 5);
//var {height, width} = Dimensions.get('window');
const style = StyleSheet.create({
  textDung: {
    textAlign: 'center',
    fontSize: 18,
    fontWeight: '300',
    color: '#989fa9'
  },
  textSai: {
    textAlign: 'center',
    fontSize: 18,
    fontWeight: '300',
    color: '#989fa9'
  },
  tiepTuc: {
    left: 100,
    width: 100,
    padding: 5,
    backgroundColor: '#4fc1e9',
    marginBottom: 20,
    marginTop: 30,
    borderRadius: 5,
  },
  cauDung: {
    padding: 10,
  },
  kiemtraKetQua: {
    position: 'absolute',
    top: centerHeight,
    left: centerWidth,
    backgroundColor: 'white',
    width: 300,
    borderRadius: 10,
  },
  cautraLoi: {
    borderBottomWidth: 1,
    borderColor: '#e3e4e8',
    padding: 10,
  },
  kiemTraOverlay: {
    backgroundColor: 'black',
    position: 'absolute',
    width: width,
    height: height,
    top: 0,
    opacity: 0.7
  },
  kiemTraButtonText: {
    color: 'white',
    textAlign: 'center',
    fontSize: 18,
    fontWeight: '300',
  },
  buttonView: {
    flex: 1,
    justifyContent: 'center',
  },
  kiemTraButton: {
    padding: 7,
    backgroundColor: '#3bafda',
    justifyContent: 'center',
    marginBottom: 5,
    borderRadius: 3,
  },

  KiemTraString: {
    fontSize: 18,
    color: 'black',
    fontWeight: '300',
    textAlign: 'center'
  },
  kiemTraText: {
    flex: 1,
    backgroundColor: 'white',
    justifyContent: 'center',
  },

  vocabularyContent: {
    flex: 1,
    marginTop: 7,
    marginLeft: 7,
    marginRight: 7,
  }
});
