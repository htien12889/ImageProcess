import React, {Component} from 'react';
import {View, TouchableOpacity, Text, StyleSheet, ListView, Image} from 'react-native';
var SQLite = require('react-native-sqlite-storage')
var db = SQLite.openDatabase({name : "jlptDB_v2_new", createFromLocation : "~jlpt_v2_new.db"}, this.openCB,this.errorCB);
export default class VocabularyContent extends Component<{}>{
  constructor(props) {
    super(props);
    console.log("hello");
    this.state = {
			dataSource: new ListView.DataSource({rowHasChanged: (r1, r2)=>r1!==r2}),
			isContent: 0,
		}
  }
  render() {
    return(
      this.renderContent()
    );
  }
  renderContent(){
    if(this.props.vocabularyDatas.length == 0) {
      return(
        <View style={style.vocabularyContainer}>
          <View style={{flex: 1, justifyContent: 'center', paddingLeft: 5, paddingRight: 5}}>
            <Text style={{textAlign: 'center', fontWeight: 'bold', fontSize: 25}}>Không có từ vựng nào tồn tại trong danh mục này</Text>
          </View>
        </View>
      );
    } else {
      return(
        <View style={style.vocabularyContainer}>
          {this.renderListView()}
        </View>
      );
    }
  }
  renderListView() {
    if(this.props.level == 0) {
      return(
        <View style={style.vocabularyContent}>
          <ListView
            dataSource={this.state.dataSource}
            renderRow={(rowData) =>
              <View style={style.vocaContentTitle}>
                <View style={{flexDirection: 'row', flex: 1}}>
                  <Text style={style.vocaTextTile}>{rowData.word + "(" + rowData.phonetic + ")"}</Text>
                  <TouchableOpacity style={style.AddIconImage} onPress={() => {this.props.removeVocaType(rowData.id, this.props.danhMucId)}}>
                    <Image style={{width: 25, height: 25}} source={require('../../../assets/remove.png')}></Image>
                  </TouchableOpacity>
                </View>
                <Text style={style.vocaMeanText}>Ý Nghĩa:</Text>
                <Text style={style.vocaMeanData}>{rowData.mean.substring(0, rowData.mean.length - 2)}</Text>
                {this.renderExample(rowData)}
              </View>
            }
          />
        </View>
      );
    } else {
      return(
        <View style={style.vocabularyContent}>
          <ListView
            dataSource={this.state.dataSource}
            renderRow={(rowData) =>
              <View style={style.vocaContentTitle}>
                <View style={{flexDirection: 'row', flex: 1}}>
                  <Text style={style.vocaTextTile}>{rowData.word + "(" + rowData.phonetic + ")"}</Text>
                  <TouchableOpacity style={style.AddIconImage} onPress={() => {this.props.addVocaType(rowData.id)}}>
                    <Image style={{width: 25, height: 25}} source={require('../../../assets/addContent.png')}></Image>
                  </TouchableOpacity>
                </View>
                <Text style={style.vocaMeanText}>Ý Nghĩa:</Text>
                <Text style={style.vocaMeanData}>{rowData.mean.substring(0, rowData.mean.length - 2)}</Text>
                {this.renderExample(rowData)}
              </View>
            }
          />
        </View>
      );
    }
  }
  renderExample(rowData) {
    //console.log(rowData);
    if(rowData.example_content != "") {
      return(
        <View>
          <Text style={style.vocaExample}>Ví Dụ:</Text>
          <Text style={style.vocaExampleKanji}>{rowData.example_content}</Text>
          <Text style={style.vocaExampleHira}>{rowData.example_transcription}</Text>
          <Text style={style.vocaExampleVN}>{rowData.example_mean}</Text>
        </View>
      );
    }
  }
  componentDidMount(){
    this.setState({
      dataSource: this.state.dataSource.cloneWithRows(this.props.vocabularyDatas),
    });
  }
  resetDatas(value){
    this.props.vocabularyDatas = value;
    this.setState({
      dataSource: this.state.dataSource.cloneWithRows(value),
    });
  }
}

var marginBottomText = 3;
const style = StyleSheet.create({
  vocaExampleVN: {
    fontSize: 15,
    fontWeight: '300',
    color: 'black',
  },
  vocaExampleHira: {
    fontSize: 15,
    fontWeight: '300',
    color: '#ed5565',
  },
  vocaExampleKanji: {
    fontSize: 15,
    fontWeight: '300',
    color: '#ed5565',
  },
  vocaExample: {
    fontSize: 15,
    fontWeight: 'bold',
    fontStyle: 'italic',
    textDecorationLine: 'underline',
    color: 'black'
  },
  vocaMeanData: {
    color: 'blue',
    fontSize: 15,
    fontWeight: '300',
    marginBottom: marginBottomText,
  },
  vocaMeanText: {
    fontSize: 15,
    fontWeight: 'bold',
    fontStyle: 'italic',
    textDecorationLine: 'underline',
    color: 'black'
  },
  vocaContentTitle: {
    backgroundColor: 'white',
    paddingTop: 10,
    paddingBottom: 10,
    paddingLeft: 10,
    paddingRight: 10,
    borderRadius: 5,
    marginBottom: 7,
  },
  vocaTextTile: {
    fontSize: 17,
    fontWeight: 'bold',
    color: '#ed5565',
    marginBottom: marginBottomText,
  },
  vocabularyContainer: {
    flex: 1,
    backgroundColor: '#e3e4e8',
  },
  vocabularyContent: {
    flex: 1,
    marginTop: 7,
    marginLeft: 7,
    marginRight: 7,
  },
  AddIconImage: {
    width: 25,
    height: 25,
    position: 'absolute',
    top: 0,
    right: 0,
  }
});
