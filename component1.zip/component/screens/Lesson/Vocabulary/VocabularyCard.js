import React, {Component} from 'react';
import {View, Text, StyleSheet, TouchableOpacity, Animated, Dimensions} from 'react-native';
var {height, width} = Dimensions.get('window');
export default class VocabularyCard extends Component {
  componentWillMount() {
    this.animatedValue = new Animated.Value(0);
    this.value = 0;
    this.animatedValue.addListener(({ value }) => {
      this.value = value;
    })
    this.frontOpacity = this.animatedValue.interpolate({
      inputRange: [89, 90],
      outputRange: [1, 0]
    })
    this.frontInterpolate = this.animatedValue.interpolate({
      inputRange: [0, 180],
      outputRange: ['0deg', '180deg'],
    })
    this.backInterpolate = this.animatedValue.interpolate({
      inputRange: [0, 180],
      outputRange: ['180deg', '360deg']
    })
    this.backOpacity = this.animatedValue.interpolate({
      inputRange: [89, 90],
      outputRange: [0, 1]
    })
  }
  flipCard() {
    if (this.value >= 90) {
      Animated.spring(this.animatedValue,{
        toValue: 0,
        friction: 8,
        tension: 30
      }).start();
    } else {
      Animated.spring(this.animatedValue,{
        toValue: 180,
        friction: 8,
        tension: 30
      }).start();
    }

  }

  render() {
    const frontAnimatedStyle = {
      opacity: this.frontOpacity,
      transform: [
        { rotateY: this.frontInterpolate}
      ]
    }
    const backAnimatedStyle = {
      opacity: this.backOpacity,
      transform: [
        { rotateY: this.backInterpolate }
      ]
    }
    return (
      <View style={styles.container}>
        <TouchableOpacity onPress={() => this.flipCard()}>
          <Animated.View style={[styles.flipCard, frontAnimatedStyle]}>
            <Text style={styles.flipText}>
              {this.props.frontString}
            </Text>
          </Animated.View>
          <Animated.View style={[backAnimatedStyle, styles.flipCard, {width: width} , styles.flipCardBack]}>
            <Text style={styles.flipText}>
              {this.props.backString}
            </Text>
          </Animated.View>
        </TouchableOpacity>
      </View>
    );
  }
  logTest(){
    console.log(width);
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  flipCard: {
    padding: 5,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
    backfaceVisibility: 'hidden',
    marginBottom: 7,
    borderRadius: 5
  },
  flipCardBack: {
    flex: 1,
    backgroundColor: "white",
    position: "absolute",
    top: 0,
  },
  flipText: {
    fontSize: 15,
    color: 'black',
    fontWeight: '300',
  }
});
