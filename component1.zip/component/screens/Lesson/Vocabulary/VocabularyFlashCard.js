import React, {Component} from 'react';
import {View, Text, StyleSheet, ListView} from 'react-native';
import VocabularyCard from './VocabularyCard.js';
export default class VocabularyFlashCard extends Component<{}>{
  constructor(props){
    super(props);
    this.state = {
			dataSource: new ListView.DataSource({rowHasChanged: (r1, r2)=>r1!==r2}),
		}
  }
  render() {
    if(this.props.vocabularyDatas.length > 0) {
      return(
        <View style={style.vocabularyContainer}>
          <View style={style.vocabularyContent}>
            <ListView
              dataSource={this.state.dataSource}
              renderRow={(rowData) =>
                <VocabularyCard
                  frontString={rowData.word + "(" + rowData.phonetic + ")"}
                  backString={rowData.mean.substring(0, rowData.mean.length - 2)} />
              }
            />
          </View>
        </View>
      );
    } else {
      return(
        <View style={style.vocabularyContainer}>
          <View style={{flex: 1, justifyContent: 'center', paddingLeft: 5, paddingRight: 5}}>
            <Text style={{textAlign: 'center', fontWeight: 'bold', fontSize: 25}}>Không có từ vựng nào tồn tại trong danh mục này</Text>
          </View>
        </View>
      );

    }
  }
  componentDidMount(){
    this.setState({
      dataSource: this.state.dataSource.cloneWithRows(this.props.vocabularyDatas),
    });
  }
}

const style = StyleSheet.create({
  vocabularyContainer: {
    flex: 1,
    backgroundColor: '#e3e4e8',
  },
  vocabularyContent: {
    flex: 1,
    marginTop: 7,
    marginLeft: 7,
    marginRight: 7,
  }
});
