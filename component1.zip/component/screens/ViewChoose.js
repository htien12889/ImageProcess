import React, {Component} from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
export default class ViewChoose extends Component<{}>{
  constructor(props){
    super(props);
    this.state = {
      chooseFlashCard: 0,
    }
  }
  render() {
    return(
      <View style={style.vocabularyContainer}>
        <TouchableOpacity style={style.chooseButton}
          onPress={() => {this.props.lession()}}>
          <Text style={{textAlign: 'center', padding: 5, fontSize: 18, color: 'white', fontWeight: 'bold', paddingTop: 5, paddingBottom: 10}}>Các Bài Học</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[style.chooseButton, {marginTop: 5}]}
          onPress={() => {this.props.test()}}>
          <Text style={{textAlign: 'center', padding: 5, fontSize: 18, color: 'white', fontWeight: 'bold', paddingTop: 5, paddingBottom: 10}}>JLPT Test</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const style = StyleSheet.create({
  vocabularyContainer: {
    flex: 1,
    backgroundColor: '#4fc1e9',
    justifyContent: 'center',
  },
  chooseButton: {
    borderColor: 'white',
    borderRadius: 3,
    padding: 2,
    borderWidth: 1,
    backgroundColor: '#a0d468',
    marginLeft: 10,
    marginRight: 10,
  }
});
