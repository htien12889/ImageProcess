import React, {Component} from 'react';
import {
	View, Text, ImageBackground, StyleSheet, TouchableOpacity, Image
} from 'react-native';

export default class Home extends Component<{}> {

	constructor(props){
		super(props)
		this.state = {
			buttonClick: 1,
			lessonOrTest: 'Hãy Chọn Cấp Độ Để Học',
			lessonOrTestParameter: 'Lesson'
		}
	}

	render() {
		return (
			<View style={style.homeContainer}>
				<ImageBackground style={style.homeCtn1} source={require('../assets/main_bground.jpg')}>
					<ImageBackground style={style.homeHeader} source={require('../assets/nen_title.png')}>
						<Text style={style.homeHeaderText}>JLPT Toàn Thư</Text>
					</ImageBackground>
					<View style={style.homeCtn1Header}>
						<Text style={{fontSize: 20, textAlign: 'center', color: '#434a54', fontWeight: 'bold'}}>Lesson</Text>
					</View>
					{this.ButtonLessonSelect()}
					<View style={style.homeCtn1Header}>
						<Text style={{fontSize: 20, textAlign: 'center', color: '#434a54', fontWeight: 'bold'}}>{this.state.lessonOrTest}</Text>
					</View>
				</ImageBackground>
				<View style={style.homeCtn2}>
					<TouchableOpacity style={style.homeJLPTButtons}
						onPress={()=>{this.props.navigation.navigate('MainScreens', {lessonOrTest: this.state.lessonOrTestParameter})}}>
						<View style={style.homeJLPTIcon}>
							<Image style={style.homeJLPTIconImage} source={require('../assets/jlpt_icon.png')}></Image>
						</View>
						<View style={style.homeJLPTText}>
							<Text style={style.homeJLPTTextContent}>JLPT N1</Text>
						</View>
					</TouchableOpacity>

					<TouchableOpacity style={style.homeJLPTButtons}
						onPress={()=>{this.props.navigation.navigate('MainScreens', {lessonOrTest: this.state.lessonOrTestParameter})}}>
						<View style={style.homeJLPTIcon}>
							<Image style={style.homeJLPTIconImage} source={require('../assets/jlpt_icon.png')}></Image>
						</View>
						<View style={style.homeJLPTText}>
							<Text style={style.homeJLPTTextContent}>JLPT N2</Text>
						</View>
					</TouchableOpacity>

					<TouchableOpacity style={style.homeJLPTButtons}
						onPress={()=>{this.props.navigation.navigate('MainScreens', {lessonOrTest: this.state.lessonOrTestParameter})}}>
						<View style={style.homeJLPTIcon}>
							<Image style={style.homeJLPTIconImage} source={require('../assets/jlpt_icon.png')}></Image>
						</View>
						<View style={style.homeJLPTText}>
							<Text style={style.homeJLPTTextContent}>JLPT N3</Text>
						</View>
					</TouchableOpacity>

					<TouchableOpacity style={style.homeJLPTButtons}
						onPress={()=>{this.props.navigation.navigate('MainScreens', {lessonOrTest: this.state.lessonOrTestParameter})}}>
						<View style={style.homeJLPTIcon}>
							<Image style={style.homeJLPTIconImage} source={require('../assets/jlpt_icon.png')}></Image>
						</View>
						<View style={style.homeJLPTText}>
							<Text style={style.homeJLPTTextContent}>JLPT N4</Text>
						</View>
					</TouchableOpacity>

					<TouchableOpacity style={style.homeJLPTButtons}
						onPress={()=>{this.props.navigation.navigate('MainScreens', {lessonOrTest: this.state.lessonOrTestParameter})}}>
						<View style={style.homeJLPTIcon}>
							<Image style={style.homeJLPTIconImage} source={require('../assets/jlpt_icon.png')}></Image>
						</View>
						<View style={style.homeJLPTText}>
							<Text style={style.homeJLPTTextContent}>JLPT N5</Text>
						</View>
					</TouchableOpacity>

					<TouchableOpacity style={style.homeJLPTButtons}>
						<View style={style.homeJLPTIcon}>
							<Image style={style.homeJLPTIconImage} source={require('../assets/jlpt_icon.png')}></Image>
						</View>
						<View style={style.homeJLPTText}>
							<Text style={style.homeJLPTTextContent}>Đánh giá ứng dụng</Text>
						</View>
					</TouchableOpacity>

					<TouchableOpacity style={style.homeJLPTButtons}>
						<View style={style.homeJLPTIcon}>
							<Image style={style.homeJLPTIconImage} source={require('../assets/jlpt_icon.png')}></Image>
						</View>
						<View style={style.homeJLPTText}>
							<Text style={style.homeJLPTTextContent}>Thoát ứng dụng</Text>
						</View>
					</TouchableOpacity>

				</View>
			</View>
		);
	}
	ButtonLessonSelect() {
		var selectedColor = '#4fc1e9';
		if(this.state.buttonClick == 0) {
			return (
				<View style={style.homeCtn1Buttons}>
					<TouchableOpacity style={{flex: 1, borderBottomWidth: 2, borderColor: '#e3e4e8'}}
						onPress={()=>{this.button1Onclick()}}>
						<View style={{flex: 2, justifyContent: 'center', alignItems: 'center'}}>
							<Image style={{width: 60, height: 60}} source={require('../assets/Popular-05-512.png')} />
						</View>
						<View style={{flex: 1, justifyContent: 'center'}}>
							<Text style={{fontSize: 15, textAlign: 'center', color: '#3bafda'}}>Các Bài Học</Text>
						</View>
					</TouchableOpacity>

					<TouchableOpacity style={{flex: 1, backgroundColor: selectedColor}} onPress={()=>{this.button2Onclick()}}>
						<View style={{flex: 2, justifyContent: 'center', alignItems: 'center'}}>
							<Image style={{width: 60, height: 60}} source={require('../assets/list-512.png')} />
						</View>
						<View style={{flex: 1, justifyContent: 'center'}}>
							<Text style={{fontSize: 15, textAlign: 'center', color: '#ffffff'}}>JLPT Test</Text>
						</View>
					</TouchableOpacity>
				</View>
			);
		} else {
			return (
				<View style={style.homeCtn1Buttons}>
					<TouchableOpacity style={{flex: 1, borderBottomWidth: 2, borderColor: '#e3e4e8', backgroundColor: selectedColor}} onPress={()=>{this.button1Onclick()}}>
						<View style={{flex: 2, justifyContent: 'center', alignItems: 'center'}}>
							<Image style={{width: 60, height: 60}} source={require('../assets/Popular-05-512.png')} />
						</View>
						<View style={{flex: 1, justifyContent: 'center'}}>
							<Text style={{fontSize: 15, textAlign: 'center', color: '#ffffff'}}>Các Bài Học</Text>
						</View>
					</TouchableOpacity>

					<TouchableOpacity style={{flex: 1}} onPress={()=>{this.button2Onclick()}}>
						<View style={{flex: 2, justifyContent: 'center', alignItems: 'center'}}>
							<Image style={{width: 60, height: 60}} source={require('../assets/list-512.png')} />
						</View>
						<View style={{flex: 1, justifyContent: 'center'}}>
							<Text style={{fontSize: 15, textAlign: 'center', color: '#3bafda'}}>JLPT Test</Text>
						</View>
					</TouchableOpacity>
				</View>
			);
		}
	}
	button1Onclick(){
		this.setState({
      buttonClick: 1,
			lessonOrTest: 'Hãy Chọn Cấp Độ Để Học',
			lessonOrTestParameter: 'Lesson'
    });

	}
	button2Onclick(){
		this.setState({
      buttonClick: 0,
			lessonOrTest: 'Hãy Chọn Cấp Độ Để Làm Bài Kiểm Tra',
			lessonOrTestParameter: 'Test'
    });
	}
}



var homeHeaderHeight = 50;
var homeHeaderTextSize = 20;
const style = StyleSheet.create({

	homeJLPTIconImage: {
		width: 30,
		height: 30,
	},
	homeJLPTIcon: {
		flex: 1,
		alignItems: 'center',
		justifyContent: 'center',
	},
	homeJLPTText: {
		justifyContent: 'center',
		flex: 5,
	},
	homeJLPTTextContent: {
		fontSize: 15,
		fontWeight: '300',
		textAlign: 'left',
		color: '#434a54'
	},

	textCenter: {
		textAlign: 'center',
	},
	homeContainer: {
		flex: 1,
		backgroundColor: '#ffffff'
	},
	homeCtn1: {
		flex: 1,
		backgroundColor: '#ff0000'
	},
	homeHeaderText: {
		textAlign: 'center',
		fontSize: homeHeaderTextSize,
		color: '#4fc1e9',
	},
	homeHeader: {
		justifyContent: 'center',
		opacity: 0.8,
		height: homeHeaderHeight,
	},
	homeCtn2: {
		flex: 1,
		backgroundColor: '#000000'
	},
	homeCtn1Header: {
		flex: 1,
		justifyContent: 'center',
	},
	homeCtn1Buttons: {
		flex: 3.5,
		backgroundColor: '#f0f2f5',
		marginLeft: 20,
		marginRight: 20,
		borderRadius: 5,
	},
	homeJLPTButtons: {
		flex: 1,
		flexDirection: 'row',
		backgroundColor: '#f0f2f5',
		borderBottomWidth: 2,
		borderColor: '#d7d8dd',
		justifyContent: 'center'
	},
});
