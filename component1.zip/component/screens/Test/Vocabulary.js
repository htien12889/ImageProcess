import React, {Component} from 'react';
import {
	View, Text, StyleSheet, TouchableOpacity, ListView, TextInput, WebView, NetInfo, Alert
} from 'react-native';
import Test from './common/Test.js';
var SQLite = require('react-native-sqlite-storage')
var db = SQLite.openDatabase({name : "jlptDB_test_v2", createFromLocation : "~jlpt_test_v2_2.db"}, this.openCB,this.errorCB);

export default class Vocabulary extends Component<{}>{
	constructor(props) {
		super(props);
		this.cat_id = 0;
		this.state = {
			dataSource: new ListView.DataSource({rowHasChanged: (r1, r2)=>r1!==r2}),
			isContent: 0,
			htmlContent: "",
		}
	}
	openCB(){
		console.log("Open Database");
	}
	sucessCB() {
		ToastAndroid.show("Sucessful", ToastAndroid.SHORT);
	}
	errorCB(err) {
		ToastAndroid.show("SQL Error" + err, ToastAndroid.SHORT);
	}
  render() {
    return (
			this.renderContentGrammar()
    );
  }
	renderContentGrammar(){
		if(this.state.isContent == 0) {
			return(
				<View style={style.grammarContainer}>
					<View style={{flex: 1}}>
						<ListView
							dataSource={this.state.dataSource}
							renderRow={(rowData) =>
								<TouchableOpacity style={style.listView}
									onPress={this.GetListViewItem.bind(this, rowData.stt)}>
									<View style={{justifyContent: 'center'}}>
										<Text style={{fontSize: 17, marginLeft: 15, color: 'white'}}>{rowData.stt}</Text>
									</View>
									<View style={{justifyContent: 'center'}}>
										<Text style={{fontSize: 17, marginLeft: 15, color: 'white'}}>{rowData.title}</Text>
									</View>
								</TouchableOpacity>
							}
						/>
					</View>
				</View>
			);
		} else {
			return(
				<Test
					level={this.props.level}
					addTestType={(value) => this.props.addTestType(value)}
					grammarTestDatas={this.state.grammarTestDatas}
					lessonUpdateClickNoAds={(value) => {this.props.lessonUpdateClickNoAds(value)}}
					lessonUpdateClick={(value)=>this.props.lessonUpdateClick(value)}/>
			);
		}
	}
	backProcess(){
		this.setState({
			isContent: 0,
		});
	}
	GetListViewItem(page) {
		this.props.lessonUpdateClick(3);
		this.props.updateIsContent();
		var sql = "SELECT * FROM test_group WHERE `parent_id`="+ this.cat_id +" and page='" + page + "'";
    console.log(sql);
		db.transaction((tx) => {
			tx.executeSql(sql, [], (tx, results) => {
					var array = [];
					var len = results.rows.length;
					for (let i = 0; i < len; i++) {
						var row = {data: results.rows.item(i), index: i, total: len}
						array[i] = row;
					}
					this.setState({
						isContent: 1,
						grammarTestDatas: array,
					});
			 });
		});
	}

	componentDidMount() {
		if(this.props.level == 1) {
			this.cat_id = 11;
		}
		else if(this.props.level == 4) {
			this.cat_id = 8;
		}
		else if(this.props.level == 5) {
			this.cat_id = 7;
		}
		else if(this.props.level == 3) {
			this.cat_id = 9;
		}
		else {
			this.cat_id = 10;
		}
		db.transaction((tx) => {
      tx.executeSql('SELECT * FROM category_test where id='+this.cat_id, [], (tx, results) => {
					var array = [];
          var numberPage = results.rows.item(0)["tong_page"];
          for (let i = 0; i < numberPage; i++) {
            var row = {"stt": i + 1, "index": i, "title": "Bài Số " + (i + 1)};
            array[i] = row;
          }
					this.setState({
						dataSource: this.state.dataSource.cloneWithRows(array),
					});
        });
    });
	}
}

const style = StyleSheet.create({
	listView: {
		/*flexDirection: 'row',
		height: 40,
		marginLeft: 10,
		marginRight: 10,
		marginTop: 3,
		borderRadius: 7,
		backgroundColor: '#ffffff',*/
		flexDirection: 'row',
    padding: 10,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderBottomColor: '#2ea5dd',
    borderTopColor: '#75d2f0',
    backgroundColor: '#4fc1e9',
		//justifyContent: 'center',
	},
	TextInputStyleClass: {
		textAlign: 'center',
		color: '#989fa9',
		height: 40,
		borderWidth: 1,
		borderColor: '#d7d8dd',
		borderRadius: 7 ,
		backgroundColor : "#f0f2f5",
		margin: 10
	},
  grammarContainer: {
		flex: 1,
		backgroundColor: '#e3e4e8',
	},
});
