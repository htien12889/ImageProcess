import React, {Component} from 'react';
import {
	View, Text, StyleSheet, TouchableOpacity, ListView, TextInput, WebView, NetInfo, Alert
} from 'react-native';
import Test from './common/Test.js';
var SQLite = require('react-native-sqlite-storage')
var db = SQLite.openDatabase({name : "jlptDB_test_v2", createFromLocation : "~jlpt_test_v2_2.db"}, this.openCB,this.errorCB);
var db1 = SQLite.openDatabase({name : "jlptDB_folder", createFromLocation : "~folder.db"}, this.openCB,this.errorCB);
export default class DMTest extends Component<{}>{
	constructor(props) {
		super(props);
		this.cat_id = 0;
		this.dmId = 0;
		this.state = {
			numberDatas: 1,
			dataSource: new ListView.DataSource({rowHasChanged: (r1, r2)=>r1!==r2}),
			isContent: 0,
		}
	}
	openCB(){
		console.log("Open Database");
	}
	sucessCB() {
		ToastAndroid.show("Sucessful", ToastAndroid.SHORT);
	}
	errorCB(err) {
		ToastAndroid.show("SQL Error" + err, ToastAndroid.SHORT);
	}
  render() {
		if(this.state.numberDatas == 0) {
			return(
        <View style={style.grammarContainer}>
          <View style={{flex: 1, justifyContent: 'center', paddingLeft: 5, paddingRight: 5}}>
            <Text style={{textAlign: 'center', fontWeight: 'bold', fontSize: 25}}>Không có danh mục test nào</Text>
          </View>
        </View>
      );
		}
    return (
			this.renderContentGrammar()
    );
  }
	renderContentGrammar(){
		if(this.state.isContent == 0) {
			return(
				<View style={style.grammarContainer}>
					<View style={{flex: 1}}>
						<ListView
							dataSource={this.state.dataSource}
							renderRow={(rowData) =>
								<TouchableOpacity style={style.listView}
									onPress={this.GetListViewItem.bind(this, rowData)}>
									<View style={{justifyContent: 'center'}}>
										<Text style={{fontSize: 17, marginLeft: 15, color: 'white'}}>{rowData.stt}</Text>
									</View>
									<View style={{justifyContent: 'center'}}>
										<Text style={{fontSize: 17, marginLeft: 15, color: 'white'}}>{rowData.name}</Text>
									</View>
								</TouchableOpacity>
							}
						/>
					</View>
				</View>
			);
		} else {
			return(
				<Test
					ref="child"
					level={0}
					removeTestType={(value) => this.removeTestType(value)}
					grammarTestDatas={this.state.grammarTestDatas}
					lessonUpdateClickNoAds={(value) => {this.props.lessonUpdateClickNoAds(value)}}
					lessonUpdateClick={(value)=>this.props.lessonUpdateClick(value)}/>
			);
		}
	}
	backProcess(){
		this.setState({
			isContent: 0,
		});
	}
	removeTestType(value) {
		dmId = this.dmId;
		var sql = "SELECT * FROM folder WHERE `id`='"+ dmId +"'";
    console.log(sql);
    db1.transaction((tx) => {
      tx.executeSql(sql, [], (tx, results) => {
        let ids = results.rows.item(0).ids;
        let idsWrite = "";
        let arrayIds = ids.split(',');
        let j = 0;
        for(let i = 0; i < arrayIds.length; i++) {
          if(arrayIds[i] == value) {
            continue;
          }
          if(j == 0) {
            idsWrite = idsWrite + arrayIds[i];
          } else {
            idsWrite = idsWrite + "," + arrayIds[i];
          }
          j++;
        }
        db1.transaction((tx) => {
          tx.executeSql("UPDATE folder SET ids='"+idsWrite+"' WHERE id='"+dmId+"'", [], (tx, results) => {
						let parameter = {id: this.dmId, ids: idsWrite};
						this.GetListViewItem(parameter);
						this.getDatas();
          });
        });
       });
    });
	}

	GetListViewItem(value) {
		this.dmId = value.id;
		this.props.lessonUpdateClick(3);
		this.props.updateIsContent();
		var sql = "SELECT * FROM test_group WHERE `id` in ("+value.ids+")";
		db.transaction((tx) => {
			tx.executeSql(sql, [], (tx, results) => {
					var array = [];
					var len = results.rows.length;
					for (let i = 0; i < len; i++) {
						var row = {data: results.rows.item(i), index: i, total: len}
						array[i] = row;
					}
					this.setState({
						isContent: 1,
						grammarTestDatas: array,
					});
					this.refs.child.resetView(array);
			 });
		});
	}
	getDatas() {
		db1.transaction((tx) => {
      tx.executeSql("SELECT * FROM folder where type='test'", [], (tx, results) => {
					var array = [];
          for (let i = 0; i < results.rows.length; i++) {
            var row = {"stt": i + 1, "index": i, "ids": results.rows.item(i).ids, "name": results.rows.item(i).name, id: results.rows.item(i).id};
            array[i] = row;
          }
					this.setState({
						numberDatas: array.length,
						dataSource: this.state.dataSource.cloneWithRows(array),
					});
        });
    });
	}
	componentDidMount() {
		this.getDatas();
	}
}

const style = StyleSheet.create({
	listView: {
		/*flexDirection: 'row',
		height: 40,
		marginLeft: 10,
		marginRight: 10,
		marginTop: 3,
		borderRadius: 7,
		backgroundColor: '#ffffff',*/
		flexDirection: 'row',
    padding: 10,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderBottomColor: '#2ea5dd',
    borderTopColor: '#75d2f0',
    backgroundColor: '#4fc1e9',
		//justifyContent: 'center',
	},
	TextInputStyleClass: {
		textAlign: 'center',
		color: '#989fa9',
		height: 40,
		borderWidth: 1,
		borderColor: '#d7d8dd',
		borderRadius: 7 ,
		backgroundColor : "#f0f2f5",
		margin: 10
	},
  grammarContainer: {
		flex: 1,
		backgroundColor: '#e3e4e8',
	},
});
