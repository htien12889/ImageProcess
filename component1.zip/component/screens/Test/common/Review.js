import React, {Component} from 'react';
import {View, TouchableOpacity, Text, StyleSheet, Image} from 'react-native';
import Highlighter from 'react-native-highlight-words';
export default class Review extends Component<{}> {
  constructor(props) {
    super(props);
    this.questions = [];
    this.answrs = [];
    this.answForQues = [];
    this.answClick = [];
    this.backgroundColor = [];
    this.color = [];
    this.state = {
      click: 0,
    }
  }
  render() {
    if(this.props.datas.count > 1) {
      this.questions = this.props.datas.question.split("$$##$$");
      let answsRp = this.props.datas.answ.split("$$##$$");
      var lenAns = answsRp.length;
      for(let i = 0; i < lenAns; i++) {
        this.answrs[i] = answsRp[i].split(",");
        if(this.state.click == 0) {
          this.backgroundColor[i] = new Array(this.answrs[i].length);
          this.color[i] = new Array(this.answrs[i].length);
        }
      }
      if(this.props.index == (this.props.total - 1)) {
        return (
          <View>
            <View style={style.vocaContentTitle}>
              {this.renderTest()}
              {this.renderQuestion()}
            </View>
            <TouchableOpacity
              onPress={() => {this.props.tryAgain1()}}
              style={{padding: 7, backgroundColor: '#4fc1e9', marginTop: 10, marginBottom: 5, borderRadius: 5}}>
              <Text style={{color: 'white', fontSize: 17, fontWeight: 'bold', textAlign: 'center'}}>Làm Lại</Text>
            </TouchableOpacity>
          </View>
        );
      } else {
        return (
          <View style={style.vocaContentTitle}>
            {this.renderTest()}
            {this.renderQuestion()}
          </View>
        );
      }

    } else {
      this.answForQues = this.props.datas.answ.split(",");
      if(this.props.index == (this.props.total - 1)) {
        return(
          <View>
            <View style={style.vocaContentTitle}>
              <Text style={style.vocaTextTile}>{this.props.datas.text}</Text>
              {this.renderAnsw()}
            </View>
            <TouchableOpacity
              onPress={() => {this.props.tryAgain()}}
              style={{padding: 7, backgroundColor: '#4fc1e9', marginTop: 10, marginBottom: 5, borderRadius: 5}}>
              <Text style={{color: 'white', fontSize: 17, fontWeight: 'bold', textAlign: 'center'}}>Làm Lại</Text>
            </TouchableOpacity>
          </View>

        );
      } else {
        return(
          <View style={style.vocaContentTitle}>
            <Text style={style.vocaTextTile}>{this.props.datas.text}</Text>
            {this.renderAnsw()}
          </View>
        );
      }
    }
  }
  renderAnsw(){
    return(
      <View>
        {this.answForQues.map((prop, key) => {
          let bgr = 'white';
          let color = '#434a54';
          let fontW = '400';
          let indexRs = this.props.index;
          let iamgeStatus = 0;
          if(this.props.resultDatas[indexRs].haveAnsw) {
            if(this.props.resultDatas[indexRs].isRight) {
              if(this.props.resultDatas[indexRs].correctIndex == key) {
                bgr = '#41ad49';
                color = '#41ad49';
                fontW = 'bold';
                iamgeStatus = 1;
              }
            } else {
              if(this.props.resultDatas[indexRs].correctIndex == key) {
                bgr = '#41ad49';
                color = '#41ad49';
                fontW = 'bold';
                iamgeStatus = 1;
              }
              if(this.props.resultDatas[indexRs].chooseIndex == key) {
                bgr = '#e44061';
                color = '#e44061';
                fontW = 'bold';
                iamgeStatus = 2;
              }
            }
          } else {
            if(this.props.resultDatas[indexRs].correctIndex == key) {
              bgr = 'white';
              color = '#41ad49';
              fontW = 'bold';
            }
          }
          if(prop != "") {
            if(iamgeStatus == 0) {
              return (
               <View style={{flexDirection: 'row'}} key={key}>
                 <View style={{margin: 3, width: 18, height: 18, borderWidth: 2, borderRadius: 9, borderColor: '#434a54', marginRight: 10, backgroundColor: bgr}}>
                   <Text style={{color: '#434a54', textAlign: 'center', fontWeight: 'bold', fontSize: 10}}>{key + 1}</Text>
                 </View>
                 <Text style={{color: color, fontWeight: fontW, fontSize: 16, paddingRight: 20}}>
                   {prop}
                 </Text>
               </View>
              );
            } else if(iamgeStatus == 1) {
              return (
               <View style={{flexDirection: 'row'}} key={key}>
                 <View style={{margin: 3, width: 18, height: 18, marginRight: 10}}>
                   <Image style={{width: 18, height: 18}} source={require('./correct.png')}></Image>
                 </View>
                 <Text style={{color: color, fontWeight: fontW, fontSize: 16, paddingRight: 20}}>
                   {prop}
                 </Text>
               </View>
              );
            } else if(iamgeStatus == 2) {
              return (
               <View style={{flexDirection: 'row'}} key={key}>
                 <View style={{margin: 3, width: 18, height: 18, marginRight: 10}}>
                   <Image style={{width: 18, height: 18}} source={require('./incorrect.png')}></Image>
                 </View>
                 <Text style={{color: color, fontWeight: fontW, fontSize: 16, paddingRight: 20}}>
                   {prop}
                 </Text>
               </View>
              );
            }

          }
        })}
      </View>
    );
  }
  renderTest() {
    if(this.props.datas.text != "") {
      let split1s = this.props.datas.text.split('<u>');
      let stringBetween = [];
      for(i = 1; i < split1s.length; i++) {
        stringBetween[i] = split1s[i].split('</u>')[0];
      }
      /*for(; i < split2s.length + i; i++) {
        stringBetween[i] = split2s[j].split('</u>')[0];
        j++;
      }*/
      let textContent = this.props.datas.text;
      for(let i = 0; i < 10; i++) {
        textContent = textContent.replace('<u>', "");
        textContent = textContent.replace('</u>', "");
      }
      textContent = textContent.replace('<strong>', "");
      textContent = textContent.replace('</strong>', "");
      textContent = textContent.replace('&#8211;', "")
      return (
        <Highlighter
          style={{color: '#434a54', fontWeight: '500', fontSize: 17, marginBottom: 15}}
          highlightStyle={{backgroundColor: '#ed5565'}}
          searchWords={stringBetween}
          textToHighlight={textContent}
        />
      );
    }
  }

  renderAnsType2(anwsDatas, key){
    return(
      <View>
        {anwsDatas.map((ansText, key1) => {
          let bgr = 'white';
          let color = '#434a54';
          let fontW = '400';
          let indexRs = this.props.index;
          let iamgeStatus = 0;
          if(this.props.resultDatas[indexRs][key].haveAnsw) {
            if(this.props.resultDatas[indexRs][key].isRight) {
              if(this.props.resultDatas[indexRs][key].correctIndex == key1) {
                bgr = '#41ad49';
                color = '#41ad49';
                fontW = 'bold';
                iamgeStatus = 1;
              }
            } else {
              if(this.props.resultDatas[indexRs][key].correctIndex == key1) {
                bgr = '#41ad49';
                color = '#41ad49';
                fontW = 'bold';
                iamgeStatus = 1;
              }
              if(this.props.resultDatas[indexRs][key].chooseIndex == key1) {
                bgr = '#e44061';
                color = '#e44061';
                fontW = 'bold';
                iamgeStatus = 2;
              }
            }
          } else {
            if(this.props.resultDatas[indexRs][key].correctIndex == key1) {
              bgr = 'white';
              color = '#41ad49';
              fontW = 'bold';
            }
          }
          if(iamgeStatus == 0) {
            return (
              <View style={{flexDirection: 'row', backgroundColor: 'white'}} key={key1}>
                <View style={{marginTop: 3, width: 18, height: 18, borderWidth: 2, borderRadius: 9, borderColor: '#434a54', marginRight: 10, backgroundColor: bgr}}>
                  <Text style={{color: '#434a54', textAlign: 'center', fontWeight: 'bold', fontSize: 10}}>{key1 + 1}</Text>
                </View>
                <Text style={{color: color, fontWeight: fontW, fontSize: 16, paddingRight: 20}}>{ansText}</Text>
              </View>
            );
          } else if(iamgeStatus == 1) {
            return (
              <View style={{flexDirection: 'row', backgroundColor: 'white', marginRight: 10}} key={key1}>
                <View style={{marginTop: 3, width: 18, height: 18, marginRight: 10}}>
                  <Image style={{width: 18, height: 18}} source={require('./correct.png')}></Image>
                </View>
                <Text style={{color: color, fontWeight: fontW, fontSize: 16, paddingRight: 20}}>{ansText}</Text>
              </View>
            );
          } else if(iamgeStatus == 2) {
            return (
              <View style={{flexDirection: 'row', backgroundColor: 'white', marginRight: 10}} key={key1}>
                <View style={{marginTop: 3, width: 18, height: 18, marginRight: 10}}>
                  <Image style={{width: 18, height: 18}} source={require('./incorrect.png')}></Image>
                </View>
                <Text style={{color: color, fontWeight: fontW, fontSize: 16, paddingRight: 20}}>{ansText}</Text>
              </View>
            );
          }

        })}
      </View>

    );
  }

  renderQuestion(){
    return(
      <View>
        {this.questions.map((prop, key) => {
          let answerForKey = this.answrs[key];
          if(prop != "") {
           return (
             <View key={key}>
               <Text style={style.vocaTextTile}>
                 {prop}
               </Text>
               {this.renderAnsType2(answerForKey, key)}
             </View>
           );
          }
        })}
      </View>
    );
  }
}
var marginBottomText = 3;
const style = StyleSheet.create({
  vocaContentTitle: {
    backgroundColor: 'white',
    paddingTop: 10,
    paddingBottom: 10,
    paddingLeft: 10,
    paddingRight: 10,
    borderRadius: 5,
    marginBottom: 7,
  },
  vocaTextTile: {
    fontSize: 17,
    fontWeight: '400',
    color: '#434a54',
    marginBottom: marginBottomText,
  },
  vocaMeanData: {
    color: 'black',
    fontSize: 15,
    fontWeight: '300',
    marginBottom: marginBottomText,
  },
});
