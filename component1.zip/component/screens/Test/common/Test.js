import React, {Component} from 'react';
import {View, TouchableOpacity, Text, StyleSheet, ListView} from 'react-native';
import Highlighter from 'react-native-highlight-words';
import TestContent from './TestContent.js';
import TestResult from './TestResult.js';
import Review from './Review.js'
export default class Test extends Component<{}>{
  constructor(props) {
    super(props);
    this.answerResults = [];
    this.traLoiDung = 0;
    this.tongSo = 0;
    this.perCent = 0;
    this.state = {
			dataSource: new ListView.DataSource({rowHasChanged: (r1, r2)=>r1!==r2}),
      page: 'test',
		}
  }
  createAnswerResults(){
    for(let i = 0; i < this.props.grammarTestDatas.length; i++) {
      let countQues = this.props.grammarTestDatas[i].data.count;
      let row = [];
      /************************************************************/

      /**********************************************************************/
      if(countQues > 1) {
        let answWithIndex = this.props.grammarTestDatas[i].data;
        let answerArrays = answWithIndex.answ.split("$$##$$");
        let corrects = answWithIndex.correct.split("$$##$$");
        for(let j = 0; j < countQues; j++) {
          let answerArray = answerArrays[j].split(",");
          let correct = corrects[j].replace('　', "");
          let correctNumber = 0;
          for(let k = 0; k < answerArray.length; k++) {
            let answerLoop = answerArray[k].replace('　', "");
            if(answerLoop == correct) {
              correctNumber = k;
            }
          }
          this.tongSo += 1;
          row[j] = {chooseIndex: 0, answrString: '', haveAnsw: false, correctIndex: correctNumber, isRight: false};
        }
      } else {
        let answWithIndex = this.props.grammarTestDatas[i].data;
        let answerArray = answWithIndex.answ.split(",");
        let correct = answWithIndex.correct.replace('　', "");
        let correctNumber = 0;
        for(let k = 0; k < answerArray.length; k++) {
          let answerLoop = answerArray[k].replace('　', "");
          if(answerLoop == correct) {
            correctNumber = k;
          }
        }
        this.tongSo += 1;
        row = {chooseIndex: 0, answrString: '', haveAnsw: false, correctIndex: correctNumber, isRight: false};
      }
      this.answerResults[i] = row;
    }
  }
  render() {
    if(this.props.grammarTestDatas.length == 0) {
      return(
        <View style={style.vocabularyContainer}>
          <View style={{flex: 1, justifyContent: 'center', paddingLeft: 5, paddingRight: 5}}>
            <Text style={{textAlign: 'center', fontWeight: 'bold', fontSize: 25}}>Không có câu hỏi nào tồn tại trong danh mục này</Text>
          </View>
        </View>
      );
    }
    if(this.state.page == 'test1') {
      this.traLoiDung = 0;
      this.tongSo = 0;
      this.perCent = 0;
      this.createAnswerResults();
      return(
        <View style={style.vocabularyContainer}>
          <View style={style.vocabularyContent}>
            <Text style={{height: 0}}></Text>
            <ListView
              dataSource={this.state.dataSource}
              renderRow={(rowData) =>
                <TestContent
                  level={this.props.level}
                  datas={rowData.data}
                  index={rowData.index}
                  total={rowData.total}
                  removeTestType={(value) => this.props.removeTestType(value)}
                  addTestType={(value) => this.props.addTestType(value)}
                  updateAnswerType1={(index, key, userAns) => {this.updateAnswerType1(index, key, userAns)}}
                  updateAnswerType2={(index, key1, key2, userAns) => {this.updateAnswerType2(index, key1, key2, userAns)}}
                  submitJLPT={() => {this.submitJLPT()}}
                  lessonUpdateClickNoAds={(value) => {this.props.lessonUpdateClickNoAds(value)}}
                  lessonUpdateClick={(value) => {this.props.lessonUpdateClick(value)}}/>
              }
            />
          </View>
        </View>
      );
    }
    if(this.state.page == 'test') {
      this.traLoiDung = 0;
      this.tongSo = 0;
      this.perCent = 0;
      this.createAnswerResults();
      return(
        this.renderContent()
      );
    } else if(this.state.page == 'result') {
      return(
        <TestResult
          tongCauDung={this.traLoiDung}
          tongCau={this.tongSo}
          percent={this.perCent}
          tryAgain={() => this.tryAgain()}
          reviewTest={() => this.reviewTest()}
          //lessonUpdateClick={(value) => {this.props.lessonUpdateClick(value)}}
        />
      );
    } else if(this.state.page == 'review') {
      return(
        <View style={style.vocabularyContainer}>
          <View style={style.vocabularyContent}>
            <ListView
              dataSource={this.state.dataSource}
              renderRow={(rowData) =>
                <Review
                  datas={rowData.data}
                  index={rowData.index}
                  total={rowData.total}
                  resultDatas={this.answerResults}
                  tryAgain={() => {this.tryAgain()}}
                  tryAgain1={() => this.tryAgain1()}/>
              }
            />
          </View>
        </View>
      );
    }

  }
  lessonUpdateClick(value) {
    this.props.lessonUpdateClick(2);
  }
  reviewTest(){
    this.props.lessonUpdateClick(2);
    this.setState({
      page: 'review',
    });
  }
  tryAgain() {
    this.props.lessonUpdateClick(2);
    this.setState({
      page: 'test',
    });
  }
  tryAgain1() {
    this.props.lessonUpdateClick(2);
    this.setState({
      page: 'test1',
    });
  }
  renderContent(){
    return(
      <View style={style.vocabularyContainer}>
        <View style={style.vocabularyContent}>
          <Text style={{height: 0}}></Text>
          <ListView
            dataSource={this.state.dataSource}
            renderRow={(rowData) =>
              <TestContent
                level={this.props.level}
                datas={rowData.data}
                index={rowData.index}
                total={rowData.total}
                removeTestType={(value) => this.props.removeTestType(value)}
                addTestType={(value) => this.props.addTestType(value)}
                updateAnswerType1={(index, key, userAns) => {this.updateAnswerType1(index, key, userAns)}}
                updateAnswerType2={(index, key1, key2, userAns) => {this.updateAnswerType2(index, key1, key2, userAns)}}
                submitJLPT={() => {this.submitJLPT()}}
                lessonUpdateClickNoAds={(value) => {this.props.lessonUpdateClickNoAds(value)}}
                lessonUpdateClick={(value) => {this.props.lessonUpdateClick(value)}}/>
            }
          />

        </View>
      </View>
    );
  }
  submitJLPT(){
    this.props.lessonUpdateClick(1);
    /*{chooseIndex: 0, haveAnsw: false, correctIndex: 0, isRight: false, inCorrBgr: '#ed5565', inCorrColor: '#ed5565',
    corrBgr: '#a0d468', corrColor: '#a0d468', chuaTLBgr: '#912ffe', chuaTLColor: '#912ffe'};*/
    for(let i = 0; i < this.answerResults.length; i++) {
      if(this.answerResults[i].length > 1) {
        for(let j = 0; j < this.answerResults[i].length; j++) {
          let ansResult = this.answerResults[i][j];
          if(ansResult.haveAnsw && ansResult.isRight) {
            if(ansResult.isRight) {
              this.traLoiDung += 1;
            }
          }
        }
      } else {
        let ansResult = this.answerResults[i];
        if(ansResult.haveAnsw && ansResult.isRight) {
          this.traLoiDung += 1;
        }
      }
    }
    var percentage = (this.traLoiDung / this.tongSo) * 100;
    this.perCent = parseInt(percentage);
    this.setState({
      page: 'result',
    });
  }
  updateAnswerType2(index, key1, key2, userAns) {
    this.answerResults[index][key1].answrString = userAns;
    this.answerResults[index][key1].haveAnsw = true;
    this.answerResults[index][key1].chooseIndex = key2;
    if(this.answerResults[index][key1].chooseIndex == this.answerResults[index][key1].correctIndex) {
      this.answerResults[index][key1].isRight = true;
    }
  }
  updateAnswerType1(index, key,userAns) {
    this.answerResults[index].answrString = userAns;
    this.answerResults[index].haveAnsw = true;
    this.answerResults[index].chooseIndex = key;
    if(this.answerResults[index].chooseIndex == this.answerResults[index].correctIndex) {
      this.answerResults[index].isRight = true;
    }
    //this.answerResults[]
  }
  resetView(testDatas){
    this.props.grammarTestDatas = testDatas;
    this.setState({
      dataSource: this.state.dataSource.cloneWithRows(testDatas),
    });
  }
  componentDidMount(){
    this.setState({
      dataSource: this.state.dataSource.cloneWithRows(this.props.grammarTestDatas),
    });
  }
}

var marginBottomText = 3;
const style = StyleSheet.create({
  vocaExampleVN: {
    fontSize: 15,
    fontWeight: '300',
    color: 'black',
  },
  vocaExampleHira: {
    fontSize: 15,
    fontWeight: '300',
    color: '#ed5565',
  },
  vocaExampleKanji: {
    fontSize: 15,
    fontWeight: '300',
    color: '#ed5565',
  },
  vocaExample: {
    fontSize: 15,
    fontWeight: 'bold',
    fontStyle: 'italic',
    textDecorationLine: 'underline',
    color: 'black'
  },
  vocaMeanData: {
    color: 'blue',
    fontSize: 15,
    fontWeight: '300',
    marginBottom: marginBottomText,
  },
  vocaMeanText: {
    fontSize: 15,
    fontWeight: 'bold',
    fontStyle: 'italic',
    textDecorationLine: 'underline',
    color: 'black'
  },
  vocaContentTitle: {
    backgroundColor: 'white',
    paddingTop: 10,
    paddingBottom: 10,
    paddingLeft: 10,
    paddingRight: 10,
    borderRadius: 5,
    marginBottom: 7,
  },
  vocaTextTile: {
    fontSize: 17,
    fontWeight: 'bold',
    color: '#ed5565',
    marginBottom: marginBottomText,
  },
  vocabularyContainer: {
    flex: 1,
    backgroundColor: '#e3e4e8',
  },
  vocabularyContent: {
    flex: 1,
    marginTop: 7,
    marginLeft: 7,
    marginRight: 7,
  }
});
