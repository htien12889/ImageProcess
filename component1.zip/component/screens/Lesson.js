import React, {Component} from 'react';
import {
	View, Text, StyleSheet
} from 'react-native';
import FlashCardQuiz from './Lesson/flashcard/FlashCardQuiz.js';
import Header from './common/Header.js';
import BottomMenu from './common/BottomMenu.js';
import Grammar from './Lesson/Grammar.js';
import Vocabulary from './Lesson/Vocabulary.js';
import Kanji from './Lesson/Kanji.js';
export default class Lesson extends Component<{}>{
	constructor(props) {
		super(props);
		this.lanThu = 0;
		if(this.props.level == 0) {
			this.state = {
				level: this.props.level,
				titleName: 'Ngữ Pháp',
				type: 'grammar',
				isContent: 0,
			}
		} else {
			this.state = {
				level: this.props.level,
				titleName: 'Ngữ Pháp N' + this.props.level,
				type: 'grammar',
				isContent: 0,
			}
		}

	}

  render() {
    return (
      <View style={style.lesson}>
				<Header title={this.state.titleName} backClick={() => {this.backClick()}} menuClick={() => this.props.menuClick()}/>
				{this.renderContentLesson()}
				<BottomMenu
					ref="buttomMenu"
					grammarClick={() => {this.grammarClick()}}
					vocabularyClick={() => {this.vocabularyClick()}}
					kanjiClick={() => {this.kanjiClick()}}
				/>
      </View>
    );
  }
	reRender(typeJLPT) {
		this.refs.buttomMenu.updateBottomMenu();
		this.lanThu += 1;
		if(typeJLPT == 0) {
			this.setState({
				level: typeJLPT,
				type: 'grammar',
				titleName: 'Ngữ Pháp',
				isContent: 0,
			});
		} else {
			this.setState({
				level: typeJLPT,
				type: 'grammar',
				titleName: 'Ngữ Pháp N' + typeJLPT,
				isContent: 0,
			});
		}

	}
	renderContentLesson() {
		/*return(
			<FlashCardQuiz ref="child"
				updateIsContent={() => {this.updateIsContent()}}
				level={this.state.level}
				lessonUpdateClick={(value) => this.lessonUpdateClick(value)}/>
		);*/
		if(this.state.type == 'grammar') {
			return(
				<Grammar ref="child"
					lanThu={this.lanThu}
					updateIsContent={() => {this.updateIsContent()}}
					level={this.state.level}
					lessonUpdateClick={(value) => this.lessonUpdateClick(value)}/>
			);
		} else if (this.state.type == 'vocabulary') {
			return(
				<Vocabulary ref="child"
					updateIsContent={() => {this.updateIsContent()}}
					level={this.state.level}
					lessonUpdateClick={(value) => this.lessonUpdateClick(value)}/>
			);
		} else if (this.state.type == 'kanji') {
			return(
				<Kanji ref="child"
					updateIsContent={() => {this.updateIsContent()}}
					level={this.state.level}
					lessonUpdateClick={(value) => this.lessonUpdateClick(value)}/>
			);
		}
	}
	grammarClick() {
		this.props.updateClick(0.5);
		if(this.state.level == 0) {
			this.setState({
				titleName: 'Ngữ Pháp',
				type: 'grammar',
				isContent: 0,
			})
		} else {
			this.setState({
				titleName: 'Ngữ Pháp N' + this.state.level,
				type: 'grammar',
				isContent: 0,
			})
		}

	}
	vocabularyClick() {
		this.props.updateClick(0.5);
		if(this.state.level == 0) {
			this.setState({
				titleName: 'Từ Vựng',
				type: 'vocabulary',
				isContent: 0,
			})
		} else {
			this.setState({
				titleName: 'Từ Vựng N' + this.state.level,
				type: 'vocabulary',
				isContent: 0,
			})
		}
	}
	kanjiClick() {
		this.props.updateClick(0.5);
		if(this.state.level == 0) {
			this.setState({
				titleName: 'Kanji',
				type: 'kanji',
				isContent: 0,
			})
		} else {
			this.setState({
				titleName: 'Kanji N' + this.state.level,
				type: 'kanji',
				isContent: 0,
			})
		}

	}
	updateIsContent() {
		this.setState({
			isContent: 1,
		});
	}
	lessonUpdateClick(value){
		this.props.updateClick(value);
	}
	backClick(){
		this.props.updateClick(2);
		if(this.state.isContent == 1 || this.state.isContent == 2) {
			this.refs.child.backProcess();
			this.setState({
				isContent: 0,
			})
		} else {
			this.props.backToHome();
		}
	}
}

const style = StyleSheet.create({
	lesson: {
		flex: 1,
		backgroundColor: '#e3e4e8',
	}
});
