import React, {Component} from 'react';
import {
  AdMobBanner,
  AdMobInterstitial,
  PublisherBanner,
} from 'react-native-admob';
import {
	View, Text, ImageBackground, StyleSheet, TouchableOpacity, Image, Alert, BackAndroid, Linking
} from 'react-native';

export default class Home extends Component<{}> {

	constructor(props){
		super(props);
		AdMobInterstitial.setAdUnitID('ca-app-pub-6155592624901589/2447012592');
		//AdMobInterstitial.setAdUnitID('ca-app-pub-3940256099942544/1033173712');
		AdMobInterstitial.setTestDevices([AdMobInterstitial.simulatorId]);
		AdMobInterstitial.requestAd().then(() => {isResquested = true; console.log(isResquested);});
		this.state = {
			buttonClick: 1,
			lessonOrTest: 'Hãy Chọn Cấp Độ Để Học',
			lessonOrTestParameter: 'Lesson'
		}
	}

	render() {
		return (
			<View style={style.homeContainer}>
				<ImageBackground style={style.homeCtn1} source={require('../assets/main_bground.jpg')}>
					<ImageBackground style={style.homeHeader} source={require('../assets/nen_title.png')}>
						<Text style={style.homeHeaderText}>JLPT Toàn Thư</Text>
					</ImageBackground>
					<View style={style.homeCtn1Header}>

					</View>
					{this.ButtonLessonSelect()}
					<View style={style.homeCtn1Header}>
						<Text style={{fontSize: 20, textAlign: 'center', color: 'white', fontWeight: 'bold'}}>{this.state.lessonOrTest}</Text>
					</View>
				</ImageBackground>
				<View style={style.homeCtn2}>
					<TouchableOpacity style={style.homeJLPTButtons}
						onPress={()=>{this.props.navigation.navigate('MainScreens', {lessonOrTest: this.state.lessonOrTestParameter, jlpt_level: 5})}}>
						<View style={style.homeJLPTIcon}>
							<Image style={style.homeJLPTIconImage} source={require('../assets/N5Button.png')}></Image>
						</View>
						<View style={style.homeJLPTText}>
							<Text style={style.homeJLPTTextContent}>JLPT N5</Text>
						</View>
					</TouchableOpacity>

					<TouchableOpacity style={style.homeJLPTButtons}
						onPress={()=>{this.props.navigation.navigate('MainScreens', {lessonOrTest: this.state.lessonOrTestParameter, jlpt_level: 4})}}>
						<View style={style.homeJLPTIcon}>
							<Image style={style.homeJLPTIconImage} source={require('../assets/N4Button.png')}></Image>
						</View>
						<View style={style.homeJLPTText}>
							<Text style={style.homeJLPTTextContent}>JLPT N4</Text>
						</View>
					</TouchableOpacity>

					<TouchableOpacity style={style.homeJLPTButtons}
						onPress={()=>{this.props.navigation.navigate('MainScreens', {lessonOrTest: this.state.lessonOrTestParameter, jlpt_level: 3})}}>
						<View style={style.homeJLPTIcon}>
							<Image style={style.homeJLPTIconImage} source={require('../assets/N3Button.png')}></Image>
						</View>
						<View style={style.homeJLPTText}>
							<Text style={style.homeJLPTTextContent}>JLPT N3</Text>
						</View>
					</TouchableOpacity>

					<TouchableOpacity style={style.homeJLPTButtons}
						onPress={()=>{this.props.navigation.navigate('MainScreens', {lessonOrTest: this.state.lessonOrTestParameter, jlpt_level: 2})}}>
						<View style={style.homeJLPTIcon}>
							<Image style={style.homeJLPTIconImage} source={require('../assets/N2Button.png')}></Image>
						</View>
						<View style={style.homeJLPTText}>
							<Text style={style.homeJLPTTextContent}>JLPT N2</Text>
						</View>
					</TouchableOpacity>

					<TouchableOpacity style={style.homeJLPTButtons}
						onPress={()=>{this.props.navigation.navigate('MainScreens', {lessonOrTest: this.state.lessonOrTestParameter, jlpt_level: 1})}}>
						<View style={style.homeJLPTIcon}>
							<Image style={style.homeJLPTIconImage} source={require('../assets/N1Button.png')}></Image>
						</View>
						<View style={style.homeJLPTText}>
							<Text style={style.homeJLPTTextContent}>JLPT N1</Text>
						</View>
					</TouchableOpacity>

					<TouchableOpacity style={style.homeJLPTButtons}
						onPress={() => {this.rateThisApp()}}>
						<View style={style.homeJLPTIcon}>
							<Image style={style.homeJLPTIconImage} source={require('../assets/review.png')}></Image>
						</View>
						<View style={style.homeJLPTText}>
							<Text style={style.homeJLPTTextContent}>Đánh giá ứng dụng</Text>
						</View>
					</TouchableOpacity>

					<TouchableOpacity style={style.homeJLPTButtons}
						onPress={() => {this.exitApp()}}>
						<View style={style.homeJLPTIcon}>
							<Image style={style.homeJLPTIconImage} source={require('../assets/exit_.jpg')}></Image>
						</View>
						<View style={style.homeJLPTText}>
							<Text style={style.homeJLPTTextContent}>Thoát ứng dụng</Text>
						</View>
					</TouchableOpacity>

				</View>
			</View>
		);
	}
	rateThisApp() {
		Linking.openURL('https://play.google.com/store/apps/details?id=tienjoneey.com.jlpt');
	}
	exitApp(){
		Alert.alert(
			'Thông Báo',
			'Bạn muốn thoát khỏi ứng dụng?',
			[
				{text: 'OK', onPress: () => BackAndroid.exitApp()},
			]
		);
	}
	ButtonLessonSelect() {
		var selectedColor = '#4fc1e9';
		if(this.state.buttonClick == 0) {
			return (
				<View style={style.homeCtn1Buttons}>
					<TouchableOpacity style={{flex: 1, borderBottomWidth: 2, borderColor: '#e3e4e8'}}
						onPress={()=>{this.button1Onclick()}}>
						<View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
							<Image style={{width: 25, height: 25}} source={require('../assets/Popular-05-512.png')} />
						</View>
						<View style={{flex: 1, justifyContent: 'center'}}>
							<Text style={{fontSize: 15, textAlign: 'center', color: '#3bafda', fontWeight: 'bold'}}>Các Bài Học</Text>
						</View>
					</TouchableOpacity>

					<TouchableOpacity style={{flex: 1, backgroundColor: selectedColor}} onPress={()=>{this.button2Onclick()}}>
						<View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
							<Image style={{width: 25, height: 25}} source={require('../assets/list-512.png')} />
						</View>
						<View style={{flex: 1, justifyContent: 'center'}}>
							<Text style={{fontSize: 15, textAlign: 'center', color: '#ffffff', fontWeight: 'bold'}}>JLPT Test</Text>
						</View>
					</TouchableOpacity>

          <TouchableOpacity style={{flex: 1, borderTopWidth: 2, borderColor: '#e3e4e8'}} onPress={()=>{this.button3Onclick()}}>
						<View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
							<Image style={{width: 25, height: 25}} source={require('../assets/checked_icon.png')} />
						</View>
						<View style={{flex: 1, justifyContent: 'center'}}>
							<Text style={{fontSize: 15, textAlign: 'center', color: '#3bafda', fontWeight: 'bold'}}>Đã Đánh Dấu</Text>
						</View>
					</TouchableOpacity>
				</View>
			);
		} else if(this.state.buttonClick == 1) {
			return (
				<View style={style.homeCtn1Buttons}>
					<TouchableOpacity style={{flex: 1, borderBottomWidth: 2, borderColor: '#e3e4e8', backgroundColor: selectedColor}} onPress={()=>{this.button1Onclick()}}>
						<View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
							<Image style={{width: 25, height: 25}} source={require('../assets/Popular-05-512.png')} />
						</View>
						<View style={{flex: 1, justifyContent: 'center'}}>
							<Text style={{fontSize: 15, textAlign: 'center', color: '#ffffff', fontWeight: 'bold'}}>Các Bài Học</Text>
						</View>
					</TouchableOpacity>

					<TouchableOpacity style={{flex: 1}} onPress={()=>{this.button2Onclick()}}>
						<View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
							<Image style={{width: 25, height: 25}} source={require('../assets/list-512.png')} />
						</View>
						<View style={{flex: 1, justifyContent: 'center'}}>
							<Text style={{fontSize: 15, textAlign: 'center', color: '#3bafda', fontWeight: 'bold'}}>JLPT Test</Text>
						</View>
					</TouchableOpacity>

          <TouchableOpacity style={{flex: 1, borderTopWidth: 2, borderColor: '#e3e4e8'}} onPress={()=>{this.button3Onclick()}}>
						<View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
							<Image style={{width: 25, height: 25}} source={require('../assets/checked_icon.png')} />
						</View>
						<View style={{flex: 1, justifyContent: 'center'}}>
							<Text style={{fontSize: 15, textAlign: 'center', color: '#3bafda', fontWeight: 'bold'}}>Đã Đánh Dấu</Text>
						</View>
					</TouchableOpacity>
				</View>
			);
		} else {
      <View style={style.homeCtn1Buttons}>
        <TouchableOpacity style={{flex: 1, borderBottomWidth: 2, borderColor: '#e3e4e8'}} onPress={()=>{this.button1Onclick()}}>
          <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
            <Image style={{width: 25, height: 25}} source={require('../assets/Popular-05-512.png')} />
          </View>
          <View style={{flex: 1, justifyContent: 'center'}}>
            <Text style={{fontSize: 15, textAlign: 'center', color: '#3bafda', fontWeight: 'bold'}}>Các Bài Học</Text>
          </View>
        </TouchableOpacity>

        <TouchableOpacity style={{flex: 1}} onPress={()=>{this.button2Onclick()}}>
          <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
            <Image style={{width: 25, height: 25}} source={require('../assets/list-512.png')} />
          </View>
          <View style={{flex: 1, justifyContent: 'center'}}>
            <Text style={{fontSize: 15, textAlign: 'center', color: '#3bafda', fontWeight: 'bold'}}>JLPT Test</Text>
          </View>
        </TouchableOpacity>

        <TouchableOpacity style={{flex: 1, borderTopWidth: 2, borderColor: '#e3e4e8', backgroundColor: selectedColor}} onPress={()=>{this.button3Onclick()}}>
          <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
            <Image style={{width: 25, height: 25}} source={require('../assets/checked_icon.png')} />
          </View>
          <View style={{flex: 1, justifyContent: 'center'}}>
            <Text style={{fontSize: 15, textAlign: 'center', color: '#ffffff', fontWeight: 'bold'}}>Đã Đánh Dấu</Text>
          </View>
        </TouchableOpacity>
      </View>
    }
	}
	button1Onclick(){
		this.setState({
      buttonClick: 1,
			lessonOrTest: 'Hãy Chọn Cấp Độ Để Học',
			lessonOrTestParameter: 'Lesson'
    });

	}
	button2Onclick(){
		this.setState({
      buttonClick: 0,
			lessonOrTest: 'Hãy Chọn Cấp Độ Để Làm Bài Kiểm Tra',
			lessonOrTestParameter: 'Test'
    });
	}
  button3Onclick(){
    //this.props.navigation.navigate('MainScreens', {lessonOrTest: this.state.lessonOrTestParameter, jlpt_level: 1})
		this.props.navigation.navigate('MainScreens', {lessonOrTest: "Marker", jlpt_level: 0});
	}
}



var homeHeaderHeight = 50;
var homeHeaderTextSize = 20;
const style = StyleSheet.create({

	homeJLPTIconImage: {
		width: 30,
		height: 30,
	},
	homeJLPTIcon: {
		flex: 1,
		alignItems: 'center',
		justifyContent: 'center',
	},
	homeJLPTText: {
		justifyContent: 'center',
		flex: 5,
	},
	homeJLPTTextContent: {
		fontSize: 15,
		fontWeight: '300',
		textAlign: 'left',
		color: 'white'
	},

	textCenter: {
		textAlign: 'center',
	},
	homeContainer: {
		flex: 1,
		backgroundColor: '#ffffff'
	},
	homeCtn1: {
		flex: 1,
	},
	homeHeaderText: {
		textAlign: 'center',
		fontSize: homeHeaderTextSize,
		color: '#4fc1e9',
	},
	homeHeader: {
		justifyContent: 'center',
		opacity: 0.8,
		height: homeHeaderHeight,
	},
	homeCtn2: {
		flex: 1,
		backgroundColor: 'white'
	},
	homeCtn1Header: {
		flex: 1,
		justifyContent: 'center',
	},
	homeCtn1Buttons: {
		flex: 4.5,
		backgroundColor: '#f0f2f5',
		marginLeft: 20,
		marginRight: 20,
		borderRadius: 5,
	},
	homeJLPTButtons: {
		flex: 1,
		flexDirection: 'row',
		//backgroundColor: '#f0f2f5',
    backgroundColor: '#4fc1e9',
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderBottomColor: '#2ea5dd',
    borderTopColor: '#75d2f0',
		justifyContent: 'center'
	},
});
