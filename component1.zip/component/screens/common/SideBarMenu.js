import React, {Component} from 'react';
import {View, Text, Image, StyleSheet, TouchableOpacity} from 'react-native';
export default class SideBarMenu extends Component<{}> {
  render(){
    return(
      <View style={style.sideBarContainer}>
        <View style={style.headMenu}>
          <Text style={{color: 'white', fontSize: 17, fontWeight: 'bold'}}>JLPT LESSONS</Text>
        </View>
        <View style={style.headMenuButton}>
          <View style={{height: 2, backgroundColor: "#23242d"}}></View>
          <View style={{height: 2, backgroundColor: "#454753"}}></View>
          <TouchableOpacity style={style.headMenuButtonText} onPress={() => {this.props.menuChoose('Lesson', 5)}}>
            <Image style={style.homeJLPTIconImage} source={require('../../assets/N5Button.png')}></Image>
            <Text style={{color: 'white', fontSize: 17, fontWeight: '300'}}>JLPT N5</Text>
          </TouchableOpacity>
        </View>
        <View style={style.headMenuButton}>
          <View style={{height: 2, backgroundColor: "#23242d"}}></View>
          <View style={{height: 2, backgroundColor: "#454753"}}></View>
          <TouchableOpacity style={style.headMenuButtonText} onPress={() => {this.props.menuChoose('Lesson', 4)}}>
            <Image style={style.homeJLPTIconImage} source={require('../../assets/N4Button.png')}></Image>
            <Text style={{color: 'white', fontSize: 17, fontWeight: '300'}}>JLPT N4</Text>
          </TouchableOpacity>
        </View>
        <View style={style.headMenuButton}>
          <View style={{height: 2, backgroundColor: "#23242d"}}></View>
          <View style={{height: 2, backgroundColor: "#454753"}}></View>
          <TouchableOpacity style={style.headMenuButtonText} onPress={() => {this.props.menuChoose('Lesson', 3)}}>
            <Image style={style.homeJLPTIconImage} source={require('../../assets/N3Button.png')}></Image>
            <Text style={{color: 'white', fontSize: 17, fontWeight: '300'}}>JLPT N3</Text>
          </TouchableOpacity>
        </View>
        <View style={style.headMenuButton}>
          <View style={{height: 2, backgroundColor: "#23242d"}}></View>
          <View style={{height: 2, backgroundColor: "#454753"}}></View>
          <TouchableOpacity style={style.headMenuButtonText} onPress={() => {this.props.menuChoose('Lesson', 2)}}>
            <Image style={style.homeJLPTIconImage} source={require('../../assets/N2Button.png')}></Image>
            <Text style={{color: 'white', fontSize: 17, fontWeight: '300'}}>JLPT N2</Text>
          </TouchableOpacity>
        </View>
        <View style={style.headMenuButton}>
          <View style={{height: 2, backgroundColor: "#23242d"}}></View>
          <View style={{height: 2, backgroundColor: "#454753"}}></View>
          <TouchableOpacity style={style.headMenuButtonText} onPress={() => {this.props.menuChoose('Lesson', 1)}}>
            <Image style={style.homeJLPTIconImage} source={require('../../assets/N1Button.png')}></Image>
            <Text style={{color: 'white', fontSize: 17, fontWeight: '300'}}>JLPT N1</Text>
          </TouchableOpacity>
        </View>

        <View style={style.headMenu}>
          <Text style={{color: 'white', fontSize: 17, fontWeight: 'bold'}}>JLPT Test</Text>
        </View>
        <View style={style.headMenuButton}>
          <View style={{height: 2, backgroundColor: "#23242d"}}></View>
          <View style={{height: 2, backgroundColor: "#454753"}}></View>
          <TouchableOpacity style={style.headMenuButtonText} onPress={() => {this.props.menuChoose('Test', 5)}}>
            <Image style={style.homeJLPTIconImage} source={require('../../assets/N5Button.png')}></Image>
            <Text style={{color: 'white', fontSize: 17, fontWeight: '300'}}>JLPT N5</Text>
          </TouchableOpacity>
        </View>
        <View style={style.headMenuButton}>
          <View style={{height: 2, backgroundColor: "#23242d"}}></View>
          <View style={{height: 2, backgroundColor: "#454753"}}></View>
          <TouchableOpacity style={style.headMenuButtonText} onPress={() => {this.props.menuChoose('Test', 4)}}>
            <Image style={style.homeJLPTIconImage} source={require('../../assets/N4Button.png')}></Image>
            <Text style={{color: 'white', fontSize: 17, fontWeight: '300'}}>JLPT N4</Text>
          </TouchableOpacity>
        </View>
        <View style={style.headMenuButton}>
          <View style={{height: 2, backgroundColor: "#23242d"}}></View>
          <View style={{height: 2, backgroundColor: "#454753"}}></View>
          <TouchableOpacity style={style.headMenuButtonText} onPress={() => {this.props.menuChoose('Test', 3)}}>
            <Image style={style.homeJLPTIconImage} source={require('../../assets/N3Button.png')}></Image>
            <Text style={{color: 'white', fontSize: 17, fontWeight: '300'}}>JLPT N3</Text>
          </TouchableOpacity>
        </View>
        <View style={style.headMenuButton}>
          <View style={{height: 2, backgroundColor: "#23242d"}}></View>
          <View style={{height: 2, backgroundColor: "#454753"}}></View>
          <TouchableOpacity style={style.headMenuButtonText} onPress={() => {this.props.menuChoose('Test', 2)}}>
            <Image style={style.homeJLPTIconImage} source={require('../../assets/N2Button.png')}></Image>
            <Text style={{color: 'white', fontSize: 17, fontWeight: '300'}}>JLPT N2</Text>
          </TouchableOpacity>
        </View>
        <View style={style.headMenuButton}>
          <View style={{height: 2, backgroundColor: "#23242d"}}></View>
          <View style={{height: 2, backgroundColor: "#454753"}}></View>
          <TouchableOpacity style={style.headMenuButtonText} onPress={() => {this.props.menuChoose('Test', 1)}}>
            <Image style={style.homeJLPTIconImage} source={require('../../assets/N1Button.png')}></Image>
            <Text style={{color: 'white', fontSize: 17, fontWeight: '300'}}>JLPT N1</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

}
let imageSize = 25;
const style=StyleSheet.create({
  homeJLPTIconImage: {
    width: imageSize,
    height: imageSize,
    marginRight: 5
  },
  headMenuButtonText: {
    padding: 7,
    flexDirection: 'row',
  },
  Header: {
		backgroundColor: "#37383b",
	},
  headMenu: {
    backgroundColor: "#444755",
    padding: 7,
  },
  headMenuButton: {
    backgroundColor: "#313340",
  }
});
