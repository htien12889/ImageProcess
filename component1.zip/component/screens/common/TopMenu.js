import React, {Component} from 'react';
import {View, StyleSheet, Text, TouchableOpacity} from 'react-native';

export default class TopMenu extends Component<{}> {
  constructor(props) {
    super(props);
    console.log("hello8");
    this.state = {
      buttonClick: 0,
    }
  }
  render(){
    return(
      this.renderTopMenu()
    );
  }
  renderTopMenu(){
    console.log(this.state.buttonClick);
    if(this.state.buttonClick == 0) {
      return(
        <View style={style.topMenuContainer}>
          <TouchableOpacity style={style.homeButtonActive} onPress={() => {this.button1Click()}}>
            <Text style={style.textActive}>{this.props.nameButton}</Text>
          </TouchableOpacity>

          <TouchableOpacity style={style.homeButton} onPress={() => {this.button2Click()}}>
            <Text style={style.text}>FlashCard</Text>
          </TouchableOpacity>

          <TouchableOpacity style={style.homeButton} onPress={() => {this.button3Click()}}>
            <Text style={style.text}>Luyện Tập</Text>
          </TouchableOpacity>
        </View>
      );
    } else if (this.state.buttonClick == 1) {
      return(
        <View style={style.topMenuContainer}>
          <TouchableOpacity style={style.homeButton} onPress={() => {this.button1Click()}}>
            <Text style={style.text}>{this.props.nameButton}</Text>
          </TouchableOpacity>

          <TouchableOpacity style={style.homeButtonActive} onPress={() => {this.button2Click()}}>
            <Text style={style.textActive}>FlashCard</Text>
          </TouchableOpacity>

          <TouchableOpacity style={style.homeButton} onPress={() => {this.button3Click()}}>
            <Text style={style.text}>Luyện Tập</Text>
          </TouchableOpacity>
        </View>
      );
    } else {
      return(
        <View style={style.topMenuContainer}>
          <TouchableOpacity style={style.homeButton} onPress={() => {this.button1Click()}}>
            <Text style={style.text}>{this.props.nameButton}</Text>
          </TouchableOpacity>

          <TouchableOpacity style={style.homeButton} onPress={() => {this.button2Click()}}>
            <Text style={style.text}>FlashCard</Text>
          </TouchableOpacity>

          <TouchableOpacity style={style.homeButtonActive} onPress={() => {this.button3Click()}}>
            <Text style={style.textActive}>Luyện Tập</Text>
          </TouchableOpacity>
        </View>
      );
    }
  }
  button1Click(){
    console.log("hello1");
    this.setState({
      buttonClick: 0
    })
    this.props.contentClick();
  }
  button2Click(){
    console.log("hello2");
    this.setState({
      buttonClick: 1
    })
    this.props.flashCardClick();
  }
  button3Click(){
    console.log("hello3");
    this.setState({
      buttonClick: 2
    })
    this.props.quizClick();
  }
}

const style = StyleSheet.create({
  topMenuContainer: {
    backgroundColor: 'white',
    flexDirection: 'row',
    height: 50,
    alignItems: 'center',
  },
  textActive: {
    fontSize: 15,
    fontWeight: '300',
    textAlign: 'center',
    color: 'white'
  },
  text: {
    fontSize: 15,
    fontWeight: '300',
    textAlign: 'center',
    color: '#989fa9'
  },
  homeButtonActive: {
    borderRadius: 3,
    height: 35,
    padding: 5,
    justifyContent: 'center',
    marginLeft: 10,
    backgroundColor: '#3bafda'
  },
  homeButton: {
    borderRadius: 3,
    height: 35,
    padding: 5,
    justifyContent: 'center',
    marginLeft: 10,
    backgroundColor: '#e1e4e9'
  }
});
