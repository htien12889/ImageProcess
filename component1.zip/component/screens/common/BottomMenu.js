import React, {Component} from 'react';
import {
	View, Text, TouchableOpacity, StyleSheet
} from 'react-native';

export default class Header extends Component<{}>{
  constructor(props) {
    super(props);
    this.state = {
      buttonClick: 0,
    };
  }
  render() {
    if(this.state.buttonClick == 0) {
      return(
        <View style={style.MenuBottom}>
          <TouchableOpacity style={{flex: 1,backgroundColor: '#3bafda', justifyContent: 'center'}}
            onPress={() => {this.grammarClick()}}>
            <Text style={style.menuText}>Ngữ Pháp</Text>
          </TouchableOpacity>
          <TouchableOpacity style={{flex: 1,backgroundColor: '#4fc1e9', borderLeftWidth: 1, borderRightWidth: 1, borderColor: '#3bafda', justifyContent: 'center'}}
            onPress={() => {this.vocabularyClick()}}>
            <Text style={style.menuText}>Từ Vựng</Text>
          </TouchableOpacity>
          <TouchableOpacity style={{flex: 1,backgroundColor: '#4fc1e9', justifyContent: 'center'}}
            onPress={() => {this.kanjiClick()}}>
            <Text style={style.menuText}>Kanji</Text>
          </TouchableOpacity>
        </View>
      );
    } else if (this.state.buttonClick == 1) {
      return(
        <View style={style.MenuBottom}>
          <TouchableOpacity style={{flex: 1,backgroundColor: '#4fc1e9', justifyContent: 'center'}}
            onPress={() => {this.grammarClick()}}>
            <Text style={style.menuText}>Ngữ Pháp</Text>
          </TouchableOpacity>
          <TouchableOpacity style={{flex: 1,backgroundColor: '#3bafda', borderLeftWidth: 1, borderRightWidth: 1, borderColor: '#3bafda', justifyContent: 'center'}}
            onPress={() => {this.vocabularyClick()}}>
            <Text style={style.menuText}>Từ Vựng</Text>
          </TouchableOpacity>
          <TouchableOpacity style={{flex: 1,backgroundColor: '#4fc1e9', justifyContent: 'center'}}
            onPress={() => {this.kanjiClick()}}>
            <Text style={style.menuText}>Kanji</Text>
          </TouchableOpacity>
        </View>
      );
    } else {
      return(
        <View style={style.MenuBottom}>
          <TouchableOpacity style={{flex: 1,backgroundColor: '#4fc1e9', justifyContent: 'center'}}
            onPress={() => {this.grammarClick()}}>
            <Text style={style.menuText}>Ngữ Pháp</Text>
          </TouchableOpacity>
          <TouchableOpacity style={{flex: 1,backgroundColor: '#4fc1e9', borderLeftWidth: 1, borderRightWidth: 1, borderColor: '#3bafda', justifyContent: 'center'}}
            onPress={() => {this.vocabularyClick()}}>
            <Text style={style.menuText}>Từ Vựng</Text>
          </TouchableOpacity>
          <TouchableOpacity style={{flex: 1,backgroundColor: '#3bafda', justifyContent: 'center'}}
            onPress={() => {this.kanjiClick()}}>
            <Text style={style.menuText}>Kanji</Text>
          </TouchableOpacity>
        </View>
      );
    }

  }
	updateBottomMenu(){
		this.setState({
      buttonClick: 0,
    });
	}
  grammarClick() {
    this.setState({
      buttonClick: 0,
    });
    this.props.grammarClick();
  }
  vocabularyClick() {
    this.setState({
      buttonClick: 1,
    });
    this.props.vocabularyClick();
  }
  kanjiClick() {
    this.setState({
      buttonClick: 2,
    });
    this.props.kanjiClick();
  }
}

const style=StyleSheet.create({
  MenuBottom: {
    flexDirection: 'row',
		height: 50,
		backgroundColor: '#3bafda',
    justifyContent: 'center',
		borderTopWidth: 3,
		borderTopColor: '#6fd0ef',
	},
  menuText: {
    textAlign: 'center',
    color: 'white',
    fontWeight: '300',
    fontSize: 17
  }
});
