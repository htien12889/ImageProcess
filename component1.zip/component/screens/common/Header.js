import React, {Component} from 'react';
import {
	View, Text, TouchableOpacity, StyleSheet, Image
} from 'react-native';

export default class Header extends Component<{}>{
  render() {
    return(
      <View style={style.Header}>
        <TouchableOpacity style={{width: 65, justifyContent: 'center', marginLeft: 10}} onPress={() => {this.props.backClick()}}>
          <Image style={style.homeBackJLPTIconImage} source={require('../../assets/back.png')}></Image>
        </TouchableOpacity>

        <View style={{flex: 1, justifyContent: 'center'}}>
          <Text style={{textAlign: 'center', fontWeight: '300', fontSize: 17, color: 'white'}}>{this.props.title}</Text>
        </View>

        <TouchableOpacity style={{width: 50, justifyContent: 'center'}} onPress={() => {this.props.menuClick()}}>
					<Image style={style.homeJLPTIconImage} source={require('../../assets/menuButton.png')}></Image>
        </TouchableOpacity>
      </View>
    );
  }
}

const style=StyleSheet.create({
	homeBackJLPTIconImage: {
		height: 30,
		width: 65,
	},
	homeJLPTIconImage: {
		height: 30,
		width: 40,
	},
  Header: {
		flexDirection: 'row',
		justifyContent: 'center',
		height: 50,
		backgroundColor: '#3bafda',
	},
});
