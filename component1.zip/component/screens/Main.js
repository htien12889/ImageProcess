import React, {Component} from 'react';
import {View, Text} from 'react-native';
import Lesson from './Lesson.js';
import Test from './Test.js';
import ViewChoose from './ViewChoose.js';
import Drawer from 'react-native-drawer';
import SideBarMenu from './common/SideBarMenu.js';
import {
  AdMobBanner,
  AdMobInterstitial,
  PublisherBanner,
} from 'react-native-admob';
var numberClick = 8;
var isResquested = false;
export default class Main extends Component<{}> {
  constructor(props) {
    super(props);
    this.state = {
      type: this.props.navigation.state.params.lessonOrTest,
      level: this.props.navigation.state.params.jlpt_level,
    }
  }
  render(){
    return(
        this.renderByParameter()
    );
  }
  renderByParameter() {
    if(this.state.type == 'Lesson'){
      return (
        <Drawer
          openDrawerOffset={0.5}
          tapToClose={true}
          ref={(ref) => this._drawer = ref}
          content={<SideBarMenu menuChoose={(typeJLPT, jlpt_level) => this.chooseMenu(typeJLPT, jlpt_level)}/>}
          tweenHandler={(ratio) => ({
            main: { opacity:(2-ratio)/2 }
          })}>
            <Lesson
              ref="child"
              menuClick={() => {this.openControlPanel()}}
              level={this.state.level}
              backToHome={()=>{this.props.navigation.navigate('HomeScreens')}}
              updateClick={(value)=>{this.updateNumberClick(value)}}/>
        </Drawer>
      );
    } else if(this.state.type == 'Test') {
      return (
        <Drawer
          openDrawerOffset={0.5}
          tapToClose={true}
          ref={(ref) => this._drawer = ref}
          content={<SideBarMenu menuChoose={(typeJLPT, jlpt_level) => this.chooseMenu(typeJLPT, jlpt_level)}/>}
          tweenHandler={(ratio) => ({
            main: { opacity:(2-ratio)/2 }
          })}>
          <Test
            ref="child"
            menuClick={() => {this.openControlPanel()}}
            level={this.state.level}
            backToHome={()=>{this.props.navigation.navigate('HomeScreens')}}
            lessonUpdateClickNoAds={(value) => {numberClick += value;}}
            updateClick={(value)=>{this.updateNumberClick(value)}}/>
        </Drawer>
      );
    } else {
      return(
        <ViewChoose
          lession={() => {this.lession()}}
          test={() => {this.test()}}
          />
      );
    }
  }
  lession(){
    this.setState({
      type: "Lesson",
    });
  }
  test(){
    this.setState({
      type: "Test",
    });
  }
  chooseMenu(typeJLPT, jlpt_level){
    this.refs.child.reRender(jlpt_level);
    this.setState({
      type: typeJLPT,
      level: jlpt_level,
    });
  }
  closeControlPanel = () => {
    this._drawer.close()
  };
  openControlPanel = () => {
    this._drawer.open()
  };
  updateNumberClick(value){
    numberClick += value;
    if(numberClick >= 10) {
      AdMobInterstitial.setAdUnitID('ca-app-pub-6155592624901589/2447012592');
      //AdMobInterstitial.setAdUnitID('ca-app-pub-3940256099942544/1033173712');
      AdMobInterstitial.setTestDevices([AdMobInterstitial.simulatorId]);
      AdMobInterstitial.requestAd();
      AdMobInterstitial.showAd().then(() => {isResquested = true; console.log(isResquested);})
      if(isResquested) {
        numberClick = numberClick - 10;
        isResquested = false;
      }
    } else {

    }
  }
}
