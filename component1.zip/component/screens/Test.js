import React, {Component} from 'react';
import {
	View, Text, StyleSheet, Animated, Dimensions, StatusBar, Alert
} from 'react-native';
var SQLite = require('react-native-sqlite-storage');
var db = SQLite.openDatabase({name : "jlptDB_v2_new", createFromLocation : "~jlpt_v2_new.db"}, this.openCB,this.errorCB);
var db1 = SQLite.openDatabase({name : "jlptDB_folder", createFromLocation : "~folder.db"}, this.openCB,this.errorCB);
import DanhMuc from './Lesson/danhMuc/DanhMuc.js';
import Header from './common/Header.js';
import TopMenuJLPT from './common/TopMenuJLPT.js';
import Grammar from './Test/Grammar.js';
import Vocabulary from './Test/Vocabulary.js';
import Kanji from './Test/Kanji.js';
import Reading from './Test/Reading.js';
import DMTest from './Test/DMTest.js';
var {height, width} = Dimensions.get('window');
var heightOfView = height - 100 - StatusBar.currentHeight;
var heightOfAddDanhMuc = heightOfView;
export default class Test extends Component<{}>{
	constructor(props) {
		super(props);
		this.jlptTestId = 0;
		this.lanThu = 0;
		let firstRenderType = "";
		let titleName = '';
		if(this.props.level == 0) {
			firstRenderType = 'DMTest';
			titleName = 'JLPT Test';
		} else {
			firstRenderType = 'grammar';
			titleName = 'JLPT Test Grammar N' + this.props.level;
		}


		this.state = {
			level: this.props.level,
			titleName: titleName,
			type: firstRenderType,
			isContent: 0,
			topAnimate: new Animated.Value(-heightOfView),
			renderOverlay: 0,
		}
	}

  render() {
		if(this.props.level == 0) {
			return (
	      <View style={style.lesson}>
					<Header title={this.state.titleName} backClick={() => {this.backClick()}} menuClick={() => this.props.menuClick()}/>
					{this.renderContentLesson()}
	      </View>
	    );
		} else {
			return (
	      <View style={style.lesson}>
					{this.renderOverlay()}
					<Animated.View style={{position: 'absolute', bottom: this.state.topAnimate, left: 7, height: heightOfAddDanhMuc, width: width - 14, zIndex: 999}}>
						<DanhMuc
							title="Danh mục JLPT Test"
							type="test"
							ref="danhMuc"
							addDanhMucAction={(value) => {this.addDanhMucAction(value)}}
							closeList={() => {this.closeList()}}/>
					</Animated.View>
					<Header title={this.state.titleName} backClick={() => {this.backClick()}} menuClick={() => this.props.menuClick()}/>
					<TopMenuJLPT
						ref="childTopMenu"
						grammarClick={() => {this.grammarClick()}}
						vocabularyClick={() => {this.vocabularyClick()}}
						kanjiClick={() => {this.kanjiClick()}}
						readingClick={() => {this.readingClick()}}
					/>
					{this.renderContentLesson()}
	      </View>
	    );
		}
  }
	reRender(typeJLPT) {
		this.refs.childTopMenu.updateTopMenuJLPT();
		this.lanThu += 1;
		this.setState({
			level: typeJLPT,
			type: 'grammar',
			titleName: 'JLPT Test Grammar N' + typeJLPT,
			isContent: 0,
		});
	}
	renderContentLesson() {
		if(this.state.type == 'grammar') {
			return(
				<Grammar ref="child"
					lanThu={this.lanThu}
					addTestType={(value) => {this.addTestType(value)}}
					updateIsContent={() => {this.updateIsContent()}}
					level={this.state.level}
					lessonUpdateClickNoAds={(value) => {this.props.lessonUpdateClickNoAds(value)}}
					lessonUpdateClick={(value) => this.lessonUpdateClick(value)}/>
			);
		} else if (this.state.type == 'vocabulary') {
			/*AdMobInterstitial.setAdUnitID('ca-app-pub-3940256099942544/1033173712');
			AdMobInterstitial.setTestDevices([AdMobInterstitial.simulatorId]);
			AdMobInterstitial.requestAd().then(() => AdMobInterstitial.showAd());*/
			return(
				<Vocabulary ref="child"
					updateIsContent={() => {this.updateIsContent()}}
					addTestType={(value) => {this.addTestType(value)}}
					level={this.state.level}
					lessonUpdateClickNoAds={(value) => {this.props.lessonUpdateClickNoAds(value)}}
					lessonUpdateClick={(value) => this.lessonUpdateClick(value)}/>
			);
		} else if (this.state.type == 'kanji') {
			return(
				<Kanji ref="child"
					updateIsContent={() => {this.updateIsContent()}}
					addTestType={(value) => {this.addTestType(value)}}
					level={this.state.level}
					lessonUpdateClickNoAds={(value) => {this.props.lessonUpdateClickNoAds(value)}}
					lessonUpdateClick={(value) => this.lessonUpdateClick(value)}/>
			);
		} else if (this.state.type == 'reading') {
			return(
				<Reading ref="child"
					updateIsContent={() => {this.updateIsContent()}}
					addTestType={(value) => {this.addTestType(value)}}
					level={this.state.level}
					lessonUpdateClickNoAds={(value) => {this.props.lessonUpdateClickNoAds(value)}}
					lessonUpdateClick={(value) => this.lessonUpdateClick(value)}/>
			);
		} else {
			return(
				<DMTest
					ref="child"
					updateIsContent={() => {this.updateIsContent()}}
					lessonUpdateClickNoAds={(value) => {this.props.lessonUpdateClickNoAds(value)}}
					lessonUpdateClick={(value) => this.lessonUpdateClick(value)}/>
			);
		}
	}
	renderOverlay(){
    if(this.state.renderOverlay == 1) {
      return(
        <View style={{backgroundColor: 'black', opacity: 0.5, width: width, height: height, position: 'absolute', top: 0, left: 0, zIndex: 99}}></View>
      );
    }
  }
	addDanhMucAction(value) {
    db1.transaction((tx) => {
      tx.executeSql("SELECT * FROM folder where type='test' and id='"+value.id+"'", [], (tx, results) => {
        let ids = results.rows.item(0).ids;
        if(ids) {
          let arrayIds = ids.split(',');
          let lengthIds = arrayIds.length;
          if(lengthIds == 0) {
            ids = ids + "," + this.jlptTestId;
          } else {
            let check = false;
            for(let i = 0; i < lengthIds; i++) {
              if(this.jlptTestId == arrayIds[i]) {
                check = true;
                break;
              }
            }
            if(check) {
              Alert.alert(
                'Thông Báo',
                '"'+value.name+'" đã tồn tại câu hỏi này',
                [
                  {text: 'OK', onPress: () => {console.log("ok")}},
                ]
              );
              return;
            } else {
              ids = ids + "," + this.jlptTestId;
            }
          }
        } else {
          ids = this.jlptTestId;
        }
        //console.log(ids);
        db1.transaction((tx) => {
          tx.executeSql("UPDATE folder SET ids='"+ids+"' WHERE id='"+value.id+"'", [], (tx, results) => {
            this.closeList();
          });
        });

      });
    });
  }
	closeList() {
    //console.log(value);
    this.setState({
      renderOverlay: 0,
    });
    Animated.timing(
      this.state.topAnimate,
      {
        toValue: -heightOfView,
        duration: 200,
      }
    ).start();
  }
	addTestType(value) {
		this.jlptTestId = value;
		this.refs.danhMuc.resetDanhMuc(value);
    //console.log(value);
    this.setState({
      renderOverlay: 1,
    });
    Animated.timing(
      this.state.topAnimate,
      {
        toValue: 0,
        duration: 200,
      }
    ).start();
	}
	grammarClick() {
		this.props.updateClick(0.5);
		this.setState({
			titleName: 'JLPT Test Grammar N' + this.state.level,
			type: 'grammar',
			isContent: 0,
		})
	}
	vocabularyClick() {
		this.props.updateClick(0.5);
		this.setState({
			titleName: 'JLPT Test Vocabulary N' + this.state.level,
			type: 'vocabulary',
			isContent: 0,
		})
	}
	kanjiClick() {
		this.props.updateClick(0.5);
		this.setState({
			titleName: 'JLPT Test Kanji N' + this.state.level,
			type: 'kanji',
			isContent: 0,
		})
	}
	readingClick() {
		this.props.updateClick(0.5);
		this.setState({
			titleName: 'JLPT Test Reading N' + this.state.level,
			type: 'reading',
			isContent: 0,
		})
	}
	updateIsContent() {
		this.setState({
			isContent: 1,
		});
	}
	lessonUpdateClick(value){
		this.props.updateClick(value);
	}
	backClick(){
		this.props.updateClick(2);
		if(this.state.isContent == 1) {
			this.refs.child.backProcess();
			this.setState({
				isContent: 0,
			})
		} else {
			this.props.backToHome();
		}
	}
}

const style = StyleSheet.create({
	lesson: {
		flex: 1,
		backgroundColor: '#e3e4e8',
	}
});
