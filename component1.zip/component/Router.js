import React from 'react';
import {StackNavigator} from 'react-navigation';
import Home from './screens/Home.js';
import Main from './screens/Main.js';
export const HomeStack = StackNavigator ({
  HomeScreens: {
    screen: Home,
    navigationOptions:{
      header: null
    }
  },
  MainScreens: {
    screen: Main,
    navigationOptions:{
      header: null
    }
  },
});
