<?php 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "jlpt";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
$conn->set_charset("utf8");
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo chr(0xEF).chr(0xBB).chr(0xBF);
header('Content-Type: text/html; charset=utf-8');
/*$utf32  = mb_convert_encoding( '安', 'UTF-32', "utf-8" );
$length = mb_strlen( $utf32, 'UTF-32' );
$result = [];
for( $i = 0; $i < $length; ++$i ){
	echo dechex(hexdec( bin2hex( mb_substr( $utf32, $i, 1, 'UTF-32' ))));
	$result[] = hexdec( bin2hex( mb_substr( $utf32, $i, 1, 'UTF-32' )));
}*/
$urls = array("http://localhost/mazzi/kanji/n5/0.json", "http://localhost/mazzi/kanji/n4/0.json", "http://localhost/mazzi/kanji/n4/1.json", "http://localhost/mazzi/kanji/n3/0.json", "http://localhost/mazzi/kanji/n3/1.json", "http://localhost/mazzi/kanji/n3/2.json", "http://localhost/mazzi/kanji/n3/3.json", "http://localhost/mazzi/kanji/n2/0.json", "http://localhost/mazzi/kanji/n2/1.json", "http://localhost/mazzi/kanji/n2/2.json", "http://localhost/mazzi/kanji/n2/3.json", "http://localhost/mazzi/kanji/n1/0.json", "http://localhost/mazzi/kanji/n1/1.json", "http://localhost/mazzi/kanji/n1/2.json", "http://localhost/mazzi/kanji/n1/3.json", "http://localhost/mazzi/kanji/n1/4.json", "http://localhost/mazzi/kanji/n1/5.json", "http://localhost/mazzi/kanji/n1/6.json", "http://localhost/mazzi/kanji/n1/7.json", "http://localhost/mazzi/kanji/n1/8.json", "http://localhost/mazzi/kanji/n1/9.json", "http://localhost/mazzi/kanji/n1/10.json", "http://localhost/mazzi/kanji/n1/11.json", "http://localhost/mazzi/kanji/n1/12.json");
foreach($urls as $url) {
	$content = file_get_contents($url);
	$jsons = json_decode($content, true);
	$jsons = $jsons["results"];
	foreach($jsons as $json) { 

		$json_data = $json["value"];
		$kanji = $json_data["kanji"];
		$level = $json_data["level"];
		$stroke_count = $json_data["stroke_count"];
		$query = "select id from kanji where kanji_name='$kanji' and level='$level'";
		$result = $conn->query($query);
		if($result){
			while($row = $result->fetch_assoc()) {
				$id = $row["id"];
				$sql = "UPDATE kanji SET stroke_count='$stroke_count' WHERE id='$id'";
				if ($conn->query($sql) === TRUE) {
				    
				} else {
				    echo "Error updating record: " . $conn->error;
				}
			}
		}
	}
}
$conn->close();
echo "<h1>Successfully</h1>";
?>