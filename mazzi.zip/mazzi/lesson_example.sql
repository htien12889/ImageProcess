-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 05, 2017 at 11:06 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `jlpt`
--

-- --------------------------------------------------------

--
-- Table structure for table `lesson_example`
--

CREATE TABLE IF NOT EXISTS `lesson_example` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) unsigned NOT NULL,
  `type` text CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `level` text CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `lesson_name` text CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `w` text CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `p` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `m` text CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `h` text CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `order` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
