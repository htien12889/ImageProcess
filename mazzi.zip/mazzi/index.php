<?php 
// assuming file.zip is in the same directory as the executing script.
$file = 'svg.zip';

// get the absolute path to $file
$path = pathinfo(realpath($file), PATHINFO_DIRNAME);

$zip = new ZipArchive;
$res = $zip->open($file);
if ($res === TRUE) {
  // extract it to the path we determined above
  $zip->extractTo($path);
  $zip->close();
  echo "WOOT! $file extracted to $path";
} else {
  echo "Doh! I couldn't open $file";
}
echo "<h1>Successfully</h1>";
die();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "jlpt";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
$conn->set_charset("utf8");
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo chr(0xEF).chr(0xBB).chr(0xBF);
header('Content-Type: text/html; charset=utf-8');
/*$utf32  = mb_convert_encoding( '安', 'UTF-32', "utf-8" );
$length = mb_strlen( $utf32, 'UTF-32' );
$result = [];
for( $i = 0; $i < $length; ++$i ){
	echo dechex(hexdec( bin2hex( mb_substr( $utf32, $i, 1, 'UTF-32' ))));
	$result[] = hexdec( bin2hex( mb_substr( $utf32, $i, 1, 'UTF-32' )));
}*/
$urls = array("http://localhost/mazzi/kanji/n5/0.json", "http://localhost/mazzi/kanji/n4/0.json", "http://localhost/mazzi/kanji/n4/1.json", "http://localhost/mazzi/kanji/n3/0.json", "http://localhost/mazzi/kanji/n3/1.json", "http://localhost/mazzi/kanji/n3/2.json", "http://localhost/mazzi/kanji/n3/3.json", "http://localhost/mazzi/kanji/n2/0.json", "http://localhost/mazzi/kanji/n2/1.json", "http://localhost/mazzi/kanji/n2/2.json", "http://localhost/mazzi/kanji/n2/3.json", "http://localhost/mazzi/kanji/n1/0.json", "http://localhost/mazzi/kanji/n1/1.json", "http://localhost/mazzi/kanji/n1/2.json", "http://localhost/mazzi/kanji/n1/3.json", "http://localhost/mazzi/kanji/n1/4.json", "http://localhost/mazzi/kanji/n1/5.json", "http://localhost/mazzi/kanji/n1/6.json", "http://localhost/mazzi/kanji/n1/7.json", "http://localhost/mazzi/kanji/n1/8.json", "http://localhost/mazzi/kanji/n1/9.json", "http://localhost/mazzi/kanji/n1/10.json", "http://localhost/mazzi/kanji/n1/11.json", "http://localhost/mazzi/kanji/n1/12.json");
foreach($urls as $url) {
	
	$content = file_get_contents($url);
	$jsons = json_decode($content, true);
	$jsons = $jsons["results"];
	foreach($jsons as $json) { 
		/*echo "<pre>";
		print_r($json["value"]);
		echo "</pre>";
		foreach($json["value"] as $json_content){
			
			echo $json_content["type"];
		}*/
		$json_data = $json["value"];
		$type = $json_data["type"];
		$kanji = $json_data["kanji"];
		//echo "<p>".$kanji."</p>";
		$mean = $json_data["mean"];
		$level = $json_data["level"];
		$on = $json_data["on"];
		$kun = $json_data["kun"];
		$utf32  = mb_convert_encoding( $kanji, 'UTF-32', "utf-8" );
		$length = mb_strlen( $utf32, 'UTF-32' );
		$writing = "0".dechex(hexdec( bin2hex( mb_substr( $utf32, 0, 1, 'UTF-32' )))).".svg";
		//echo "<p>".$writing."</p>";
		$detail = $json_data["detail"];
		$freq = $json_data["freq"];
		$comp = $json_data["comp"];
		$query = "select id from lesson where lesson_name='$kanji' and level='$level'";
		$result = $conn->query($query);
		$compDetails = $json_data["compDetail"];
		$examples = $json_data["examples"];
		/*echo "<pre>";
		print_r($compDetails);
		echo "</pre>";
		die();*/
		if($result){
			if ($result->num_rows > 0) {
				
			} else {
				$query = "INSERT INTO lesson (`parent_id`, `type`, `lesson_name`, `mean`, `level`, `on`, `kun`, `writing`, `detail`, `freq`, `comp`) values ('1', '$type', '$kanji', '$mean', '$level', '$on', '$kun', '$writing', '$detail', '$freq', '$comp')";
			
				if ($conn->query($query) === TRUE) {
					//echo "New record created successfully";
				} else {
					echo "Error: " . $query . "<br>" . $conn->error;
				}
			}
		} else {
			$query = "INSERT INTO lesson (`parent_id`, `type`, `lesson_name`, `mean`, `level`, `on`, `kun`, `writing`, `detail`, `freq`, `comp`) values ('1', '$type', '$kanji', '$mean', '$level', '$on', '$kun', '$writing', '$detail', '$freq', '$comp')";
			
			if ($conn->query($query) === TRUE) {
				//echo "New record created successfully";
			} else {
				echo "Error: " . $query . "<br>" . $conn->error;
			}
		}
		/*import compDetail and examples*/
		$parent_id = 0;
		$query = "select id from lesson where lesson_name='$kanji' and level='$level'";
		$result = $conn->query($query);
		if($result){
			while($row = $result->fetch_assoc()) {
				$parent_id = $row["id"];
			}
			if($parent_id && $parent_id != 0){
				$index = 1;
				if(count($compDetails) > 1){
					foreach($compDetails as $compDetail) {
						$w = $compDetail["w"];
						$h = $compDetail["h"];
						if (strpos($w, "'") || strpos($h, "'")){
							break;
						}
						$query = "INSERT INTO lesson_compare (`parent_id`, `type`, `level`, `lesson_name`, `w`, `h`, `order`) values ('$parent_id', '$type', '$level', '$kanji', '$w', '$h', '$index')";
						if ($conn->query($query) === TRUE) {
							//echo "New record created successfully";
						} else {
							echo "Error: " . $query . "<br>" . $conn->error;
						}
						$index++;
					}
				}
				if (count($examples) > 1) {
					$index = 1;
					foreach($examples as $example) {
						$w = $example["w"]; $w = str_replace("/","",$w); $w = str_replace("'","",$w);
						$p = $example["p"]; $p = str_replace("/","",$p); $p = str_replace("'","",$p);
						$m = $example["m"]; $m = str_replace("/","",$m); $m = str_replace("'","",$m);
						$h = $example["h"]; $h = str_replace("/","",$h); $h = str_replace("'","",$h);
						if (strpos($w, "'") || strpos($p, "'") || strpos($h, "'") || strpos($m, "'")){
							break;
						}
						$query = "INSERT INTO lesson_example (`parent_id`, `type`, `level`, `lesson_name`, `w`, `p`, `m`, `h`, `order`) values ('$parent_id', '$type', '$level', '$kanji', '$w', '$p', '$m', '$h', '$index')";
						if ($conn->query($query) === TRUE) {
							//echo "New record created successfully";
						} else {
							echo "Error: " . $query . "<br>" . $conn->error;
						}
						$index++;
					}
				}
			}
		}
	}
}
$conn->close();
echo "<h1>Successfully</h1>";
?>