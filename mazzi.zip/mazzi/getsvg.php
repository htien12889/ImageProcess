<?php 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "jlpt";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
$conn->set_charset("utf8");
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo chr(0xEF).chr(0xBB).chr(0xBF);
header('Content-Type: text/html; charset=utf-8');
$query = "select * from kanji";
$result = $conn->query($query);
if($result){
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$filename = "http://data.mazii.net/kanji/".$row["writing"];
			$content = file_get_contents($filename);
			file_put_contents('svg/'.$row["writing"], $content);
		}
	} else {
		
	}
} else {
	
}
?>
